<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('busca') ?>
</div>
<div class="conteudo-left">
	<div class="resultado-busca">
    <h1><?= $titulo?></h1>
    <?= $qt?>  <?= $this->lang->line('resultados_encontrados') ?>
    
    
    <div class="resultados">
    	<? foreach($busca as $resultado){ ?>
			
            <? if($resultado['tipo']==1 or $resultado['tipo']==0){
				$link = site_url()."noticia/".$resultado['id'].'/'.str_replace('%','',urlencode($this->formata_nome_model->formataNome($resultado['titulo'])));
            }
            if($resultado['tipo']==2){
				$link = site_url()."pagina/".$resultado['id'].'/'.str_replace('%','',urlencode($this->formata_nome_model->formataNome($resultado['titulo'])));
            }
			if($resultado['tipo']==3){
				$link = site_url()."paginaaba/".$resultado['id'].'/'.str_replace('%','',urlencode($this->formata_nome_model->formataNome($resultado['titulo'])));
            }
            ?>
            <a href="<?=$link?>">
            <h3><?= utf8_decode($resultado['titulo'])?></h3>
            <p>
            	<? $breve_desc = strip_tags($resultado['texto'])?>
            	<?= utf8_decode(substr($breve_desc, 0, strrpos(substr($breve_desc, 0, 200), ' ')))?>...<br />
            </p>
            </a>
		<? } ?>
 	</div>
    <div class="paginacao">
		<?php echo $paginacao; ?>
    </div>  
	</div> 
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>