<? if($this->session->userdata("pagina") == "dentista"){ ?>
        		
                
					<ul class="menu">
        			   	<li><a class="categoria"><img src="<?=site_url()?>images/icons/user.png" border="0"><?= $this->lang->line('a_uniodonto_e_voce') ?></a>
                            <ul>
                              	<li><a href="http://virgo.uniodontocuritiba.com.br:81/" target="_blank"><?= $this->lang->line('agenda') ?></a></li>
                                <li><a href="http://webmail.uniodontocuritiba.com.br/" target="_blank"><?= $this->lang->line('email') ?></a></li>
                                <li><a href="<?=site_url("dentista/dados-cadastrais")?>"><?= $this->lang->line('dados_cadastrais') ?></a></li>
                                <li><a href="<?=site_url("dentista/informe-de-rendimentos")?>"><?= $this->lang->line('informe_de_rendimentos') ?></a></li>
                                <li><a href="<?=site_url("dentista/boleto")?>"><?= $this->lang->line('boleto_bancario') ?></a></li>
                                <li><a href="<?=site_url("revisaovalores")?>"><?= $this->lang->line('revisao_de_valores') ?></a></li>
                                <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == "1"){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                        <li><a class="categoria" href="<?=site_url("dentista/liberacao-online")?>"><img src="<?=site_url()?>images/icons/sistema.png" border="0"><?= $this->lang->line('liberacao_online') ?></a>
                            <ul>
                              
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/formulario.png" border="0"><?= $this->lang->line('formularios') ?></a>
                            <ul>
                              	<li><a href="<?=site_url("dentista/impostoderenda")?>"><?= $this->lang->line('cedula_c') ?></a></li>
							    <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == 2){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                        <li><a class="categoria" ><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabelas') ?></a>
                            <ul>
                              <li><a href="<?=site_url("tabeladeatos2013/1")?>"><?= $this->lang->line('tabela_de_atos') ?></a></li>
							    <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == 3){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                        <li><a class="categoria" href="<?=site_url()?>calendario"><img src="<?=site_url()?>images/icons/calendario.png" border="0"><?= $this->lang->line('calendario') ?></a>
                            <ul>
                              
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/fique-por-dentro.png" border="0"><?= $this->lang->line('fique_por_dentro') ?></a>
                            <ul>
                              	<li><a href="<?=site_url()?>revista"><?= $this->lang->line('unionews') ?></a></li>
                                <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == 4){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/duvida.png" border="0"><?= $this->lang->line('manuais') ?></a>
                            <ul>
                                <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == 5){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                  </ul>            


<? } ?>

<? if($this->session->userdata("pagina") == "beneficiario"){ ?>
				<ul class="menu">
        			   	<li><a class="categoria"><img src="<?=site_url()?>images/icons/user.png" border="0"><?= $this->lang->line('voce_beneficiario') ?></a>
                            <ul>
                              	<li><a href="<?=site_url("beneficiario/alterar-dados")?>"><?= $this->lang->line('alterar_dados_cadastrais') ?></a></li>
                                <li><a href=<?=site_url("beneficiario/impostoderenda")?>><?= $this->lang->line('cedula_c') ?></a></li>
                                <li><a href="<?=site_url("beneficiario/boleto")?>"><?= $this->lang->line('boleto_bancario') ?></a></li>
                                <? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "1"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/duvida.png" border="0"><?= $this->lang->line('como_utilizar_seu_plano') ?></a>
                            <ul>
                              	<? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == 2){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                            </ul>
                        </li>
                        <li><a href="<?=site_url("beneficiario/boleto")?>" class="categoria"><img src="<?=site_url()?>images/icons/pagamento.png" border="0"><?= $this->lang->line('pagamento_online') ?></a>
                        </li>
           		</ul>
<? } ?>

<? if($this->session->userdata("pagina") == "empresa"){ ?>
				<ul class="menu">
        			   	<li><a class="categoria"><img src="<?=site_url()?>images/icons/sistema.png" border="0"><?= $this->lang->line('sistema_de_gestao') ?></a>
                            <ul>
                              	<li><a href="<?=site_url("empresa/movimentacao-cadastral")?>"><?= $this->lang->line('movimentacao_cadastral') ?></a></li>
                                <li><a href="<?=site_url("empresa/liberacao-online")?>"><?= $this->lang->line('liberacao_online') ?></a></li>
                                <li><a href="<?=site_url("empresa/consulta-notafiscal")?>"><?= $this->lang->line('consulta_nota_fiscal') ?></a></li>
                                <li><a href="<?=site_url("empresa/relatorio-beneficiarios")?>"><?= $this->lang->line('relatorio_beneficiarios') ?></a></li>
                                <li><a href="<?=site_url("empresa/alterar-dados")?>"><?= $this->lang->line('alterar_dados_cadastrais') ?></a></li>
                                <li><a href="<?=site_url("empresa/alterar-senha")?>"><?= $this->lang->line('alterar_senha') ?></a></li>
                                <li><a href="<?=site_url("empresa/boleto")?>"><?= $this->lang->line('boleto_bancario') ?></a></li>
                                <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == "1"){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/formulario.png" border="0"><?= $this->lang->line('formularios') ?></a>
                            <ul>
                              	<? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == 2){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                          </ul>
                  		</li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/relatorio.png" border="0"><?= $this->lang->line('relatorios') ?></a>
                            <ul>
                              	<li><a href="<?=site_url("relatorios/empresa/atendimentomes")?>"><?= $this->lang->line('atendimentos_mes') ?></a></li>
                                <li><a href="<?=site_url("relatorios/empresa/guias")?>"><?= $this->lang->line('status_das_guias') ?></a></li>
                                <li><a href="<?=site_url("relatorios/empresa/atendimentoespecialidade")?>"><?= $this->lang->line('atendimentos_por_especialidade') ?></a></li>
                                <li><a href="<?=site_url("relatorios/empresa/faturamento")?>"><?= $this->lang->line('faturamento') ?></a></li>
                                <? if(is_array($menus_logado)){
                                    if(count($menus_logado) != 0);
                                        foreach($menus_logado as $menu_logado){
                                            if($menu_logado['menu'] == 3){
                                                print "<li>".$menu_logado['link']."</li>";
                                                }
                                            }
                                        
                                    }?>
                          </ul>
                  		</li>
           		</ul>
<? } ?>

<? if($this->session->userdata("pagina") == "uniodonto"){ ?>
				<ul class="menu">
        			   	<li><a class="categoria"><img src="<?=site_url()?>images/icons/user.png" border="0"><?= $this->lang->line('a_uniodonto_e_voce') ?></a>
                            <ul>
                              	<? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "1"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                            </ul>
                        </li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/sistema.png" border="0"><?= $this->lang->line('sistema_de_gestao') ?></a>
                            <ul>
                              	<li><a href="<?=site_url("uniodonto/boleto")?>"><?= $this->lang->line('boletos') ?></a></li>
                                <li><a href="<?=site_url("uniodonto/liberacao-online")?>"><?= $this->lang->line('liberacao_online') ?></a></li>
                                <li><a href="<?=site_url("uniodonto/dados-cadastrais")?>"><?= $this->lang->line('dados_cadastrais') ?></a></li>
                                <? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "2"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                          </ul>
                  		</li>
                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/relatorio.png" border="0"><?= $this->lang->line('relatorios') ?></a>
                            <ul>
                              	<li><a href="<?= site_url('relatorios/uniodonto/faturamento')?>"><?= $this->lang->line('faturamento') ?></a></li>
                                <li><a href="<?= site_url('relatorios/uniodonto/faturamentointercambio')?>"><?= $this->lang->line('faturamento_intercambio') ?></a></li>
                                <li><a href="<?= site_url('relatorios/uniodonto/qtbeneficiarios')?>"><?= $this->lang->line('quantidade_beneficiarios_x_beneficiarios_atendidos') ?></a></li>
                                <? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "3"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                                
                          </ul>
                  		</li>
           		</ul>
<? } ?>

<? if($this->session->userdata("pagina") == "representante"){ ?>
				<ul class="menu">
        			   	<li><a class="categoria"><img src="<?=site_url()?>images/icons/analise.png" border="0"><?= $this->lang->line('analise_critica') ?></a>
                            <ul>
                              	<? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "1"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                            </ul>
                        </li>

                        <li><a class="categoria"><img src="<?=site_url()?>images/icons/arquivos.png" border="0"><?= $this->lang->line('marketing') ?></a>
                            <ul>
                              	<? if(is_array($menus_logado)){
									if(count($menus_logado) != 0);
										foreach($menus_logado as $menu_logado){
											if($menu_logado['menu'] == "3"){
												print "<li>".$menu_logado['link']."</li>";
												}
											}
										
									}?>
                            </ul>
                        </li>
                        <? if($this->session->userdata("codigo") == "37"){ ?>
                        <li><a href="<?= site_url('prospect')?>" class="categoria"><img src="<?=site_url()?>images/icons/proposta.png" border="0"><?= $this->lang->line('prospect') ?></a>
                        </li>
                        <? } ?>
           		</ul>
<? } ?>