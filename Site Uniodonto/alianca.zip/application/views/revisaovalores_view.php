<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Revisão de valores
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1>Revisão de valores</h1>

	<? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
	<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
	jQuery(function($){
		$(".data").mask("99/99/9999");
		$(".tel").mask("(99) 9999-9999");
		
		});
	
	function enviarContato(){
	$("#status").html("<img src='<?=site_url()?>images/loading.gif' alt='Enviando' /> Aguarde...");
	var dados = jQuery("#form").serialize();

			jQuery.ajax({
				type: "POST",
				url: "<?=site_url("revisaovalores")?>",
				data: dados,
				success: function( data )
				{
					$("#status").html(data);
					
				}
		});
	}		
    </script>
<div class="contato">
    	<form method="post" id="form" name="form"/>
        	<label>CRO</label>
            <input type="text" name="cro" id="cro">
            <label>N° Guia</label>
            <input type="text" name="guia" id="guia">
            <label>Quantidade U.S.O</label>
            <input type="text" name="quantidade" id="quantidade">

            <label>Descrição do Problema</label>
            <textarea name="msg"></textarea>
            <div class="bts-form">
	            <span>
	            	<input type="button" value="Enviar"  name="Enviar" class="btn-submit" onclick="enviarContato()" >
	            </span>
	            <span id="status">

	            </span>
            </div>
        </form>
        
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>