<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rio Atendimentos M&ecirc;s
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>

<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rio Atendimentos M&ecirc;s</h1>
		          
<script>

	function loadCharts() {
		xmlHttpLine = GetXmlHttpObject();

		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'line','empresa','<?=site_url("site/serverRequest")?>', xmlHttpLine, 	document.getElementById('mesFiltroAtendimento').value );
	}

	function loadChartsAtendimento(){
		xmlHttpLine=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'line','empresa','<?=site_url("site/serverRequest")?>', xmlHttpLine, 	document.getElementById('mesFiltroAtendimento').value );
	}


</script>
</head>
<body onLoad="loadCharts()">
	
	<div class="desc-relatorio">
		Este relat&oacute;rio consiste em apresentar a quantidade de atendimentos feitos no per&iacute;odo selecionado.<br/>
		Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>	

	<label>&Uacute;ltimos
		<select id="mesFiltroAtendimento" name="mesFiltroAtendimento" class="style2" onChange="loadChartsAtendimento();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
		meses</label>

			<div id="chartLine" align="center"></div>
		</fieldset>

	

            <script type="text/javascript">

                   function semDados(chartName, msg){
                   		document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>"+msg+"</b><br>( Nenhum dado foi encontrado. )</p>"
                   }

                   function buildChart( id, xml ) {

                   		if( id=="line" ) {
				   			var chart = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Line.swf", "chartLineId", "710", "520");
				   			chart.addParam("wMode","transparent");
				   			chart.setDataXML( xml );
				   			chart.render("chartLine");

				   			jQuery("#chartLine").fancybox({
				  				'autoDimensions':	false,
				  				'autoScale'		: 	false,
				  				'scrolling'		: 'auto',
				  				'href'			: "<?=site_url()?>empresa/chart/details/chartDetails.html",
				  				'width'			:750,
				  				'height'		:600,
				  				'onComplete'	:	function() {
									  					jQuery("#chartLineId").hide();

									  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Line.swf", "ChartId", "684", "398");
														chartZoom.setDataXML(xml);
														chartZoom.render("content");
									  				},
				  				'onCleanup' : function(){
				  					jQuery("#chartLineId").show();
				  				}
				  			});
				   		}
					}
				</script>


         
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>