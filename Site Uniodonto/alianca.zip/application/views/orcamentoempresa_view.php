<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('planos_empresariais') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1><?= $this->lang->line('planos_empresariais') ?></h1>

	<? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
	<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
	jQuery(function($){
		$(".data").mask("99/99/9999");
		$(".tel").mask("(99) 9999-9999");
		
		});
	
	$(document).ready(function(){
	$("#ncartao").val("");
	$("#numeroCartaoLabel").hide();
	$("#cliente").click(function(){
		if ($(this).is(":checked")){
			$("#numeroCartao").show();
			$("#ncartao").val("");
			} else {
				$("#numeroCartao").hide();
				$("#ncartao").val("");
				}
		});
	$("#naocliente").click(function(){
		if ($(this).is(":checked")){
			$("#ncartao").val("N&atilde;o h&aacute;.");
			$("#numeroCartao").hide();
			}
		});
	}); 
	
	function enviarContato(){
	
	$("#status").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> <?= $this->lang->line('enviando_por_favor_aguarde') ?>");
	var dados = jQuery("#form").serialize();

			jQuery.ajax({
				type: "POST",
				url: "<?=site_url("orcamento_empresa")?>",
				data: dados,
				success: function( data )
				{
					var obj = eval ("(" + data + ")"); 
					$("#status").html(obj.msg);
					$("#captcha").attr("src",obj.captcha);
					
				}
		});
	}		
    </script>
<div class="contato">
    	<form method="post" id="form" name="form"/>
        	<label><?= $this->lang->line('empresa') ?></label>
            <input type="text" title="Informe o nome da empresa" name="empresa" id="nome">
            <label><?= $this->lang->line('responsavel') ?></label>
            <input type="text" title="Informe o responsavel" name="responsavel" id="nome">
            <label><?= $this->lang->line('email') ?></label>
            <input type="text" title="Informe seu email" name="email" id="email">
            <label><?= $this->lang->line('telefone') ?></label>
            <input type="text" title="Informe seu telefone" name="telefone" id="telefone" class="tel">
            <label><?= $this->lang->line('endereco') ?></label>
            <textarea name="endereco"></textarea>
            <label><?= $this->lang->line('cidade_estado') ?></label>
            <input type="text" title="Informe seu estado/cidade" name="cidade" id="cidade" >
            <label><?= $this->lang->line('qtd_funcionarios') ?></label>
            <input type="text" title="Qtd. Funcionários" name="qtd_funcionarios" id="qtd_funcionarios" >
            <div class="bts-form">
            <label><?= $this->lang->line('qtd_funcionarios') ?></label>
            <img id="captcha" src="<?= $captcha['src']?>" border="0" style="margin:5px 3px 0px 3px;" />
            <input type="text" name="captcha" style="width:170px;">
            </div>
            <div class="bts-form">
	            <span>
	            	<input type="button" value="<?= $this->lang->line('enviar') ?>"  name="Enviar" class="btn-submit" onclick="enviarContato()" >
	            </span>
	            <span id="status">

	            </span>
            </div>
        </form>
        
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>