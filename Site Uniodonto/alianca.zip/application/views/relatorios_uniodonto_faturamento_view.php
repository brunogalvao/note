<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rio status das guias
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>

<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rio faturamento</h1>
		          
<script>
	function loadCharts(){
		$('#graficoFaturamentoUniodonto').html("Carregando...");
		$("#mesFiltroFaturamentoUniodonto").attr('disabled', 'disabled');
		xmlHttpBar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'barFaturamentoUnio','uniodonto','<?=site_url("site/serverRequest")?>', xmlHttpBar, 	document.getElementById('mesFiltroFaturamentoUniodonto').value );

	}

	function loadChartsFaturamentoUniodonto(){
		$('#graficoFaturamentoUniodonto').html("Carregando...");
		$("#mesFiltroFaturamentoUniodonto").attr('disabled', 'disabled');

		xmlHttpBar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'barFaturamentoUnio','uniodonto','<?=site_url("site/serverRequest")?>', xmlHttpBar, 	document.getElementById('mesFiltroFaturamentoUniodonto').value );
	}



</script>
</head>
<body onload="loadCharts()">
	<div class="desc-relatorio">
	Este relat&oacute;rio consiste em apresentar o faturamento total com os benefici&aacute;rios atendidos em determinado per&iacute;odo. Esse total ser&aacute; adquirido atrav&eacute;s da soma das guias conclu&iacute;das no per&iacute;odo, utilizando o mesmo per&iacute;odo de produ&ccedil;&atilde;o do cooperado.

<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento
    </div>
	<label>&Uacute;ltimos
		<select id="mesFiltroFaturamentoUniodonto" name="mesFiltroFaturamentoUniodonto" class="style2" onchange="loadChartsFaturamentoUniodonto();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>

			<div id="graficoFaturamentoUniodonto" align="center" class="chartClass"></div>


            <script type="text/javascript">
                   function semDados(chartName, msg){
                   		document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>"+msg+"</b><br>( Nenhum dado foi encontrado. )</p>"
                   }

                   function buildChart( id, xml ) {
                	   if( id=="bar" ) {
							$('#graficoFaturamentoUniodonto').html("Carregando...");

							var chart = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId", "710", "510");
							chart.addParam("wMode","transparent");
							chart.setDataXML(xml);
		  					chart.render("graficoFaturamentoUniodonto");

		  					$("#mesFiltroFaturamentoUniodonto").attr('disabled', '');

	              			jQuery("#graficoFaturamentoUniodonto").fancybox({
	            				'autoDimensions':	false,
	            				'autoScale'		: 	false,
	            				'scrolling'		: 'auto',
	            				'href'			: "<?=site_url()?>js/aba_uniodonto/chart/details/chartDetails.html",
	            				'width'			:710,
	            				'height'		:600,
	            				'onComplete'	:	function() {
	            				  					jQuery("#ChartId").hide();

	            				  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId2", "700", "400");
	        					  					chartZoom.setDataXML(xml);
	        					  					chartZoom.render("content");
	            				  				},
	            				'onCleanup' : function(){
	            					jQuery("#ChartId").show();
	            				}
	            			});







				   		}
				}
				</script>
		
</div>

         
    
 
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>