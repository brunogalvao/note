
<a href="<?= site_url("site/dadosemailproposta/".$email) ?>">
<table width="808" height="1633" border="0" cellpadding="0" cellspacing="0" align="center">
	<tr>
		<td colspan="2">
			<img src="<?= site_url()?>images/emailproposta/email_01.png" width="808" height="455" alt=""  border="0"></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="<?= site_url()?>images/emailproposta/email_02.png" width="808" height="177" alt=""  border="0"></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="<?= site_url()?>images/emailproposta/email_03.png" width="808" height="311" alt=""  border="0"></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="<?= site_url()?>images/emailproposta/email_04.png" width="808" height="351" alt=""  border="0"></td>
	</tr>
	<tr>
		<td>
			<img src="<?= site_url()?>images/emailproposta/email_05.png" width="404" height="102" alt=""  border="0"></td>
		<td>
			<img src="<?= site_url()?>images/emailproposta/email_06.jpg" width="404" height="102" alt=""  border="0"></td>
	</tr>
	<tr>
		<td colspan="2">
			<img src="<?= site_url()?>images/emailproposta/email_07.png" width="808" height="237" alt=""  border="0"></td>
	</tr>
</table>
</a>
