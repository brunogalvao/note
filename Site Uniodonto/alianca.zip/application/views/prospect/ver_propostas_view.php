<? print $this->load->view("header_view",$this->data); ?>

<div class="nav">
<a href="<?=site_url()?>">Home</a>  / <a href="<?=site_url("gerarproposta")?>"><?= $this->lang->line('prospect') ?></a> / <?= $this->lang->line('ver_propostas') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
    <img src="<?=site_url()?>images/logo-prospect.png" title="Prospect"> 
        <div class="menu-proposta">
        	<a href="<?=site_url("emailproposta")?>" ><img src="<?=site_url()?>images/icons/email.png" border="0"><?= $this->lang->line('enviar_email') ?></a>
            <a href="<?=site_url("novaproposta")?>" ><img src="<?=site_url()?>images/icons/novo.png" border="0"><?= $this->lang->line('nova_proposta') ?></a>
            <a href="<?=site_url("verpropostas/1")?>" ><img src="<?=site_url()?>images/icons/propostas.png" border="0"><?= $this->lang->line('ver_propostas') ?></a>
            <a href="<?=site_url("upload/files/representante/tabela.pdf")?>" ><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabela') ?></a>
            <a href="<?=site_url("contratospropostas")?>" ><img src="<?=site_url()?>images/icons/contrato.png" border="0"><?= $this->lang->line('contrato') ?></a>
            <a href="<?=site_url("materialgraficopropostas")?>" ><img src="<?=site_url()?>images/icons/arquivos.png" border="0"><?= $this->lang->line('material_grafico') ?></a>
        </div>
        
        <div class="pesquisa-proposta">
                <form method="post" id="form" name="form" action="<?=site_url("verpropostas/1")?>" />
                <div>
                    <label><?= $this->lang->line('numero') ?></label>
                    <input type="text" name="proposta_n" id="proposta_n" >
                </div>
                <div>
                    <label><?= $this->lang->line('data_de_inclusao') ?></label>
                    <input type="text" name="datade" style="width:127px;" class="data"> >
                </div>
                <div>
                    <input type="text" name="dataate" class="data">
                </div>
                <div>
                    <label><?= $this->lang->line('cnpj') ?></label>
                    <input type="text" name="cnpj" id="cnpj" class="cnpj">
                </div>
                <div>
                    <label><?= $this->lang->line('nome_da_empresa') ?></label>
                    <input type="text" name="empresa" id="empresa" >
                </div>
                <div>
                    <label><?= $this->lang->line('email') ?></label>
                    <input type="text" name="email" id="email" >
                </div>
                
                <div>
                        <label><?= $this->lang->line('cidade') ?></label>
                        <input type="text" name="cidade" id="cidade" >
                </div>
                <div>
                        <label><?= $this->lang->line('estado') ?></label>
                        <select name="uf">
                            <option value="AC">AC</option>
                            <option value="AL">AL</option>
                            <option value="AM">AM</option>
                            <option value="AP">AP</option>
                            <option value="BA">BA</option>
                            <option value="CE">CE</option>
                            <option value="DF">DF</option>
                            <option value="ES">ES</option>
                            <option value="GO">GO</option>
                            <option value="MA">MA</option>
                            <option value="MG">MG</option>
                            <option value="MS">MS</option>
                            <option value="MT">MT</option>
                            <option value="PA">PA</option>
                            <option value="PB">PB</option>
                            <option value="PE">PE</option>
                            <option value="PI">PI</option>
                            <option value="PR" selected>PR</option>
                            <option value="RJ">RJ</option>
                            <option value="RN">RN</option>
                            <option value="RO">RO</option>
                            <option value="RR">RR</option>
                            <option value="RS">RS</option>
                            <option value="SC">SC</option>
                            <option value="27">SE</option>
                            <option value="SE">SP</option>
                            <option value="TO">TO</option>
                        </select> 
                
                </div>
                <div class="botoes">
                    <span>
                    <input type="submit" value="<?= $this->lang->line('buscar') ?>"  name="<?= $this->lang->line('buscar') ?>" class="btn-submit">
                    </span>
                    <span>
                    <a href="<?=site_url("site/limpar_pesquisa")?>" >Limpar pesquisa</a>
                    </span>
                </div>
                
            </form>
                
             
        </div>
     
        <div class="propostas">
        <?= $qt?>  <?= $this->lang->line('resultados_encontrados') ?><br /><br />
		<? foreach($propostas as $proposta){  
			$data_inclusao = explode("-", $proposta->proposta_data);
			$validade = explode("-", $proposta->proposta_validade);
		?>
        	
        	<div class="proposta" id="<?= $proposta->proposta_id ?>">
            	<div>
                    <span><h2><?= $proposta->proposta_n ?></h2></span>
                    <span><h2><?= $proposta->proposta_empresa ?></h2></span>
                    
                </div>
                <div>    
                    <span><?= $this->lang->line('cnpj') ?> <?= $proposta->proposta_cnpj ?></span>
                </div>
                <div>    
                    <span><?= $this->lang->line('data_de_inclusao') ?> <?= $data_inclusao[2] ?>/<?= $data_inclusao[1] ?>/<?= $data_inclusao[0] ?></span>
                    <span><?= $this->lang->line('validade') ?> <?= $validade[2] ?>/<?= $validade[1] ?>/<?= $validade[0] ?></span>
                </div>
                <div>     
                    <span><?= $this->lang->line('contato') ?> <?= $proposta->proposta_contato ?></span>
                    <span><?= $proposta->proposta_tel ?></span>
                    <span><?= $proposta->proposta_email ?></span>
                </div>
                <div>
                	<a href="javascript:enviarEmail('<?= $proposta->proposta_id ?>')" title="Enviar email" ><img src="<?=site_url()?>images/icons/enviar-email.png" border="0"></a>
            		<a href="<?=site_url("site/baixarproposta/".$proposta->proposta_id)?>" target="_blank" title="Baixar proposta"><img src="<?=site_url()?>images/icons/download.png" border="0"></a>
                </div>
                <div class="msg">
                	
                </div>
            </div>
        
        <? } ?>
 		</div>
        <div class="paginacao">
        	<?php echo $paginacao; ?>
        </div>
</div>
<script>

function enviarEmail(id){
	$("#"+id+" .msg").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Enviando por favor aguarde...");
		jQuery.ajax({
				type: "GET",
				url: "<?=site_url("site/enviarproposta")?>/"+id,
				success: function( data )
				{
					$("#"+id+" .msg").html(data);
				
				}
		});
	}
</script>
<div class="conteudo-right" style="padding-top:10px;">
	<? print $this->load->view("lateral_view",$this->data); ?>
</div>
<? print $this->load->view("footer_view",$this->data); ?>