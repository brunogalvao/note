<? print $this->load->view("header_view",$this->data); ?>

<div class="nav">
<a href="<?=site_url()?>">Home</a> / <a href="<?=site_url("gerarproposta")?>"><?= $this->lang->line('prospect') ?></a> / <?= $this->lang->line('material_grafico') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
    <img src="<?=site_url()?>images/logo-prospect.png" title="Prospect"> 
        <div class="menu-proposta">
        	<a href="<?=site_url("emailproposta")?>" ><img src="<?=site_url()?>images/icons/email.png" border="0"><?= $this->lang->line('enviar_email') ?></a>
            <a href="<?=site_url("novaproposta")?>" ><img src="<?=site_url()?>images/icons/novo.png" border="0"><?= $this->lang->line('nova_proposta') ?></a>
            <a href="<?=site_url("verpropostas/1")?>" ><img src="<?=site_url()?>images/icons/propostas.png" border="0"><?= $this->lang->line('ver_propostas') ?></a>
            <a href="<?=site_url("upload/files/representante/tabela.pdf")?>" ><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabela') ?></a>
            <a href="<?=site_url("contratospropostas")?>" ><img src="<?=site_url()?>images/icons/contrato.png" border="0"><?= $this->lang->line('contrato') ?></a>
            <a href="<?=site_url("materialgraficopropostas")?>" ><img src="<?=site_url()?>images/icons/arquivos.png" border="0"><?= $this->lang->line('material_grafico') ?></a>
        </div>
        <div class="proposta-texto">
        	<h1>Comunica&ccedil;&atilde;o implanta&ccedil;&atilde;o</h1>
            <p>A Comunica&ccedil;&atilde;o de implanta&ccedil;&atilde;o do Plano seguir&aacute;  algumas etapas, a fim de despertar a aten&ccedil;&atilde;o dos seus funcion&aacute;rios, e ser  reconhecido com um grande benef&iacute;cio ofertado pela sua empresa.</p>
            <img src="<?=site_url()?>images/prospect/1.jpg"> 
            <img src="<?=site_url()?>images/prospect/2.jpg"> 
            <img src="<?=site_url()?>images/prospect/3.jpg" style="float:left;"> 
            <p><em>A&ccedil;&atilde;o Teaser, ser&atilde;o disparados 3 e-mails e comunicados      internos a fim de despertar a aten&ccedil;&atilde;o do funcion&aacute;rio e associado.</em></p>
        
        </div>
        <div class="proposta-texto">
        	<img src="<?=site_url()?>images/prospect/4.jpg" style="float:left;"> 
            <p><em>Material desenvolvido para intranet,  direcionando para site Uniodonto, ou &aacute;rea designada pela EMPRESA.</em>
</p>
            <p><em>Cartaz, material desenvolvido para mural, facilitando a  visualiza&ccedil;&atilde;o dos funcion&aacute;rios.</em>
</p>

            <p><em>E-mail Marketing, para disparo ao mailing dos funcion&aacute;rios e  associados EMPRESA, indicando alguns benef&iacute;cios, o plano e custo mensal por  pessoa.</em>
</p>

            <p><em>Banner disposto em &aacute;reas estrat&eacute;gicas, para visualiza&ccedil;&atilde;o dos  funcion&aacute;rios, sempre enfatizando o benef&iacute;cio oferecido pela EMPRESA a seus  funcion&aacute;rios e associados.</em>
</p>
        </div>
        <div class="proposta-texto">
        <img src="<?=site_url()?>images/prospect/5.jpg" style="float:left;"> 
            <p><em  style="width:140px;">Folder informativo, material completo com benef&iacute;cios, cobertura, facilidades, planos, valores,       dependentes, centrais de atendimento e a perman&ecirc;ncia no plano.</em></p>
            
       
        </div>
        <div class="proposta-texto">
        	<img src="<?=site_url()?>images/prospect/7.jpg" style="float:left;">
            <p><em>Hot site, dispon&iacute;vel para empresa com ficha de inscri&ccedil;&atilde;o,  diferenciais, cobertura, como utilizar o plano, perguntas frequentes e muitas  outras informa&ccedil;&otilde;es para o benefici&aacute;rio.</em></p>
             
       
        </div>
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? print $this->load->view("lateral_view",$this->data); ?>
</div>
<? print $this->load->view("footer_view",$this->data); ?>