<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
  		<div class="plano" style="background: url(<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/bg-plano.png) no-repeat;">

            <a onclick="mostraFicha()"></a>
      </div>
        <div class="titulo">

        </div>
        
  		<div class="icones"><span class="logo-cliente"> <img src="<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/logo-cliente.png" alt="" border="0"></span> <span> <a href="<?= site_url().$pasta?>/perguntas/#parcelamento">
        <h2>Parcelamento</h2>
        <p>Parcele os atos n&atilde;o cobertos em at&eacute; <b>12x</b> sem juros.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/odontomovel">
        <h2>Odontom&oacute;vel</h2>
        <p>Sa&uacute;de, Preven&ccedil;&atilde;o e Educa&ccedil;&atilde;o circulando por todo lugar.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/encontreseudentista">
        <h2>Encontre seu dentista</h2>
        <p>Clique aqui para encontrar o dentista mais pr&oacute;ximo.</p>
        </a></span> </div>

  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top"></div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Ficha de inscri&ccedil;&atilde;o</h1>
          <h2>Dados do Benefici&aacute;rio</h2>
          <form enctype="multipart/form-data" method="post" id="form" name="form">
          <div class="form">
          
            <span style="display: inline-block;">
              <label>Nome completo do titular</label><br>
                <input  id="nome" class="validate[required]" name="nome" type="text" style="width:612px;">
              
            </span> 
            <span style="display: inline-block;">
              <label>Sexo</label><br>
                <select id="sexo" name="sexo" class="validate[required]">
                     <option value="M">Masculino</option>
                     <option value="F">Feminino)</option>
                </select> 
            </span>
            <span style="display: inline-block;">
              <label>Estado Civil</label><br>
                <select id="estadoCivil" name="estadoCivil" class="validate[required]">
                     <option value="Solteiro(a)">Solteiro(a)</option>
                     <option value="Casado(a)">Casado(a)</option>
                     <option value="Separado(a)">Separado(a)</option>
                     <option value="Divorciado(a)">Divorciado(a)</option>
                     <option value="Vi&uacute;vo(a)">Vi&uacute;vo(a)</option>
                </select> 
            </span>
            <span style="display: inline-block;">
                <label>CPF</label><br>
                <input  id="cpf" class="validate[required] cpf" name="cpf" type="text">
            </span>
            <span style="display: inline-block;">
                <label>Data de Nascimento</label><br>
                <input  id="dataNascimento" class="validate[required] data" name="dataNascimento" type="text">
            </span> 
            <span style="display: inline-block;">
                <label>N&deg; Decl. de Nascido Vivo</label><br>
                <input  id="nascidovivo" name="nascidovivo" type="text" class="validate[required]" >
            </span>
            <span style="display: inline-block;">
                <label>Cart&atilde;o Nacional de Sa&uacute;de</label><br>
                <input  id="cartaonacionalsaude" name="cartaonacionalsaude" type="text" class="validate[required]" >
            </span>
            
            <span style="display: inline-block;">
                <label>RG</label><br>
                <input  id="rg" class="validate[required]" name="rg" type="text">
            </span> 
           
            <span style="display: inline-block;">
                 <label>Org&atilde;o emissor</label><br>
                 <input  id="orgaoemissor" class="validate[required]" name="orgaoemissor" type="text">
            </span> 
            <span style="display: inline-block;">
                 <label>Data emiss&atilde;o </label><br>
                 <input  id="dataemissao" class="validate[required]  data" name="dataemissao" type="text">
            </span> 
           	<span style="display: block; padding-bottom: 10px;">
                 <label>Tipo de benefici&aacute;rio</label><br>
                 <input style="border: medium none;" name="tipobeneficiario" id="tipobeneficiario" value="1" checked="checked" type="radio">Ativo
                 <input style="border: medium none;" name="tipobeneficiario" id="tipobeneficiario" value="2" type="radio">Inativo 
                 <input style="border: medium none;" name="tipobeneficiario" id="tipobeneficiario" value="3" type="radio">Pensionista 
                  
            </span> 
           	
            <span style="display: inline-block;">
                <label>Matr. Servidor/SIAPE</label><br>
                <input  id="matriculaservidor" name="matriculaservidor" type="text" class="validate[required]">
            </span> 
            <span style="display: inline-block;">
                <label>Matr. Pensionista</label><br>
                <input  id="matriculapensionista" name="matriculapensionista" type="text" >
            </span>
            <span style="display: inline-block;">
                <label>Ocupa&ccedil;&atilde;o Principal</label><br>
                <input  id="ocupacao" name="ocupacao" type="text" class="validate[required]">
            </span> 
            <span style="display: block;">
                <label>Nome completo da m&atilde;e</label><br>
                <input  id="nomemae" name="nomemae" type="text" style="width:455px;" class="validate[required]">
            </span>  
            <span style="display: block;">
                <label>Email</label><br>
                <input  id="email" name="email" type="text" class="validate[required]" style="width:455px;">
            </span>
            <span style="display: inline-block;">
                <label> Endere&ccedil;o</label><br>
                <input  id="endereco" class="validate[required]" name="endereco" type="text" style="width:455px;">
            </span> 
            <span style="display: inline-block;">
                <label> N&ordm;</label><br>
                <input  id="numero" class="validate[required]" name="numero" type="text">
            </span> 
            <span style="display: inline-block;">
                <label> Complemento</label><br>
                <input  id="complemento" name="complemento" type="text">
            </span> 
            <span style="display: inline-block;">
                <label> Bairro</label><br>
                <input  id="bairro" class="validate[required]" name="bairro" type="text">
            </span> 
            <span style="display: inline-block;">
                <label> Cidade</label><br>
                <input  id="cidade" class="validate[required]" name="cidade" type="text">
            </span> 
            <span style="display: inline-block;">
                <label> CEP</label><br>
                <input  id="cep" class="validate[required] cep" name="cep" type="text">
            </span> 
            <span style="display: inline-block;">
                <label> Estado</label><br>
                <select id="uf" name="uf" class="validate[required]">
                                              <option value="AC">AC</option>
                                              <option value="AL">AL</option>
                                              <option value="AM">AM</option>
                                              <option value="AP">AP</option>
                                              <option value="BA">BA</option>
                                              <option value="CE">CE</option>
                                              <option value="DF">DF</option>
                                              <option value="ES">ES</option>
                                              <option value="GO">GO</option>
                                              <option value="MA">MA</option>
                                              <option value="MG">MG</option>
                                              <option value="MS">MS</option>
                                              <option value="MT">MT</option>
                                              <option value="PA">PA</option>
                                              <option value="PB">PB</option>
                                              <option value="PE">PE</option>
                                              <option value="PI">PI</option>
                                              <option value="PR" selected="selected">PR</option>
                                              <option value="RJ">RJ</option>
                                              <option value="RN">RN</option>
                                              <option value="RO">RO</option>
                                              <option value="RR">RR</option>
                                              <option value="RS">RS</option>
                                              <option value="SC">SC</option>
                                              <option value="SE">SE</option>
                                              <option value="SP">SP</option>
                                              <option value="TO">TO</option>
                                            </select>
             </span>
             <span style="display: inline-block; padding-bottom: 10px;">
                 <label>Tipo de endere&ccedil;o</label><br>
                 <input style="border: medium none;" name="tipoendereco" id="tipoendereco" value="1" checked="checked" type="radio">Residencial
                 <input style="border: medium none;" name="tipoendereco" id="tipoendereco" value="2" type="radio">Comercial 

                  
            </span> 
            
            
            <span style="display: inline-block;">
                  <label>Tel. resid&ecirc;ncial</label><br>
              	  <input  id="telresidencial" class="validate[required] tel" name="telresidencial" type="text">
            </span> 
            <span style="display: inline-block;">
                  <label>Tel. comercial</label><br>
              	  <input  id="telcomercial" class="tel" name="telcomercial" type="text">
            </span> 
            <span style="display: inline-block;">
                  <label>Ramal</label><br>
              	  <input  id="ramal" name="ramal" type="text">
            </span> 
            <span style="display: inline-block;">
                  <label>Tel. Celular</label><br>
                  <input  id="telcelular" class="tel" name="telcelular" type="text">
            </span>
            <span style="display: inline-block;">
                  <label>PIS/PASEP</label><br>
                  <input  id="pispasep" class="validate[required]" name="pispasep" type="text">
            </span>  

            </div>
            <h2>Dependentes</h2>
            <div class="form" id="dependente"> 
            
             

            </div>
             <input onclick="dependente();" value="" class="btn-dependente"  type="button">
            <div class="botao">
            	<input type="button" value="" class="btn-enviar" onclick="enviarForm()" />
              	<div id="status"></div>
            </div>
          </form>
<script>

function dependente(){
	$("#dependente").append('<hr /><div class="form"><input type="hidden" name="qtddependente[]" /><span style="display: inline-block;"> <label>Nome completo</label><br><input type="text" style="width:612px;" name="dependentenome[]" class="validate[required] text"></span> <span style="display: inline-block;">            <label>Estado Civil</label><br><div class="selector" id="uniform-estadoCivil"><span style="-moz-user-select: none;">Solteiro(a)</span><select class="validate[required]" name="dependenteestadoCivil[]" id="dependenteestadoCivil" style="opacity: 0;">       <option value="Solteiro(a)">Solteiro(a)</option><option value="Casado(a)">Casado(a)</option><option value="Separado(a)">Separado(a)</option><option value="Divorciado(a)">Divorciado(a)</option><option value="Vi�vo(a)">Vi&uacute;vo(a)</option></select></div> </span> <span style="display: inline-block;"><label> Data de Nascimento<br></label><input type="text"class="validate[required] data text"  name="dependentedataNascimento[]" ></span> <span style="display: inline-block;"><label> Parentesco</label><br><input type="text" name="dependenteparentesco[]" class="validate[required] text"></span> <span style="display: inline-block;"><label> CPF</label><br> <input type="text" name="dependentecpf[]" class="cpf text" ></span> <span style="display: inline-block;"><label> RG</label><br> <input type="text" name="dependenterg[]" class="text"></span> <span style="display: inline-block;"><label> Org&atilde;o expedidor RG</label><br><input type="text" name="dependenteorgaorg[]" class="text"></span> <span style="display: inline-block;"><label> Data expedi&ccedil;&atilde;o RG</label><br><input type="text" name="dependentedatarg[]" class="data text" ></span> <span style="display: inline-block;"><label> N&deg; Decl. de Nascido Vivo</label><br> <input type="text" name="dependentenascidovivo[]" class="text" ></span></span> <span style="display: inline-block;"><label> Cart&atilde;o Nacional de Sa&uacute;de</label><br> <input type="text" name="dependentecartaonacionalsaude[]" class="text" ></span><span style="display: inline-block;"><label>Sexo</label><br><div class="selector" id="uniform-sexo"><span style="-moz-user-select: none;">Masculino</span><select class="validate[required]" name="sexo[]" id="sexo" style="opacity: 0;"><option value="M">Masculino</option><option value="F">Feminino)</option></select></div></span> <span style="display: block;"><label> Nome completo da m&atilde;e</label><br><input type="text" style="width:455px;" name="dependentenomemae[]" class="validate[required] text" ></span></div>');
	}

function enviarForm(){

	$("#status").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Enviando por favor aguarde...");
	var dados = $("#form").serialize();
    $.ajax({
		type: "POST",
		url: "<?= site_url().$pasta?>/envia",
		data: dados,
		success: function( data )
		{

			}
		});      

  }
  
 
  
</script>
        </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
