﻿<?php
include("topo_view.php");
?>
<div class="conteudo-superior">
	<h3>Cl&iacute;nica 24hs</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncias</h1>
          <img src="<?= site_url()?>hotsite/PJ/images/clinica.png" border="0" style="display:block; float:right;" /> <img src="images/fotos-clinica.png" border="0" style="display:block; float:right;" />
          <ul>
            <li>Moderna cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncia, <br />
              inclusive s&aacute;bados, domingos e feriados, dispon&iacute;vel para benefici&aacute;rio e cliente
              particular;</li>
            <li>Equipamentos de &uacute;ltima gera&ccedil;&atilde;o;</li>
            <li>Brinquedoteca;</li>
            <li>Espa&ccedil;o Sorriso (higieniza&ccedil;&atilde;o antes do atendimento);</li>
            <li>Profissionais qualificados;</li>
            <li>Atendimento personalizado: Agilidade e seguran&ccedil;a;</li>
          </ul>
          
       	  <p style="margin-left: -5px;">
          
          <h1>(41) 3342-9060 - (41) 308-DENTE*</h1>
            Rua Silveira Peixoto, 1040, Sala 04 (sobreloja) - Batel (esquina com Av. Sete de Setembro)</p>
        	<h1>Atendimentos de emerg&ecirc;ncia outras regi&otilde;es:</h1>
            <div class="clinica-outras">
              <div class="cidade">
                <h2>Ponta Grossa</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(42) 3301-7232 - (42) 8407-5336</h3>
                </span> </div>
              <div class="cidade">
                <h2>Londrina</h2>
                <span>
                  <h4>Dr. Ac&aacute;cio Almeida Andrade</h4>
                  <h3>(43) 3345-3578 - (43) 9997-3131</h3>
                </span> <span>
                    <h4>Dr. Kenyti Muraoka</h4>
                    <h3>(43) 3324-7410 - (43) 9997-3130</h3>
                    </span> <span>
                      <h4>Dra. Erika Rodrigues</h4>
                      <h3>(43) 9998-3130</h3>
                      </span> <span>
                        <h4>Dra. Daniela B. C. Morettini</h4>
                        <h3>(43) 9944-3131</h3>
                        </span> <span>
                          <h4>Dra. Suzane Carla Santos</h4>
                          <h3>(43) 9944-3131</h3>
                        </span> </div>
              <div class="cidade">
                <h2>Joinville</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(47) 3028-8000</h3>
                </span> </div>
              <div class="cidade">
                <h2>Florian&oacute;polis</h2>
                <span>
                  <h4>Cl&iacute;nica Simone Leal</h4>
                  <h3>(47) 3222-8448</h3>
                </span> <span>
                    <h4>Cl&iacute;nica Jorge Bezerra</h4>
                    <h3>(47) 3258-0235</h3>
                  </span> </div>
              <div class="cidade">
                <h2>Porto Alegre</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(51) 3302-4000</h3>
                </span> </div>
              <div class="cidade">
                <h2>Gua&iacute;ba</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(51) 3055-4058 - (51) 3491-9615</h3>
                </span> </div>
              <div class="cidade">
                <h2>Pelotas</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(53) 3227-6515</h3>
                </span> </div>
              <div class="cidade">
                <h2>Rio de Janeiro</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs Tijuca</h4>
                  <h3>(21)2288-4797</h3>
                </span> <span>
                    <h4>Cl&iacute;nica 24hs Meier</h4>
                    <h3>(21)2594-5144</h3>
                    </span> <span>
                      <h4>Cl&iacute;nica 24hs Leblon</h4>
                      <h3>(21)2274-4144 - (21)2259-1649</h3>
                      </span> <span>
                        <h4>Cl&iacute;nica 24hs Botafogo</h4>
                        <h3>(21)2539-6870 - (21)3068-3716</h3>
                        </span> <span>
                          <h4>Cl&iacute;nica 24hs Barra da Tijuca</h4>
                          <h3>(21)3079-0124</h3>
                          </span> <span>
                            <h4>Cl&iacute;nica Oral Plus Barra da Tijuca</h4>
                            <h3>(21)3433-7799</h3>
                            </span> <span>
                              <h4>RDC Dentista 24hs Barra da Tijuca</h4>
                              <h3>(21)3079-0124</h3>
                            </span> </div>
              <div class="cidade">
                <h2>S&atilde;o Paulo - Zona Leste</h2>
                <span>
                  <h4>CSB Cl&iacute;nica de Sa&uacute;de Bucal Ltda</h4>
                  <h3>(11) 2294-9000</h3>
                </span> <span>
                    <h4>PS Odontologia</h4>
                    <h3>(11) 3459-2828</h3>
                    </span> <span>
                      <h4>Centro Odont. Especializado Mazzine e Mayer</h4>
                      <h3>(11) 2781-9840</h3>
                    </span> </div>
              <div class="cidade">
                <h2>S&atilde;o Paulo - Zona Norte</h2>
                <span>
                  <h4>Centro Odont. Especializado Mazzine e Mayer</h4>
                  <h3>(11) 2950-6803</h3>
                </span> </div>
              <div class="cidade">
                <h2>S&atilde;o Paulo - Zona Oeste</h2>
                <span>
                  <h4>Centro Odontol&oacute;gico &Aacute;gua Branca</h4>
                  <h3>(11) 3872-1716</h3>
                </span> <span>
                    <h4>Plant&atilde;o Odonto</h4>
                    <h3>(11) 3873-2001</h3>
                  </span> </div>
              <div class="cidade">
                <h2>S&atilde;o Paulo - Zona Sul</h2>
                <span>
                  <h4>Clinic Odontologia</h4>
                  <h3>(11) 3089-6060</h3>
                </span> <span>
                    <h4>Plant&atilde;o Odonto</h4>
                    <h3>(11) 5549-3030</h3>
                    </span> <span>
                      <h4>Viver Odonto Ltda</h4>
                      <h3>(11) 5686-3025</h3>
                    </span> </div>
              <div class="cidade">
                <h2>Barueri</h2>
                <span>
                  <h4>Brown Odontologia</h4>
                  <h3>(11) 4193-1059 - (11)2865-0544</h3>
                </span> </div>
              <div class="cidade">
                <h2>Guarulhos</h2>
                <span>
                  <h4>Iarossi Centro de Preven&ccedil;&atilde;o e Reabilita&ccedil;&atilde;o</h4>
                  <h3>(11) 2468-1011</h3>
                </span> <span>
                    <h4>Iarossi Genial Dente</h4>
                    <h3>(11) 2414-5170</h3>
                    </span> <span>
                      <h4>Iarossi Sa&uacute;de</h4>
                      <h3>(11) 2408-7794 - (11) 2468-1011</h3>
                    </span> </div>
              <div class="cidade">
                <h2>Osasco</h2>
                <span>
                  <h4>AVB SOS Cl&iacute;nica Odontol&oacute;gica</h4>
                  <h3>(11) 3682-5720</h3>
                </span> </div>
              <div class="cidade">
                <h2>S&atilde;o Caetano do Sul</h2>
                <span>
                  <h4>Internacional</h4>
                  <h3>(11) 4231-1000</h3>
                </span> </div>
              <div class="cidade">
                <h2>Goi&acirc;nia</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(62) 3254-9100</h3>
                </span> </div>
              <div class="cidade">
                <h2>An&aacute;polis</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(62) 3311-1020</h3>
                </span> </div>
              <div class="cidade">
                <h2>Campo Grande</h2>
                <span>
                  <h4>Dr.Pedro Mauro</h4>
                  <h3>(67) 33612784</h3>
                </span> <span>
                    <h4>Dra.Thaina</h4>
                    <h3>(67) 3325-7701</h3>
                    </span> <span>
                      <h4>Dra. Isabel Cristina</h4>
                      <h3>(67) 3326-7667</h3>
                    </span> </div>
              <div class="cidade">
                <h2>Dourados</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(67) 8177-3422</h3>
                </span> </div>
              <div class="cidade">
                <h2>Cuiab&aacute;</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(65) 9224-9000</h3>
                </span> </div>
              <div class="cidade">
                <h2>Belo Horizonte</h2>
                <span>
                  <h4>Cl&iacute;nica 24hs</h4>
                  <h3>(31) 3025-7500</h3>
                </span></div>

        </div>
    </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
