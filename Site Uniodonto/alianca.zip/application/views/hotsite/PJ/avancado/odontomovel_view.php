﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Odontom&oacute;vel</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
			<h1>Saúde Prevenção e Educação circulando por todo lugar.</h1>
	  		<div class="odontomovel">
            	<span>A Uniodonto Curitiba está sempre em movimento para oferecer o melhor para os seus beneficiários. Prova disso são as nossas cinco Odontomóveis, unidades móveis equipadas com um consultório odontológico para a realização de avaliações bucais.	
                <br /><br />
            	A Uniodonto oferece com a Odontomóvel palestras sobre a promoção de saúde bucal com várias opções de temas, contribuindo e ajudando a melhorar a qualidade de vida das pessoas agindo também com o
compromisso e responsabilidade social.
				</span>
           	 	<span>
					<img src="<?= site_url()?>hotsite/PJ/images/odontomovel.png" border="0"/>
            	</span>
			</div>
			

		</div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>     
<?php
include("rodape_view.php");
?>
