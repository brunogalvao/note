<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
	<title>Ficha de cadastro Uniodonto</title>
	<link rel="stylesheet" type="text/css" href="<?= site_url()?>hotsite/PJ/css/email.css" />
	<style>
	body{
		font-family: "Tahoma", Arial;
	}
	</style>
</head>
		
<body>
<div>	
	<div class="topo">
		<div class="logo">
        <img src="<?= site_url()?>hotsite/PJ/images/logo-print.jpg" border="0"/>
        <img src="<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/logo-print-cliente.jpg" border="0"/>
		</div>
	
	</div>
	<div class="ficha-inscricao-print">
	<div>
		<h1>Ficha de inscri&ccedil;&atilde;o</h1>
		<h2>Dados do Benefici&aacute;rio</h2>
		
<span style="display: block;">
	<label>
	   Nome completo do titular: <?=$nome?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Data de Nascimento: <?=$dataNascimento?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Matr&iacute;cula: <?=$matricula?>
	</label>
</span>
<span style="display: block;">
	<label>
	   CPF: <?=$cpf?>
	</label>
</span>
<span style="display: block;">
	<label>
	   RG: <?=$rg?>
	</label>
</span>
<span style="display: block;">
	<label>
	  Org&atilde;o expedidor RG: <?=$orgaorg?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Data expedi&ccedil;&atilde;o RG: <?=$datarg?>
	</label>
</span>

<span style="display: block;">
	<label>
	   Sexo: <?=$sexo?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Endere&ccedil;o: <?=$endereco?>, <?=$numero?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Complemento: <?=$complemento?>
	</label>
</span>	
<span style="display: block;">
	<label>
		   <?=$bairro?> - <?=$cidade?> - <?=$estado?>
	</label>
</span>
<span style="display: block;">
	<label>
	   CEP: <?=$cep?>
	</label>
</span>
		
<br />
<span style="display: block;">
	<label>
	   Tel residencial: <?=$telresidencial?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Celular: <?=$celular?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Co-responsabilidade Tutelar: <?=$tutelar?>
	</label>
</span>
<span style="display: block;">
	<label>
	   Nome completo da m&acirc;e: <?=$nomemae?>
	</label>
</span>


<? if($dadosdependentes != ""){?>		
<h2>Dependentes</h2>
<div class="dependentes">
<?=$dadosdependentes?>
</div>
<? }?>		
		</div>
		
</div>

</div>		
</body>
		</html>