﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
  		<div class="plano" style="background: url(<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/bg-plano.png) no-repeat;">

            <a onclick="mostraFicha()"></a>
      </div>
        <div class="busca"></div>
        
  		<div class="icones"><span class="logo-cliente"> <img src="<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/logo-cliente.png" alt="" border="0"></span> <span> <a href="<?= site_url().$pasta?>/perguntas/#parcelamento">
        <h2>Parcelamento</h2>
        <p>Parcele os atos n&atilde;o cobertos em at&eacute; <b>12x</b> sem juros.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/odontomovel">
        <h2>Odontom&oacute;vel</h2>
        <p>Sa&uacute;de, Preven&ccedil;&atilde;o e Educa&ccedil;&atilde;o circulando por todo lugar.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/encontreseudentista">
        <h2>Encontre seu dentista</h2>
        <p>Clique aqui para encontrar o dentista mais pr&oacute;ximo.</p>
        </a></span> </div>
        <div class="slogan"><?=$titulo?> </div>
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top"></div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Ficha de inscri&ccedil;&atilde;o</h1>
          <h2>Dados do Benefici&aacute;rio</h2>
          <div class="form">
          <form enctype="multipart/form-data" method="post" id="form" name="form">
            <span style="display: inline-block;">
              <label> Nome completo do titular<br>
                <input  id="nome" class="validate[required]" name="nome" type="text" style="width:612px;">
              </label>
            </span> <span style="display: inline-block;">
                <label> Data de Nascimento<br>
                  <input  id="dataNascimento" class="validate[required] data" name="dataNascimento" type="text">
                </label>
                </span> <span style="display: inline-block;">
                  <label> Matricula<br>
                    <input  id="matricula" name="matricula" type="text">
                  </label>
                  </span> <span style="display: inline-block;">
                    <label> CPF<br>
                      <input  id="cpf" class="validate[required] cpf" name="cpf" type="text">
                    </label>
                    </span> <span style="display: inline-block;">
                      <label> RG<br>
                        <input  id="rg" class="validate[required]" name="rg" type="text">
                      </label>
                      </span> <span style="display: inline-block;">
                        <label> Org&atilde;o expedidor RG<br>
                          <input  id="orgaorg" class="validate[required]" name="orgaorg" type="text">
                        </label>
                        </span> <span style="display: inline-block;">
                          <label> Data expedi&ccedil;&atilde;o RG<br>
                            <input  id="datarg" class="validate[required]  data" name="datarg" type="text">
                          </label>
                          </span> <span style="display: block;">
                            <label> Sexo<br>
                              <input style="border: medium none;" name="sexo" id="sexo" value="M" checked="checked" type="radio">
                              Masculino
                              <input style="border: medium none;" name="sexo" id="sexo" value="F" type="radio">
                              Feminino </label>
                            </span> <span style="display: inline-block;">
                              <label> Endere&ccedil;o<br>
                                <input  id="endereco" class="validate[required]" name="endereco" type="text" style="width:455px;">
                              </label>
                              </span> <span style="display: inline-block;">
                                <label> N&ordm;<br>
                                  <input  id="numero" class="validate[required]" name="numero" type="text">
                                </label>
                                </span> <span style="display: inline-block;">
                                  <label> Complemento<br>
                                    <input  id="complemento" name="complemento" type="text">
                                  </label>
                                  </span> <span style="display: inline-block;">
                                    <label> Bairro<br>
                                      <input  id="bairro" class="validate[required]" name="bairro" type="text">
                                    </label>
                                    </span> <span style="display: inline-block;">
                                      <label> Cidade<br>
                                        <input  id="cidade" class="validate[required]" name="cidade" type="text">
                                      </label>
                                      </span> <span style="display: inline-block;">
                                        <label> CEP<br>
                                          <input  id="cep" class="validate[required] cep" name="cep" type="text">
                                        </label>
                                        </span> <span style="display: inline-block;">
                                          <label> Estado<br>
                                            <select id="estado" name="estado" class="validate[required]">
                                              <option value="AC">AC</option>
                                              <option value="AL">AL</option>
                                              <option value="AM">AM</option>
                                              <option value="AP">AP</option>
                                              <option value="BA">BA</option>
                                              <option value="CE">CE</option>
                                              <option value="DF">DF</option>
                                              <option value="ES">ES</option>
                                              <option value="GO">GO</option>
                                              <option value="MA">MA</option>
                                              <option value="MG">MG</option>
                                              <option value="MS">MS</option>
                                              <option value="MT">MT</option>
                                              <option value="PA">PA</option>
                                              <option value="PB">PB</option>
                                              <option value="PE">PE</option>
                                              <option value="PI">PI</option>
                                              <option value="PR" selected="selected">PR</option>
                                              <option value="RJ">RJ</option>
                                              <option value="RN">RN</option>
                                              <option value="RO">RO</option>
                                              <option value="RR">RR</option>
                                              <option value="RS">RS</option>
                                              <option value="SC">SC</option>
                                              <option value="SE">SE</option>
                                              <option value="SP">SP</option>
                                              <option value="TO">TO</option>
                                            </select>
                                          </label>
                                          </span> <br />
            <span style="display: inline-block;">
              <label> Tel resid&ecirc;ncial<br>
                <input  id="telresidencial" class="validate[required] tel" name="telresidencial" type="text">
              </label>
            </span> <span style="display: inline-block;">
                <label> Celular<br>
                  <input  id="celular" class="validate[required] tel" name="celular" type="text">
                </label>
                </span> <span style="display: block;">
                  <label> Co-responsabilidade Tutelar<br>
                    <input type="checkbox" name="tutelar" value="Sim">
                  </label>
                  </span> <span style="display: block;">
                    <label> Nome completo da m&atilde;e<br>
                      <input  id="nomemae" name="nomemae" type="text" style="width:455px;">
                    </label>
                    </span>
            </div>
            <h2>Dependentes</h2>
            <div class="form"> <span style="display: inline-block;">
              <label> Nome completo do titular<br>
                <input  id="dependentenome" name="dependentenome" type="text" style="width:612px;">
              </label>
              </span> <span style="display: inline-block;">
                <label> Data de Nascimento<br>
                  <input  id="dependentedataNascimento" class="data" name="dependentedataNascimento" type="text">
                </label>
                </span> <span style="display: inline-block;">
                  <label> Parentesco<br>
                    <input  id="dependenteparentesco"  name="dependenteparentesco" type="text">
                  </label>
                  </span> <span style="display: inline-block;">
                    <label> CPF<br>
                      <input  id="dependentecpf" class="cpf" name="dependentecpf" type="text">
                    </label>
                    </span> <span style="display: inline-block;">
                      <label> RG<br>
                        <input  id="dependenterg" name="dependenterg" type="text">
                      </label>
                      </span> <span style="display: inline-block;">
                        <label> Org&atilde;o expedidor RG<br>
                          <input  id="dependenteorgaorg" name="dependenteorgaorg" type="text">
                        </label>
                        </span> <span style="display: inline-block;">
                          <label> Data expedi&ccedil;&atilde;o RG<br>
                            <input  id="dependentedatarg" class="data" name="dependentedatarg" type="text">
                          </label>
                          </span> <span style="display: block;">
                            <label> Sexo<br>
                              <input style="border: medium none;" name="dependentesexo" id="dependentesexo" value="M" checked="checked" type="radio">
                              Masculino
                              <input style="border: medium none;" name="dependentesexo" id="dependentesexo" value="F" type="radio">
                              Feminino </label>
                            </span> <span style="display: block;">
                              <label> Nome completo da m&atilde;e<br>
                                <input  id="dependentenomemae" name="dependentenomemae" type="text" style="width:455px;">
                              </label>
                              </span>
              <input onclick="addDependente();" value="" class="btn-dependente"  type="button">
              <input value="" name="lista_dependentes" id="conteudolistadependentes" type="hidden">
              <div id="status1"></div>
              <div class="lista_dependentes" id="lista_dependentes"></div>
            </div>
            <div class="botao">
            	<input type="button" value="" class="btn-enviar" onclick="enviarForm()" />
              	<div id="status"></div>
            </div>
          </form>
<script>
function enviarForm(){

    var $form = $("#form"),
        term = $form.find( 'input[name="s"]' ).val(),
        url = '<?= site_url().$pasta?>/envia';
	var formnome = $("#nome").val(); 
	var formdataNascimento = $("#dataNascimento").val(); 
	var formmatricula = $("#matricula").val(); 
	var formcpf = $("#cpf").val(); 
	var formrg = $("#rg").val(); 
	var formorgaorg = $("#orgaorg").val(); 
	var formdatarg = $("#datarg").val(); 
	var formsexo = $("#sexo").val(); 
	var formendereco = $("#endereco").val(); 
	var formnumero = $("#numero").val(); 
	var formcomplemento = $("#complemento").val();  
	var formbairro = $("#bairro").val(); 
	var formcidade = $("#cidade").val(); 
	var formcep = $("#cep").val(); 
	var formestado = $("#estado").val(); 
	var formtelresidencial = $("#telresidencial").val(); 
	var formcelular = $("#celular").val();
	var formnomemae = $("#nomemae").val();  
	var formdependentenome = $("#dependentenome").val(); 
	var formdependentedataNascimento = $("#dependentedataNascimento").val(); 
	var formdependenteparentesco = $("#dependenteparentesco").val(); 
	var formdependentecpf = $("#dependentecpf").val(); 
	var formdependenterg = $("#dependenterg").val(); 
	var formdependenteorgaorg = $("#dependenteorgaorg").val(); 
	var formdependentedatarg = $("#dependentedatarg").val(); 
	var formdependentenomemae = $("#dependentenomemae").val();  
	var formlista_dependentes = $("#lista_dependentes").html();

    $("#status").html("<img src='<?= site_url()?>hotsite/PJ/images/loading.gif' alt='Enviando' /> Aguarde...");

    $.post( url, {
			nome  : formnome,
			dataNascimento  : formdataNascimento,
			matricula  : formmatricula,
			cpf  : formcpf,
			rg  : formrg,
			orgaorg  : formorgaorg,
			datarg  : formdatarg,
			sexo  : formsexo,
			endereco  : formendereco,
			numero  : formnumero,
			complemento  : formcomplemento, 
			bairro  : formbairro,
			cidade  : formcidade,
			cep  : formcep,
			estado  : formestado,
			telresidencial  : formtelresidencial,
			celular : formcelular,
			nomemae  : formnomemae, 
			dependentenome  : formdependentenome,
			dependentedataNascimento  : formdependentedataNascimento,
			dependenteparentesco  : formdependenteparentesco,
			dependentecpf  : formdependentecpf,
			dependenterg  : formdependenterg,
			dependenteorgaorg  : formdependenteorgaorg,
			dependentedatarg  : formdependentedatarg,
			dependentenomemae  : formdependentenomemae, 
			lista_dependentes  : formlista_dependentes
		},
      function(resposta) {
            // Quando terminada a requisição
            // Exibe a div status
            $("#status").slideDown();
            switch(resposta){
			case "1":
				$("#status").html("&Eacute; necess&aacute;rio preencher todos os campos antes de enviar o email!");
				break;
			case "2":
				$("#status").html("O CPF digitado &eacute; inv&aacute;lido. Verifique e tente novamente!");
				break;
			case "3":
				$("#status").html("Verifique o CPF dos dependentes e tente novamente!");
				break;
			case "4":
				$("#status").html("Email enviado com sucesso!");
				break;
			case "5":
				$("#status").html("N&atilde;o foi poss&iacute;vel enviar o email! Tente novamente!");
				break;
			};
         });    

  }
  
function imprimirForm(){

	$("#conteudolistadependentes").val($("#lista_dependentes").html());
	$("#status").html("<img src='<?= site_url()?>hotsite/PJ/images/loading.gif' alt='Enviando' /> Aguarde...");
	var dados = jQuery("#form").serialize();

			jQuery.ajax({
				type: "POST",
				url: "<?= site_url().$pasta?>/imprimir",
				data: dados,
				success: function( data )
				{
					
					switch(data){
					case "1":
					  $("#status").html("&Eacute; necess&aacute;rio preencher todos os campos antes de imprimir!");
					  break;
					case "2":
					  $("#status").html("O CPF digitado &eacute; inv&aacute;lido. Verifique e tente novamente!");
					  break;
					case "3":
					  $("#status").html("Verifique o CPF dos dependentes e tente novamente!");
					  break;
					default:
						$("#status").empty();
					  	var popupWin = window.open('', '_blank');
			           	popupWin.document.open();
			           	popupWin.document.write(data);
			           	popupWin.document.close(); 
					}
					
					
				}
			});

	
	
}  
  
          </script>
        </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
