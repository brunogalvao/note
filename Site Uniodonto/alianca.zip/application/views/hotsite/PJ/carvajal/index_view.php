<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
  		<div class="plano" style="background: url(<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/bg-plano.png) no-repeat;">

            <a onclick="mostraFicha()"></a>
      </div>
        <div class="busca"></div>
        
  		<div class="icones"><span class="logo-cliente"> <img src="<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/logo-cliente.png" alt="" border="0"></span> <span> <a href="<?= site_url().$pasta?>/perguntas/#parcelamento">
        <h2>Parcelamento</h2>
        <p>Parcele os atos n&atilde;o cobertos em at&eacute; <b>12x</b> sem juros.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/odontomovel">
        <h2>Odontom&oacute;vel</h2>
        <p>Sa&uacute;de, Preven&ccedil;&atilde;o e Educa&ccedil;&atilde;o circulando por todo lugar.</p>
        </a></span> <span> <a href="<?= site_url().$pasta?>/encontreseudentista">
        <h2>Encontre seu dentista</h2>
        <p>Clique aqui para encontrar o dentista mais pr&oacute;ximo.</p>
        </a></span> </div>
        <div class="slogan"><?=$titulo?> </div>
  </div>

</div>    
<?php
include("rodape_view.php");
?>
