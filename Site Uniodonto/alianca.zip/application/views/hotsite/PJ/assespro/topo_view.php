<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title><?= $titulo?></title>

  <link rel='stylesheet' type='text/css' href='<?= site_url()?>hotsite/PJ/css/css.css' />
  <script src="<?= site_url()?>js/jquery-latest.js"></script> 
  <script src="<?= site_url()?>hotsite/PJ/js/js.js" type="text/javascript" charset="utf-8"></script>
  <link rel="stylesheet" href="<?= site_url()?>hotsite/PJ/js/validation/css/validationEngine.jquery.css" type="text/css"/>
  <script src="<?= site_url()?>hotsite/PJ/js/validation/js/languages/jquery.validationEngine-pt_BR.js" type="text/javascript" charset="utf-8"></script>
  <script src="<?= site_url()?>hotsite/PJ/js/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>

  
  <script src='<?= site_url()?>hotsite/PJ/js/jquery.form.js' type="text/javascript" language="javascript"></script>
  <link href="<?= site_url()?>hotsite/PJ/css/input.css" rel="stylesheet" type="text/css"/>
  <script src="<?= site_url()?>hotsite/PJ/js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>	
  
  <script src="<?= site_url()?>hotsite/PJ/js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>		
  

  
  	<script type='text/javascript'>
  		
  		$(document).ready(function(){

			$("#form").validationEngine({
			});
		});
		


	</script>

</head>

<body>
  <div class="topo">
    	<div class="logo"><a href="<?= site_url().$pasta?>"><img src="<?= site_url()?>hotsite/PJ/images/logo.png" border="0"></a></div>
        <div class="menu">
            <a href="<?= site_url().$pasta?>">Home</a>
            <a href="<?= site_url().$pasta?>/plano">Conhe&ccedil;a o plano</a>
            <a href="<?= site_url().$pasta?>/tabela_atos">Tabela de atos</a>
            <a href="<?= site_url().$pasta?>/clinica">Cl&iacute;nica 24hs</a>
            <a href="<?= site_url().$pasta?>/perguntas">Perguntas frequentes</a>
            <a href="<?= site_url().$pasta?>/contato">Contato</a>
        </div>
  </div>
