﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>SIO</title>
</head>

<body onload="redir();">

<iframe src="<?= $link ?>" style="display:none;" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" ></iframe>
<? if($tipo == 1){ ?>
	<script type="text/javascript">
		function redir()
		{
		document.location = "http://www.uniodontocuritiba.com.br";
		}
	</script>
    
	<? }else{ ?>
		
   	<script type="text/javascript">
		function redir()
		{
		document.location = "<?= site_url() ?>";
		}
	</script>
    
<? } ?>

</body>
</html>
