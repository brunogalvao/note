<? include('header_view.php'); ?>
	<div>
    <h1><?=$titulo ?></h1>
    <?=$texto ?>
    <iframe id="kc_frame" name="kcfinder_alone" src="<?=site_url($link)?>"/>
    </iframe>	
    </div>
<? include("footer_view.php") ?>
