<? include("header_view.php") ?>
   <div>
	<h1>Adicionar usuário</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/usuarios/')?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/usuarios/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
             <ul class="formulario">
             	<li> <span class="titulo">Nome</span>   
                <input type="text" name="user_nome" value="" class="input-grande" /></li>
                <li> <span class="titulo">E-mail</span>   
                <input type="text" name="user_email" value="" class="input-grande"/></li>
                <li> <span class="titulo">Senha</span>   
                <input type="password" name="user_senha" value="" class="input-grande" /></li> 
                
                <li class="permissoes">
                <span class="titulo">Permiss&otilde;es</span> <br />
                <? foreach($metodos as $metodo){ ?>
                
                	<span class="permissao-user"><input type="checkbox" class="checkbox" name="metodo[]" value="<?= $metodo->id ?>" ><?= ucfirst($metodo->apelido) ?></span>
                <? } ?>
  				</li>
            </ul>
        </form>
		</div>
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
