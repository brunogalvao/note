<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="pt-br" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Administração - Uniodonto Curitiba</title>
    <link type="image/x-icon" href="<?= site_url()?>images/admin/favicon.ico" rel="shortcut icon">
    <script src='<?= site_url()?>js/jquery.js' type="text/javascript"></script>
    <script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
    
    <script src='<?= site_url()?>js/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
    <script src='<?= site_url()?>js/jquery.blockUI.js' type="text/javascript" language="javascript"></script>
    <script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>
    <script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
    <script src="<?= site_url()?>js/js.js" type="text/javascript" charset="utf-8"></script>
    
    <script type="text/javascript" src="<?= site_url()?>/includes/minicolors/jquery.miniColors.js"></script>
	<link type="text/css" rel="stylesheet" href="<?= site_url()?>/includes/minicolors/jquery.miniColors.css" />
  
    
    <script type="text/javascript" src="<?=site_url()?>/includes/ckeditor/ckeditor.js"></script>
    <script src="<?= site_url()?>/includes/ckeditor/_samples/sample.js" type="text/javascript"></script>
    <link href="<?= site_url()?>/includes/ckeditor/_samples/sample.css" rel="stylesheet" type="text/css">
    <link href="<?= site_url()?>/css/css_admin2.css" rel="stylesheet" type="text/css"/>
    <link href="<?= site_url()?>/css/uniform.default_admin.css" rel="stylesheet" type="text/css"/>
    <!--[if IE]>
		<link href="<?= site_url()?>/css/css_admin_ie.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
    <script type="text/javascript" charset="utf-8">
		$(function(){
			$("input").uniform();
			$("select").uniform();
			
		});
		function submitform()
		{
			document.forms["form"].submit();
		}
		jQuery(function($){
		   $(".data").mask("99/99/9999");
		   $(".tel").mask("(99) 9999-9999");
		   $(".numero").mask("99");
		   $(".cnpj").mask("99.999.999/9999-99");
		
		});
    </script>

</head>

<body onload="initialize()">
<div class="site">
<div class="todo">
    <div class="topo">
        <span>
        	<img src="<?= site_url()?>images/admin/logo_sio.png" /></span>
        <span>
            <h2>&Aacute;rea Administrativa</h2>
			<h1>Uniodonto Curitiba</h1>
        </span>
                
    </div>     
    <div class="menu">
    	<? include('menu_view.php'); ?>
    </div>
    <div class="conteudo">
        
