<? include("header_view.php") ?>
   <div>
	<h1>Adicionar página institucional</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/textos/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/textos/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
				                
              				
             <ul class="formulario">
             	<li> <span class="titulo">Menu</span>   
                <select name="texto_menu" class="select">
                      <option value="1">A Uniodonto</option>
                      <option value="2">Planos</option>
                      <option value="3">Dental Uni</option>
                      <option value="4">Uniodonto 24h</option>
                      <option value="5">Contato</option>
                      <option value="6">Sustentabilidade</option>
                 </select><span class="titulo">Ordem</span>
                  <input type="text" name="texto_posicao" value="" /></li>
				<li> <span class="titulo">Título</span><br /> <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> <input type="text" name="texto_titulo_ptBR" value="" class="input-grande" /></li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  /> <input type="text" name="texto_titulo_en" value="" class="input-grande" /></li> 
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />   
                  <input type="text" name="texto_titulo_es" value="" class="input-grande" /></li>
                  				
				<li> <span class="titulo">Texto</span> <br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />   
                <textarea name="texto_texto_ptBR" cols="5" rows="5" class="ckeditor"></textarea>
				
				</li>
                <li><img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <textarea name="texto_texto_en" cols="5" rows="5" class="ckeditor"></textarea>
				
				</li>
                <li><img  src="<?= site_url()?>images/icons/spain_16x16.png"  /> 
                <textarea name="texto_texto_es" cols="5" rows="5" class="ckeditor"></textarea>
				</li>
                
				
				<li> <span class="titulo">Imagens</span>   
				<input type="file" class="multi" accept="gif|jpg|png" name="teste[]" />
				
				
				</li>
				
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
