<? include("header_view.php") ?>
        
    <div>
    <h1>Planos</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
	  <div class="pesquisa">
      		<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/planos/index/1") ?>" method="post">
            	<span>
                Tipo de plano<br />
                <select name="plano_tipo">
                	<option value="">Selecione</option>
                    <option value="1">Superior</option>
                    <option value="2">Avan&ccedil;ado</option>
                </select>
                
                </span>
                <span>
                Pagamento<br />
                <select name="plano_modalidade">
                	<option value="">Selecione</option>
                    <option value="1">Com car&ecirc;ncia</option>
                    <option value="2">Sem car&ecirc;ncia</option>
                    <option value="3">CO-Participa&ccedil;&atilde;o</option>
                </select>
                
                </span>
                <span>
                Modalidade<br />
                <select name="plano_pagamento">
                	<option value="">Selecione</option>
                    <option value="1">Boleto</option>
                    <option value="2">D&eacute;bito</option>
                </select>
                
                </span>
                <span style="width: 70px;">
				<input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar"/>
                </span>
                
            </form>
  
            <a href="<?= site_url('admin/limpar_pesquisa/planos') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 

       </div> 
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:130px;">Tipo de plano</div>
          <div style="width:130px;">Pagamento</div>
          <div style="width:130px;">Modalidade</div>
          <div style="width:130px;">Beneficiários</div>
          <div style="width:130px;">Valor R$</div>
          <div style="width:70px; text-align:center;">Editar</div>
        </li>
        <? $i= 1; ?>
        <? foreach($planos as $plano){
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
			?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:130px;"><? if($plano->plano_tipo == 1){print "Superior";}else{ print"Avançado";} ?></div>	
          <div style="width:130px;"><? if($plano->plano_pagamento == 1){print "Boleto";}else{ print"Débito";} ?></div>
          <div style="width:130px;"><? 	if($plano->plano_modalidade == 1){print "Com carência";}
		  								if($plano->plano_modalidade == 2){print "Sem carência";} 
										if($plano->plano_modalidade == 3){print "CO-Participação";}?></div>
          <div style="width:130px;" ><?= $plano->plano_qtd ?></div>
          <div style="width:130px;" ><?= $plano->plano_preco ?></div>
          <div style="width:70px; text-align:center;"><a href="<?= site_url('admin/planos/editar/'.$plano->plano_id) ?>" class="bt-editar"></a></div>
        </li>
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
