<? include('header_view.php'); ?>
		
<div class="home">
	<a href="<?=site_url("admin/usuarios")?>" alt="Usuários" title="Usuários">
			<img src="<?= site_url('images/admin/bt-user.png') ?>" border="0"></a>
    <a href="<?=site_url("admin/noticias")?>" alt="Noticias" title="Noticias">
			<img src="<?= site_url('images/admin/bt-noticias.png') ?>" border="0"></a>        
	<a href="<?=site_url("admin/textos")?>" alt="Páginas Institucionais" title="Páginas Institucionais">
			<img src="<?= site_url('images/admin/bt-pagina.png') ?>" border="0"></a>		
	<a href="<?=site_url("admin/textos_abas")?>" alt="Páginas Restritas" title="Páginas Restritas">
			<img src="<?= site_url('images/admin/bt-pagina-restrita.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/links_abas")?>" alt="Links Restritos" title="Links Restritos">
			<img src="<?= site_url('images/admin/bt-links.png') ?>" border="0"></a>	
	<a href="<?=site_url("admin/localizacao")?>" alt="Links Localização" title="Links Localização">
			<img src="<?= site_url('images/admin/bt-localizacao.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/planos")?>" alt="Planos" title="Planos">
			<img src="<?= site_url('images/admin/bt-planos.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/banners")?>" alt="Banners" title="Banners">
			<img src="<?= site_url('images/admin/bt-banners.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/eventos")?>" alt="Eventos" title="Eventos">
			<img src="<?= site_url('images/admin/bt-eventos.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/upload/arquivosupload")?>" alt="Enviar Arquivos" title="Enviar Arquivos">
			<img src="<?= site_url('images/admin/bt-arquivos.png') ?>" border="0"></a>	
	<a href="<?=site_url("admin/upload/clientes")?>" alt="Clientes" title="Clientes">
			<img src="<?= site_url('images/admin/bt-clientes.png') ?>" border="0"></a>
	<a href="<?=site_url("admin/revistas")?>" alt="Revistas" title="Revistas">
			<img src="<?= site_url('images/admin/bt-revistas.png') ?>" border="0"></a>	
    <a href="<?=site_url("admin/propostas")?>" alt="Propostas" title="Propostas">
			<img src="<?= site_url('images/admin/bt-propostas.png') ?>" border="0"></a>									
</div>		
		
<? include('footer_view.php'); ?>