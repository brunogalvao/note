<? include('header_view.php'); ?>
	<div>
    <h1>Revistas</h1>
	<? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>	
		<div class="pesquisa">
        		<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/revistas/index/1") ?>" method="post">
                <input type="text" name="revista_titulo" class="input-pesquisa" />
				<input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar"/>
                
            </form>
         	
            <a href="<?= site_url('admin/limparpesquisa/revistas') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:670px;">Título</div>
          <div style="width:100px; text-align:center;">Editar/Apagar</div>
        </li>
        <? $i= 1; ?>
        <? foreach($revistas as $revista){
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#ffffff";
				}
			?>
			
		    
          <li class="itens" style="background:<?=$bg ?>;">
          	<div style="width:670px;">
               <?= $revista->revista_titulo ?>                
            </div>
       
          	<div style="width:100px; text-align:center;">
                  <a href="<?= site_url('admin/revistas/editar/'.$revista->revista_id) ?>" class="bt-editar" alt="Editar" title="Editar"></a> 
                  <a href="<?= site_url('admin/revistas/excluir/'.$revista->revista_id) ?>" class="bt-excluir" alt="Excluir" title="Excluir"></a>
          	</div>
          </li>
        
        
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>  
      
	
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
    
	</div>
    
 	
<? include('footer_view.php'); ?>