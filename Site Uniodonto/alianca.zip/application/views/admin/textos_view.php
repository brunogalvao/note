<? include("header_view.php") ?>
    <h1>Páginas institucionais</h1>   
    <div>
    <? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
        <div class="pesquisa">
        <h2>Pesquisar</h2>
			<form action="<?= site_url("admin/textos") ?>" method="post">
            	<select name="texto_menu" class="select">
                	  <option value="">Selecione o menu</option>
                      <option value="1">A Uniodonto</option>
                      <option value="2">Planos</option>
                      <option value="3">Dental Uni</option>
                      <option value="4">Uniodonto 24h</option>
                      <option value="5">Contato</option>
                      <option value="6">Sustentabilidade</option>
                 </select>
                <input type="text" name="texto_titulo" class="input-pesquisa" />
				<input type="submit" name="Pesquisar" value="Buscar" class="bt-pesquisar" />
            </form>
            <a href="<?= site_url('admin/limparpesquisa/textos') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:410px;">Titulo</div>
          <div style="width:150px;">Menu</div>
          <div style="width:100px; text-align:center;">Ordem</div>
          <div style="width:90px; text-align:center;">Editar / Excluir</div>
        </li>
        <? $i= 1; ?>
        <? foreach($textos as $texto){
			
			if($i % 2 == 0){
				$bg = "#efefee";

				}else{
				$bg = "#fff";

				}
			?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:410px;"><?= ucfirst($texto->texto_titulo_ptBR) ?></div>
          <div style="width:150px;">
		  <?
		  if($texto->texto_menu == 1) print "A Uniodonto";
		  if($texto->texto_menu == 2) print "Planos";
		  if($texto->texto_menu == 3) print "Dental Uni";
		  if($texto->texto_menu == 4) print "Clinica 24hs";
		  if($texto->texto_menu == 5) print "Contato";
		  if($texto->texto_menu == 6) print "Sustentabilidade"; 
		   ?></div>
           <div style="width:100px; text-align:center;"><?= $texto->texto_posicao ?></div>
          <div style="width:80px; text-align:center;"><a href="<?= site_url('admin/textos/editar/'.$texto->texto_id) ?>" class="bt-editar"></a>
          <a href="<?= site_url('admin/textos/excluir/'.$texto->texto_id) ?>" class="bt-excluir"></a></div>
        </li>
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
