<? include("header_view.php") ?>
   <div>

    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar"></a>
                <a href="<?= site_url('admin/menus/') ?>" class="bt-voltar" alt="Voltar" title="Voltar"></a>
            </div>
			<form action="<?= site_url('admin/menus/editar/'.$menu->menu_id) ?>" method="post" enctype="multipart/form-data" id="form">
            <input type="hidden" name="menu_id" value="<?= $menu->menu_id ?>" />
             <ul class="formulario">
             	<li> <span class="titulo">Titulo</span>   
                <input type="text" name="menu_titulo" value="<?= $menu->menu_titulo ?>" class="input-grande"  /></li>
                <li> <span class="titulo">Status</span>   
                <input type="text" name="menu_status" value="<?= $menu->menu_status ?>" class="input-grande" /></li>
                <li> <span class="titulo">Tipo</span>   
                <select name="menu_pai" class="select">
                      <option value="0" <? if($menu->menu_pai == 0)print "selected"?>>Principal</option>
                      <? foreach($menus_pai as $menu_pai){ ?>
                      <option value="<?=$menu_pai->menu_id ?>" <? if($menu->menu_pai == $menu_pai->menu_id) print "selected" ?>><?=$menu_pai->menu_titulo ?></option>
                      <? } ?>
                </select></li>
                <li> <span class="titulo">pagina</span>   
                <select name="menu_pagina" class="select">
                      <option value="beneficiario" <? if($menu->menu_pagina == 0){print "beneficiario";}?>>Beneficiário</option>
                      <option value="empresa" <? if($menu->menu_pagina == "empresa"){print "selected";}?>>Empresa</option>
                      <option value="dentista" <? if($menu->menu_pagina == "dentista"){print "selected";}?>>Dentista</option>
                      <option value="uniodonto" <? if($menu->menu_pagina == "uniodonto"){print "selected";}?>>Uniodonto</option>
                      <option value="colaborador" <? if($menu->menu_pagina == "colaborador"){print "selected";}?>>Colaborador</option>
                      <option value="representante" <? if($menu->menu_pagina == "representante"){print "selected";}?>>Representante</option>
                      
                </select></li>
                <li> <span class="titulo">link</span>   
                <input type="text" name="menu_link" value="<?= $menu->menu_link ?>" class="input-grande"  /></li>     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
