<? include('header_view.php'); ?>
		
<div class="home">
	<div style="padding-top:10px; width: 600px; height: 300px; margin:auto; text-align: center;">
    <h1 style="font-size: 40px; color:#d1cfcf;">Ops</h1>
    <p style="font-size: 20px; padding: 10px; color: #808080;">Acesso negado</p>
    <p style="font-size: 12px;">Voc&ecirc; n&atilde;o possui previl&eacute;gios para acessar esta funcionalidade.</p>
    </div>
										

</div>		
		
<? include('footer_view.php'); ?>