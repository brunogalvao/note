<? include("header_view.php") ?>
   <div>

    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar"></a>
                <a href="<?= site_url('admin/menus/') ?>" class="bt-voltar" alt="Voltar" title="Voltar"></a>
            </div>
			<form action="<?= site_url('admin/menus/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
             <ul class="formulario">
             	<li> <span class="titulo">Titulo</span>   
                <input type="text" name="menu_titulo" value="" class="input-grande"  /></li>
                <li> <span class="titulo">Status</span>   
                <input type="text" name="menu_status" value="" class="input-grande" /></li>
                <li> <span class="titulo">Tipo</span>   
                <select name="menu_pai" class="select">
                      <option value="0" selected>Principal</option>
                      <? foreach($menus_pai as $menu){ ?>
                      <option value="<?=$menu->menu_id ?>"><?=$menu->menu_titulo ?></option>
                      <? } ?>
                </select></li>           
                <li> <span class="titulo">pagina</span>   
                <select name="menu_pagina" class="select">
                      <option value="beneficiario">Beneficiário</option>
                      <option value="empresa">Empresa</option>
                      <option value="dentista">Dentista</option>
                      <option value="uniodonto">Uniodonto</option>
                      <option value="colaborador">Colaborador</option>
                      <option value="representante">Representante</option>
                      
                </select></li>
                <li> <span class="titulo">link</span>   
                <input type="text" name="menu_link" value="" class="input-grande"  /></li>     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
