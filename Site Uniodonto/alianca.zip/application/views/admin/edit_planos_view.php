<? include("header_view.php") ?>
   <div>
   <h1>Editar plano</h1>

    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/planos/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/planos/editar/'.$plano->plano_id) ?>" method="post" enctype="multipart/form-data" id="form">
			<ul class="formulario">	
                <li>	              
                  <div>
                  <span class="titulo">Tipo de plano:</span>
                  <? if($plano->plano_tipo == 1){print "Superior";}else{ print"Avançado";} ?></div>	
                  <div>
                  <span class="titulo">Forma de pagamento:</span>
                  <? if($plano->plano_pagamento == 1){print "Boleto";}else{ print"Débito";} ?></div>
                  <div>
                  <span class="titulo">Modalidade:</span>
                  <? 	if($plano->plano_modalidade == 1){print "Com carência";}
                                                if($plano->plano_modalidade == 2){print "Sem carência";} 
                                                if($plano->plano_modalidade == 3){print "CO-Participação";}?></div>
                  <div>
                  <span class="titulo">Qtd. de beneficiários</span>
                  <?= $plano->plano_qtd ?></div>
                 </li> 			
             
					
                 <li> <span class="titulo">Valor R$</span>   
                  <input type="text" name="plano_preco" value="<?= $plano->plano_preco ?>" /></li>				
							
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
