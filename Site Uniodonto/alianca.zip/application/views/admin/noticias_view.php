<? include('header_view.php'); ?>
	<div>
    <h1>Notícias</h1> 
	<? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>	
		<div class="pesquisa">
        		<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/noticias/index/1") ?>" method="post">
            	<span>
                Data inicial<br /> <input type="text" name="data-inicial" class="input-pesquisa data" />
                </span>
                <span>
                Data final<br /> <input type="text" name="data-final" class="input-pesquisa data" />
                </span>
                <span>
                Status<br /> 
                <select name="status">
                	<option value="">Selecione</option>
                    <option value="1">Publicado</option>
                    <option value="0">N&atilde;o publicado</option>
                </select>
                
                </span>
                <span>
                Destaque<br /> 
                <select name="destaque">
                	<option value="">Selecione</option>
                    <option value="1">SIM</option>
                    <option value="0">N&Atilde;O</option>
                </select>
                
                </span>
                <span>
                Página<br />
                <select name="aba">
                	<option value="">Selecione</option>
                    <option value="noticia_home">Home</option>
                    <option value="noticia_beneficiario">Benefici&aacute;rio</option>
                    <option value="noticia_empresa">Empresa</option>
                    <option value="noticia_dentista">Dentista</option>
                    <option value="noticia_uniodonto">Uniodonto</option>
                    <option value="noticia_colaborador">Colaborador</option>
                    <option value="noticia_representante">Representante</option>
                </select>
               
                </span>
                <span>
                Título<br /> 
                <input type="text" name="pesquisa" class="input-pesquisa" />
                </span>
                <span style="width:120px;">
				<input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar"/>
                </span>
                
            </form>
        
	
            <a href="<?= site_url('admin/limparpesquisa/noticias') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:80px;">Data criação</div>
		  <div style="width:470px;">Título</div>
          <div style="width:50px; text-align:center;">Status</div>
          <div style="width:70px; text-align:center;">Destaque</div>
          <div style="width:80px; text-align:center;">Editar/Apagar</div>
        </li>
        <? $i= 1; ?>
        <? foreach($noticias as $noticia){
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#ffffff";
				}
			$data = explode(" ",$noticia->noticia_data);
			$dia = explode("-",$data[0]);
			?>
			
		    
          <li class="itens" style="background:<?=$bg ?>;">
		  	<div style="width:80px;">
				<?= $dia[2] ?>/<?= $dia[1] ?>/<?= $dia[0] ?>
            </div>
          	<div style="width:470px;">
                <div style="display:block; width:430px;"><?= $noticia->noticia_titulo_ptBR ?></div>
                <div style="display:block; font-weight:bold; font-size:12px; width:430px;">
                    
                    <? if($noticia->noticia_home == 1)print " (Home) " ?>
                    <? if($noticia->noticia_beneficiario == 1)print " (Beneficiário) " ?>
                    <? if($noticia->noticia_empresa == 1)print " (Empresa) " ?>
                    <? if($noticia->noticia_dentista == 1)print " (Dentista) " ?>
                    <? if($noticia->noticia_uniodonto == 1)print " (Uniodonto) " ?>
                    <? if($noticia->noticia_colaborador == 1)print " (Colaborador) " ?>
                    <? if($noticia->noticia_representante == 1)print " (Representante) " ?>
                   
                   
                </div>
            </div>
          	<div style="width:50px; text-align:center;">
				<? if($noticia->noticia_status == 1){ 
                    print '<img src="'.site_url().'images/admin/ok-l.png" width="21" height="18" />';} ?>
            </div>
            <div style="width:60px; text-align:center;">
				<? if($noticia->noticia_destaque == 1){ 
                    print '<img src="'.site_url().'images/admin/ok-l.png" width="21" height="18" />';} ?>
            </div>        
          	<div style="width:90px; text-align:center;">
                  
                  <a href="<?= site_url('admin/noticias/editar/'.$noticia->noticia_id) ?>" class="bt-editar" alt="Editar" title="Editar"></a> 
                  <a href="<?= site_url('admin/noticias/excluir/'.$noticia->noticia_id) ?>" class="bt-excluir" alt="Excluir" title="Excluir"></a>
          	</div>
          </li>
        
        
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>  
      
	
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
    
	</div>
    
    








    	
<? include('footer_view.php'); ?>