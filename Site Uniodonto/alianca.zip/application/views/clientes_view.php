<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('clientes') ?>
</div>
<div class="conteudo-left">
    <div class="texto">
    	<h1><?= $this->lang->line('clientes') ?></h1>
		<?php
			//pega imagens no diretório 
			$imgs = glob("upload/clientes".'/*.jpg');
			//abre array e mostra as imagens
			foreach($imgs as $img){
				print '<div class="cliente">';
				
				print '<img src="'.site_url($img).'" width="71" height="46"/>';
				
				print "</div>";
				
			}
			
			
		?>
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>