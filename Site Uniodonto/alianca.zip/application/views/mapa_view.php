<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?= $this->lang->line('title') ?></title>
</head>
<body onload="initialize()">

		        
<script type="text/javascript"src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript">
  function initialize() {
    var latlng = new google.maps.LatLng(<?=$mapa?>);
    var myOptions = {
      zoom: 18,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
    };
    var map = new google.maps.Map(document.getElementById("map_canvas"),
        myOptions);
		
	  var image = '<?=site_url()?>images/admin/logo-icon.png';
	  var myLatLng = new google.maps.LatLng(<?=$mapa?>);
	  var beachMarker = new google.maps.Marker({
		  position: myLatLng,
		  map: map,
		  icon: image,
   	  	  title:"Uniodonto"
	  });
   
		
	
  }

</script>

        <div class="mapa" style="height:420px;"> 
        	<div id="map_canvas" style="width:700px; height:400px;></div>
        </div>    
		
	
    </div>
    
    <div class="push"></div>

</body>
