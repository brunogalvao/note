</div>
</div>
    <div class="rodape">
        <div class="conteudo-rodape">
        	<span style="width:160px;">
            	<a href="<?= site_url()?>"><img src="<?= site_url()?>images/logo-rodape_<?= $this->session->userdata("idioma")?>.png" alt="<?= $this->lang->line('title');?>" border="0"></a>
            <div style="margin-top:160px;">
            	<a href="http://www.ocepar.org.br/"><img src="<?= site_url()?>images/icons/ocepar.jpg" border="0"></a>
                <a href="http://www.ans.gov.br/"><img src="<?= site_url()?>images/icons/logo_ans.jpg" border="0"></a><br />
                <a href="<?= site_url()?>pagina/37/portal+tiss"><img src="<?= site_url()?>images/icons/tiss.jpg" border="0"></a>
            </div>                   
            </span>
            <span>
            	<div class="tel">
                    <h1><?= $this->lang->line('tel_atendimento');?></h1>
                    <p><?= $this->lang->line('atendimento_ao_beneficiario');?></p>
                </div>
                <div class="tel">
                    <h1><?= $this->lang->line('tel_24h');?></h1>
                    <p><?= $this->lang->line('uniodonto_24h');?></p>
                </div>
                <div class="tel">
                    <h1><?= $this->lang->line('tel_dental');?></h1>
                    <p><?= $this->lang->line('dental_uni');?></p>
                </div>
            </span>
            <span>
            	<ul class="map-site">
                <li style="display: inline-block; float: left;">
       	 		<ul>
                    <li><h2><?= $this->lang->line('a_uniodonto');?></h2></li>
                    <? foreach($menu_uniodonto as $uniodonto){ ?>
                       <li><a href="<?= site_url()?>pagina/<?=$uniodonto->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($uniodonto->texto_titulo))?>"><?=utf8_decode(ucfirst($uniodonto->texto_titulo))?></a></li>
                    <? } ?>
                </ul>
        		<ul>
                    <li><h2><?= $this->lang->line('dental_uni');?></h2></li>
                    <? foreach($menu_dental as $dental){ ?>
                         <li><a href="<?= site_url()?>pagina/<?=$dental->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($dental->texto_titulo))?>"><?=utf8_decode(ucfirst($dental->texto_titulo))?></a></li>
                    <? } ?>
                    <li><a href="http://www.dentaluni.com.br/" target="_blank"><?= $this->lang->line('loja_virtual');?></a></li>
                </ul>
                </li>
                <li style="display: inline-block; float: left;">
                <ul>
                    <li><h2><?= $this->lang->line('planos');?></h2></li>
                    <? foreach($menu_planos as $planos){ ?>
                       <li><a href="<?= site_url()?>pagina/<?=$planos->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($planos->texto_titulo))?>"><?=utf8_decode(ucfirst($planos->texto_titulo))?></a></li>
                    <? } ?>
        		</ul>
                </li>
                <li style="display: inline-block; float: left;">
                <ul>
                 	<li><a href="<?=site_url('encontreseudentista') ?>"><h2><?= $this->lang->line('encontre_seu_dentista');?></h2></a></h2></li>
                </ul>
        
               	<ul>
                    <li><h2><?= $this->lang->line('uniodonto_24h');?></h2></li>
                    <? foreach($menu_clinica as $clinica){ ?>
                        <li><a href="<?= site_url()?>pagina/<?=$clinica->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($clinica->texto_titulo))?>"><?=utf8_decode(ucfirst($clinica->texto_titulo))?></a></li>
                    <? } ?>
                </ul>
        
                <ul>
                    <li><a href="<?=site_url('historico') ?>">
                    <h2><?= $this->lang->line('noticias');?></h2></a></li>
                </ul>
        
                <ul>
                    <li><h2><?= $this->lang->line('contato');?></h2></li>
                    <li><a href="<?= site_url('localizacao')?>"><?= $this->lang->line('localizacao');?></a></li>
                    <li><a href="<?= site_url('contato')?>"><?= $this->lang->line('fale_conosco');?></a></li>
                    <li><a href="<?= site_url("trabalheconosco/colaborador")?>"><?= $this->lang->line('trabalhe_conosco');?></a></li>
                   <? foreach($menu_contato as $contato){ ?>
                            
                        <li><a href="<?= site_url()?>pagina/<?=$contato->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($contato->texto_titulo))?>"><?=utf8_decode(ucfirst($contato->texto_titulo))?></a></li>
                   <? } ?>
                </ul>
                <ul>
                    <li><h2><?= $this->lang->line('redes_sociais');?></h2></li>
                    <li><a href="http://www.facebook.com/uniodontocuritiba" target="_blank"><img src="<?= site_url()?>images/bt-facebook.png" alt="Facebook" border="0" style="margin-bottom:-4px;"></a> 
                       <div id="fb-root" =></div>
						<script>(function(d, s, id) {
                          var js, fjs = d.getElementsByTagName(s)[0];
                          if (d.getElementById(id)) return;
                          js = d.createElement(s); js.id = id;
                          js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
                          fjs.parentNode.insertBefore(js, fjs);
                        }(document, 'script', 'facebook-jssdk'));</script>
                       <div class="fb-like" data-href="http://www.facebook.com/uniodontocuritiba" data-send="false" data-layout="button_count" data-width="450" data-show-faces="true"></div>
                    </li>
                    
                </ul>
                
                </li>
                </ul>
            
            </span>
        
        </div>
        <div class="rodape-icones">
            <span class="ans">
                <img src="<?= site_url()?>images/ans.png">
            </span>
            <span class="idioma-rodape">
            <?= $this->lang->line('alterar_idioma');?>
            <a class="categoria idioma" href="<?= site_url("site/trocaidioma/ptBR")?>"><img  src="<?= site_url()?>images/icons/brasil_16x16.png" border="0" /></a>
            <a class="categoria idioma" href="<?= site_url("site/trocaidioma/es")?>"><img  src="<?= site_url()?>images/icons/spain_16x16.png" border="0" /></a>
            <a class="categoria idioma" href="<?= site_url("site/trocaidioma/en")?>"><img  src="<?= site_url()?>images/icons/eua_16x16.png" border="0" /></a>
            
            </span>
        </div>
    </div>
    
<style>
.galleria-lightbox-overlay{
	z-index:9999999;
}
.galleria-lightbox-box{
	z-index:99999999;
}

</style>	
	
   
    
</body>
</html>
