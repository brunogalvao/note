<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('encontre_seu_dentista') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1><?= $this->lang->line('encontre_seu_dentista') ?></h1>
	<div>
	<p><?= $this->lang->line('texto_encontre_seu_dentista') ?></p><br />
	</div>
	<div class="encontreseudentista">
    <script type="text/javascript">
        $(document).ready(function(){
			
            $('#estadoDentista').change(function(){
                $('#cidadeDentista').load('<?=site_url()?>retorna_estados/'+$('#estadoDentista').val() );

            });
			 $('#especialidadeDentista').load('<?=site_url()?>retorna_especialidades').val();
			 $('#cidadeDentista').load('<?=site_url()?>retorna_estados/17').val();
			
		$("#btn_buscar").click(function(event) {
				
				if(($("#croDentista").val() != "")  || ($("#nomeDentista").val() != "") || ($("#cidadeDentista").val() != "0" || ($("#especialidadeDentista").val() != "0")) ){
						$("#dentistaForm").submit();
						$("#error").html("");
				}else{
					$("#error").html("<?= $this->lang->line('para_efetuar_a_busca_preencha_pelo_menos_um_dos_campos
') ?>");
					
				}
		   
			});
        });

    </script>
	<form name="dentistaForm" id="dentistaForm" action="<?= $link_sistema ?>EncontreSeuDentista.do" method="POST" target="POPUPW">
	   	<div class="form" style="padding-bottom: 15px;">
            <label>CRO</label>           
            <input type="text" name="croDentista" id="croDentista"/>
            
        	<label><?= $this->lang->line('nome') ?></label>
            <input type="text" name="nomeDentista" id="nomeDentista" />
            
            	<span style="display: inline-block;">
                    <label><?= $this->lang->line('estado') ?></label>            
                    <select name="estadoDentista" id="estadoDentista">
                            <option value="1">AC</option>
                            <option value="2">AL</option>
                            <option value="4">AM</option>
                            <option value="3">AP</option>
                            <option value="5">BA</option>
                            <option value="6">CE</option>
                            <option value="7">DF</option>
                            <option value="8">ES</option>
                            <option value="10">GO</option>
                            <option value="11">MA</option>
                            <option value="14">MG</option>
                            <option value="13">MS</option>
                            <option value="12">MT</option>
                            <option value="15">PA</option>
                            <option value="16">PB</option>
                            <option value="18">PE</option>
                            <option value="19">PI</option>
                            <option value="17" selected>PR</option>
                            <option value="20">RJ</option>
                            <option value="21">RN</option>
                            <option value="23">RO</option>
                            <option value="9">RR</option>
                            <option value="22">RS</option>
                            <option value="25">SC</option>
                            <option value="27">SE</option>
                            <option value="26">SP</option>
                            <option value="24">TO</option>    
                    </select>
            	</span>
                <span style="display: inline-block;">
                	<label><?= $this->lang->line('cidade') ?></label>            
            		<select name="cidadeDentista" id="cidadeDentista"></select>
                </span>
            
            
        
            <label><?= $this->lang->line('bairro') ?></label>            
            <input type="text" name="bairroDentista" />

            <span style="display: inline-block;">
                <input type="radio" value="E" name="dentista.tipoEspecialidade">
                <font style="font-size: 9.3px"><?= $this->lang->line('especialidade') ?></font>
                <input type="radio" value="A" name="dentista.tipoEspecialidade">
                <font style="font-size: 9.3px"><?= $this->lang->line('area_de_atuacao') ?></font><br />       
                <select name="especialidadeDentista" id="especialidadeDentista"></select>
            </span>
            <span style="display: block; padding-bottom: 15px;">
                 
                <input type="checkbox" name="mostrarLiberacaoOnlineDentista" /><?= $this->lang->line('liberacao_online') ?>
            </span> 
            <div id="error" style="padding: 5px; color:#af2638;"></div>
            <input type="button" id="btn_buscar" value="<?= $this->lang->line('buscar') ?>" class="btn-submit" style="padding-top:0px;" />   
        </div>
    </form>
        
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>