<div class="login-popup" id="login-popup">
<div style="width:1000px; text-align:left; margin: auto;">
	<div id="beneficiario" style="display:none;">
    	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?associado=true&title=Beneficiario" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        


	<div id="empresa" style="display:none;">
	   	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?empresa=true&title=Empresa" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        

	<div id="dentista" style="display:none;">
    	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?cooperado=true&title=Cooperado" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        

	<div id="uniodonto" style="display:none;">
    	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?uniodonto=true&title=Uniodonto" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        

	<div id="colaborador" style="display:none;">
    	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?colaborador=true&title=Colaborador" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        

	<div id="representante" style="display:none;">
    	<iframe width="1000" scrolling="no" height="180" frameborder="0" src="http://unioweb.uniodontocuritiba.com.br/Uniodonto/LogonSite.do?vendedor=true&title=Representante" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>	
	</div>        
</div>
</div>


