<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rio status das guias
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>

<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rio faturamento interc�mbio</h1>
		          
<script>
	function loadChartFaturamento(){
		xmlHttpFaturamento=GetXmlHttpObject();

		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar-faturamento','uniodonto','<?=site_url("site/serverRequest")?>', xmlHttpFaturamento, 	document.getElementById('mesFiltroFaturamento').value );

	}

</script>
</head>
<body onload="loadChartFaturamento()">
	<div class="desc-relatorio">
	Este relat&oacute;rio consiste em apresentar o faturamento dos interc&acirc;mbios externos, somando as notas emitidas para uniodonto logada<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>
	<label>&Uacute;ltimos
		<select id="mesFiltroFaturamento" name="mesFiltroFaturamento" class="style2" onchange="loadChartFaturamento()">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>


			<div id="graficoFaturamento" align="center" class="chartClass"></div>

<script type="text/javascript">

function semDados(chartName, msg){
	document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>"+msg+"</b><br>( Nenhum dado foi encontrado. )</p>"
}

function buildChartFaturamento( id, xml ) {
	if( id=="bar" ) {
		var chart = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId", "710", "510");
		chart.setDataXML(xml);
		chart.addParam("wMode","transparent");
		chart.render("graficoFaturamento");

		jQuery("#graficoFaturamento").fancybox({
				'autoDimensions':	false,
				'autoScale'		: 	false,
				'scrolling'		: 'auto',
				'href'			: "<?=site_url()?>js/aba_uniodonto/chart/details/chartDetails.html",
				'width'			:750,
				'height'		:600,
				'onComplete'	:	function() {
					  					jQuery("#ChartId").hide();

					  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId2", "700", "400");
					  					chartZoom.setDataXML(xml);
					  					chartZoom.render("content");
									},
				'onCleanup' : function(){
					jQuery("#ChartId").show();
				}
			});


	}
}

</script>

	</div>
         
    
 
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>