<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rio atendimentos por especialidade
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>

<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rio atendimentos por especialidade</h1>
		          
<script>

	function loadCharts() {
		xmlHttpPie = GetXmlHttpObject();

		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'pie' ,'empresa','<?=site_url("site/serverRequest")?>', xmlHttpPie, 	document.getElementById('mesFiltroEspec').value );
	}

	function loadChartsEspec(){
		xmlHttpPie=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'pie' ,'empresa','<?=site_url("site/serverRequest")?>', xmlHttpPie, 	document.getElementById('mesFiltroEspec').value );
	}



	function XmlObject(name, value, color){
		this.name=name;
		this.value=value;
		this.percentage=0;
		this.color=color;
	}

	function calcPercentages(listXmlObject, total){
		$(listXmlObject).each(function(index, obj){
			obj.percentage = Math.round( parseFloat(parseFloat((parseFloat(obj.value) * parseFloat(100))) / parseFloat(total)));
		});
		return listXmlObject;
	}

	function extractSets(xml){
		var listXmlObject = new Array();
		var sum = 0;
		$(xml).find("set").each(function(index, value){
			obj = new XmlObject($(value).attr("name"), $(value).attr("value"), $(value).attr("color"));
			listXmlObject.push(obj);
			sum = (sum + ($(value).attr("value")*1)*1);
		});
		listXmlObject = calcPercentages(listXmlObject, sum);

		return listXmlObject;
	}

	function generateTablePie(xml){
		var xmlData;

		if(jQuery.browser.msie){
			xmlData = new ActiveXObject("Microsoft.XMLDOM");
			xmlData.loadXML("<a>"+xml+"</a>");
		}else{
			xmlData = $("<a>"+xml+"</a>");
		}
		xml = xmlData;


		var listXmlObject = extractSets(xml);

		var html = $("#chartPieTable")[0];
		var trDefault = $(html).find("tbody tr")[0];
		$(html).find("tbody").html(trDefault);
		var sum = 0;


		$(listXmlObject).each(function(index, obj){
			var trExample = $(html).find("tbody tr")[0];
			var tr = $(trExample).clone();

			sum = sum + obj.value*1;

			$(tr).find("#cor").css('backgroundColor', '#'+obj.color);
			$(tr).find("#name").html(obj.name);
			$(tr).find("#value").html(obj.value);
			$(tr).find("#percentage").html(obj.percentage+"%");
			$(tr).show();
			$(tr).appendTo($(html).find("tbody"));
		});

		var trFoot = $(html).find("tfoot tr")[0];
		$(trFoot).find("#totalQtde").html(sum);

		if($(listXmlObject).size() > 0){
			$("#chartPieDivTable").show();
		}else{
			$("#chartPieDivTable").hide();
		}

	}

</script>
</head>
<body onLoad="loadCharts()">
	<div class="desc-relatorio">
        Este relat&oacute;rio consiste em apresentar a quantidade de atendimentos por especialidade no per&iacute;odo selecionado.<br/>
		Dados considerados at&eacute; &uacute;ltimo fechamento.
    </div>
	<label>&Uacute;ltimos
		<select id="mesFiltroEspec" name="mesFiltroEspec" class="style2" onChange="loadChartsEspec();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
		meses</label>


			<div id="chartPie3D" align="center"></div>
			<div id="chartPieDivTable" style="display: none;">
				<table id="chartPieTable" width="98%" style="border: 1px solid #CCC; background-color: white; color: #333;" cellpadding="0" cellspacing="0">
					<thead>
						<tr >
							<th width="5%" style="border-right: 1px solid #CCC; text-align: center;" >&nbsp;</th>
							<th width="40%" style="border-right: 1px solid #CCC; text-align: center;" >Especialidade</th>

							<th width="25%" style="border-right: 1px solid #CCC; text-align: center;">Quantidade</th>
							<th width="30%" style="text-align: center;" >Porcentagem</th>
						</tr>
					</thead>
					<tbody>
						<tr style="display:none;">
							<td id="cor" width="5%" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC;">&nbsp;</td>
							<td id="name" width="40%" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC;"></td>

							<td id="value" width="25%" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: center;"></td>
							<td id="percentage" width="30%" style="border-top: 1px solid #CCC; text-align: center;"></td>
						</tr>
					</tbody>
					<tfoot>
						<tr>
							<td style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: right;" colspan="2">
								<b>TOTAL</b>&nbsp;&nbsp;&nbsp;&nbsp;

							</td>
							<td id="totalQtde" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: center;">&nbsp;
								
							</td>
							<td style="border-top: 1px solid #CCC; text-align: center;">
								100%
							</td>
						</tr>

					</tfoot>

				</table>

</div>

            <script type="text/javascript">

                   function semDados(chartName, msg){
                   		document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>"+msg+"</b><br>( Nenhum dado foi encontrado. )</p>"
                   }

                   function buildChart( id, xml ) {

                   		if( id=="pie" ) {
				   			if( (xml==-1) ){
				   				semDados("chartPie3D", "Especialidades atendidas em 6 meses.");
				   				$("#chartPieDivTable").hide();
				   				//jQuery("#chartPie3D").hide();
				   			}else{
				   				jQuery("#chartPie3D").show();
				   				var chart = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Pie3D.swf", "chartPie3DId", "400", "210", "0", "0");
				   				chart.addParam("wMode","transparent");
				   				chart.setDataXML( xml);
				   				chart.render("chartPie3D");
				   				$("#chartPieDivTable").show();
				   				generateTablePie(xml);

				   				jQuery("#chartPie3D").fancybox({
					  				'autoDimensions':	false,
					  				'autoScale'		: 	false,
					  				'scrolling'		: 'auto',
					  				'href'			: "<?=site_url()?>js/empresa/chart/details/chartDetails.html",
					  				'width'			:750,
					  				'height'		:600,
					  				'onComplete'	:	function() {
										  					jQuery("#chartPie3DId").hide();

										  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Pie3D.swf", "ChartId", "684", "398");
															xml = xml.replace("100","200");
															chartZoom.setDataXML(xml);
															chartZoom.render("content");

															$("#tabelaChartDetails").html($("#chartPieTable").clone().attr("width","98%").attr("align","center"));
										  				},
					  				'onCleanup' : function(){
					  					jQuery("#chartPie3DId").show();
					  				}
					  			});





				   			}
				   		}
					}
				</script>


         
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>