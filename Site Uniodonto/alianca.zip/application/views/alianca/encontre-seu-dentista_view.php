
<div class="conteudo"> 
	<div>

  		  <iframe width="870" scrolling="auto" height="2000" class="iframe" src="http://www2.uniodonto.com.br" name="Encontre seu Dentista" id="blockrandom" onload="iFrameHeight()"></iframe>
          <script type="type/javascript">
			var blockrandom = (document.getElementById("blockrandom").contentWindow || document.getElementById("blockrandom").contentDocument);
			
			if (blockrandom.document) {
				blockrandom = blockrandom.document;
			}
			
			// FINALMENTE, ACESSO AO DOM DO IFRAME
			
			blockrandom.body.style.backgroundColor = "#FF0000";
		 </script>
  </div>
</div>
