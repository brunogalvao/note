<div class="busca-dentista">
	<div>
    	<a href="<?=site_url()?>alianca/encontreseudentista">
    	<h1>Rede credenciada</h1>
        <p>Clique aqui para encontrar o dentista mais perto de voc&ecirc;</p>
        </a>
    </div>

</div>
<div class="home">
   	<div class="bloco">
    	<div class="promocao">
        	<h1>30</h1>
            <h2>DIAS</h2>
            <h3>GR&Aacute;TIS</h3>
            <h4>*Para atendimentos de urg&ecirc;ncia</h4>
        </div>
        <div class="preco">
        	<span class="preco1">Plano avan&ccedil;ado</span>
            <span class="preco2">R$</span>
            <span class="preco3">10,</span>
            <span>
            	<p class="preco4">00</p>
            	<p class="preco5">Mensais por pessoa</p>
            </span>
            
        </div>
    </div>
    <div class="bloco botoes">
    	<div class="contratar">
	        <a href="<?= site_url("alianca/contratar") ?>">Contratar agora</a>
        </div>
        <div class="contratei">
			<h1>J&aacute; contratei</h1>
           	<a href="#">Consultar status</a>
            <a href="#">Enviar formul&aacute;rio assinado</a>
        </div>
        
    </div>
    <div class="bloco procedimentos">
		<span class="maior">176</span>
        <span class="menor">Procedimentos<br /> cobertos pelo plano</span>
    </div>
    <div class="bloco texto">
        A Uniodonto e a Alian&ccedil;a em parceria oferecem o melhor plano odontol&oacute;gico para voce sorrir.</div>
	
</div>
