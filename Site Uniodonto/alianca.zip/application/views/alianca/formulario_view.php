<script type="text/javascript">
	var dados;
	$(document).ready(function($){
		$.ajax({

			url : "http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_contratos?CHAVE_ACESSO=MDAwMQ==",

			dataType : "xml",

			success : function(xml){
				$("#carregando").hide();
				$("#formulario").show();
				dados = xml;
				$(dados).find("ModeloContrato").each(function(){
					$("#instituicao").append(
						'<option value="'+$(this).find('Codigo_Contrato').text()+'-'+$(this).find('Numero_SubContrato').text()+'">'+$(this).find('Nome_Completo').text()+'</option>');
				});
				
			}
		});
		
	
		
		
	});
	
</script>
<div class="conteudo1">
	<div id="carregando">
    	Carregando...<br />
    	<img src="<?=site_url("images/alianca/ajax-loader.gif")?>"  />
    </div>
    <div id="formulario" style="display:none;">
		<h1>Selecione sua institui&ccedil;&atilde;o</h1>
   	  <form method="post" action="">
        	<div class="select-instituicao">
        	<select id="instituicao" name="instituicao">
            
            </select>
            </div>
		
            <input type="submit" value="Continuar" class="bt-continuar" />

        </form>
  	</div>

</div>
