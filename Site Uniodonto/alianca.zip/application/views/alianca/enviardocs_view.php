<script src='<?= site_url()?>js/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>

<div class="conteudo1">
	<div class="cadastrado">
        <h1>Enviar documentos</h1>
		
        <form method="post" enctype="multipart/form-data">

            Proposta
            <input type="file" class="multi" accept="jpg|jpeg" name="proposta[]" />
			<? if(isset($cadastro->alianca_copia_contrato) and $cadastro->alianca_copia_contrato != "") print "OK" ?><br />
            RG
            <input type="file" name="rg" />
            <? if(isset($cadastro->alianca_copia_rg) and $cadastro->alianca_copia_rg != "") print "OK" ?><br />
            CPF
            <input type="file" name="cpf" />
            <? if(isset($cadastro->alianca_copia_cpf) and $cadastro->alianca_copia_cpf != "") print "OK" ?><br />
            Comprovante de vinculo
            <input type="file" name="vinculo" />
            <? if(isset($cadastro->alianca_copia_vinculo) and $cadastro->alianca_copia_vinculo != "") print "OK" ?><br />
            Residencia
            <input type="file" name="residencia" />
            <? if(isset($cadastro->alianca_copia_residencia) and $cadastro->alianca_copia_residencia != "") print "OK" ?><br />
            Termo de posse
            <input type="file" name="posse" />
            <? if(isset($cadastro->alianca_copia_posse) and $cadastro->alianca_copia_posse != "") print "OK" ?><br />
            
            <input type="submit" value="Salvar documentos" class="bt-continuar" />
        </form>
	</div>    


</div>

	
