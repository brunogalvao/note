<div class="conteudo"> 
	<div>
	  <h5>O que fazer para ser atendido (a) na Rede Cooperada e marcar a primeira consulta? </h5>
      <p> Atrav&eacute;s do Guia do Benefici&aacute;rio ou do site da Uniodonto Curitiba voce encontrar&aacute; a listagem dos cirurgioes-dentistas cooperados e conforme a sua preferencia, de especialidade ou localidade, poder&aacute; agendar seu atendimento direto no consult&oacute;rio particular do profissional escolhido, personalizado e com hora marcada. </p>
      <h5>A Uniodonto tem algum controle do meu tratamento? Tem algum Controle de Qualidade?</h5>
      <p> A Uniodonto Curitiba possui um sistema online, o Unioweb, capaz de integrar o benefici&aacute;rio, o cirurgiao-dentista e a Uniodonto. &Eacute; atrav&eacute;s do sistema que o cooperado realiza toda a libera&ccedil;ao do tratamento e seus procedimentos, e alimenta o prontu&aacute;rio virtual do benefici&aacute;rio. Em alguns casos poder&aacute; ser solicitado avalia&ccedil;oes iniciais, no decorrer do tratamento ou finais, a fim de garantir a qualidade do procedimento realizado no benefici&aacute;rio. A Uniodonto tamb&eacute;m se diferencia por garantir por 1 ano todo procedimento odontol&oacute;gico. </p>
      <h5>A Uniodonto tem interesse em saber se eu fiquei satisfeito(a) com o tratamento?</h5>
      <p> Um dos principais objetivos da Uniodonto Curitiba &eacute; a presta&ccedil;ao de um servi&ccedil;o de qualidade que traga sa&uacute;de e bem-estar. Para garantir a satisfa&ccedil;ao de seus benefici&aacute;rios, a Uniodonto Curitiba disponibiliza em seu site canais para envio de sugestoes e d&uacute;vidas, o Servi&ccedil;o de Atendimento ao Benefici&aacute;rio via telefone (41) 3371-1900, al&eacute;m de pesquisas de satisfa&ccedil;ao, que podem ser preenchidas em qualquer recep&ccedil;ao das nossas Unidades de Atendimento. Para empresas, existem projetos de pesquisa de satisfa&ccedil;ao, realizadas de acordo com a necessidade do benefici&aacute;rio, para sua plena satisfa&ccedil;ao. </p>
      <h5>A Uniodonto tem alguma recomenda&ccedil;ao espec&iacute;fica em rela&ccedil;ao as consultas?</h5>
      <p> Em todas as consultas o benefici&aacute;rio dever&aacute; levar o seu cartao Uniodonto e um documento com foto. O cartao Uniodonto &eacute; o documento de identifica&ccedil;ao do benefici&aacute;rio, 
        emitido pela Uniodonto e indispens&aacute;vel para o atendimento em qualquer parte do Brasil. </p>
      <h5>H&aacute; limites para o n&uacute;mero de consultas ou tratamentos?</h5>
      <p> Nao h&aacute; limite de utiliza&ccedil;ao. </p>
      <h5>Existe garantia para os tratamentos realizados pela rede cooperada Uniodonto?</h5>
      <p> Sim, garantia de um ano para todos os procedimentos realizados. </p>
      <h5>Qual a finalidade das radiografias solicitadas pela Uniodonto na realiza&ccedil;ao de meus tratamentos? </h5>
      <p> As radiografias solicitadas pelos dentistas da Uniodonto sao necess&aacute;rias para um levantamento mais preciso das necessidades de tratamentos a ser realizados.  Dependendo do tratamento a radiografia &eacute; essencial como referencial para o dentista para a realiza&ccedil;ao dos procedimentos e ap&oacute;s a sua conclusao para verificar a qualidade. </p>
      <h5>Por que devo ir ao dentista regularmente e qual a periodicidade indicada?</h5>
      <p> Quando voce cuida da sa&uacute;de da sua boca est&aacute; cuidando da sua sa&uacute;de e do seu bem-estar como um todo. Uma boca saud&aacute;vel e uma adequada rotina de cuidados bucais levarao a resultados positivos, prevenindo problemas futuros e permitindo que voce tenha sempre um belo sorriso.  Para isso os dentistas recomendam uma consulta a cada seis meses. </p>
      <a name="parcelamento"></a>
      <h5>Como parcelar meus atos nao cobertos?</h5>
      <p> O parcelamento de atos nao cobertos pode ser feito em at&eacute; 12x sem juros nos cartoes MasterCard e Visa, com o valor m&iacute;nimo de R$30,00 por parcela. </p>
    </div>
</div>

