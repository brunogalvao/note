<script>
	$(function() {
		$("#tabs" ).tabs();
		$(".form").validationEngine();
		$("#formtitular").submit(function(e){
			if($("#matricula").val() == ""){
				e.preventDefault();
				alert("Digite a matricula");
				}else{
					$("#matriculatit").val($("#matricula").val());
					$("#codplano").val($("#plano").val());
					}
			});
		$("#formpagamento").submit(function(e){
			if($("#formaPagamento").val() == 2){
				if($("#matricula").val() != $("#matriculaSiape").val()){
					e.preventDefault();
					alert("A matricula do pagamento deve ser a mesma do titular!");
					}
				
				}
		});
		

	
	});

		
		
</script> 
<? 	$dados = $this->session->userdata('dados_plano'); 
	if($this->session->userdata("dados_titular")){
		$titular = $this->session->userdata("dados_titular");
	}
?>

<div class="conteudo">
	<form method="post" action="<?= site_url("alianca/site/salvar_contrato/")?>" class="form">
    <div class="salvar">
    	<span>
			<p>
			<?= $this->session->userdata("dados_titular") ? '<img src="'.site_url("images/alianca/v-etapa.png").'" border="0" >' : '<img src="'.site_url("images/alianca/x-etapa.png").'" border="0" >'; ?> Cadastro titular do plano
        	</p>    
        </span>
        <span>
			<p>
			<?= $this->session->userdata("dados_cobranca") ? '<img src="'.site_url("images/alianca/v-etapa.png").'" border="0" >' : '<img src="'.site_url("images/alianca/x-etapa.png").'" border="0" >'; ?> Cadastro forma de pagamento
        	</p>
        </span>
    	<span>
    	<? if($this->session->userdata("dados_titular") and $this->session->userdata("dados_cobranca")){ ?>
        	<input type="submit" value="Salvar contrato" class="bt-continuar" />
        <? }else{ ?>
        	<input type="button" value="Salvar contrato" class="bt-continuar-cinza" />
        <? } ?>
        </span>
    </div>
</div>
<div class="conteudo">    
	<div class="instituicao">
    	<b> <?= $dados["Nome_Completo"] ?></b><a href="<?= site_url("alianca/site/altera_instituicao/")?>">Alterar</a>
        <input type="hidden" name="convenio" value="<?= $dados["Nome_Reduzido"] ?>" />
    </div>
   	<div class="vigencia">
		Vig&ecirc;ncia: <?= $dados["Data_Vigencia"] ?>
        <input type="hidden" name="vigencia" value="<?= $dados["Data_Vigencia"] ?>" />
    </div>
     
    
    <div class="plano">
    	<span>
            Plano
            <div class="select" >
                <select <? if(isset($titular))print "disabled" ?> name="plano" id="plano" >
                <? foreach($dados["Planos_Contrato"]["Planos"] as $plano){ ?>
                    <option value="<?= $plano["Codigo"] ?>" <? if(isset($titular)){if($plano["Codigo"] == $titular["codplano"]) print 'selected="selected"'; }?>><?= $plano["Descricao"] ?></option>
                <? } ?> 
                </select>
            </div>
        </span>
        <span style="display: block;">
                Matr&iacute;cula<br />
                <input type="text" name="matricula" id="matricula" class="input matricula" <? if(isset($titular)){ ?> value="<?= $titular["matricula"] ?>" <? } ?>  <? if(isset($titular))print 'readonly="readonly"' ?>>
        </span>
        <span >
            <? if(count($dados["Lotacoes"]) != 0){  ?>
            Lota&ccedil;&atilde;o
            <div class="select-pequeno" >
            <select name="lotacao">
            <? foreach($dados["Lotacoes"]["Lista"] as $lotacao){ ?>
                <option value="<?= $lotacao["Codigo"] ?>"><?= $lotacao["Descricao"] ?></option>
            <? } ?> 
            </select>
            </div>
            <? } ?>
        </span>
	
    </div>
</div>  
<div class="conteudo2">     
    
    </form>
    <div id="demonstrativo">
    	<h1>Demonstrativo</h1>
    	<table id="tbl_demonstrativo" cellpadding="0" cellspacing="0">
            <tr class="titulo">
                <td style="text-align: center;">Excluir</td><td>Tipo</td><td>Nome</td><td>Parentesco</td><td>Idade</td><td>CPF</td><td>Mensalidade</td>
            </tr>    
                <?
				 $total_mensalidade = "";		
				 if(isset($titular)){ ?>
                	<tr class="linha"><td style="text-align: center;"><a href="<?= site_url("alianca/site/excluirtitular")?>"><img src="<?= site_url("images/alianca/bt-remover.png")?>" border="0" ></a></td><td>T</td><td><?= $titular["nome"] ?></td><td>Titular</td><td><?= $titular["idade"] ?></td><td><?= $titular["cpf"] ?></td><td>R$ <?= str_replace(".",",",$titular["mensalidade"][0]); ?></td></tr>
                <? $total_mensalidade = $titular["mensalidade"][0];} ?>
                <? if($this->session->userdata("dados_dependentes")){
					$i =0;
					foreach($this->session->userdata("dados_dependentes") as $dependentes){
					$total_mensalidade = $total_mensalidade + $dependentes["mensalidade"][0];
				?>
                	<tr class="linha">
                    <td style="text-align: center;"><a href="<?= site_url("alianca/site/excluirbeneficiario/".$i)?>"><img src="<?= site_url("images/alianca/bt-remover.png")?>" border="0" ></a></td>
                    <td>D</td>
                    <td><?= $dependentes["nome"] ?></td>
                    <td>
                    	<?  foreach($parentesco["GrauParentesco"] as $GrauParentesco){ 
								if($GrauParentesco->Codigo == $dependentes["parentesco"]){
									print $GrauParentesco->Descricao;
									
									}
							}
						?>

                    </td>
                    <td><?= $dependentes["idade"] ?></td>
                    <td><?= $dependentes["cpf"] ?></td>
                    <td>R$ <?= str_replace(".",",",$dependentes["mensalidade"][0]) ?></td>
                    </tr>
                <? $i++;} } ?>
            </tr>
            <tr>
                <td colspan="7" style="text-align:right; color:#fff; font-weight:bold;">Total: R$ <?= str_replace(".",",",$total_mensalidade)?> </td>
            </tr>
        </table>
        
    </div>
    <div id="dadoscobranca">
     	<? if($this->session->userdata("dados_cobranca")){
			$dados_cobranca = $this->session->userdata("dados_cobranca");	
			
		?>
        <table cellpadding="0" cellspacing="0">
        	<tr class="titulo">
            	<td>Forma de pagamento</td>
                <td>Banco</td>
                <td>Ag&ecirc;ncia</td>
                <? if($dados_cobranca['operacao'] != ""){ ?>
                <td>Opera&ccedil;&atilde;o</td>
                <? } ?>
                <td>Conta</td>
            </tr>
            <tr class="linha">
            	<td><?= $dados_cobranca['formaPagamento']= 2 ? 'CONSIGNACAO EM FOLHA' : 'D�BITO EM CONTA'; ?></td>
                <td>
                		<?  foreach($dados["Formas_Pagamento"]["FormaPagamento"][1]["Bancos"]["Bancos"] as $banco){ 
								if($dados_cobranca['banco'] == $banco["Codigo"]){
									print $banco["Descricao"];
									
									}
							}
						?>
                </td>
                <td><?= $dados_cobranca['agencia'] ?>-<?= $dados_cobranca['digitoAgencia'] ?></td>
                <? if($dados_cobranca['operacao'] != ""){ ?>	
                <td><?= $dados_cobranca['operacao'] ?></td>
                <? } ?>
                <td><?= $dados_cobranca['conta'] ?>-<?= $dados_cobranca['digitoConta'] ?></td>
            </tr>
        </table>    
        <? } ?>
    </div>
    
    
</div>  
<div class="conteudo">      
    
    <div id="tabs" class="formulario">
        <div class="menu-tabs">
            <ul>
                <li><a href="#tab-1"><img src="<?= site_url("images/alianca/bt-add-beneficiario.png") ?>" border="0" />Adicionar benefici&aacute;rio</a></li>
                <? if(isset($titular)){ ?>
                <li><a href="#tab-2"><img src="<?= site_url("images/alianca/bt-pagamento.png") ?>" border="0" />Adicionar dados para cobran&ccedil;a</a></li>
                <? } ?>
            </ul>
        </div>
    
    <? if(!$this->session->userdata("dados_titular")){ ?>
    	<div id="tab-1">
            <h2>Dados do titular</h2>
            <form method="post" id="formtitular" class="form" action="<?= site_url("alianca/site/salvatitular/")?>">
           	<input type="hidden" name="matricula" id="matriculatit" />
            <input type="hidden" name="codplano" id="codplano" />

            <span>
                CPF<br />
                <input  id="cpf" class="validate[required] cpf input" name="cpf" type="text" onblur="validarCpf()">
                
            </span>    
            <span>
                Nome completo<br />
                <input  id="nome" class="validate[required] input" name="nome" type="text" style="width:612px;">
                
            </span>
            <span>
                Data de Nascimento<br />
                <input  id="dataNascimento" class="validate[required] data input" name="dataNascimento" type="text">
                
            </span>
            <span>
                Estado Civil
                <div class="select-pequeno">
                <select id="estadocivil" name="estadocivil" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($estadocivil["Lista"] as $tipo){ ?>
                    	<option value="<?= $tipo->Codigo?>"><?= $tipo->Descricao ?></option>
                    <? } ?>
                
                </select>
                </div>
                
            </span>
            <span>
                Sexo
                <div class="select-pequeno">
                <select id="sexo" name="sexo" class="validate[required]">
                    <option value="">--</option>
                    <option value="1">MASCULINO</option>
                    <option value="2">FEMININO</option>
                
                </select>
                </div> 
            </span> 
            <span>
                N&ordm; Documento<br />
                <input  id="documento" class="validate[required] input" name="documento" type="text" >
                
            </span> 
            <span>
                Tipo de Documento
                <div class="select-medio">
                <select id="tipodocumento" name="tipodocumento" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($tipodocumento["Lista"] as $documento){ ?>
                    	<option value="<?= $documento->Codigo?>"><?= $documento->Descricao ?></option>
                    <? } ?>               
                </select>
                </div>
            </span>
            <span>
                Org&atilde;o emissor<br />
                <input  id="orgaoemissor" class="validate[required] input" name="orgaoemissor" type="text">
                
            </span>
            <span>
                Data expedi&ccedil;&atilde;o<br />
                <input  id="dataexpedicao" class="validate[required]  data input" name="dataexpedicao" type="text">
                
            </span>
            <span>
                Org&atilde;o UF
                <div class="select-pequeno">
                <select id="orgaouf" name="orgaouf" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($uf["string"] as $estado){ ?>
                    	<option value="<?= $estado ?>"><?= $estado ?></option>
                    <? } ?>
                    
                
                </select>
                </div>
            </span>
            <span>
                Principal atividade desenvolvida
                <div class="select-medio2">
                <select id="Atividade" name="Atividade" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($atividades["Lista"] as $atividade){ ?>
                    	<option value="<?= $atividade->Codigo?>"><?= $atividade->Descricao ?></option>
                    <? } ?>
                    
                
                </select>
                </div>
                
            </span> 
            <span>
                Declara&ccedil;&atilde;o de Nascido Vivo<br />
                <input  id="nascidovivo" name="nascidovivo" type="text" class="validate[required] input nascvivo" style="width: 145px;">
                
            </span> 
            <span>N&deg; Cart&atilde;o nacional de sa&uacute;de<br />
                <input  id="cartaosaude" name="cartaosaude" type="text" class="input saude">
                
            </span>
            <span>
                PIS/PASEP<br />
                <input  id="pis" name="pis" type="text" class="input pis">
                
            </span>
             
            <span>
                Nome completo da m&atilde;e<br />
                <input  id="nomemae" name="nomemae" type="text" class="validate[required] input" style="width:612px;">
                
            </span>
            
            <h2>Dados de endere&ccedil;o</h2> 
            <span>
               	CEP<br />
                <input  id="cep" class="validate[required] input" name="cep" type="text">
                                
            </span>
            <span style="margin-bottom: -10px;">
                <input type="button" id="buscacep" class="bt-continuar" value="Buscar" onclick="buscaCep('<?=site_url("alianca/site/buscacep")?>');" />
                
            </span> 
            <span>
                Endere&ccedil;o<br />
                <input  id="endereco" class="validate[required] input" name="endereco" type="text" style="width:370px;" readonly>
                
            </span> 
            <span>
                N&ordm;<br />
                <input  id="numero" class="validate[required] input"  name="numero" type="text">
                
            </span> 
            <span>
                Complemento<br />
                <input  id="complemento" name="complemento" type="text" class="input">
                
            </span> 
            <span>
                Bairro<br />
                <input  id="bairro" class="validate[required] input" name="bairro" type="text" readonly>
                
            </span> 
            <span>
                Cidade<br />
                <input  id="cidade" class="validate[required] input" name="cidade" type="text" readonly>
                
            </span> 
            
            <span>
                Estado<br />
                <input  id="uf" class="validate[required] input" name="uf" type="text" readonly>
                
            </span> 
            <span>
            	
                Tipo de endere&ccedil;o
                <div class="select-pequeno">
                <select id="tipoendereco" name="tipoendereco" tabindex="0">
					<option value="" selected="selected">--</option>
					<option value="R">RESIDENCIAL</option>
					<option value="C">COMERCIAL</option>

				</select>
                </div>
                
            </span> 
            <h2>Dados para contato</h2>
            <span>
                Tel resid&ecirc;ncial<br />
                <input  id="telresidencial" class="validate[required] tel input" name="telresidencial" type="text">
                
            </span> 
            <span>
                Tel comercial<br />
                <input  id="telcomercial" class="tel input" name="telcomercial" type="text">
                
            </span> 
            <span>
                Ramal<br />
                <input  id="telramal" name="telramal" class="input" type="text">
                
            </span>
            <span>
                Celular<br />
                <input  id="celular" class="tel input" name="celular" type="text">
                
            </span>
            <span>
                Email<br />
                <input  id="email" class="validate[required] input" name="email" type="text" style="width:300px;">
                
            </span>  
        
            <input type="submit" value="Salvar Titular" class="bt-continuar" />
            </form>
        </div>
	<? }else{ ?>
        <div id="tab-1">
        	<h2>Dados do dependente</h2>
            <form method="post" id="formdependente" class="form" action="<?= site_url("alianca/site/salvadependente")?>">
               
            <span>
                Nome completo<br />
                <input  id="nome" class="validate[required] input" name="nome" type="text" style="width:612px;">
                
            </span>
            <span>
                Data de Nascimento<br />
                <input  id="dataNascimento" class="validate[required] data input" name="dataNascimento" type="text" onblur="calculaMaioridade(this)">
                
            </span>
            <span>
                CPF<br />
                <input  id="cpf" class="cpf input" name="cpf" type="text" onblur="validarCpf()">
                
            </span> 
            <span>
                Grau de parentesco
                <div class="select-medio2">
                <select id="parentesco" name="parentesco" class="validate[required]">
                    <option value="" selected="selected">--</option>
                    <?  foreach($parentesco["GrauParentesco"] as $GrauParentesco){ ?>
                    	<option value="<?= $GrauParentesco->Codigo?>"><?= $GrauParentesco->Descricao ?></option>
                    <? } ?>
                
                </select>
                </div>
                
            </span>
            <span>
                Estado Civil
                <div class="select-pequeno">
                <select id="estadocivil" name="estadocivil" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($estadocivil["Lista"] as $tipo){ ?>
                    	<option value="<?= $tipo->Codigo?>"><?= $tipo->Descricao ?></option>
                    <? } ?>
                
                </select>
                </div>
                
            </span>
            <span>
                Sexo
                <div class="select-pequeno">
                <select id="sexo" name="sexo" class="validate[required]">
                    <option value="">--</option>
                    <option value="1" selected="selected">MASCULINO</option>
                    <option value="2">FEMININO</option>
                
                </select>
                </div> 
            </span> 
            <span>
                N&ordm; Documento<br />
                <input  id="documento" class="validate[required] input" name="documento" type="text">
                
            </span> 
            <span>
                Tipo de Documento
                <div class="select-medio">
                <select id="tipodocumento" name="tipodocumento" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($tipodocumento["Lista"] as $documento){ ?>
                    	<option value="<?= $documento->Codigo?>"><?= $documento->Descricao ?></option>
                    <? } ?>
                
                </select>
                </div>
                
            </span>
            <span>
                Org&atilde;o emissor<br />
                <input  id="orgaoemissor" class="validate[required] input" name="orgaoemissor" type="text">
                
            </span>
            <span>
                Data expedi&ccedil;&atilde;o<br />
                <input  id="dataexpedicao" class="validate[required]  data input" name="dataexpedicao" type="text">
                
            </span>
            <span>
                Org&atilde;o UF<br />
                <div class="select-pequeno">
                <select id="orgaouf" name="orgaouf" class="validate[required]">
                    <option value="">--</option>
                    <?  foreach($uf["string"] as $estado){ ?>
                    	<option value="<?= $estado ?>"><?= $estado ?></option>
                    <? } ?>
                    
                
                </select>
                </div>
                
            </span>
            <span>
                Nome completo da m&atilde;e<br />
                <input  id="nomemae" name="nomemae" type="text" class="validate[required] input" style="width:550px;">
                
            </span>
            <span>
                Declara&ccedil;&atilde;o de Nascido Vivo<br />
                <input  id="nascidovivo" name="nascidovivo" type="text" class="input" style="width:160px;">
                
            </span> 
            <span>N&deg; Cart&atilde;o nacional de sa&uacute;de<br />
                <input  id="cartaosaude" name="cartaosaude" type="text" class="input" style="width:160px;">
                
            </span>

        
            <input type="submit" value="Salvar Dependente" class="bt-continuar" />
            </form>
        	
        </div>
    <? } ?> 
    	<div id="tab-2" style="display: none;">
        	<h2>Dados para cobran&ccedil;a</h2>
       	  <div id="msgdebito" style="display: none;">
            	<p><b>Escolha Consigna&ccedil;&atilde;o em Folha e tenha muito mais praticidade e seguran&ccedil;a no pagamento da mensalidade do seu plano de sa&uacute;de ou odontol&oacute;gico:</b></p>
                <p>
                - Acompanhe mensalmente o desconto do plano no contracheque e n&atilde;o corra risco de suspens&atilde;o de atendimento em raz&atilde;o de um d&eacute;bito autom&aacute;tico n&atilde;o realizado.</p>
                <p>
                - Garantia de receber o Aux&iacute;lio-Sa&uacute;de. O atraso na realiza&ccedil;&atilde;o do d&eacute;bito autom&aacute;tico pode adiar o cr&eacute;dito do ressarcimento concedido pelo seu &oacute;rg&atilde;o.</p>
                <p>
                <input type="radio" onclick="AlterarFormaPagamento(value);" value="1" name="rdConsig" > Desejo Consigna&ccedil;&atilde;o em Folha. <br /> 
                <input type="radio" onclick="AlterarFormaPagamento(value);" value="2" name="rdConsig" > N&atilde;o, obrigado.   
                </p>                                              
                                          
            </div>
            <form method="post" class="form" action="<?= site_url("alianca/site/salvar_dados_cobranca/")?>" id="formpagamento">
			<div style="display: block;">
            	Forma de pagamento
                <div class="select-medio">
                <select onchange="tipoPagamento();" id="formaPagamento" name="formaPagamento" >
					<option value="" selected="selected">--</option>
                    <option value="2">CONSIGNACAO EM FOLHA</option>
                    <option value="1">D&Eacute;BITO EM CONTA</option>

				</select>
                </div>
                
            </div>
            <div id="consignacao" style="display: none;">
            	<span>
                    Unidade de Pagamento
                    <div class="select">
                    <select id="unidadePagamento" name="unidadePagamento" class="validate[required]">
                        <option value="" selected="selected">--</option>
                        <? foreach($dados["Formas_Pagamento"]["FormaPagamento"][1]["Unidade_Pagamento"]["Lista"] as $unidade_pagamento){ ?>
                        <option value="<?= $unidade_pagamento["Codigo"] ?>"><?= $unidade_pagamento["Descricao"] ?></option>
                        <? } ?>
        
                    </select>
                    </div>
                </span>
                <span>
                    Matr.Serv/Instituidor<br />
                    <input type="text" class="validate[required] input matricula" id="matriculaSiape" name="matriculaSiape" >
                </span>
                <span>
                    Tipo Servidor
                    <div class="select-pequeno">
                    <select onchange="matriculaPencionista();" id="tipoServidor" name="tipoServidor" class="validate[required]" >
                        <option value="1">Ativo</option>
                        <option value="2">Inativo</option>
                        <option value="3">Pensionista</option>
        
                    </select>
                    </div>
                </span>
              	<span style="display: none;" id="divMatriculaPencionista">
                    Matr&iacute;cula / Registro na Entidade Pensionista<br />
                    <input type="text" id="matPensionista" maxlength="8" name="matPensionista" class="validate[required] input" style="width:230px;" >
                </span>
                <span style="display: block;">Banco
               	<div class="select">
                    <select id="banco" name="banco" onchange="tipoBanco();" class="validate[required]">
                        <option value=""  selected="selected">--</option>
                        
                        <? foreach($dados["Formas_Pagamento"]["FormaPagamento"][1]["Bancos"]["Bancos"] as $banco){ ?>
                        <option value="<?= $banco["Codigo"] ?>"><?= $banco["Descricao"] ?></option>
                        <? } ?>
   
                    </select>
                    </div>
                </span>
                <span>
                    Ag&ecirc;ncia<br />
                    <input type="text" class="validate[required] input" id="agencia" maxlength="5" name="agencia" >
                </span>
                <span>
                    DV<br />
                    <input type="text" class="validate[required] input" id="digitoAgencia" maxlength="1" name="digitoAgencia" >
                </span style="display: block;">
                <span style="display: none;" id="fsOperacao">
                    Opera&ccedil;&atilde;o<br />
                    <input type="text" class="validate[required] input" id="operacao" maxlength="3" name="operacao" tabindex="0" style="width: 60px">
                </span>
                <span>
                    Conta<br />
                    <input type="text" class="validate[required] input" id="conta" maxlength="8" name="conta" tabindex="0" value="">
                </span>
                <span>
                    DV<br />
                    <input type="text" class="validate[required] input" id="digitoConta" maxlength="1" name="digitoConta" >
                </span>
                <span>
                    TP. Conta
                <div class="select-pequeno">
                    <select id="TPConta" name="TPConta" class="validate[required]">
                        <option value="" selected="selected">--</option>
                        <option value="1">CORRENTE</option>
                        <option value="2">POUPAN&Ccedil;A</option>
    
                    </select>
                    </div>
                </span>
                <input type="submit" value="Salvar dados de cobran&ccedil;a" class="bt-continuar"/>
                
            </div>
            
            <div id="debito" style="display: none;">
            	<span style="display: block;">Banco
               	<div class="select">
                    <select id="banco" name="banco" onchange="tipoBanco();" class="validate[required]">
                        <option value=""  selected="selected">--</option>
                        
                        <? foreach($dados["Formas_Pagamento"]["FormaPagamento"][0]["Bancos"]["Bancos"] as $banco){ ?>
                        <option value="<?= $banco["Codigo"] ?>"><?= $banco["Descricao"] ?></option>
                        <? } ?>
   
                    </select>
                    </div>
                </span>
                <span>
                    Ag&ecirc;ncia<br />
                    <input type="text" class="validate[required] input" id="agencia" maxlength="5" name="agencia" >
                </span>
                <span>
                    DV<br />
                    <input type="text" class="validate[required] input" id="digitoAgencia" maxlength="1" name="digitoAgencia" >
                </span style="display: block;">
                <span style="display: none;" id="fsOperacao">
                    Opera&ccedil;&atilde;o<br />
                    <input type="text" class="validate[required] input" id="operacao" maxlength="3" name="operacao" tabindex="0" style="width: 60px">
                </span>
                <span>
                    Conta<br />
                    <input type="text" class="validate[required] input" id="conta" maxlength="8" name="conta" tabindex="0" value="">
                </span>
                <span>
                    DV<br />
                    <input type="text" class="validate[required] input" id="digitoConta" maxlength="1" name="digitoConta" >
                </span>
                <span>
                    TP. Conta
                <div class="select-pequeno">
                    <select id="TPConta" name="TPConta" class="validate[required]">
                        <option value="" selected="selected">--</option>
                        <option value="1">CORRENTE</option>
                        <option value="2">POUPAN&Ccedil;A</option>
    
                    </select>
                    </div>
                </span>
                <input type="submit" value="Salvar dados de cobran&ccedil;a" class="bt-continuar"/>
                </form>
            </div>
				
            </div>
            
        
        </div>   
    </div>    
    
		
   	

</div>
