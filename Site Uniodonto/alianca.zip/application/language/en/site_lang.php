<?php
$lang["title"] = 'Uniodonto Curitiba - Quem tem valoriza';
$lang["description"] = 'Uniodonto Curitiba - Individual, Family and Corporate Dental Plans';
$lang["ola"] = 'Hello, ';
$lang["sair"] = 'Logout';
$lang["alterar_cidade"] = 'Change city';
$lang["pesquisar"] = 'Search';
$lang["enviar"] = 'Send';
$lang["a_uniodonto"] = 'About Uniodonto';
$lang["planos"] = 'Dental Plans';
$lang["encontre_seu_dentista"] = 'Find your Dentist';
$lang["dental_uni"] = 'Dental Uni';
$lang["uniodonto_24h"] = 'Uniodonto 24 hours';
$lang["noticias"] = 'News';
$lang["sustentabilidade"] = 'Social Responsibility';
$lang["contato"] = 'Contact';
$lang["clientes"] = 'Clients';
$lang["loja_virtual"] = 'Online Store';
$lang["localizacao"] = 'Location';
$lang["fale_conosco"] = 'Contact Us';
$lang["trabalhe_conosco"] = 'Career';
$lang["colaborador"] = 'Employee';
$lang["dentista"] = 'Dentist';
$lang["alterar_idioma"] = 'Change Language';
$lang["atendimento_ao_beneficiario"] = 'Beneficiaries Service';
$lang["tel_atendimento"] = '<font>+55 41 </font>3371-1900';
$lang["tel_24h"] = '<font>+55 41 </font>3342-9060';
$lang["tel_dental"] = '<font>+55 41 </font>3276-6000';
$lang["redes_sociais"] = 'Uniodonto on Social';
$lang["proximos_eventos"] = 'Next Events';
$lang["ver_calendario_completo"] = 'Go to complete calendar';
$lang["mais_noticias"] = 'More news';
$lang["video_institucional"] = 'Institutional Video';
$lang["selecione_todos_os_campos"] = 'Select  all the fields';
$lang["monte_seu_plano_pf"] = 'Customer Dental Plan';
$lang["plano"] = 'Plan';
$lang["selecione"] = 'Select';
$lang["superior"] = 'Superior';
$lang["avancado"] = 'Advanced';
$lang["modalidade"] = 'Types Plan';
$lang["com_carencia"] = 'With grace period';
$lang["sem_carencia"] = 'Without grace period';
$lang["co-participacao"] = 'CO-Participate';
$lang["pagamento"] = 'Payment';
$lang["boleto"] = 'Bank Slip';
$lang["debito"] = 'Debit';
$lang["beneficiarios"] = 'Beneficiary';
$lang["contratar"] = 'Contract';
$lang["calcular"] = 'Compute';
$lang["valor_por_beneficiario"] = 'Value for beneficiary: R$ ';
$lang["valor_total"] = 'Total: R$ ';
$lang["planos_empresariais"] = 'Business Plan';
$lang["clique_aqui_e_solicite_um_orcamento"] = 'Click here and request budget ';
$lang["para_efetuar_a_busca_preencha_pelo_menos_um_dos_campos"] = 'To perform a search fill at least one of the fields!';
$lang["nome"] = 'Name';
$lang["estado"] = 'State';
$lang["cidade"] = 'City';
$lang["bairro"] = 'District';
$lang["especialidade"] = 'Specialty';
$lang["area_de_atuacao"] = 'Field';
$lang["liberacao_online"] = 'Release Online';
$lang["busca"] = 'Search';
$lang["buscar"] = 'Search';
$lang["nossos_clientes"] = 'Our Customers';
$lang["area_do_beneficiario"] = 'Beneficiary Area';
$lang["relatorios"] = 'Reports';
$lang["alterar_dados_cadastrais"] = 'Changing Registration Data';
$lang["boleto_bancario"] = 'Bank Slip';
$lang["area_da_empresa"] = 'Company area';
$lang["movimentacao_cadastral"] = 'Cadastre';
$lang["area_do_dentista"] = 'Dentist Area';
$lang["agenda"] = 'Agenda';
$lang["email"] = 'Email';
$lang["tabela_de_atos"] = 'Dental Procedures';
$lang["area_uniodonto"] = 'Uniodonto Area';
$lang["boletos"] = 'Slips';
$lang["area_do_representante"] = 'Representative Area';
$lang["analise_critica"] = 'Critical Analysis';
$lang["alterar_senha"] = 'Change Password';
$lang["a_uniodonto_e_voce"] = 'Uniodonto and you';
$lang["dados_cadastrais"] = 'Cadastral data';
$lang["informe_de_rendimentos"] = 'Report income';
$lang["revisao_de_valores"] = 'Reviewing Values';
$lang["cedula_c"] = 'Income Tex Return';
$lang["calendario"] = 'Calendary';
$lang["fique_por_dentro"] = 'News';
$lang["voce_beneficiario"] = 'Beneficiary';
$lang["como_utilizar_seu_plano"] = 'How tyo use to plan';
$lang["sistema_de_gestao"] = 'SIO';
$lang["consulta_nota_fiscal"] = 'Query the invoice';
$lang["relatorio_beneficiarios"] = 'Report Beneficiaries';
$lang["atendimento_mes"] = 'Attendances months';
$lang["status_das_guias"] = 'Status of the guide';
$lang["atendimentos_por_especialidade"] = 'Attendance by Specialty';
$lang["faturamento"] = 'Billing';
$lang["faturamento_intercambio"] = 'Billing interchange';
$lang["quantidade_beneficiarios_x_beneficiarios_atendidos"] = 'Number of beneficiaries x beneficiaries served';
$lang["contrato"] = 'Contract';
$lang["unionews"] = 'Unionews magazine';
$lang["marketing"] = 'Marketing';
$lang["formularios"] = 'forms';
$lang["dados_da_empresa"] = 'Company Data';
$lang["razao_social"] = 'Company Name';
$lang["nome_fantasia"] = 'Fantasy Name';
$lang["cnpj"] = 'CNPJ';
$lang["endereco"] = 'Address';
$lang["numero"] = 'Number';
$lang["complemento"] = 'Complement';
$lang["ramo_de_atividade"] = 'Business Activity';
$lang["telefone"] = 'Phone';
$lang["fax"] = 'Fax';
$lang["pessoa_de_contato"] = 'Contact Person';
$lang["cargo"] = 'Role';
$lang["pesquisa_para_elaboracao_da_proposta"] = 'Search for preparing the proposal';
$lang["n_de_funcionarios_da_empresa"] = 'Number of company employees?';
$lang["quantos_participam_do_plano"] = 'How many participate in the plan?';
$lang["possui_convenio_medico"] = 'Have health insurance?';
$lang["sim"] = 'Yes';
$lang["nao"] = 'No';
$lang["com_qual_operadora_ou_seguradora"] = 'Which Provider or Insurer?';
$lang["possui_convenio_odontologico"] = 'Dental has an agreement?';
$lang["motivo_mudanca"] = 'Reason for change';
$lang["tem_filiais"] = 'It has branches?';
$lang["em_quais_cidade"] = 'What cities?';
$lang["o_plano_odontologico_sera_extensivo_para_estas_filiais"] = 'The Dental Plan will be extended to these branches?';
$lang["o_plano_odontologico_sera_extensivo_aos_dependentes_dos_funcionarios"] = 'The Dental Plan will be extended to dependents of employees?';
$lang["caso_negativo_qual_sera_o_percentual_de_participacao_do_funcionario"] = 'If not, what is the percentage of employee participation';
$lang["coletivo_empresarial"] = 'Collective for Corporate';
$lang["coletivo_por_adesao"] = 'Collective for Accession';
$lang["tipo_de_plano"] = 'Plan Type';
$lang["basico"] = 'Basic';
$lang["emergencia_misto"] = 'Emergency / Mixed';
$lang["custo_operacional"] = 'Operating Cost';
$lang["valor"] = 'Value';
$lang["proposta_pra_quantas_vidas"] = 'Proposal to how many lives?';
$lang["observacoes"] = 'Observation';
$lang["enviar"] = 'Send';
$lang["beneficios"] = 'Benefits';
$lang["cavo"] = '"<h1>Benefit Cavo</h1>
     <p><strong>
        Collection Services and Waste Management</strong></p>
     <p>&nbsp; </p>
     <p>
        We closed a contract with the company CAVO Services and Environment SA for collection services and waste management.</p>
     <p>&nbsp;</p>
 <p>
  We chose the company CAVO not only by its structure and experience in the business, but also because it was very flexible in negotiations and offered us the lowest values, already including drums (containers used for the storage of garbage bags) of 30 or 50 liters.</p>
 <p>&nbsp;</p>
 <strong>CURITIBA VALUES AND METROPOLITAN AREA</strong>
    <style>
     table td{padding: 10px;}
    </style>
 <table border=""0"" class=""tabela-atos"">
  <tbody>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 105,18 per collection point</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      weekly collection</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (4 samples / month)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      up to 50 liters / week</p>
    </td>
   </tr>
   <tr height=""15"">
    <td height=""20"">
     <p align=""left"">
      R$ 83,71 per collection point</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      fortnightly collection</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      (2 samples / month)</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      up to 50 liters / fortnight</p>
    </td>
   </tr>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 62,25 per collection point</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      collecting monthly</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (1 sample / month)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      up to 50 liters / month</p>
    </td>
   </tr>
  </tbody>
 </table>
 <br />
 <br />
 <strong>VALUES PARANAGU�</strong>
 <table border=""0"" cellpadding=""2"" cellspacing=""2"" class=""tabela-atos"">
  <tbody>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 124,05 &nbsp; per collection point</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      weekly collection</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (4 samples / month)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      up to 50 liters / week</p>
    </td>
   </tr>
   <tr height=""15"">
    <td height=""20"">
     <p align=""left"">
      R$ 112,96 per collection point</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      fortnightly collection</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      (2 samples / month)</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      up to 50 liters / fortnight</p>
    </td>
   </tr>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 94,61 &nbsp; per collection point</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      collecting monthly</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (1 sample / month)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      up to 50 liters / month</p>
    </td>
   </tr>
  </tbody>
 </table>
 <br />
 <br />
 <strong>INSTRUCTIONS</strong><br />
 For the cooperative interested in joining, please follow the instructions below:<br />
 <br />
 <ul>
  <li>
   Attend the Head Office Uniodonto Curitiba and search by sector GRC - Relationship Management Cooperative - on time from 08h00 to 18h00.</li>
  <br />
  <li>
   For the cooperative who performed the protocol on Form Waste Management by the Municipal Environment, bring ORIGINAL protocol. There will be a copy of our protocol for file and control.</li>
  <br />
  <li>
   For those who did not undergo cooperative protocol with the Municipal Environment, bring Waste Management Form (copy attached) completely filled, because the Department is no longer performing the protocol. There will be a copy of this document to our archive and control.</li>
  <br />
  <li>
   Subsequently, the cooperative will fill out the REQUEST FOR COLLECTION indicate where the (s) address (es) and periodicity (s) collection (s) and sign the AUTHORIZATION TO DEBIT ACCOUNT CURRENT at Banco Santander, which will occur at discount payday production.</li>
 </ul>
    <p>&nbsp;</p>
 <div>
  Questions contact the GRC sector - Management Cooperative Relations by phone:
<br />
  <strong>+55 41 3371-1935 - 3371-1937, 3371-1940 - grc@uniodontocuritiba.com.br:</strong></div>"';
$lang["unimed"] = '"<h1>Benefit Unimed</h1><p>
 <b>Insurance cover</b></p>
<p>
 The Health Plan of Unimed Curitiba is in accordance with Law No. 9656/98, has wide coverage, with no shortage ara inclusion of the holder and their dependents.</p>
<p>&nbsp;
 </p>
<p>
 <strong>MAJOR COVER - ACCORDING WITH THE LAW NO. 9656/98</strong></p>
<ul>
 <li>Medical appointments without limits;</li>
    <li>Inpatient medical / surgical no daily limits;</li>
    <li>Hospitalization in ICU without daily limits;</li>
    <li>Laboratory tests without limits;</li>
    <li>Prosthetics and orthotics related to surgery;</li>
    <li>Exams expensive such as Magnetic Resonance and Computed Tomo spelling without limits;</li>
    <li>Chemotherapy and radiotherapy without limits;</li>
    <li>Infectious and contagious diseases;</li>
    <li>Transplant kidney and cornea;</li>
    <li>Physiotherapy boundless; (Since it is not found to accident).</li>
    <li>Urgent care / emergency outpatient;</li>
    <li>12 sessions of psychotherapy crisis;
    </li>
</ul>
<p>&nbsp;
 </p>
<p>
 <strong>Psychiatric Inpatient limited to 30 days, continuous or not, by contract year not cumulative.</strong><br />
 <br />
 <strong>In the event of a change of plan:</strong><br />
 30 days: term births<br />
 06 months: single room (apartment)<br />
 <br />
 <br />
 <strong>When using the above benefits, the lack of continuity of the chosen plan is 01 years.

</strong><br />
 &nbsp;</p>
<table cellpadding=""0"" cellspacing=""0"" class=""tabela-atos"">
 <tbody>
  <tr style=""color: #fff;"">
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>Age Group</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>Entry Fee</strong></p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>Codes Plans</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>801</strong><br />
     <strong>HOSP. ENF.</strong><br />
     <strong>OBSTETRICIA</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>802</strong><br />
     <strong>HOSP. WARD</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>803</strong><br />
     <strong>HOSP. SUITABLE OBSTETRICIA</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>804</strong><br />
     <strong>HOSP.</strong><br />
     <strong>APARTMENT</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>by User</strong></p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>0-18</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 89,63</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 56,75</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 111,33</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 77,19</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>19-23</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 104,30</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 69,96</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 135,36</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 89,38</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>24-28</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 110,16</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 76,26</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 148,23</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 97,42</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>29-33</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 128,05</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 95,45</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 181,13</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 118,90</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>34-38</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 134,44</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 100,23</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 192,00</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 126,40</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>39-43</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 148,12</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 114,69</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 229,89</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 159,26</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>44-48</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 188,97</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 157,89</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 252,88</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 190,32</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>49-53</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 245,50</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 219,65</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 312,80</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 253,31</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>54-58</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 271,52</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 252,59</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 375,36</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 302,95</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>&gt;58 </strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 373,34</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 337,72</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 559,28</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 462,91</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
 </tbody>
</table>
<p>
 *When requested by the holder a duplicate, it will have on your monthly $ 5.00 plus the monthly fee to come.<br />
 &nbsp;</p>
<p>
 <b><font color=""#AC2D44"">To download the document to formalize the inclusion of dependents in the plan Unimed <a href=""http://www.sistemauniodonto.com.br/curitiba/upload/files/dentista/formalizacao-inclusao-dependente-unimed.pdf""> Click here</a> </font></b></p>
<div>
 Questions contact the GRC sector - Management Cooperative Relations by phone:<br />
 <strong>+ 55 41 3371-1935 - 3371-1937, 3371-1940 - grc@uniodontocuritiba.com.br</strong></div> "';
$lang["nissei"] = '"<h1>Benefit Nissei</h1><p>
 <b>The UNIODONTO NISSEI AND JOINTS ARE TO SERVE YOU BETTER!</b></p>
<p>&nbsp;
 </p>
<p>
 The Uniodonto Curitiba and Nissei, teamed up to offer your employees the best agreement of the pharmacy chain fastest growing in Brazil.</p>
<p>&nbsp;
 </p>
<p>
 <strong>Now look at some of the benefits of being a agreement Nissei.</strong></p>
<ul>
 <li>
  More than 60 stores in Curitiba metropolitan region, Ponta Grossa and Coast Paranaense;</li>
 <li>
  15 stores, with 24 hour care;</li>
 <li>
  Week Covenant 14-20 of each month with 15% discount on all medicines;</li>
 <li>
  Social Card;</li>
 <li>
  Emergency Health;</li>
 <li>
  Manipulation of Pharmacy;</li>
 <li>
  Home Delivery (0800 416162);</li>
 <li>
  Scheduled Delivery;</li>
 <li>
  Promotional inserts in stores;</li>
 <li>
  Ribbon of offerings practiced in stores;</li>
</ul>
<p>&nbsp;
 </p>
<p>
 <strong>Modality Loyalty:</strong></p>
<p>
 Using the Mode Fidelity, the dentist will buy in 01 to 07 days each month, medicines at cost price with cash payment. On the other days the discounts vary 15% to 20%. Present the same card.</p>
<p>&nbsp;
 </p>
<p>
 <strong>Remember that this is valid only for the benefit of cooperative Curitiba metropolitan area and coastline.</strong></p>
<p>
 Questions contact the GRC sector - Management Cooperative Relations by phone:

<br />
 +55 41 3371-1935 - 3371-1937, 3371-1940  grc@uniodontocuritiba.com.br</p>  "';
$lang["resultados_encontrados"] = ' Results Found';
$lang["cliente_uniodonto"] = 'Client Uniodonto';
$lang["numero_do_cartao_uniodonto"] = 'ID Card Uniodonto';
$lang["mensagem"] = 'Message';
$lang["digite_o_codigo_verificador"] = 'Enter the code checker:';
$lang["proposta_de_adesao"] = 'Application Form';
$lang["adesao"] = '"<p>You Application Form is validated for area Uniodonto Scope of Curitiba, with the following municipalities: <br>
        <br>
        Almirante Tamandar�, Anahy, Andir�, Araruna, Arauc�ria, Balsa Nova, Bocaiuva do Sul, Barbosa Ferraz, Boa Esperan�a, Campina Grande do Sul, Campina da Lagoa, Campo Largo, Campo Mourao, Cand�i, C�ndido de Abreu, Cantagalo, Capanema, Cascavel, Colombo, Contenda, Corb�lia, Coronel Vivida, Corumbata� do Sul, Chopinzinho, Clevel�ndia, Curitiba, Dois Vizinhos, Engenheiro Beltrao, Entre Rios, Fazenda Rio Grande, Fenix, Francisco Beltrao, Foz do Igua�u, Goioere, Gua�ra, Guarapuava, Guaratuba, Itaperu�u, Ivaipora, Jacarezinho, Juranda, Lapa, Laranjeiras do Sul, Mambore, Mangueirinha, Manoel Ribas, Matinhos, Medianeira, Moreira Sales, Morretes, Nova Cantu, Nova Santa Rosa, Palotina, Palmas, Paranagu�, Paranava�, Pato Branco, Peabiru, Pien, Pinhais, Pinhao, Piraquara, Pitanga, Pontal do Paran�, Porto Amazonas, Prudent�polis, Quatro Barras, Quarto Centen�rio, Quedas do Igua�u, Rebou�as, Rio Azul, Roncador, Santa Tereza D\'Oeste, Santo Ant�nio da Platina, Sao Joao do Iva�, Sao Jos� dos Pinhais, Sao Mateus do Sul, Sao Pedro do Igua�u, Tijucas do Sul, Toledo, Tupassi, Umuarama, Uniao da Vit�ria. </p>
      <p>&nbsp;</p>
      <p>You chose the Advanced Plan <strong>"';
$lang["adesao_superior"] = 'The Superior Plan covers 171 procedures, including diagnostics, emergency care 24 hours, resin restoration, surgical removal of impacted teeth and semi-enclosed, gum treatment, treatment and retreatment channel, some types of radiographs and prevention services (orientation, prophylaxis and fluoride application). At the time of hiring you can opt for Higher Plane with or without deprivation and choose the form of payment of tuition, by bank transfer or direct debit. This Plan has a contract term of two years.';
$lang["adesao_avancado"] = 'By choosing the Advanced Plan, and Plan coverage Superior, the plan offers coverage with extended right to the panoramic radiograph, RX hand and wrist for orthodontic documentation, alveolotomia, dessensibilidade dental, totaling 182 sessions. At the time of hiring you can opt for the Advanced Plan with or without deprivation and choose the form of payment of tuition, by bank transfer or direct debit. This Plan has a contract term of two years.';
$lang["adesao_valor1"] = '<p>This plan has a <strong>monthly amount per person</strong> of <strong>R$ ';
$lang["adesao_valor2"] = '</strong> and the <strong>monthly amount</strong> of <strong>R$ ';
$lang["adesao_valor3"] = '"</strong></p>
      <p>&nbsp;</p>
      <p><strong>Value of Membership Fee: R$ 40,00</strong></p>
      <p>&nbsp;</p>
      <p>To complete your membership is required to be provided some relevant data for registration in our system.</p>
      <p>&nbsp;</p>
      <p>Fill out the form data below to send the adhesion term plan to Uniodonto Curitiba.</p>"';
$lang["dados_pessoais_do_titular_do_contrato"] = 'Personal Data of the contract Holder';
$lang["sexo"] = 'Sex';
$lang["data_de_Nascimento"] = 'Date of Birth';
$lang["estado_civil"] = 'Civil Status';
$lang["solteiro"] = 'Single';
$lang["casado"] = 'Married';
$lang["separado"] = 'Separate';
$lang["divorciado"] = 'Divorced';
$lang["viuvo"] = 'Widow(er)';
$lang["tipo_de_endereco"] = 'Address Type';
$lang["rua"] = 'Street';
$lang["avenida"] = 'Avenue';
$lang["alameda"] = 'Square';
$lang["praca"] = 'Mall Road';
$lang["rodovia"] = 'Highway';
$lang["travessa"] = 'Crossing';
$lang["cep"] = 'Cod. Postal';
$lang["telefone_residencial"] = 'Phone Number';
$lang["celular"] = 'Mobile Number';
$lang["telefone_de_recado"] = 'Phone Message';
$lang["falar_com"] = 'Contact Name';
$lang["documentacao"] = 'Personal Documents';
$lang["rg"] = 'ID';
$lang["orgao_expedidor"] = 'Organ Consignor';
$lang["data_expedicao_rg"] = 'Date expedition ID';
$lang["cpf"] = 'CPF';
$lang["escolaridade"] = 'Education';
$lang["nivel"] = 'Level';
$lang["fundamental"] = 'Fundamental';
$lang["medio"] = 'Average';
$lang["superior"] = 'Upper';
$lang["pos_graduacao"] = 'Graduate';
$lang["mestrado"] = 'Master\'s degree';
$lang["doutorado"] = 'Doctorate';
$lang["pos_doutorado"] = 'Post Doctoral';
$lang["nome_completo_da_mae_do_titular_do_contrato"] = 'Full name of the mother of the contract holder';
$lang["dados_comerciais_do_titular_responsavel"] = 'Holder Responsible Business Data';
$lang["empresa"] = 'Business';
$lang["autonomo"] = 'Autonomous';
$lang["cargo"] = 'Role';
$lang["renda_familiar"] = 'Family Income';
$lang["vinculo_empregaticio"] = 'Employment';
$lang["empregado"] = 'Employee';
$lang["contratado"] = 'Engaged';
$lang["estagiario"] = 'Trainee';
$lang["outros"] = 'Other';
$lang["informacoes_do_beneficiario_dependente"] = 'Information of beneficiaries dependent';
$lang["grau_de_parentesco"] = 'Degree of Kinship';
$lang["conjuge"] = 'Spouse';
$lang["filho"] = 'Son';
$lang["filha"] = 'Daughter';
$lang["pai"] = 'Father';
$lang["mae"] = 'Mother';
$lang["agregado"] = 'Aggregate';
$lang["nome_completo_da_mae"] = 'Full name of the mother';
$lang["masculino"] = 'Male';
$lang["feminino"] = 'Female';
$lang["e_necessario_ler_o_termo_de_adesao_e_assinalar_o_marcador_abaixo_para_completar_o_envio"] = 'You should read the term adhesion and signaling the marker below to complete submission.';
$lang["eu_li_e_concordo_com_os_termos_descritos_no_termo_de_adesao_de_plano"] = 'I have read and agree to the terms described in the Declaration of Compliance Plan';
$lang["texto_encontre_seu_dentista"] = 'See how easy it is to find the dentist of your choice. Simply choose the specialty, the neighborhood or your location. If you are traveling within Paran&aacute; state, simply select the destination city and you will find a dentist to serve you.';
$lang["eventos"] = 'Events';
$lang["mes01"] = 'January';
$lang["mes02"] = 'February';
$lang["mes03"] = 'March';
$lang["mes04"] = 'April';
$lang["mes05"] = 'May';
$lang["mes06"] = 'June';
$lang["mes07"] = 'July';
$lang["mes08"] = 'August';
$lang["mes09"] = 'September';
$lang["mes10"] = 'October';
$lang["mes11"] = 'November';
$lang["mes12"] = 'December';
$lang["janeiro"] = 'January';
$lang["fevereiro"] = 'February';
$lang["marco"] = 'March';
$lang["abril"] = 'April';
$lang["maio"] = 'May';
$lang["junho"] = 'June';
$lang["julho"] = 'July';
$lang["agosto"] = 'August';
$lang["setembro"] = 'September';
$lang["outubro"] = 'October';
$lang["novembro"] = 'November';
$lang["dezembro"] = 'December';
$lang["como_chegar"] = 'Directions - Map';
$lang["enviando_por_favor_aguarde"] = 'Sending please wait ...';
$lang["responsavel"] = 'Responsible';
$lang["cidade_estado"] = 'City/State';
$lang["qtd_funcionarios"] = 'Number of Employees';
$lang["pagina_nao_encontrada"] = 'Page not found';
$lang["desculpe_a_pagina_que_voce_procura_nao_foi_encontrada_em_nosso_site"] = 'Sorry, the page you requested was not found on our site.';
$lang["revistas"] = 'Magazine';
$lang["texto_sustentabilidade"] = '"Uniodonto&rsquo;s sustainable development has three main dimensions: economic growth, human capital development and environmental balance.<br><br>
Our actions have the purpose of ensure that our results are consistent, generating economic growth through development and training of our members and employees, while maintaining a commitment to the environment.<br><br>
We focus on innovation of our services, striving to offer quality, generating satisfaction of our customers, for both present and future generations.<br><br>
As part of that commitment, we are in constant search for community development through social projects in partnership with public and private institutions.<br><br>

<strong>Our Commitments</strong><br><br>
Fulfillment of the Seven Principles of Cooperatives<br><br>
1st Voluntary and open membership: Cooperatives are organizations open to participation by all.<br><br>
2nd Democratic management: the cooperative voted the objectives and goals of working together, and elect representatives who will manage the company.<br><br>
3rd Economic Participation Members: all contribute equally to the formation of the cooperative capital. If there is profit generated, it will be divided among the partners.<br><br>
4th Autonomy and independence: the functioning of the cooperative is controlled by its members, who are the owners of the business.<br><br>
5th Education, training and information: permanent objective of the cooperative is to promote actions and use resources to train its members, enabling them to the cooperate practice.<br><br>
6th Intercooperation: to strengthen the cooperative movement, it is important that the exchange of information, products and services among cooperatives to enable it as socioeconomic activity.<br><br>
7th Concern for Community: Cooperatives work for the sustainable development of their communities through the implementation of cultural and social programs, conducted in partnership with government and other non-profit organizations.<br><br>"';
$lang["pis"] = 'Private Company Employee fund';
$lang["carteira_de_trabalho"] = 'Employment Record Card';
$lang["serie"] = 'Sequence';
$lang["cnh"] = 'Driver\'s License';
$lang["nao_possui"] = 'No Driver\'s License';
$lang["curso_de_formacao"] = 'Training Course';
$lang["escola_instituicao"] = 'School/Institution';
$lang["ano_de_conclusao"] = 'Year of Completion';
$lang["outros_cursos"] = 'Other courses';
$lang["palestras_treinamentos"] = 'Lectures/Training';
$lang["experiencia"] = 'Work Experience';
$lang["ultima_empresa"] = 'Last company';
$lang["data_admissao"] = 'Date of Admission';
$lang["data_demissao"] = 'Date of Resignation';
$lang["funcao"] = 'Role';
$lang["ultimo_salario"] = 'Final Salary';
$lang["descreva_as_tarefas_realizadas"] = 'Describe activities and responsibilities';
$lang["penultima_empresa"] = 'Penultimate Company';
$lang["antepenultima_empresa"] = 'Antepenultimate Company';
$lang["pretensoes"] = 'Preferred Job';
$lang["departamento"] = 'Department';
$lang["cadastro"] = 'Cadastre';
$lang["intercambio"] = 'Exchange';
$lang["sac_empresa"] = 'SAC Company';
$lang["cobranca"] = 'Collection';
$lang["sac_coop"] = 'SAC Coop';
$lang["administracao"] = 'Administration';
$lang["avaliador"] = 'Appraiser';
$lang["salario_pretendido"] = 'Salary Desired';
$lang["portador_de_necessidades_especiais"] = 'With special needs';
$lang["qual_necessidade"] = 'Which would';
$lang["disponibilidade_para_trabalhar_em_outra_cidade"] = 'Availability to work in another city';
$lang["foto"] = 'Photo';
$lang["cnes"] = 'CNES';
$lang["n_de_licenca_sanitaria"] = 'License Number Sanitary';
$lang["alvara"] = 'Charter';
$lang["registrado_pelo_cro"] = 'Joined By Cro?';
$lang["e_sua_especialidade_principal"] = 'It Is Their Specialty Principal?';
$lang["incluir"] = 'Include';
$lang["comercial"] = 'Commercial';
$lang["atende_pacientes_com_nescessidades_especiais"] = 'Treats patients with special needs?';
$lang["possui_acesso_aos_mesmos"] = 'It has access to them?';
$lang["atende_em_quais_dias"] = 'Meets on which days?';
$lang["este_e_seu_local_principal"] = 'This is your principal local?';
$lang["horario"] = 'Time';
$lang["aperfeicoamento"] = 'Improvement';
$lang["especializacoes"] = 'Specializations';
$lang["area"] = 'Area';
$lang["instituicoes"] = 'Institutions';
$lang["concluido"] = 'Completed';
$lang["em_andamento"] = 'In Progress';
$lang["data"] = 'Date';
$lang["arquivos"] = 'Archives';
$lang["Alguem_da_uniodonto_esta_lhe_indicando_quem"] = 'Someone from Uniodonto are you indicating? Who?';
$lang["curriculum"] = 'Curriculum';
$lang["telefone_comercial"] = 'Business phone';
$lang["segunda"] = 'Monday';
$lang["terca"] = 'Tuesday';
$lang["quarta"] = 'Wednesday';
$lang["quinta"] = 'Thursday';
$lang["sexta"] = 'Friday';
$lang["sabado"] = 'Saturday';
$lang["domingo"] = 'Sunday';
$lang["as"] = 'to';
$lang["cro"] = 'CRO';
$lang["e_necessario_preencher_todos_os_campos"] = 'Select  all the fields.';
$lang["preencha_o_codigo_verificador_corretamente"] = 'Please complete the code verifier correctly!';
$lang["email_enviado_com_sucesso"] = 'Email sent successfully!';
$lang["nao_foi_possivel_enviar_o_email_tente_novamente"] = 'Could not send the email! Try again!';
$lang["resultado_da_busca_por"] = 'Rearch results for:';
$lang["nome_da_empresa"] = '';
$lang["qtd_de_vidas"] = '';
$lang["taxa_de_adesao"] = '';
$lang["carencia"] = '';
$lang["gerar_proposta"] = '';
$lang["gerar "] = '';
$lang["tabelas"] = 'Tables';
$lang["manuais"] = 'manuals';
$lang["ja_existe_uma_proposta_ativa_para_esta_empresa"] = '';
$lang["esta_empresa_j�_possui_contrato"] = '';
$lang["preencha_todos_os_campos_antes_de_gerar_a_proposta"] = '';
$lang["nova_proposta"] = '';
$lang["ver_propostas"] = '';
$lang["tabela"] = '';
$lang["material_grafico"] = '';
$lang["validade"] = '';
$lang["data_de_inclusao"] = '';
$lang["empresa_reservada_consulte_o_departamento_comercial"] = '';
$lang["esta_empresa_ja_e_cliente_uniodonto"] = '';
$lang["digite_o_numero_do_cnpj"] = '';
$lang["consultando_cnpj_por_favor_aguarde"] = '';
$lang["enviar_email"] = '';
$lang["pagamento_online"] = 'Online Payment';