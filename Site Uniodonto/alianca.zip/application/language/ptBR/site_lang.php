<?php
$lang["title"] = 'Uniodonto Curitiba - Quem tem valoriza';
$lang["description"] = 'Uniodonto Curitiba - Planos Odontol&oacute;gicos Familiares, Individuais e Empresariais';
$lang["ola"] = 'Ol&aacute;,';
$lang["sair"] = 'Sair';
$lang["alterar_cidade"] = 'Alterar cidade';
$lang["pesquisar"] = 'Pesquisar';
$lang["enviar"] = 'Enviar';
$lang["a_uniodonto"] = 'A Uniodonto';
$lang["planos"] = 'Planos';
$lang["encontre_seu_dentista"] = 'Encontre seu Dentista';
$lang["dental_uni"] = 'Dental Uni';
$lang["uniodonto_24h"] = 'Uniodonto 24h';
$lang["noticias"] = 'Not&iacute;cias';
$lang["sustentabilidade"] = 'Sustentabilidade';
$lang["contato"] = 'Contato';
$lang["clientes"] = 'Clientes Uniodonto';
$lang["loja_virtual"] = 'Loja Virtual';
$lang["localizacao"] = 'Localiza&ccedil;&atilde;o';
$lang["fale_conosco"] = 'Fale conosco';
$lang["trabalhe_conosco"] = 'Trabalhe conosco';
$lang["colaborador"] = 'Colaborador';
$lang["dentista"] = 'Dentista';
$lang["alterar_idioma"] = 'Alterar idioma';
$lang["atendimento_ao_beneficiario"] = 'Atendimento ao Benefici&aacute;rio';
$lang["tel_atendimento"] = '<font>(41)</font>3371-1900';
$lang["tel_24h"] = '<font>(41)</font>3342-9060';
$lang["tel_dental"] = '<font>(41)</font>3276-6000';
$lang["redes_sociais"] = 'Redes Sociais';
$lang["proximos_eventos"] = 'Pr&oacute;ximos eventos';
$lang["ver_calendario_completo"] = 'Ver calend&aacute;rio completo';
$lang["mais_noticias"] = 'Mais not&iacute;cias';
$lang["video_institucional"] = 'V&iacute;deo Institucional';
$lang["selecione_todos_os_campos"] = 'Selecione todos os campos';
$lang["monte_seu_plano_pf"] = 'Monte Seu Plano - Pessoa F&iacute;sica';
$lang["plano"] = 'Plano';
$lang["selecione"] = 'Selecione';
$lang["superior"] = 'Superior';
$lang["avancado"] = 'Avan&ccedil;ado';
$lang["modalidade"] = 'Modalidade';
$lang["com_carencia"] = 'Com car&ecirc;ncia';
$lang["sem_carencia"] = 'Sem car&ecirc;ncia';
$lang["co-participacao"] = 'CO-Participa&ccedil;&atilde;o';
$lang["pagamento"] = 'Pagamento';
$lang["boleto"] = 'Boleto';
$lang["debito"] = 'D&eacute;bito';
$lang["beneficiarios"] = 'Benefici&aacute;rios';
$lang["contratar"] = 'Contratar';
$lang["calcular"] = 'Calcular';
$lang["valor_por_beneficiario"] = 'Valor por benefici&aacute;rio: R$ ';
$lang["valor_total"] = 'Valor Total: R$ ';
$lang["planos_empresariais"] = 'Planos empresariais';
$lang["clique_aqui_e_solicite_um_orcamento"] = 'Clique aqui e solicite um or&ccedil;amento';
$lang["para_efetuar_a_busca_preencha_pelo_menos_um_dos_campos"] = 'Para efetuar a busca preencha pelo menos um dos campos!';
$lang["nome"] = 'Nome';
$lang["estado"] = 'Estado';
$lang["cidade"] = 'Cidade';
$lang["bairro"] = 'Bairro';
$lang["especialidade"] = 'Especialidade';
$lang["area_de_atuacao"] = '&Aacute;rea de atua&ccedil;&atilde;o';
$lang["liberacao_online"] = 'Libera&ccedil;&atilde;o Online';
$lang["busca"] = 'Busca';
$lang["buscar"] = 'Buscar';
$lang["nossos_clientes"] = 'Nossos clientes';
$lang["area_do_beneficiario"] = '&Aacute;rea do benefici&aacute;rio';
$lang["relatorios"] = 'Relat&oacute;rios';
$lang["alterar_dados_cadastrais"] = 'Alterar dados cadastrais';
$lang["boleto_bancario"] = 'Boleto banc&aacute;rio';
$lang["area_da_empresa"] = '&Aacute;rea da empresa';
$lang["movimentacao_cadastral"] = 'Movimenta&ccedil;&atilde;o Cadastral';
$lang["area_do_dentista"] = '&Aacute;rea do dentista';
$lang["agenda"] = 'Agenda';
$lang["email"] = 'Email';
$lang["tabela_de_atos"] = 'Tabela de Atos';
$lang["area_uniodonto"] = '&Aacute;rea da Uniodonto';
$lang["boletos"] = 'Boletos';
$lang["area_do_representante"] = '&Aacute;rea do representante';
$lang["analise_critica"] = 'An&aacute;lise Cr&iacute;tica';
$lang["alterar_senha"] = 'Alterar Senha';
$lang["a_uniodonto_e_voce"] = 'A Uniodonto e voc&ecirc;';
$lang["dados_cadastrais"] = 'Dados Cadastrais';
$lang["informe_de_rendimentos"] = 'Informe de Rendimentos';
$lang["revisao_de_valores"] = 'Revis&atilde;o de Valores';
$lang["cedula_c"] = 'Declara&ccedil;&atilde;o IRPF';
$lang["calendario"] = 'Calend&aacute;rio';
$lang["fique_por_dentro"] = 'Fique por dentro';
$lang["voce_beneficiario"] = 'Voc&ecirc; benefici&aacute;rio';
$lang["como_utilizar_seu_plano"] = 'Como utilizar seu plano';
$lang["sistema_de_gestao"] = 'SIO';
$lang["consulta_nota_fiscal"] = 'Consulta Nota Fiscal';
$lang["relatorio_beneficiarios"] = 'Relat&oacute;rio Benefici&aacute;rios';
$lang["atendimento_mes"] = 'Atendimentos M&ecirc;s';
$lang["status_das_guias"] = 'Status das Guias';
$lang["atendimentos_por_especialidade"] = 'Atendimentos por Especialidade';
$lang["faturamento"] = 'Faturamento';
$lang["faturamento_intercambio"] = 'Faturamento Interc&acirc;mbio';
$lang["quantidade_beneficiarios_x_beneficiarios_atendidos"] = 'Quantidade de Benefici&aacute;rios X Benefici&aacute;rios Atendidos';
$lang["contrato"] = 'Contrato';
$lang["unionews"] = 'Unionews';
$lang["marketing"] = 'Marketing';
$lang["formularios"] = 'Formul&aacute;rios';
$lang["dados_da_empresa"] = 'Dados da Empresa';
$lang["razao_social"] = 'Raz&atilde;o Social';
$lang["nome_fantasia"] = 'Nome Fantasia';
$lang["cnpj"] = 'CNPJ';
$lang["endereco"] = 'Endere&ccedil;o';
$lang["numero"] = 'N&uacute;mero';
$lang["complemento"] = 'Complemento';
$lang["ramo_de_atividade"] = 'Ramo de Atividade';
$lang["telefone"] = 'Telefone';
$lang["fax"] = 'Fax';
$lang["pessoa_de_contato"] = 'Pessoa de contato';
$lang["cargo"] = 'Cargo';
$lang["pesquisa_para_elaboracao_da_proposta"] = 'Pesquisa para elabora&ccedil;&atilde;o da proposta';
$lang["n_de_funcionarios_da_empresa"] = 'N&ordm; de funcion&aacute;rios da empresa?';
$lang["quantos_participam_do_plano"] = 'Quantos participar&atilde;o do plano?';
$lang["possui_convenio_medico"] = 'Possui conv&ecirc;nio m&eacute;dico?';
$lang["sim"] = 'Sim';
$lang["nao"] = 'N&atilde;o';
$lang["com_qual_operadora_ou_seguradora"] = 'Com qual Operadora ou Seguradora?';
$lang["possui_convenio_odontologico"] = 'Possui conv&ecirc;nio Odontol&oacute;gico?';
$lang["motivo_mudanca"] = 'Motivo da mudan&ccedil;a';
$lang["tem_filiais"] = 'Tem filiais?';
$lang["em_quais_cidade"] = 'Em quais cidades?';
$lang["o_plano_odontologico_sera_extensivo_para_estas_filiais"] = 'O Plano Odontol&oacute;gico ser&aacute; extensivo para estas filiais?';
$lang["o_plano_odontologico_sera_extensivo_aos_dependentes_dos_funcionarios"] = 'O Plano Odontol&oacute;gico ser&aacute; extensivo aos dependentes dos funcion&aacute;rios?';
$lang["caso_negativo_qual_sera_o_percentual_de_participacao_do_funcionario"] = 'Caso negativo, qual ser&aacute; o percentual de participa&ccedil;&atilde;o do funcion&aacute;rio';
$lang["coletivo_empresarial"] = 'Coletivo Empresarial';
$lang["coletivo_por_adesao"] = 'Coletivo por Ades&atilde;o';
$lang["tipo_de_plano"] = 'Tipo de Plano';
$lang["basico"] = 'B&aacute;sico';
$lang["emergencia_misto"] = 'Emerg&ecirc;ncia / Misto';
$lang["custo_operacional"] = 'Custo  Operacional';
$lang["valor"] = 'Valor';
$lang["proposta_pra_quantas_vidas"] = 'Proposta pra quantas vidas?';
$lang["observacoes"] = 'Observa&ccedil;&atilde;o';
$lang["enviar"] = 'Enviar';
$lang["beneficios"] = 'Benef&iacute;cios';
$lang["cavo"] = '"<h1>Benef&iacute;cio Cavo</h1>
     <p><strong>
        Servi&ccedil;o de Coleta e Gerenciamento de Res&iacute;duos</strong></p>
     <p>&nbsp; </p>
     <p>
        Fechamos contrato com a empresa CAVO Servi&ccedil;os e Meio Ambiente S.A. para o servi&ccedil;o de coleta e gerenciamento de res&iacute;duos.</p>
     <p>&nbsp;</p>
 <p>
  Escolhemos a empresa CAVO n&atilde;o s&oacute; por sua estrutura e experi&ecirc;ncia no ramo, mas tamb&eacute;m, porque a mesma foi bastante flex&iacute;vel nas negocia&ccedil;&otilde;es e nos ofereceu os menores valores, j&aacute; incluindo as bombonas (recipientes utilizados para o armazenamento dos sacos de lixo) de 30 ou 50litros.</p>
 <p>&nbsp;</p>
 <strong>VALORES CURITIBA E REGI&Atilde;O METROPOLITANA </strong>
    <style>
     table td{padding: 10px;}
    </style>
 <table border=""0"" class=""tabela-atos"">
  <tbody>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 105,18 por ponto de coleta</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      Coleta semanal</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (4 coletas/m&ecirc;s)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      at&eacute;&nbsp;50 litros/semana</p>
    </td>
   </tr>
   <tr height=""15"">
    <td height=""20"">
     <p align=""left"">
      R$ 83,71 por ponto de coleta</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      Coleta quinzenal</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      (2 coletas/m&ecirc;s)</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      at&eacute; 50 litros/quinzena</p>
    </td>
   </tr>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 62,25 por ponto de coleta</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      Coleta mensal</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (1 coleta/m&ecirc;s)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      at&eacute;&nbsp;50&nbsp;litros/m&ecirc;s</p>
    </td>
   </tr>
  </tbody>
 </table>
 <br />
 <br />
 <strong>VALORES PARANAGU&Aacute;</strong>
 <table border=""0"" cellpadding=""2"" cellspacing=""2"" class=""tabela-atos"">
  <tbody>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 124,05 &nbsp; por ponto de coleta</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      Coleta semanal</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (4 coletas/m&ecirc;s)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      at&eacute;&nbsp;50 litros/semana</p>
    </td>
   </tr>
   <tr height=""15"">
    <td height=""20"">
     <p align=""left"">
      R$ 112,96 por ponto de coleta</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      Coleta quinzenal</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      (2 coletas/m&ecirc;s)</p>
    </td>
    <td align=""center"" height=""20"">
     <p align=""left"">
      at&eacute;&nbsp;50 litros/quinzena</p>
    </td>
   </tr>
   <tr height=""15"">
    <td bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      R$ 94,61 &nbsp; por ponto de coleta</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      Coleta mensal</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      (1 coleta/m&ecirc;s)</p>
    </td>
    <td align=""center"" bgcolor=""#FFCCCC"" height=""20"">
     <p align=""left"">
      at&eacute;&nbsp;50 litros/m&ecirc;s</p>
    </td>
   </tr>
  </tbody>
 </table>
 <br />
 <br />
 <strong>INSTRU&Ccedil;&Otilde;ES</strong><br />
 Para os cooperados interessados em aderir, solicitamos seguir as instru&ccedil;&otilde;es abaixo:<br />
 <br />
 <ul>
  <li>
   Comparecer na Sede da Uniodonto Curitiba e procurar pelo setor GRC - Gest&atilde;o de Relacionamento com o Cooperado &ndash; no hor&aacute;rio das 08h00 &agrave;s 18h00.</li>
  <br />
  <li>
   Para os cooperados que realizaram o protocolo do Formul&aacute;rio de Gerenciamento de Res&iacute;duos junto &agrave; Secretaria Municipal de Meio Ambiente, trazer o protocolo ORIGINAL. Ser&aacute; feita uma c&oacute;pia deste protocolo para nosso arquivo e controle.</li>
  <br />
  <li>
   Para os cooperados que n&atilde;o realizaram o protocolo junto &agrave; Secretaria Municipal de Meio Ambiente, trazer o Formul&aacute;rio de Gerenciamento de Res&iacute;duos (c&oacute;pia em anexo) preenchido completamente, pois a Secretaria n&atilde;o est&aacute; mais realizando o protocolo. Ser&aacute; feita uma c&oacute;pia deste documento para nosso arquivo e controle.</li>
  <br />
  <li>
   Na seq&uuml;&ecirc;ncia, o cooperado ir&aacute; preencher o formul&aacute;rio de SOLICITA&Ccedil;&Atilde;O DE COLETA onde indicar&aacute; o(s) endere&ccedil;o(s) e a peridiocidade da(s) coleta(s) e assinar a AUTORIZA&Ccedil;&Atilde;O PARA D&Eacute;BITO EM CONTA CORRENTE no Banco Santander, cujo desconto ocorrer&aacute; no dia do pagamento da produ&ccedil;&atilde;o.</li>
 </ul>
    <p>&nbsp;</p>
 <div>
  D&uacute;vidas entrar em contato com o setor GRC - Gest&atilde;o de Relacionamento com o Cooperado pelo fone:<br />
  <strong>(41) 3371-1935 - 3371-1937 - 3371-1940 - grc@uniodontocuritiba.com.br</strong></div>"';
$lang["unimed"] = '"<h1>Benef&iacute;cio Unimed</h1> <p>
 <b>Cobertura </b></p>
<p>
 O Plano de Sa&uacute;de da Unimed Curitiba esta em conformidade com a Lei N&deg; 9656/98, possui cobertura ampla, sem car&ecirc;ncia ara inclus&atilde;o do titular e seus dependentes.</p>
<p>&nbsp;
 </p>
<p>
 <strong>PRINCIPAIS COBERTURAS &ndash; EM COMFORMIDADE COM A LEI N&deg; 9656/98 </strong></p>
<ul>
 <li>
  Consultas m&eacute;dicas sem limites;</li>
 <li>
  Internamento cl&iacute;nico/cir&uacute;rgico sem limites de di&aacute;rias;</li>
 <li>
  Internamento em UTI sem limites de di&aacute;rias;</li>
 <li>
  Exames laboratoriais sem limites;</li>
 <li>
  Pr&oacute;teses e &oacute;rteses ligadas ao ato cir&uacute;rgico;</li>
 <li>
  Exames de alto custo tais como: Resson&acirc;ncia Magn&eacute;tica e Tomo grafia Computadorizada sem limites;</li>
 <li>
  Quimioterapia e radioterapia sem limites;</li>
 <li>
  Doen&ccedil;as infecto-contagiosos;</li>
 <li>
  Transplante de rim e c&oacute;rneas;</li>
 <li>
  Fisioterapia sem limites; (Desde que n&atilde;o seja constatado como acidente de trabalho).</li>
 <li>
  Atendimentos de urg&ecirc;ncia /emerg&ecirc;ncias em regime ambulatorial;</li>
 <li>
  12 sess&otilde;es de psicoterapia de crise;</li>
</ul>
<p>&nbsp;
 </p>
<p>
 <strong>Internamento Psiqui&aacute;tricos limitado h&aacute; 30 dias, cont&iacute;nuos ou n&atilde;o, por ano de contrato n&atilde;o cumulativo.</strong><br />
 <br />
 <strong>No caso de altera&ccedil;&atilde;o de plano:</strong><br />
 30 dias: partos a termo<br />
 06 meses: quarto individual (apartamento)<br />
 <br />
 <br />
 <strong>Quando utilizado o beneficio acima, a car&ecirc;ncia sobre a perman&ecirc;ncia do plano escolhido &eacute; de 01 ano.</strong><br />
 &nbsp;</p>
<table cellpadding=""0"" cellspacing=""0"" class=""tabela-atos"">
 <tbody>
  <tr style=""color: #fff;"">
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>Faixa Et&aacute;ria</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>2012</strong></p>
   </td>
   <td bgcolor=""#af2638"" height=""20"">
    <p align=""center"">
     <strong>Taxa de Inscri&ccedil;&atilde;o</strong></p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>C&oacute;digos dos Planos</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>801</strong><br />
     <strong>HOSP. ENF.</strong><br />
     <strong>OBSTETRICIA</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>802</strong><br />
     <strong>HOSP. ENFERMARIA</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>803</strong><br />
     <strong>HOSP. APTO OBSTETRICIA</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>804</strong><br />
     <strong>HOSP.</strong><br />
     <strong>APARTAMENTO</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""39"">
    <p align=""center"">
     <strong>Por Usu&aacute;rio</strong></p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>0-18</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 89,63</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 56,75</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 111,33</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 77,19</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>19-23</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 104,30</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 69,96</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 135,36</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 89,38</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>24-28</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 110,16</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 76,26</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 148,23</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 97,42</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>29-33</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 128,05</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 95,45</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 181,13</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 118,90</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>34-38</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 134,44</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 100,23</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 192,00</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 126,40</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>39-43</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 148,12</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 114,69</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 229,89</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 159,26</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>44-48</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 188,97</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 157,89</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 252,88</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 190,32</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>49-53</strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 245,50</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 219,65</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 312,80</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 253,31</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     <strong>54-58</strong></p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 271,52</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 252,59</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 375,36</p>
   </td>
   <td height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 302,95</p>
   </td>
   <td height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
  <tr>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     <strong>&gt;58 </strong></p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 373,34</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 337,72</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 559,28</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""bottom"">
    <p align=""center"">
     R$ 462,91</p>
   </td>
   <td bgcolor=""#FFCCCC"" height=""20"" valign=""top"">
    <p align=""center"">
     R$ 16,41</p>
   </td>
  </tr>
 </tbody>
</table>
<p>
 *Quando solicitado pelo titular uma segunda via, o mesmo ter&aacute; em sua mensalidade R$ 5,00 que vir&atilde;o acrescidos na mensalidade.<br />
 &nbsp;</p>
<p>
 <b><font color=""#AC2D44"">Para o download do documento de formaliza&ccedil;&atilde;o de inclus&atilde;o de dependentes no plano Unimed <a href=""http://www.sistemauniodonto.com.br/curitiba/upload/files/dentista/formalizacao-inclusao-dependente-unimed.pdf""> Clique aqui </a> </font></b></p>
<div>
 D&uacute;vidas entrar em contato com o setor GRC - Gest&atilde;o de Relacionamento com o Cooperado pelo fone:<br />
 <strong>(41) 3371-1935 - 3371-1937 - 3371-1940 - grc@uniodontocuritiba.com.br</strong></div>"';
$lang["nissei"] = '"<h1>Benef&iacute;cio Nissei</h1><p>
 <b>A UNIODONTO E A NISSEI EST&Atilde;O JUNTAS PARA MELHOR ATENDER VOC&Ecirc;!</b></p>
<p>&nbsp;
 </p>
<p>
 A Uniodonto Curitiba e a Nissei, uniram-se para oferecer a seus colaboradores o melhor conv&ecirc;nio da rede de farm&aacute;cias que mais cresce no Brasil.</p>
<p>&nbsp;
 </p>
<p>
 <strong>Veja agora alguns dos benef&iacute;cios de ser um conveniado Nissei. </strong></p>
<ul>
 <li>
  Mais de 60 lojas espalhadas por Curitiba, Regi&atilde;o metropolitana, Ponta Grossa e Litoral Paranaense;</li>
 <li>
  15 lojas, com atendimento 24 horas;</li>
 <li>
  Semana do Conveniado de 14 a 20 de cada m&ecirc;s com 15% de desconto em todos os medicamentos;</li>
 <li>
  Cart&atilde;o Social;</li>
 <li>
  Emerg&ecirc;ncia Sa&uacute;de;</li>
 <li>
  Farm&aacute;cia de Manipula&ccedil;&atilde;o;</li>
 <li>
  Entrega em Domic&iacute;lio (0800 416162);</li>
 <li>
  Entrega Programada;</li>
 <li>
  Encartes promocionais nas lojas;</li>
 <li>
  List&atilde;o de ofertas praticadas nas lojas;</li>
</ul>
<p>&nbsp;
 </p>
<p>
 <strong>Modalidade Fidelidade:</strong></p>
<p>
 Utilizando a Modalidade Fidelidade, o dentista comprar&aacute; nos dias 01 a 07 de cada m&ecirc;s, medicamentos a pre&ccedil;o de custo com pagamento a vista. Nos demais dias os descontos variam 15% a 20%. Apresentar o mesmo cart&atilde;o.</p>
<p>&nbsp;
 </p>
<p>
 <strong>Lembramos que esse beneficio &eacute; valido somente para cooperados de Curitiba, Regi&atilde;o Metropolitana e Litoral.</strong></p>
<p>
 D&uacute;vidas entrar em contato com o setor GRC - Gest&atilde;o de Relacionamento com o Cooperado pelo fone:<br />
 (41) 3371-1935 - 3371-1937 - 3371-1940 grc@uniodontocuritiba.com.br</p>"';
$lang["resultados_encontrados"] = ' Resultado(s) encontrado(s)';
$lang["cliente_uniodonto"] = 'Cliente Uniodonto';
$lang["numero_do_cartao_uniodonto"] = 'N&uacute;mero do Cart&atilde;o Uniodonto';
$lang["mensagem"] = 'Mensagem';
$lang["digite_o_codigo_verificador"] = 'Digite o c&oacute;digo verificador:';
$lang["proposta_de_adesao"] = 'Proposta de Ades&atilde;o';
$lang["adesao"] = '<p>Est&aacute; Proposta de Ades&atilde;o &eacute; validada para &aacute;rea de Abrang&ecirc;ncia da Uniodonto Curitiba, sendo os seguintes munic&iacute;pios: <br>
  <br>
Almirante Tamandar&eacute;, Anahy, Andir&aacute;, Araruna, Arauc&aacute;ria, Balsa Nova,   Bocaiuva do Sul, Barbosa Ferraz, Boa Esperan&ccedil;a, Campina Grande do Sul,   Campina da Lagoa, Campo Largo, Campo Mour&atilde;o, Cand&oacute;i, C&acirc;ndido de Abreu,   Cantagalo, Capanema, Cascavel, Colombo, Contenda, Corb&eacute;lia, Coronel   Vivida, Corumbata&iacute; do Sul, Chopinzinho, Clevel&acirc;ndia, Curitiba, Dois   Vizinhos, Engenheiro Beltr&atilde;o, Entre Rios, Fazenda Rio Grande, F&ecirc;nix,   Francisco Beltr&atilde;o, Foz do Igua&ccedil;u, Goioer&ecirc;, Gua&iacute;ra, Guarapuava,   Guaratuba, Itaperu&ccedil;u, Ivaipor&atilde;, Jacarezinho, Juranda, Lapa, Laranjeiras   do Sul, Mambor&ecirc;, Mangueirinha, Manoel Ribas, Matinhos, Medianeira,   Moreira Sales, Morretes, Nova Cantu, Nova Santa Rosa, Palotina, Palmas,   Paranagu&aacute;, Paranava&iacute;, Pato Branco, Peabiru, Pi&ecirc;n, Pinhais, Pinh&atilde;o,   Piraquara, Pitanga, Pontal do Paran&aacute;, Porto Amazonas, Prudent&oacute;polis,   Quatro Barras, Quarto Centen&aacute;rio, Quedas do Igua&ccedil;u, Rebou&ccedil;as, Rio Azul,   Roncador, Santa Tereza D\'Oeste, Santo Ant&ocirc;nio da Platina, S&atilde;o Jo&atilde;o do   Iva&iacute;, S&atilde;o Jos&eacute; dos Pinhais, S&atilde;o Mateus do Sul, S&atilde;o Pedro do Igua&ccedil;u,   Tijucas do Sul, Toledo, Tup&atilde;ssi, Umuarama, Uni&atilde;o da Vit&oacute;ria. </p>
<p>&nbsp;</p>
<p>Voc&ecirc; escolheu o plano <strong>"';
$lang["adesao_superior"] = 'O Plano Superior cobre 171 procedimentos, dentre eles   diagn&oacute;sticos, atendimento de urg&ecirc;ncia 24 horas, restaura&ccedil;&atilde;o em resina,   cirurgias de remo&ccedil;&atilde;o de dentes inclusos e semi-inclusos, tratamento de   gengiva, tratamento e retratamento de canal, alguns tipos de   radiografias e servi&ccedil;os de preven&ccedil;&atilde;o (orienta&ccedil;&atilde;o, profilaxia e aplica&ccedil;&atilde;o   de fl&uacute;or).    No momento da contrata&ccedil;&atilde;o voc&ecirc; pode optar pelo Plano Superior com ou sem   car&ecirc;ncia e escolher a forma de pagamento das mensalidades, por boleto   banc&aacute;rio ou d&eacute;bito em conta corrente. Esse Plano possui um prazo   contratual de dois anos.';
$lang["adesao_avancado"] = 'Ao optar pelo Plano Avan&ccedil;ado, al&eacute;m da cobertura do Plano Superior, o plano oferece uma cobertura estendida com direito &agrave; radiografia panor&acirc;mica, RX de m&atilde;o e punho para a documenta&ccedil;&atilde;o ortod&ocirc;ntica, alveolotomia, dessensibilidade dent&aacute;ria, totalizando 182 procedimentos. No momento da contrata&ccedil;&atilde;o voc&ecirc; pode optar pelo Plano Avan&ccedil;ado com ou sem car&ecirc;ncia e escolher a forma de pagamento das mensalidades, por boleto banc&aacute;rio ou d&eacute;bito em conta corrente. Esse Plano possui um prazo contratual de dois anos.';
$lang["adesao_valor1"] = '<p>Este plano possui o <strong>valor mensal por pessoa</strong> de <strong>R$ ';
$lang["adesao_valor2"] = '</strong> e o <strong>valor total mensal</strong> de <strong>R$ ';
$lang["adesao_valor3"] = '"</strong></p>
      <p>&nbsp;</p>
     <p><strong>Valor da Taxa de Ades&atilde;o: R$ 40,00</strong></p>
      <p>&nbsp;</p>
      <p>Para completarmos sua ades&atilde;o &eacute; necess&aacute;rio que seja fornecido alguns dados relevantes para o cadastramento em nosso sistema.</p>
<p>&nbsp;</p>
      <p>Preencha os dados do formul&aacute;rio abaixo para enviar o termo de ades&atilde;o do plano &agrave; Uniodonto Curitiba.</p>"';
$lang["dados_pessoais_do_titular_do_contrato"] = 'Dados Pessoais do titular do contrato';
$lang["sexo"] = 'Sexo';
$lang["data_de_nascimento"] = 'Data de Nascimento';
$lang["estado_civil"] = 'Estado Civil';
$lang["solteiro"] = 'Solteiro(a)';
$lang["casado"] = 'Casado(a)';
$lang["separado"] = 'Separado(a)';
$lang["divorciado"] = 'Divorciado(a)';
$lang["viuvo"] = 'Vi&uacute;vo(a)';
$lang["tipo_de_endereco"] = 'Tipo de Endere&ccedil;o';
$lang["rua"] = 'Rua';
$lang["avenida"] = 'Avenida';
$lang["alameda"] = 'Alameda';
$lang["praca"] = 'Pra&ccedil;a';
$lang["rodovia"] = 'Rodovia';
$lang["travessa"] = 'Travessa';
$lang["cep"] = 'CEP';
$lang["telefone_residencial"] = 'Telefone Residencial';
$lang["celular"] = 'Celular';
$lang["telefone_de_recado"] = 'Telefone de Recado';
$lang["falar_com"] = 'Falar com';
$lang["documentacao"] = 'Documenta&ccedil;&atilde;o';
$lang["rg"] = 'RG';
$lang["orgao_expedidor"] = 'Org&atilde;o Expedidor';
$lang["data_expedicao_rg"] = 'Data expedi&ccedil;&atilde;o RG';
$lang["cpf"] = 'CPF';
$lang["escolaridade"] = 'Escolaridade';
$lang["nivel"] = 'N&iacute;vel';
$lang["fundamental"] = 'Fundamental';
$lang["medio"] = 'M&eacute;dio';
$lang["superior"] = 'Superior';
$lang["pos_graduacao"] = 'P&oacute;s Gradua&ccedil;&atilde;o';
$lang["mestrado"] = 'Mestrado';
$lang["doutorado"] = 'Doutorado';
$lang["pos_doutorado"] = 'P&oacute;s Doutorado';
$lang["nome_completo_da_mae_do_titular_do_contrato"] = 'Nome completo da m&atilde;e do titular do contrato';
$lang["dados_comerciais_do_titular_responsavel"] = 'Dados Comerciais do Titular Respons&aacute;vel';
$lang["empresa"] = 'Empresa';
$lang["autonomo"] = 'Aut&ocirc;nomo';
$lang["cargo"] = 'Cargo';
$lang["renda_familiar"] = 'Renda Familiar';
$lang["vinculo_empregaticio"] = 'V&iacute;nculo Empregat&iacute;cio';
$lang["empregado"] = 'Empregado';
$lang["contratado"] = 'Contratado';
$lang["estagiario"] = 'Estagi&aacute;rio';
$lang["outros"] = 'Outros';
$lang["informacoes_do_beneficiario_dependente"] = 'Informa&ccedil;&otilde;es do benefici&aacute;rio dependente';
$lang["grau_de_parentesco"] = 'Grau de Parentesco';
$lang["conjuge"] = 'C&ocirc;njuge';
$lang["filho"] = 'Filho';
$lang["filha"] = 'Filha';
$lang["pai"] = 'Pai';
$lang["mae"] = 'M&atilde;e';
$lang["agregado"] = 'Agregado';
$lang["nome_completo_da_mae"] = 'Nome Completo da Mae';
$lang["masculino"] = 'Masculino';
$lang["feminino"] = 'Feminino';
$lang["e_necessario_ler_o_termo_de_adesao_e_assinalar_o_marcador_abaixo_para_completar_o_envio"] = '&Eacute; necess&aacute;rio ler o termo de ades&atilde;o e assinalar o marcador abaixo para completar o envio.';
$lang["eu_li_e_concordo_com_os_termos_descritos_no_termo_de_adesao_de_plano"] = 'Eu li e concordo com os termos descritos no Termo de Ades&atilde;o de Plano';
$lang["texto_encontre_seu_dentista"] = 'Veja como &eacute; f&aacute;cil encontrar o dentista de sua prefer&ecirc;ncia. Basta escolher a especialidade do cirurgi&atilde;o-dentista cooperado, o bairro de sua prefer&ecirc;ncia ou a sua localidade. Caso voc&ecirc; viaje dentro do estado do Paran&aacute;, basta selecionar a cidade de destino e voc&ecirc; encontrar&aacute; um dentista para atend&ecirc;-lo.';
$lang["eventos"] = 'Eventos';
$lang["mes01"] = 'Janeiro';
$lang["mes02"] = 'Fevereiro';
$lang["mes03"] = 'Mar&ccedil;o';
$lang["mes04"] = 'Abril';
$lang["mes05"] = 'Maio';
$lang["mes06"] = 'Junho';
$lang["mes07"] = 'Julho';
$lang["mes08"] = 'Agosto';
$lang["mes09"] = 'Setembro';
$lang["mes10"] = 'Outubro';
$lang["mes11"] = 'Novembro';
$lang["mes12"] = 'Dezembro';
$lang["janeiro"] = 'Janeiro';
$lang["fevereiro"] = 'Fevereiro';
$lang["marco"] = 'Mar&ccedil;o';
$lang["abril"] = 'Abril';
$lang["maio"] = 'Maio';
$lang["junho"] = 'Junho';
$lang["julho"] = 'Julho';
$lang["agosto"] = 'Agosto';
$lang["setembro"] = 'Setembro';
$lang["outubro"] = 'Outubro';
$lang["novembro"] = 'Novembro';
$lang["dezembro"] = 'Dezembro';
$lang["como_chegar"] = 'Como chegar - Mapa';
$lang["enviando_por_favor_aguarde"] = 'Enviando por favor aguarde';
$lang["responsavel"] = 'Respons&aacute;vel';
$lang["cidade_estado"] = 'Cidade/Estado';
$lang["qtd_funcionarios"] = 'Qtd. Funcion&aacute;rios';
$lang["pagina_nao_encontrada"] = 'P&aacute;gina n&atilde;o encontrada';
$lang["desculpe_a_pagina_que_voce_procura_nao_foi_encontrada_em_nosso_site"] = 'Desculpe, a p&aacute;gina que voc&ecirc; procura n&atilde;o foi encontrada em nosso site.';
$lang["revistas"] = 'Revistas';
$lang["texto_sustentabilidade"] = '"O desenvolvimento sustent&aacute;vel da Uniodonto apresenta tr&ecirc;s grandes dimens&otilde;es: crescimento econ&ocirc;mico, desenvolvimento do capital humano e equil&iacute;brio do meio ambiente.<br><br>
          Nossas a&ccedil;&otilde;es t&ecirc;m o proposito de garantir que os resultados alcan&ccedil;ados sejam consistentes, gerando um crescimento econ&ocirc;mico, atrav&eacute;s de treinamento, desenvolvimento e capacita&ccedil;&atilde;o dos nossos cooperados e colaboradores, al&eacute;m de manter o compromisso com o meio ambiente.<br><br>
          Inova&ccedil;&atilde;o dos nossos servi&ccedil;os, sempre buscando ofertar a qualidade gerando satisfa&ccedil;&atilde;o dos nossos benefici&aacute;rios, tanto no presente como para a gera&ccedil;&atilde;o futura.<br>
          A busca pelo desenvolvimento da comunidade atrav&eacute;s de projetos sociais, em parceria com institui&ccedil;&otilde;es p&uacute;blicas e privadas. <br><br>
          <b>Nossos Compromissos</b><br><br>
          Cumprimento dos Sete Princ&iacute;pios do Cooperativismo<br><br>
          1&ordm; Ades&atilde;o volunt&aacute;ria e livre: as cooperativas s&atilde;o organiza&ccedil;&otilde;es abertas &agrave; participa&ccedil;&atilde;o de todos.<br><br>
          2&ordm; Gest&atilde;o democr&aacute;tica: os cooperados votam os objetivos e metas de trabalho conjunto, bem como elegem os representantes que ir&atilde;o administrar a sociedade.<br><br>
          3&ordm; Participa&ccedil;&atilde;o econ&ocirc;mica dos membros: todos contribuem igualmente para a forma&ccedil;&atilde;o do capital da cooperativa. Se houver sobras, ser&atilde;o divididas entre os s&oacute;cios.<br><br>
          4&ordm; Autonomia e independ&ecirc;ncia: o funcionamento da cooperativa &eacute; controlado por seus s&oacute;cios, que s&atilde;o os donos do neg&oacute;cio.<br><br>
          5&ordm; Educa&ccedil;&atilde;o, forma&ccedil;&atilde;o e informa&ccedil;&atilde;o: &eacute; objetivo permanente da cooperativa destinar a&ccedil;&otilde;es e recursos para formar seus associados, capacitando-os para a pr&aacute;tica cooperativista.<br><br>
          6&ordm; Intercoopera&ccedil;&atilde;o: para o fortalecimento do cooperativismo, &eacute; importante que haja interc&acirc;mbio de informa&ccedil;&otilde;es, produtos e servi&ccedil;os entre as cooperativas, viabilizando o setor como atividade s&oacute;cio-econ&ocirc;mica.<br><br>
          7&ordm; Interesse pela comunidade: as cooperativas trabalham para o desenvolvimento sustentado de suas comunidades, por meio da execu&ccedil;&atilde;o de programas s&oacute;cio-culturais, realizados em parceria com o governo e outras entidades civis.<br>"';
$lang["pis"] = 'PIS';
$lang["carteira_de_trabalho"] = 'Carteira de Trabalho';
$lang["serie"] = 'S&eacute;rie';
$lang["cnh"] = 'CNH';
$lang["nao_possui"] = 'N&atilde;o possui';
$lang["curso_de_formacao"] = 'Curso de Forma&ccedil;&atilde;o';
$lang["escola_instituicao"] = 'Escola/Institui&ccedil;&atilde;o';
$lang["ano_de_conclusao"] = 'Ano de conclus&atilde;o';
$lang["outros_cursos"] = 'Outros cursos';
$lang["palestras_treinamentos"] = 'Palestras/treinamentos';
$lang["experiencia"] = 'Experi&ecirc;ncia';
$lang["ultima_empresa"] = '&Uacute;ltima empresa';
$lang["data_admissao"] = 'Data de Admiss&atilde;o';
$lang["data_demissao"] = 'Data de Demiss&atilde;o';
$lang["funcao"] = 'Fun&ccedil;&atilde;o';
$lang["ultimo_salario"] = '&Uacute;ltimo sal&aacute;rio';
$lang["descreva_as_tarefas_realizadas"] = 'Descreva as tarefas realizadas';
$lang["penultima_empresa"] = 'Pen&uacute;ltima empresa';
$lang["antepenultima_empresa"] = 'Antepen&uacute;ltima empresa';
$lang["pretensoes"] = 'Pretens&otilde;es';
$lang["departamento"] = 'Departamento';
$lang["cadastro"] = 'Cadastro';
$lang["intercambio"] = 'Interc&acirc;mbio';
$lang["sac_empresa"] = 'SAC Empresa';
$lang["cobranca"] = 'Cobran&ccedil;a';
$lang["sac_coop"] = 'SAC Coop';
$lang["administracao"] = 'Administra&ccedil;&atilde;o';
$lang["avaliador"] = 'Avaliador';
$lang["salario_pretendido"] = 'Sal&aacute;rio pretendido';
$lang["portador_de_necessidades_especiais"] = 'Portador de necessidades especiais';
$lang["qual_necessidade"] = 'Qual';
$lang["disponibilidade_para_trabalhar_em_outra_cidade"] = 'Disponibilidade para trabalhar em outra cidade';
$lang["foto"] = 'Foto';
$lang["cnes"] = 'CNES';
$lang["n_de_licenca_sanitaria"] = 'N. de Licen&ccedil;a Sanit&aacute;ria';
$lang["alvara"] = 'Alvar&aacute;';
$lang["registrado_pelo_cro"] = 'Registrado pelo CRO?';
$lang["e_sua_especialidade_principal"] = '&Eacute; sua especialidade Principal?';
$lang["incluir"] = 'Incluir';
$lang["comercial"] = 'Comercial';
$lang["atende_pacientes_com_nescessidades_especiais"] = 'Atende pacientes com nescessidades especiais?';
$lang["possui_acesso_aos_mesmos"] = 'Possui acesso aos mesmos?';
$lang["atende_em_quais_dias"] = 'Atende em quais dias?';
$lang["este_e_seu_local_principal"] = 'Este &eacute; seu local Principal?';
$lang["horario"] = 'Hor&aacute;rio';
$lang["aperfeicoamento"] = 'Aperfei&ccedil;oamento';
$lang["especializacoes"] = 'Especializa&ccedil;&otilde;es';
$lang["area"] = '&Aacute;rea';
$lang["instituicoes"] = 'Institui&ccedil;&otilde;es';
$lang["concluido"] = 'Conclu&iacute;do';
$lang["em_andamento"] = 'Em andamento';
$lang["data"] = 'Data';
$lang["arquivos"] = 'Arquivos';
$lang["Alguem_da_uniodonto_esta_lhe_indicando_quem"] = 'Algu&eacute;m da Uniodonto est&aacute; lhe indicando? Quem?';
$lang["curriculum"] = 'Curriculum';
$lang["telefone_comercial"] = 'Telefone comercial';
$lang["segunda"] = 'Segunda';
$lang["terca"] = 'Ter&ccedil;a';
$lang["quarta"] = 'Quarta';
$lang["quinta"] = 'Quinta';
$lang["sexta"] = 'Sexta';
$lang["sabado"] = 'S&aacute;bado';
$lang["domingo"] = 'Domingo';
$lang["as"] = 'as';
$lang["cro"] = 'CRO';
$lang["e_necessario_preencher_todos_os_campos"] = '&Eacute; necess&aacute;rio preencher todos os campos';
$lang["preencha_o_codigo_verificador_corretamente"] = 'Preencha o c&oacute;digo verificador corretamente';
$lang["email_enviado_com_sucesso"] = 'Email enviado com sucesso!';
$lang["nao_foi_possivel_enviar_o_email_tente_novamente"] = 'N&atilde;o foi poss&iacute;vel enviar o email! Tente novamente!';
$lang["resultado_da_busca_por"] = 'Resultado da busca por:';
$lang["nome_da_empresa"] = 'Nome da empresa';
$lang["qtd_de_vidas"] = 'Qtd. de vidas';
$lang["taxa_de_adesao"] = 'Taxa de ades&atilde;o';
$lang["carencia"] = 'Car&ecirc;ncia';
$lang["gerar_proposta"] = 'Gerar proposta';
$lang["gerar"] = 'Gerar';
$lang["tabelas"] = 'Tabelas';
$lang["manuais"] = 'Manuais';
$lang["ja_existe_uma_proposta_ativa_para_esta_empresa"] = 'J&aacute; existe uma proposta ativa para esta empresa!';
$lang["esta_empresa_j�_possui_contrato"] = 'Esta empresa j&aacute; possui contrato!';
$lang["preencha_todos_os_campos_antes_de_gerar_a_proposta"] = 'Preencha todos os campos antes de gerar a proposta!';
$lang["nova_proposta"] = 'Nova proposta';
$lang["ver_propostas"] = 'Ver propostas';
$lang["tabela"] = 'Tabela';
$lang["material_grafico"] = 'Material gr&aacute;fico';
$lang["validade"] = 'Validade';
$lang["data_de_inclusao"] = 'Data de inclus&atilde;o';
$lang["empresa_reservada_consulte_o_departamento_comercial"] = 'Empresa reservada. Consulte o departamento comercial!';	
$lang["esta_empresa_ja_e_cliente_uniodonto"] = 'Esta empresa j&aacute; &eacute; cliente Uniodonto!';	
$lang["digite_o_numero_do_cnpj"] = 'Digite o n&uacute;mero do CNPJ';
$lang["consultando_cnpj_por_favor_aguarde"] = 'Consultando CNPJ por favor aguarde...';
$lang["enviar_email"] = 'Enviar email';
$lang["empresa_inativada_no_sistema_uniodonto_entre_em_contato_com_o_comercial"] = 'Empresa inativada no sistema Uniodonto! Entre em contato com o comercial.';
$lang["prospect"] = 'Prospect';
$lang["codigo_consultor"] = 'C&oacute;digo consultor';
$lang["email_consultor"] = 'Email consultor';
$lang["email_empresa"] = 'Email empresa';
$lang["pagamento_online"] = 'Pagamento Online';

