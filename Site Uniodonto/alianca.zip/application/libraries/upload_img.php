<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Upload_img {

    var $link           = ''; // endere�o para salvar imagem
    var $nome         = ''; // nome do input
	

	public function salvar($link,$nome){
			//print $link."-".$nome;
			$config['upload_path'] = $link;
			$field_name = $nome;
			$config['allowed_types'] = 'gif|jpg|png';
			$config['remove_spaces'] = TRUE;
			$config['encrypt_name'] = TRUE;
			$config['overwrite'] = FALSE;
			$config['max_size']	= '100000';
			$this->upload->initialize($config);
			/*if ( ! $this->upload->do_upload($field_name))
				{
					$die('Erro ao incluir imagem! Tente novamente');
										
				}else{
								$dados_upload = $this->upload->data();
								$config['image_library'] = 'gd2';
								$config['source_image'] = $dados_upload['full_path'];
								$config['new_image'] = $dados_upload['file_path'];
								$config['create_thumb'] = FALSE;
								$config['maintain_ratio'] = FALSE;
								$config['width'] = 940;
								$config['height'] = 400;
								$config['quality'] = 100;
								$this->image_lib->initialize($config);
								
								$this->image_lib->resize();
								
								$dados_query = array(
									'link' => $_POST["link"],
									'texto' => $_POST["texto"],
									'img' => 'images/banners/'.$dados_upload['file_name']
								
								);
								 
								$this->banners_model->add_record($dados_query);
								redirect(base_url().'admin/banner');
					}*/
			
		
		
		}
    
}
