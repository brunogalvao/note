<?php
class rx_qtd_model extends CI_Model {

	function get_rx_qtd(){
		$this->db->order_by("rx_qtd_id", "desc"); 
		$query = $this->db->get('rx_qtd');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}

	function add_record($options = array()){
		$this->db->insert('rx_qtd', $options);
  		return  $this->db->insert_id()  ;
	}
  
	function update_record($options = array()){
		$this->db->where('rx_qtd_id', $options['rx_qtd_id']);
		$this->db->update('rx_qtd', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('rx_qtd_id', $id);
		$this->db->delete('rx_qtd');
		return $this->db->affected_rows();
	}
  
	
	function get_by_id($id){
		$this->db->where("rx_qtd_id",$id);
		$query = $this->db->get("rx_qtd");
		return $query->row(0);
		}
	
	
	function confere_cod($pesquisa){
		
		$this->db->where('rx_qtd_lote',$pesquisa['rx_lote']);
		$this->db->where('rx_qtd_inicio <=',$pesquisa['rx_cod']);
		$this->db->where('rx_qtd_fim >=',$pesquisa['rx_cod']);
		$query = $this->db->get('rx_qtd');
        $result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
		
	function confere_lote($pesquisa){
		
		$this->db->where('rx_qtd_lote',$pesquisa['rx_qtd_lote']);
		
		$this->db->where('rx_qtd_inicio BETWEEN '.$pesquisa['rx_qtd_inicio'].' and '.$pesquisa['rx_qtd_fim'], NULL, FALSE); 
			
		
		$query = $this->db->get('rx_qtd');
        $result = $query->num_rows();
		
		
		$this->db->where('rx_qtd_lote',$pesquisa['rx_qtd_lote']);
		
		$this->db->where('rx_qtd_fim BETWEEN '.$pesquisa['rx_qtd_inicio'].' and '.$pesquisa['rx_qtd_fim'], NULL, FALSE); 
		
					
		
		$query = $this->db->get('rx_qtd');
        $result = $query->num_rows() + $result;
		

        return $result;
	} 
	
		
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("rx_qtd_id", "desc");
		if(isset($pesquisa['rx_qtd_id']) != ""){
			$this->db->where('rx_qtd_id',$pesquisa['rx_qtd_id']);
			}
		
		$this->db->limit($limit, $start);
		$query = $this->db->get('rx_qtd');
		
		return $query->result();

		
		}
	function count_rx_qtd($pesquisa){
		if(isset($pesquisa['rx_qtd_id']) != ""){
			$this->db->where('rx_qtd_id',$pesquisa['rx_qtd_id']);
			}
		
			
		$query = $this->db->get('rx_qtd');
        return $query->num_rows();
	} 	

		

}