<?php
class proposta_planos_model extends CI_Model {

	function get_plano($qtd, $tipo){
		$this->db->where("plano_cod",$tipo); 
		$this->db->where("plano_qtd_menor <=",$qtd); 
		$this->db->where("plano_qtd_maior >=",$qtd); 
		$query = $this->db->get('propostas_planos');

		return $query->result();
	}

		

}