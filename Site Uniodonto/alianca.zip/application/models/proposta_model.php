<?php
class proposta_model extends CI_Model {

	function get_propostas(){
		$this->db->order_by("proposta_id", "desc"); 
		$query = $this->db->get('propostas');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	
	function propostas_por_representantes(){
		$this->db->select("proposta_cod_rep, proposta_nome_rep, count(*) as total");
		$this->db->group_by("proposta_cod_rep");
		$this->db->where('proposta_data >=',date('Y-m-d', strtotime("-30 days")));
		$this->db->limit(10, 0);
		$query = $this->db->get('propostas');
		
		$result = $query->result();
		return $result;
	}

	function add_record($options = array()){
		$this->db->insert('propostas', $options);
  		return  $this->db->insert_id()  ;
	}
  
	function update_record($options = array()){
		$this->db->where('proposta_id', $options['proposta_id']);
		$this->db->update('propostas', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('proposta_id', $id);
		$this->db->delete('propostas');
		return $this->db->affected_rows();
	}
  
	
	function get_by_id($id){
		$this->db->where("proposta_id",$id);
		$query = $this->db->get("propostas");
		return $query->row(0);
		}
		
	function get_by_cnpj($cnpj){
		$this->db->where("proposta_cnpj",$cnpj);
		$this->db->where("proposta_validade >",date("Y-m-d"));
		$query = $this->db->get("propostas");
		return $query->num_rows();
		}
	
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("proposta_id", "desc");
		if(isset($pesquisa['proposta_id']) != ""){
			$this->db->where('proposta_id',$pesquisa['proposta_id']);
			}
		if(isset($pesquisa['proposta_n']) != ""){
			$this->db->where('proposta_n',$pesquisa['proposta_n']);
			}
		if(isset($pesquisa['proposta_cod_rep']) != ""){
			$this->db->where('proposta_cod_rep',$pesquisa['proposta_cod_rep']);
			}
		if(isset($pesquisa['proposta_nome_rep']) != ""){
			$this->db->like('proposta_nome_rep',$pesquisa['proposta_nome_rep']);
			}
		if(isset($pesquisa['proposta_cod_consultor']) != ""){
			$this->db->where('proposta_cod_consultor',$pesquisa['proposta_cod_consultor']);
			}
		if(isset($pesquisa['proposta_nome_consultor']) != ""){
			$this->db->like('proposta_nome_consultor',$pesquisa['proposta_nome_consultor']);
			}
		if(isset($pesquisa['datade']) != ""){
			$this->db->where('proposta_data >=',$pesquisa['datade']);
			}
		if(isset($pesquisa['dataate']) != ""){
			$this->db->where('proposta_data <=',$pesquisa['dataate']);
			}	
		if(isset($pesquisa['validadede']) != ""){
			$this->db->where('proposta_validade >=',$pesquisa['validadede']);
			}
		if(isset($pesquisa['validadeate']) != ""){
			$this->db->where('proposta_validade <=',$pesquisa['validadeate']);
			}		
		if(isset($pesquisa['proposta_validade_contrato']) != ""){
			$this->db->where('proposta_validade_contrato',$pesquisa['proposta_validade_contrato']);
			}
			
		if(isset($pesquisa['proposta_empresa']) != ""){
			$this->db->like('proposta_empresa',$pesquisa['proposta_empresa']);
			}
		if(isset($pesquisa['proposta_cnpj']) != ""){
			$this->db->where('proposta_cnpj',$pesquisa['proposta_cnpj']);
			}
		if(isset($pesquisa['proposta_contato']) != ""){
			$this->db->where('proposta_contato',$pesquisa['proposta_contato']);
			}
		if(isset($pesquisa['proposta_tel']) != ""){
			$this->db->where('proposta_tel',$pesquisa['proposta_tel']);
			}
		if(isset($pesquisa['proposta_email']) != ""){
			$this->db->like('proposta_email',$pesquisa['proposta_email']);
			}
		if(isset($pesquisa['proposta_qtd_vidas']) != ""){
			$this->db->where('proposta_qtd_vidas',$pesquisa['proposta_qtd_vidas']);
			}
		if(isset($pesquisa['proposta_adesao']) != ""){
			$this->db->where('proposta_adesao',$pesquisa['proposta_adesao']);
			}
		if(isset($pesquisa['proposta_carencia']) != ""){
			$this->db->where('proposta_carencia',$pesquisa['proposta_carencia']);
			}
		if(isset($pesquisa['proposta_cidade']) != ""){
			$this->db->where('proposta_cidade',$pesquisa['proposta_cidade']);
			}
		if(isset($pesquisa['proposta_uf']) != ""){
			$this->db->where('proposta_uf',$pesquisa['proposta_uf']);
			}
		if(isset($pesquisa['proposta_plano']) != ""){
			$this->db->where('proposta_plano',$pesquisa['proposta_plano']);
			}			


		$this->db->limit($limit, $start);
		$query = $this->db->get('propostas');
		
		return $query->result();

		
		}
	function count_propostas($pesquisa){
		if(isset($pesquisa['proposta_id']) != ""){
			$this->db->where('proposta_id',$pesquisa['proposta_id']);
			}
		if(isset($pesquisa['proposta_n']) != ""){
			$this->db->where('proposta_n',$pesquisa['proposta_n']);
			}
		if(isset($pesquisa['proposta_cod_rep']) != ""){
			$this->db->where('proposta_cod_rep',$pesquisa['proposta_cod_rep']);
			}
		if(isset($pesquisa['proposta_nome_rep']) != ""){
			$this->db->like('proposta_nome_rep',$pesquisa['proposta_nome_rep']);
			}
		if(isset($pesquisa['proposta_cod_consultor']) != ""){
			$this->db->where('proposta_cod_consultor',$pesquisa['proposta_cod_consultor']);
			}
		if(isset($pesquisa['proposta_nome_consultor']) != ""){
			$this->db->like('proposta_nome_consultor',$pesquisa['proposta_nome_consultor']);
			}
		if(isset($pesquisa['datade']) != ""){
			$this->db->where('proposta_data >=',$pesquisa['datade']);
			}
		if(isset($pesquisa['dataate']) != ""){
			$this->db->where('proposta_data <=',$pesquisa['dataate']);
			}	
		if(isset($pesquisa['validadede']) != ""){
			$this->db->where('proposta_validade >=',$pesquisa['validadede']);
			}
		if(isset($pesquisa['validadeate']) != ""){
			$this->db->where('proposta_validade <=',$pesquisa['validadeate']);
			}		
		if(isset($pesquisa['proposta_validade_contrato']) != ""){
			$this->db->where('proposta_validade_contrato',$pesquisa['proposta_validade_contrato']);
			}
			
		if(isset($pesquisa['proposta_empresa']) != ""){
			$this->db->like('proposta_empresa',$pesquisa['proposta_empresa']);
			}
		if(isset($pesquisa['proposta_cnpj']) != ""){
			$this->db->where('proposta_cnpj',$pesquisa['proposta_cnpj']);
			}
		if(isset($pesquisa['proposta_contato']) != ""){
			$this->db->where('proposta_contato',$pesquisa['proposta_contato']);
			}
		if(isset($pesquisa['proposta_tel']) != ""){
			$this->db->where('proposta_tel',$pesquisa['proposta_tel']);
			}
		if(isset($pesquisa['proposta_email']) != ""){
			$this->db->like('proposta_email',$pesquisa['proposta_email']);
			}
		if(isset($pesquisa['proposta_qtd_vidas']) != ""){
			$this->db->where('proposta_qtd_vidas',$pesquisa['proposta_qtd_vidas']);
			}
		if(isset($pesquisa['proposta_adesao']) != ""){
			$this->db->where('proposta_adesao',$pesquisa['proposta_adesao']);
			}
		if(isset($pesquisa['proposta_carencia']) != ""){
			$this->db->where('proposta_carencia',$pesquisa['proposta_carencia']);
			}
		if(isset($pesquisa['proposta_cidade']) != ""){
			$this->db->where('proposta_cidade',$pesquisa['proposta_cidade']);
			}
		if(isset($pesquisa['proposta_uf']) != ""){
			$this->db->where('proposta_uf',$pesquisa['proposta_uf']);
			}
		if(isset($pesquisa['proposta_plano']) != ""){
			$this->db->where('proposta_plano',$pesquisa['proposta_plano']);
			}	
		$query = $this->db->get('propostas');
        return $query->num_rows();
	} 	

		

}