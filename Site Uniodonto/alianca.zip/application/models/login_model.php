﻿<?php
class login_model extends CI_Model {

    # VALIDA USUÁRIO
    function validate() {
        $this->db->where('user_nome', $this->input->post('user_nome')); 
        $this->db->where('user_senha', md5($this->input->post('user_senha')));
        $this->db->where('user_status', 1); // Verifica o status do usuário

        $query = $this->db->get('user'); 
        if ($query->num_rows == 1) { 
            return array("login" => true, "user" => $query->result()); // RETORNA VERDADEIRO
        }
    }

    # VERIFICA SE O USUÁRIO ESTÁ LOGADO
    function logged() {
        $logged = $this->session->userdata('logged');

        if (!isset($logged) || $logged != true) {
            redirect(base_url().'admin');
            die();
        }
    }
	
	function logged_admin() {
        $logged = $this->session->userdata('logged');
		$admin = $this->session->userdata('admin');
		$cidade = $this->session->userdata('cidade');
        if (!isset($logged) || $admin != true || $cidade != "curitiba") {
           redirect(base_url().'admin');
            die();
        }
    }
	
	function logged_users() {
        $logged = $this->session->userdata('logged');

        if ($logged != true) {
            return false;
        }else{
			return true;
			}
    }
	
	
}

