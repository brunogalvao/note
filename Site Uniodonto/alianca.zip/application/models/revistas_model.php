<?php
class revistas_model extends CI_Model {

	function get_revistas(){
		$query = $this->db->get('revista');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('revista', $options);
		return $this->db->affected_rows();
	}
  
	function update_revistas($options = array()){
		$this->db->where('revista_id', $options['revista_id']);
		$this->db->update('revista', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('revista_id', $id);
		$this->db->delete('revista');
		return $this->db->affected_rows();
	}
	
	 
	
	function update_record($options = array()){
		
		if(isset($options['revista_titulo'])){
			$this->db->set('revista_titulo',$options['revista_titulo']);
			}
		if(isset($options['revista_capa'])){
			$this->db->set('revista_capa',$options['revista_capa']);
			}
		if(isset($options['revista_pdf'])){
			$this->db->set('revista_pdf',$options['revista_pdf']);
			}	
		
		$this->db->where('revista_id',$options['revista_id']);
		$this->db->update('revista');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("revista_id",$id);
		$query = $this->db->get("revista");
		return $query->row(0);
		}

	function pesquisa_revistas($options){
	
		$this->db->order_by("revista_id", "desc");
		if(isset($options['revista_titulo'])){
			$this->db->where('revista_titulo',$options['revista_titulo']);
			}
		
		$query = $this->db->get('revista');
		return $query->result();
	}
		
	function get_all($options, $limit, $start) {
		if(isset($options['revista_titulo'])){
			$this->db->where('revista_titulo',$options['revista_titulo']);
			}
			

		$this->db->limit($limit, $start);
		$query = $this->db->get('revista');
		return $query->result();
		}
	function count_revistas($options){
		if(isset($options['revista_titulo'])){
			$this->db->where('revista_titulo',$options['revista_titulo']);
			}
			

		$query = $this->db->get('revista');
        return $query->num_rows();
	} 
}