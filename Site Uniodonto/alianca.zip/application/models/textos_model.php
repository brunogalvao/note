<?php
class textos_model extends CI_Model {

	function get_textos(){
		$this->db->order_by("texto_id", "asc"); 
		$query = $this->db->get('textos');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function pesquisa_textos($id_menu){
		$this->db->select('texto_id, texto_titulo_'.$this->session->userdata("idioma").' as texto_titulo, texto_menu' );
		$this->db->order_by("texto_posicao", "asc"); 
		$this->db->where('texto_menu',$id_menu);
		$query = $this->db->get('textos');
		return $query->result();
	}
	function add_record($options = array()){
		$this->db->insert('textos', $options);
		return $this->db->affected_rows();
	}
 	function delete_record($id){
		$this->db->where('texto_id', $id);
		$this->db->delete('textos');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['texto_titulo_ptBR'])){
			$this->db->set('texto_titulo_ptBR',$options['texto_titulo_ptBR']);
			}
		if(isset($options['texto_titulo_en'])){
			$this->db->set('texto_titulo_en',$options['texto_titulo_en']);
			}
		if(isset($options['texto_titulo_es'])){
			$this->db->set('texto_titulo_es',$options['texto_titulo_es']);
			}	
		if(isset($options['texto_menu'])){
			$this->db->set('texto_menu',$options['texto_menu']);
			}	
		if(isset($options['texto_texto_ptBR'])){
			$this->db->set('texto_texto_ptBR',$options['texto_texto_ptBR']);
			}
		if(isset($options['texto_texto_en'])){
			$this->db->set('texto_texto_en',$options['texto_texto_en']);
			}
		if(isset($options['texto_texto_es'])){
			$this->db->set('texto_texto_es',$options['texto_texto_es']);
			}	
		if(isset($options['texto_img'])){
			$this->db->set('texto_img',$options['texto_img']);
			}
		if(isset($options['texto_posicao'])){
			$this->db->set('texto_posicao',$options['texto_posicao']);
			}
					
		$this->db->where('texto_id',$options['texto_id']);
		$this->db->update('textos');		
		
		return $this->db->affected_rows();
		
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("texto_id",$id);
		$query = $this->db->get("textos");
		return $query->row(0);
		}
	function get_by_id_array($id){
		$this->db->select('texto_titulo_'.$this->session->userdata("idioma").', texto_texto_'.$this->session->userdata("idioma") );
		$this->db->where("texto_id",$id);
		$query = $this->db->get("textos");
		return $query->result_array(0);
		}

		
	function get_all($pesquisa, $limit, $start) {
		
		if(isset($pesquisa['texto_titulo']) and !empty($pesquisa['texto_titulo'])){
			$this->db->like('texto_titulo_ptBR',$pesquisa['texto_titulo']);
			}
		if(isset($pesquisa['texto_menu'])){
			$this->db->where('texto_menu',$pesquisa['texto_menu']);
			}	
		$this->db->limit($limit, $start);
		$query = $this->db->get('textos');
		return $query->result();
		}
	function count_textos($pesquisa){
		if(isset($pesquisa['texto_titulo']) and !empty($pesquisa['texto_titulo'])){
			$this->db->like('texto_titulo_ptBR',$pesquisa['texto_titulo']);
			}
		
		if(isset($pesquisa['texto_menu'])){
			
			$this->db->where('texto_menu',$pesquisa['texto_menu']);
			}
		$query = $this->db->get('textos');
        return $query->num_rows();
} 
}