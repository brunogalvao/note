<?php
class banners_model extends CI_Model {

	function get_banners(){
		$query = $this->db->get('banners');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('banners', $options);
		return $this->db->affected_rows();
	}
  
	function update_banners($options = array()){
		$this->db->where('banner_id', $options['banner_id']);
		$this->db->update('banners', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('banner_id', $id);
		$this->db->delete('banners');
		return $this->db->affected_rows();
	}
	
	 
	
	function update_record($options = array()){
		
		if(isset($options['banner_titulo'])){
			$this->db->set('banner_titulo',$options['banner_titulo']);
			}
		if(isset($options['banner_idioma'])){
			$this->db->set('banner_idioma',$options['banner_idioma']);
			}	
		if(isset($options['banner_link'])){
			$this->db->set('banner_link',$options['banner_link']);
			}
		if(isset($options['banner_img'])){
			$this->db->set('banner_img',$options['banner_img']);
			}	
		if(isset($options['banner_status'])){
			$this->db->set('banner_status',$options['banner_status']);
			}
		if(isset($options['banner_home'])){
			$this->db->set('banner_home',$options['banner_home']);
			}
		if(isset($options['banner_beneficiario'])){
			$this->db->set('banner_beneficiario',$options['banner_beneficiario']);
			}
		if(isset($options['banner_empresa'])){
			$this->db->set('banner_empresa',$options['banner_empresa']);
			}
		if(isset($options['banner_dentista'])){
			$this->db->set('banner_dentista',$options['banner_dentista']);
			}
		if(isset($options['banner_uniodonto'])){
			$this->db->set('banner_uniodonto',$options['banner_uniodonto']);
			}
		if(isset($options['banner_colaborador'])){
			$this->db->set('banner_colaborador',$options['banner_colaborador']);
			}
		if(isset($options['banner_representante'])){
			$this->db->set('banner_representante',$options['banner_representante']);
			}	
										
			
		$this->db->where('banner_id',$options['banner_id']);
		$this->db->update('banners');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("banner_id",$id);
		$query = $this->db->get("banners");
		return $query->row(0);
		}
	
	function banners(){
		$this->db->order_by("banner_id", "desc");
		$this->db->select('banner_link, banner_img' );
		
		if($this->session->userdata("pagina") and $this->session->userdata("logged") == true){
			$this->db->where("banner_".$this->session->userdata("pagina"),1);
			$this->db->where('banner_home >=',0);
		}else{
			$this->db->where('banner_home',1);
			}
		$this->db->where('banner_idioma',$this->session->userdata("idioma"));
		$this->db->where('banner_status',1);
		
		
		$query = $this->db->get('banners');
		
		return $query->result();
		
		}

	function pesquisa_banners($options){
		$this->db->order_by("banner_id", "desc");
		if(isset($options['banner_titulo'])){
			$this->db->where('banner_titulo',$options['banner_titulo']);
			}
		if(isset($options['banner_idioma'])){
			$this->db->where('banner_idioma',$options['banner_idioma']);
			}
		if(isset($options['banner_link'])){
			$this->db->where('banner_link',$options['banner_link']);
			}
		if(isset($options['banner_img'])){
			$this->db->where('banner_img',$options['banner_img']);
			}
		if(isset($options['banner_status'])){
			$this->db->where('banner_status',$options['banner_status']);
			}
		if(isset($options['banner_home'])){
			$this->db->where('banner_home',$options['banner_home']);
			}
		if(isset($options['banner_beneficiario'])){
			$this->db->where('banner_beneficiario',$options['banner_beneficiario']);
			}
		if(isset($options['banner_empresa'])){
			$this->db->where('banner_empresa',$options['banner_empresa']);
			}
		if(isset($options['banner_dentista'])){
			$this->db->where('banner_dentista',$options['banner_dentista']);
			}
		if(isset($options['banner_uniodonto'])){
			$this->db->where('banner_uniodonto',$options['banner_uniodonto']);
			}
		if(isset($options['banner_colaborador'])){
			$this->db->where('banner_colaborador',$options['banner_colaborador']);
			}
		if(isset($options['banner_representante'])){
			$this->db->where('banner_representante',$options['banner_representante']);
			}			
	
		$query = $this->db->get('banners');
		return $query->result();
	}
		
	function get_all($options, $limit, $start) {
	
		if(isset($options['banner_titulo'])){
			$this->db->where('banner_titulo',$options['banner_titulo']);
			}
		if(isset($options['banner_link'])){
			$this->db->where('banner_link',$options['banner_link']);
			}
		if(isset($options['banner_img'])){
			$this->db->where('banner_img',$options['banner_img']);
			}
		if(isset($options['banner_status'])){
			$this->db->where('banner_status',$options['banner_status']);
			}
		if(isset($options['banner_home'])){
			$this->db->where('banner_home',$options['banner_home']);
			}
		if(isset($options['banner_beneficiario'])){
			$this->db->where('banner_beneficiario',$options['banner_beneficiario']);
			}
		if(isset($options['banner_empresa'])){
			$this->db->where('banner_empresa',$options['banner_empresa']);
			}
		if(isset($options['banner_dentista'])){
			$this->db->where('banner_dentista',$options['banner_dentista']);
			}
		if(isset($options['banner_uniodonto'])){
			$this->db->where('banner_uniodonto',$options['banner_uniodonto']);
			}
		if(isset($options['banner_colaborador'])){
			$this->db->where('banner_colaborador',$options['banner_colaborador']);
			}
		if(isset($options['banner_representante'])){
			$this->db->where('banner_representante',$options['banner_representante']);
			}		

		$this->db->limit($limit, $start);
		$query = $this->db->get('banners');
		return $query->result();
		}
	function count_banners($options){
		if(isset($options['banner_titulo'])){
			$this->db->where('banner_titulo',$options['banner_titulo']);
			}
		if(isset($options['banner_link'])){
			$this->db->where('banner_link',$options['banner_link']);
			}
		if(isset($options['banner_img'])){
			$this->db->where('banner_img',$options['banner_img']);
			}
		if(isset($options['banner_status'])){
			$this->db->where('banner_status',$options['banner_status']);
			}
		if(isset($options['banner_home'])){
			$this->db->where('banner_home',$options['banner_home']);
			}
		if(isset($options['banner_beneficiario'])){
			$this->db->where('banner_beneficiario',$options['banner_beneficiario']);
			}
		if(isset($options['banner_empresa'])){
			$this->db->where('banner_empresa',$options['banner_empresa']);
			}
		if(isset($options['banner_dentista'])){
			$this->db->where('banner_dentista',$options['banner_dentista']);
			}
		if(isset($options['banner_uniodonto'])){
			$this->db->where('banner_uniodonto',$options['banner_uniodonto']);
			}
		if(isset($options['banner_colaborador'])){
			$this->db->where('banner_colaborador',$options['banner_colaborador']);
			}
		if(isset($options['banner_representante'])){
			$this->db->where('banner_representante',$options['banner_representante']);
			}		

		$query = $this->db->get('banners');
        return $query->num_rows();
	} 
}