<?php
class menus_model extends CI_Model {

	function get_menus(){
		$this->db->order_by("menu_titulo", "asc"); 
		$query = $this->db->get('menus');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	
	function pesquisa_menus($options){
		$this->db->order_by("menu_titulo", "asc"); 
		
		
			if(isset($options['menu_titulo'])){
				$this->db->where('menu_titulo',$options['menu_titulo']);
				}
			if(isset($options['menu_status'])){
				$this->db->where('menu_status',$options['menu_status']);
				}	
			if(isset($options['menu_pai'])){
				$this->db->where('menu_pai',$options['menu_pai']);
				}	
			if(isset($options['menu_link'])){
				$this->db->where('menu_link',$options['menu_link']);
				}
			if(isset($options['menu_pagina'])){
				$this->db->where('menu_pagina',$options['menu_pagina']);
				}
			if(isset($options['id_menu_ativo'])){
				$this->db->where('menu_id !=',$options['id_menu_ativo']);
				}
			if(isset($options['menu_normal'])){
				$this->db->where('menu_pai !=',$options['menu_normal']);
				}	
		
		$query = $this->db->get('menus');
		return $query->result();
	}
	function add_record($options = array()){
		$this->db->insert('menus', $options);
		return $this->db->affected_rows();
	}
  
	function update_menus($options = array()){
		$this->db->where('menu_id', $options['menu_id']);
		$this->db->update('menus', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('menu_id', $id);
		$this->db->delete('menus');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['menu_titulo'])){
			$this->db->set('menu_titulo',$options['menu_titulo']);
			}
		if(isset($options['menu_status'])){
			$this->db->set('menu_status',$options['menu_status']);
			}	
		if(isset($options['menu_pai'])){
			$this->db->where('menu_pai',$options['menu_pai']);
			}		
		if(isset($options['menu_link'])){
			$this->db->set('menu_link',$options['menu_link']);
			}
		if(isset($options['menu_pagina'])){
			$this->db->set('menu_pagina',$options['menu_pagina']);
			}		
			
		$this->db->where('menu_id',$options['menu_id']);
		$this->db->update('menus');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("menu_id",$id);
		$query = $this->db->get("menus");
		return $query->row(0);
		}

	function get_all($pesquisa, $limit, $start) {
	
		if (isset($pesquisa)) {
            $this->db->like('menu_titulo', $pesquisa);
        }
		$this->db->limit($limit, $start);
		$query = $this->db->get('menus');
		return $query->result();
		}
		
	function count_menu($pesquisa){
		if (isset($pesquisa)) {
            $this->db->like('menu_titulo', $pesquisa);
            ;
        }
		$query = $this->db->get('menus');
        return $query->num_rows();
	} 
}