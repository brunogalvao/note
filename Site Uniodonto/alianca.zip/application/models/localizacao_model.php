<?php
class localizacao_model extends CI_Model {

	function get_localizacao(){
		$this->db->order_by("localizacao_ordem", "asc"); 
		$query = $this->db->get('localizacao');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result_array();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('localizacao', $options);
		return $this->db->affected_rows();
	}
  
	function update_usuarios($options = array()){
		$this->db->where('localizacao_id', $options['localizacao_id']);
		$this->db->update('localizacao', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('localizacao_id', $id);
		$this->db->delete('localizacao');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['localizacao_titulo_ptBR'])){
			$this->db->set('localizacao_titulo_ptBR',$options['localizacao_titulo_ptBR']);
			}
		if(isset($options['localizacao_titulo_en'])){
			$this->db->set('localizacao_titulo_en',$options['localizacao_titulo_en']);
			}
		if(isset($options['localizacao_titulo_es'])){
			$this->db->set('localizacao_titulo_es',$options['localizacao_titulo_es']);
			}
		if(isset($options['localizacao_ordem'])){
			$this->db->set('localizacao_ordem',$options['localizacao_ordem']);
			}
		if(isset($options['localizacao_tel_ptBR'])){
			$this->db->set('localizacao_tel_ptBR',$options['localizacao_tel_ptBR']);
			}
		if(isset($options['localizacao_tel_en'])){
			$this->db->set('localizacao_tel_en',$options['localizacao_tel_en']);
			}
		if(isset($options['localizacao_tel_es'])){
			$this->db->set('localizacao_tel_es',$options['localizacao_tel_es']);
			}
		if(isset($options['localizacao_endereco_ptBR'])){
			$this->db->set('localizacao_endereco_ptBR',$options['localizacao_endereco_ptBR']);
			}
		if(isset($options['localizacao_endereco_en'])){
			$this->db->set('localizacao_endereco_en',$options['localizacao_endereco_en']);
			}	
		if(isset($options['localizacao_endereco_es'])){
			$this->db->set('localizacao_endereco_es',$options['localizacao_endereco_es']);
			}
		if(isset($options['localizacao_mapa'])){
			$this->db->set('localizacao_mapa',$options['localizacao_mapa']);
			}	
			
		$this->db->where('localizacao_id',$options['localizacao_id']);
		$this->db->update('localizacao');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("localizacao_id",$id);
		$query = $this->db->get("localizacao");
		return $query->row(0);
		}

		

	function get_all($pesquisa, $limit, $start) {
		$this->db->order_by("localizacao_ordem", "asc"); 
		if (isset($pesquisa)) {
            $this->db->like('localizacao_titulo_ptBR', $pesquisa);
			$this->db->or_like('localizacao_titulo_en', $pesquisa);
			$this->db->or_like('localizacao_titulo_es', $pesquisa);
        }
		$this->db->limit($limit, $start);
		$query = $this->db->get('localizacao');
		return $query->result();
		}
	function count_localizacao($pesquisa){
		if (isset($pesquisa)) {
            $this->db->like('localizacao_titulo_ptBR', $pesquisa);
			$this->db->or_like('localizacao_titulo_en', $pesquisa);
			$this->db->or_like('localizacao_titulo_es', $pesquisa);
        }
		$query = $this->db->get('localizacao');
        return $query->num_rows();
	} 
}