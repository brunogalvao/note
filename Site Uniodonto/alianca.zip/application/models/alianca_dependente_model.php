<?php
class alianca_dependente_model extends CI_Model {

	function get_alianca_dependente(){
		$this->db->order_by("alianca_dependente_id", "desc"); 
		$query = $this->db->get('alianca_dependente');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}

	function add_record($options = array()){
		$this->db->insert('alianca_dependente', $options);
  		return  $this->db->insert_id()  ;
	}
  
	function update_record($options = array()){
		$this->db->where('alianca_dependente_id', $options['alianca_dependente_id']);
		$this->db->update('alianca_dependente', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('alianca_dependente_id', $id);
		$this->db->delete('alianca_dependente');
		return $this->db->affected_rows();
	}
  
	
	function get_by_id($id){
		$this->db->where("alianca_dependente_id",$id);
		$query = $this->db->get("alianca_dependente");
		return $query->row(0);
		}
	function get_by_cadastro($id){
		$this->db->where("alianca_id_cadastro",$id);
		$query = $this->db->get("alianca_dependente");
		return $query->result();
		}
		
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("alianca_dependente_id", "desc");
		if(isset($pesquisa['alianca_dependente_id']) != ""){
			$this->db->where('alianca_dependente_id',$pesquisa['alianca_dependente_id']);
			}
		
		$this->db->limit($limit, $start);
		$query = $this->db->get('alianca_dependente');
		
		return $query->result();

		
		}
	function count_alianca_dependente($pesquisa){
		if(isset($pesquisa['alianca_dependente_id']) != ""){
			$this->db->where('alianca_dependente_id',$pesquisa['alianca_dependente_id']);
			}
			
		$query = $this->db->get('alianca_dependente');
        return $query->num_rows();
	} 	

		

}