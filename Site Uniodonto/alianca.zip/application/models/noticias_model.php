<?php
class noticias_model extends CI_Model {

	function get_noticias(){
		$this->db->order_by("noticia_id", "desc"); 
		$query = $this->db->get('noticias');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	
	function get_noticias_sitemap(){
		$this->db->order_by("noticia_id", "desc"); 
		$this->db->where('noticia_status', 1);
		$this->db->where('noticia_home', 1);
		$query = $this->db->get('noticias');
	
		$result = $query->result();
		return $result;
	}
	
	function add_record($options = array()){
		$this->db->insert('noticias', $options);
		return $this->db->affected_rows();
	}
  

	function delete_record($id){
		$this->db->where('noticia_id', $id);
		$this->db->delete('noticias');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['noticia_titulo_ptBR'])){
			$this->db->set('noticia_titulo_ptBR',$options['noticia_titulo_ptBR']);
			}
		if(isset($options['noticia_titulo_en'])){
			$this->db->set('noticia_titulo_en',$options['noticia_titulo_en']);
			}
		if(isset($options['noticia_titulo_es'])){
			$this->db->set('noticia_titulo_es',$options['noticia_titulo_es']);
			}
		if(isset($options['noticia_data'])){
			$this->db->set('noticia_data',$options['noticia_data']);
			}	
		if(isset($options['noticia_destaque'])){
			$this->db->set('noticia_destaque',$options['noticia_destaque']);
			}
		if(isset($options['noticia_posicao'])){
			$this->db->set('noticia_posicao',$options['noticia_posicao']);
			}
		if(isset($options['noticia_texto_ptBR'])){
			$this->db->set('noticia_texto_ptBR',$options['noticia_texto_ptBR']);
			}
		if(isset($options['noticia_texto_en'])){
			$this->db->set('noticia_texto_en',$options['noticia_texto_en']);
			}
		if(isset($options['noticia_texto_es'])){
			$this->db->set('noticia_texto_es',$options['noticia_texto_es']);
			}
		if(isset($options['noticia_img_principal'])){
			$this->db->set('noticia_img_principal',$options['noticia_img_principal']);
			}	
		if(isset($options['noticia_status'])){
			$this->db->set('noticia_status',$options['noticia_status']);
			}
		if(isset($options['noticia_home'])){
			$this->db->set('noticia_home',$options['noticia_home']);
			}	
		if(isset($options['noticia_beneficiario'])){
			$this->db->set('noticia_beneficiario',$options['noticia_beneficiario']);
			}
		if(isset($options['noticia_empresa'])){
			$this->db->set('noticia_empresa',$options['noticia_empresa']);
			}
		if(isset($options['noticia_dentista'])){
			$this->db->set('noticia_dentista',$options['noticia_dentista']);
			}
		if(isset($options['noticia_uniodonto'])){
			$this->db->set('noticia_uniodonto',$options['noticia_uniodonto']);
			}	
		if(isset($options['noticia_colaborador'])){
			$this->db->set('noticia_colaborador',$options['noticia_colaborador']);
			}
		if(isset($options['noticia_representante'])){
			$this->db->set('noticia_representante',$options['noticia_representante']);
			}
		
		if(isset($options['noticia_imgs'])){
			$this->db->set('noticia_imgs',$options['noticia_imgs']);
			}
			
		$this->db->where('noticia_id',$options['noticia_id']);
		$this->db->update('noticias');		
		
		return $this->db->affected_rows();
		
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("noticia_id",$id);
		$query = $this->db->get("noticias");
		return $query->row(0);
		}
	function get_by_id_array($id){
		$this->db->select('noticia_id, noticia_data, noticia_titulo_'.$this->session->userdata("idioma").', noticia_texto_'.$this->session->userdata("idioma").', noticia_imgs' );
		$this->db->where("noticia_id",$id);
		$query = $this->db->get("noticias");
		return $query->result_array(0);
		}

	function get_noticia_principal_destaque($pesquisa) {
		$this->db->select('noticia_id, noticia_titulo_'.$this->session->userdata("idioma").', noticia_imgs' );
		$this->db->order_by("noticia_data", "desc");
		if(isset($pesquisa['noticia_destaque']) and $pesquisa['noticia_destaque'] != ""){
			$this->db->where('noticia_destaque',$pesquisa['noticia_destaque']);
			}
		if(isset($pesquisa['noticia_home']) and $pesquisa['noticia_home'] != ""){
			$this->db->where('noticia_home',$pesquisa['noticia_home']);
			}	
		if(isset($pesquisa['noticia_beneficiario']) and $pesquisa['noticia_beneficiario'] != ""){
			$this->db->where('noticia_beneficiario',$pesquisa['noticia_beneficiario']);
			}
		if(isset($pesquisa['noticia_empresa']) and $pesquisa['noticia_empresa'] != ""){
			$this->db->where('noticia_empresa',$pesquisa['noticia_empresa']);
			}
		if(isset($pesquisa['noticia_dentista']) and $pesquisa['noticia_dentista'] != ""){
			$this->db->where('noticia_dentista',$pesquisa['noticia_dentista']);
			}
		if(isset($pesquisa['noticia_uniodonto']) and $pesquisa['noticia_uniodonto'] != ""){
			$this->db->where('noticia_uniodonto',$pesquisa['noticia_uniodonto']);
			}	
		if(isset($pesquisa['noticia_colaborador']) and $pesquisa['noticia_colaborador'] != ""){
			$this->db->where('noticia_colaborador',$pesquisa['noticia_colaborador']);
			}
		if(isset($pesquisa['noticia_representante']) and $pesquisa['noticia_representante'] != ""){
			$this->db->where('noticia_representante',$pesquisa['noticia_representante']);
			}
		if(isset($pesquisa['noticia_status'])){
			$this->db->where('noticia_status',$pesquisa['noticia_status']);
			}	
				
		$this->db->limit(1, 0);
		$query = $this->db->get('noticias');
		return $query->result_array();
		}
	
	function get_noticia_principal($pesquisa) {
		$this->db->select('noticia_id, noticia_data, noticia_titulo_'.$this->session->userdata("idioma").', noticia_imgs' );
		$this->db->order_by("noticia_data", "desc");
		if(isset($pesquisa['noticia_id']) and $pesquisa['noticia_id'] != ""){
			$this->db->where('noticia_id !=',$pesquisa['noticia_id']);
			}
		if(isset($pesquisa['noticia_home']) and $pesquisa['noticia_home'] != ""){
			$this->db->where('noticia_home',$pesquisa['noticia_home']);
			}	
		if(isset($pesquisa['noticia_posicao']) and $pesquisa['noticia_posicao'] != ""){
			$this->db->where('noticia_posicao',$pesquisa['noticia_posicao']);
			}	
		if(isset($pesquisa['noticia_beneficiario']) and $pesquisa['noticia_beneficiario'] != ""){
			$this->db->where('noticia_beneficiario',$pesquisa['noticia_beneficiario']);
			}
		if(isset($pesquisa['noticia_empresa']) and $pesquisa['noticia_empresa'] != ""){
			$this->db->where('noticia_empresa',$pesquisa['noticia_empresa']);
			}
		if(isset($pesquisa['noticia_dentista']) and $pesquisa['noticia_dentista'] != ""){
			$this->db->where('noticia_dentista',$pesquisa['noticia_dentista']);
			}
		if(isset($pesquisa['noticia_uniodonto']) and $pesquisa['noticia_uniodonto'] != ""){
			$this->db->where('noticia_uniodonto',$pesquisa['noticia_uniodonto']);
			}	
		if(isset($pesquisa['noticia_colaborador']) and $pesquisa['noticia_colaborador'] != ""){
			$this->db->where('noticia_colaborador',$pesquisa['noticia_colaborador']);
			}
		if(isset($pesquisa['noticia_representante']) and $pesquisa['noticia_representante'] != ""){
			$this->db->where('noticia_representante',$pesquisa['noticia_representante']);
			}
		if(isset($pesquisa['noticia_status']) and $pesquisa['noticia_status'] != ""){
			$this->db->where('noticia_status',$pesquisa['noticia_status']);
			}	
				
		$this->db->limit(1);
		$query = $this->db->get('noticias');
		return $query->result_array();
		}
	function get_noticias_recentes($pesquisa) {
		$this->db->select('noticia_id, noticia_data, noticia_titulo_'.$this->session->userdata("idioma") );
		$this->db->order_by("noticia_data", "desc");
		
		if(isset($pesquisa['noticia_home']) and $pesquisa['noticia_home'] != ""){
			$this->db->or_where('noticia_home',$pesquisa['noticia_home']);
			}	
		if(isset($pesquisa['noticia_beneficiario']) and $pesquisa['noticia_beneficiario'] != ""){
			$this->db->or_where('noticia_beneficiario',$pesquisa['noticia_beneficiario']);
			}
		if(isset($pesquisa['noticia_empresa']) and $pesquisa['noticia_empresa'] != ""){
			$this->db->or_where('noticia_empresa',$pesquisa['noticia_empresa']);
			}
		if(isset($pesquisa['noticia_dentista']) and $pesquisa['noticia_dentista'] != ""){
			$this->db->or_where('noticia_dentista',$pesquisa['noticia_dentista']);
			}
		if(isset($pesquisa['noticia_uniodonto']) and $pesquisa['noticia_uniodonto'] != ""){
			$this->db->or_where('noticia_uniodonto',$pesquisa['noticia_uniodonto']);
			}	
		if(isset($pesquisa['noticia_colaborador']) and $pesquisa['noticia_colaborador'] != ""){
			$this->db->or_where('noticia_colaborador',$pesquisa['noticia_colaborador']);
			}
		if(isset($pesquisa['noticia_representante']) and $pesquisa['noticia_representante'] != ""){
			$this->db->or_where('noticia_representante',$pesquisa['noticia_representante']);
			}
		if(isset($pesquisa['noticia_status'])){
			$this->db->where('noticia_status',1);
			}	
				
		$this->db->limit(8, 0);
		$query = $this->db->get('noticias');
		return $query->result_array();
		}	
			
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("noticia_data", "desc");
		
		if(isset($pesquisa['noticia_home'])){
			$this->db->or_where('noticia_home',$pesquisa['noticia_home']);
			}	
		if(isset($pesquisa['noticia_beneficiario'])){
			$this->db->or_where('noticia_beneficiario',$pesquisa['noticia_beneficiario']);
			}
		if(isset($pesquisa['noticia_empresa'])){
			$this->db->or_where('noticia_empresa',$pesquisa['noticia_empresa']);
			}
		if(isset($pesquisa['noticia_dentista'])){
			$this->db->or_where('noticia_dentista',$pesquisa['noticia_dentista']);
			}
		if(isset($pesquisa['noticia_uniodonto'])){
			$this->db->or_where('noticia_uniodonto',$pesquisa['noticia_uniodonto']);
			}	
		if(isset($pesquisa['noticia_colaborador'])){
			$this->db->or_where('noticia_colaborador',$pesquisa['noticia_colaborador']);
			}
		if(isset($pesquisa['noticia_representante'])){
			$this->db->or_where('noticia_representante',$pesquisa['noticia_representante']);
			}
		if(isset($pesquisa['noticia_status'])){
			$this->db->where('noticia_status',$pesquisa['noticia_status']);
			}	
		if(isset($pesquisa['noticia_destaque'])){
			$this->db->where('noticia_destaque',$pesquisa['noticia_destaque']);
			}
		if(isset($pesquisa['data-inicial'])){
			$this->db->where('noticia_data >=',$pesquisa['data-inicial']);
			}
		if(isset($pesquisa['data-final'])){
			$this->db->where('noticia_data <=',$pesquisa['data-final']);
			}			
		if (isset($pesquisa['noticia_titulo'])) {
            $this->db->like('noticia_titulo_ptBR', $pesquisa['noticia_titulo']);
			$this->db->or_like('noticia_titulo_en', $pesquisa['noticia_titulo']);
			$this->db->or_like('noticia_titulo_es', $pesquisa['noticia_titulo']);
        }

		if (isset($pesquisa['noticia_texto'])) {
            $this->db->like('noticia_texto_ptBR', $pesquisa['noticia_texto']);
			$this->db->or_like('noticia_texto_en', $pesquisa['noticia_texto']);
			$this->db->or_like('noticia_texto_es', $pesquisa['noticia_texto']);
        }


		$this->db->limit($limit, $start);
		$query = $this->db->get('noticias');
		if ($pesquisa['tipo'] == "array") {
            	return $query->result_array();
			}else{
				return $query->result();
				}
		
		}
	function count_noticias($pesquisa){
		
		if(isset($pesquisa['noticia_home'])){
			$this->db->or_where('noticia_home',$pesquisa['noticia_home']);
			}	
		if(isset($pesquisa['noticia_beneficiario'])){
			$this->db->or_where('noticia_beneficiario',$pesquisa['noticia_beneficiario']);
			}
		if(isset($pesquisa['noticia_empresa'])){
			$this->db->or_where('noticia_empresa',$pesquisa['noticia_empresa']);
			}
		if(isset($pesquisa['noticia_dentista'])){
			$this->db->or_where('noticia_dentista',$pesquisa['noticia_dentista']);
			}
		if(isset($pesquisa['noticia_uniodonto'])){
			$this->db->or_where('noticia_uniodonto',$pesquisa['noticia_uniodonto']);
			}	
		if(isset($pesquisa['noticia_colaborador'])){
			$this->db->or_where('noticia_colaborador',$pesquisa['noticia_colaborador']);
			}
		if(isset($pesquisa['noticia_representante'])){
			$this->db->or_where('noticia_representante',$pesquisa['noticia_representante']);
			}
		if(isset($pesquisa['noticia_status'])){
			$this->db->where('noticia_status',$pesquisa['noticia_status']);
			}	
		if(isset($pesquisa['data-inicial'])){
			$this->db->where('noticia_data >=',$pesquisa['data-inicial']);
			}
		if(isset($pesquisa['data-final'])){
			$this->db->where('noticia_data <=',$pesquisa['data-final']);
			}
		if (isset($pesquisa['noticia_titulo'])) {
            $this->db->like('noticia_titulo_ptBR', $pesquisa['noticia_titulo']);
			$this->db->or_like('noticia_titulo_en', $pesquisa['noticia_titulo']);
			$this->db->or_like('noticia_titulo_es', $pesquisa['noticia_titulo']);
        }

		if (isset($pesquisa['noticia_texto'])) {
            $this->db->like('noticia_texto_ptBR', $pesquisa['noticia_texto']);
			$this->db->or_like('noticia_texto_en', $pesquisa['noticia_texto']);
			$this->db->or_like('noticia_texto_es', $pesquisa['noticia_texto']);
        }
		
		$query = $this->db->get('noticias');
        return $query->num_rows();
	} 
}