<?php
class textos_abas_model extends CI_Model {

	function get_textos_abas(){
		$this->db->order_by("texto_aba_id", "asc"); 
		$query = $this->db->get('textos_abas');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function pesquisa_textos_abas($pesquisa){
		$this->db->order_by("texto_aba_titulo_ptBR", "asc"); 
		if(isset($pesquisa['texto_aba_titulo_ptBR']) and $pesquisa['texto_aba_titulo_ptBR'] != ""){
			$this->db->like('texto_aba_titulo_ptBR',$pesquisa['texto_aba_titulo_ptBR']);
			}
		if(isset($pesquisa['texto_aba_titulo_en']) and $pesquisa['texto_aba_titulo_en'] != ""){
			$this->db->like('texto_aba_titulo_en',$pesquisa['texto_aba_titulo_en']);
			}
		if(isset($pesquisa['texto_aba_titulo_es']) and $pesquisa['texto_aba_titulo_es'] != ""){
			$this->db->like('texto_aba_titulo_es',$pesquisa['texto_aba_titulo_es']);
			}
		
		if(isset($pesquisa['texto_aba_menu']) and $pesquisa['texto_aba_menu'] != ""){
			$this->db->where('texto_aba_menu',$pesquisa['texto_aba_menu']);
			}
		if(isset($pesquisa['texto_aba_aba']) and $pesquisa['texto_aba_aba'] != ""){
			$this->db->where('texto_aba_aba',$pesquisa['texto_aba_aba']);
			}
		$query = $this->db->get('textos_abas');
		return $query->result();
	}
	function add_record($options = array()){
		$this->db->insert('textos_abas', $options);
		return $this->db->affected_rows();
	}
 	function delete_record($id){
		$this->db->where('texto_aba_id', $id);
		$this->db->delete('textos_abas');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['texto_aba_titulo_ptBR'])){
			$this->db->set('texto_aba_titulo_ptBR',$options['texto_aba_titulo_ptBR']);
			}
		if(isset($options['texto_aba_titulo_en'])){
			$this->db->set('texto_aba_titulo_en',$options['texto_aba_titulo_en']);
			}
		if(isset($options['texto_aba_titulo_es'])){
			$this->db->set('texto_aba_titulo_es',$options['texto_aba_titulo_es']);
			}	
		if(isset($options['texto_aba_menu'])){
			$this->db->set('texto_aba_menu',$options['texto_aba_menu']);
			}	
		if(isset($options['texto_aba_texto_ptBR'])){
			$this->db->set('texto_aba_texto_ptBR',$options['texto_aba_texto_ptBR']);
			}
		if(isset($options['texto_aba_texto_en'])){
			$this->db->set('texto_aba_texto_en',$options['texto_aba_texto_en']);
			}	
		if(isset($options['texto_aba_texto_es'])){
			$this->db->set('texto_aba_texto_es',$options['texto_aba_texto_es']);
			}	
		if(isset($options['texto_aba_img'])){
			$this->db->set('texto_aba_img',$options['texto_aba_img']);
			}
					
		$this->db->where('texto_aba_id',$options['texto_aba_id']);
		$this->db->update('textos_abas');		
		
		return $this->db->affected_rows();
		
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("texto_aba_id",$id);
		$query = $this->db->get("textos_abas");
		return $query->row(0);
		}
	function get_by_id_array($id){
		$this->db->select('texto_aba_titulo_'.$this->session->userdata("idioma").', texto_aba_texto_'.$this->session->userdata("idioma").', texto_aba_aba' );
		$this->db->where("texto_aba_id",$id);
		$query = $this->db->get("textos_abas");
		return $query->result_array(0);
		}

		
	function get_all($pesquisa, $limit, $start) {
	
		if(isset($pesquisa['texto_aba_titulo']) and $pesquisa['texto_aba_titulo'] != ""){
			$this->db->like('texto_aba_titulo_ptBR',$pesquisa['texto_aba_titulo']);
			$this->db->or_like('texto_aba_titulo_en',$pesquisa['texto_aba_titulo']);
			$this->db->or_like('texto_aba_titulo_es',$pesquisa['texto_aba_titulo']);
			}

		if(isset($pesquisa['texto_aba_menu']) and $pesquisa['texto_aba_menu'] != ""){
			$this->db->where('texto_aba_menu',$pesquisa['texto_aba_menu']);
			}
		if(isset($pesquisa['texto_aba_aba']) and $pesquisa['texto_aba_aba'] != ""){
			$this->db->where('texto_aba_aba',$pesquisa['texto_aba_aba']);
			}	
		$this->db->limit($limit, $start);
		$query = $this->db->get('textos_abas');
		return $query->result();
		}
	function count_textos_abas($pesquisa){
		if(isset($pesquisa['texto_aba_titulo']) and $pesquisa['texto_aba_titulo'] != ""){
			$this->db->like('texto_aba_titulo_ptBR',$pesquisa['texto_aba_titulo']);
			$this->db->or_like('texto_aba_titulo_en',$pesquisa['texto_aba_titulo']);
			$this->db->or_like('texto_aba_titulo_es',$pesquisa['texto_aba_titulo']);
			}
		if(isset($pesquisa['texto_aba_menu']) and $pesquisa['texto_aba_menu'] != ""){
			$this->db->where('texto_aba_menu',$pesquisa['texto_aba_menu']);
			}
		if(isset($pesquisa['texto_aba_aba']) and $pesquisa['texto_aba_aba'] != ""){
			$this->db->where('texto_aba_aba',$pesquisa['texto_aba_aba']);
			}	
		$query = $this->db->get('textos_abas');
        return $query->num_rows();
} 
}