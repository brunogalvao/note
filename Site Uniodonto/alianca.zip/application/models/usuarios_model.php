<?php
class usuarios_model extends CI_Model {

	function get_usuarios(){
		$this->db->order_by("user_nome", "asc"); 
		$query = $this->db->get('user');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('user', $options);
		return $this->db->insert_id();
	}
  
	function update_usuarios($options = array()){
		$this->db->where('user_id', $options['user_id']);
		$this->db->update('user', $options);
		return $this->db->insert_id();
	}
	function delete_record($id){
		$this->db->where('user_id', $id);
		$this->db->delete('user');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['user_nome'])){
			$this->db->set('user_nome',$options['user_nome']);
			}
		if(isset($options['user_email'])){
			$this->db->set('user_email',$options['user_email']);
			}
		if(isset($options['user_senha'])){
			$this->db->set('user_senha',$options['user_senha']);
			}	
		if(isset($options['user_status'])){
			$this->db->set('user_status',$options['user_status']);
			}
		
		if(isset($options['user_tipo'])){
			$this->db->set('user_tipo',$options['user_tipo']);
			}	
			
		$this->db->where('user_id',$options['user_id']);
		$this->db->update('user');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("user_id",$id);
		$query = $this->db->get("user");
		return $query->row(0);
		}

		
	function get_by_email($pesquisa){
		$this->db->where("user_email",$pesquisa['email']);
		if (isset($pesquisa['id']) and $pesquisa['id'] != "") {
            $this->db->where('user_id !=', $pesquisa['id']);
        }
		$query = $this->db->get("user");
		$return['qt'] = $query->num_rows();
		$return['rows'] = $query->result();
		return $return;
		}	
		
	function get_all($pesquisa, $limit, $start) {
	
		if (isset($pesquisa['user']) and $pesquisa['user'] != "") {
            $this->db->like('user_nome', $pesquisa['user']);
            $this->db->or_like('user_email', $pesquisa['user']);
        }
		$this->db->limit($limit, $start);
		$query = $this->db->get('user');
		return $query->result();
		}
	function count_user($pesquisa){
		if (isset($pesquisa['user']) and $pesquisa['user'] != "") {
            $this->db->like('user_nome', $pesquisa['user']);
            $this->db->or_like('user_email', $pesquisa['user']);
        }
		$query = $this->db->get('user');
        return $query->num_rows();
} 
}