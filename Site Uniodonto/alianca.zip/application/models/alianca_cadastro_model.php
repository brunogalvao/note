<?php
class alianca_cadastro_model extends CI_Model {

	function get_alianca_cadastro(){
		$this->db->order_by("alianca_id", "desc"); 
		$query = $this->db->get('alianca_cadastro');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
		}

	function add_record($options = array()){
		$this->db->insert('alianca_cadastro', $options);
  		return  $this->db->insert_id()  ;
		}
  
	function update_record($options = array()){
		$this->db->where('alianca_id', $options['alianca_id']);
		$this->db->update('alianca_cadastro', $options);
		return $this->db->affected_rows();
		}
	function delete_record($id){
		$this->db->where('alianca_id', $id);
		$this->db->delete('alianca_cadastro');
		return $this->db->affected_rows();
		}
  
	
	function get_by_id($id){
		$this->db->where("alianca_id",$id);
		$query = $this->db->get("alianca_cadastro");
		return $query->row(0);
		}
	function get_by_cpf($cpf){
		$this->db->where("alianca_cpf",$cpf);
		$query = $this->db->get("alianca_cadastro");
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
		}
		
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("alianca_id", "desc");
		if(isset($pesquisa['alianca_id']) != ""){
			$this->db->where('alianca_id',$pesquisa['alianca_id']);
			}
		
		$this->db->limit($limit, $start);
		$query = $this->db->get('alianca_cadastro');
		
		return $query->result();

		
		}
	function count_alianca_cadastro($pesquisa){
		if(isset($pesquisa['alianca_id']) != ""){
			$this->db->where('alianca_id',$pesquisa['alianca_id']);
			}
			
		$query = $this->db->get('alianca_cadastro');
        return $query->num_rows();
		} 	

		

}