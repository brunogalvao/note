<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class site extends CI_Controller {
    
    function __construct() {
        parent::__construct();
	
		
		
    }
    
    public function index() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/index_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function plano() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/plano_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function urgencia() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/urgencia_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function tabela() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/tabela_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function perguntas() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/perguntas_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function contato() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/contato_view');
		$this->load->view('alianca/rodape_view');
	}


	public function encontreseudentista() {
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/encontre-seu-dentista_view');
		$this->load->view('alianca/rodape_view');
	}
	
	public function contratar() {
		$data = array();
		if($_POST){
			$resultado = $this->verificacpf($this->input->post('cpf'));
			if($resultado == 1){
				redirect(site_url("alianca/formulario"),"refresh");
				}else if($resultado == 0){
					$data["msg"] = "O CPF digitado &eacute; inv&aacute;lido";
					}else if($resultado == 2){
						$cadastro = $this->alianca_cadastro_model->get_by_cpf($this->input->post('cpf'));
						redirect(site_url("alianca/site/cadastrado/".$cadastro["rows"][0]->alianca_id),"refresh");
						}
			}
		
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/contratar_view', $data);
		$this->load->view('alianca/rodape_view');
	}
	
	public function altera_instituicao() {
		$this->session->sess_destroy();
		redirect("alianca/formulario");
		}
	
	public function formulario() {
		$this->session->sess_destroy();
		$data["atividades"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_Atividades");
		$data["estadocivil"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_EstadoCivil");
		$data["parentesco"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_Parentesco");
		$data["tipodocumento"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_Tipo_Documento");
		$data["uf"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_UF");
		$data["tipousuario"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Tipo_Usuario");
		
		
		
		if($this->session->userdata("dados_plano") or $_POST){
				if($_POST){
					$codigo_contrato = explode("-", $_POST['instituicao']);
				
					$xml = json_decode(json_encode((array) simplexml_load_file("http://127.0.0.1/Lista_contratos.xml")), 1);
		
					foreach($xml['ModeloContrato'] as $dados){
						if($dados["Codigo_Contrato"] == $codigo_contrato[0] and $dados["Numero_SubContrato"] == $codigo_contrato[1]){
							$dados_plano = $dados;
							
							}
						
						}
					$this->session->set_userdata('dados_plano', $dados_plano);
					
				}
	
				
				$this->load->view('alianca/topo_view');
				$this->load->view('alianca/formulario2_view', $data);
				$this->load->view('alianca/rodape_view');
			}else{
				$this->load->view('alianca/topo_view');
				$this->load->view('alianca/formulario_view', $data);
				$this->load->view('alianca/rodape_view');
			
		}
	}


	public function salvatitular(){
		$dados = $_POST;
		
		$nascimento = explode("/", $dados["dataNascimento"]);
		$dados["idade"] = $this->calcula_idade($nascimento["2"]."-".$nascimento["1"]."-".$nascimento["0"],date("Y-m-d"));
		
		$dados_plano = $this->session->userdata("dados_plano");
		
		foreach($dados_plano["Planos_Contrato"]["Planos"] as $plano){ 

			if($plano["Codigo"] == $dados["codplano"]){
				$dados["versaoplano"] = $plano["Versao_plano"];
				$dados["nomeplano"] = $plano["Descricao"];
				}
			
		}

		
		$dados["mensalidade"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Valor_Plano?Codigo_Empresa=".$dados_plano["Codigo_Empresa"]."&Numero_Contrato=".$dados_plano["Numero_Contrato"]."&Versao_Contrato=".$dados_plano["Versao_Contrato"]."&Numero_SubContrato=".$dados_plano["Numero_SubContrato"]."&Versao_SubContrato=".$dados_plano["Versao_SubContrato"]."&Codigo_Plano=".$dados["codplano"]."&Versao_plano=".$dados["versaoplano"]."&Tipo_Usuario=T&Idade=".$dados["idade"]."&Grau_Parentesco=&UF_TITULAR=".$dados["uf"]);
			

		$this->session->set_userdata("dados_titular",$dados);
		
		redirect("alianca/formulario");
	} 
	
	public function salvadependente(){ 
		$dados = $_POST;
		$dados_plano = $this->session->userdata("dados_plano");
		$dados_titular = $this->session->userdata("dados_titular");
		
		
		
		if($this->session->userdata("dados_dependentes")){
			if(is_array($this->session->userdata("dados_dependentes"))){
				
				$dependentes = $this->session->userdata("dados_dependentes");
				
				$nascimento = explode("/", $dados["dataNascimento"]);
				$dados["idade"] = $this->calcula_idade($nascimento["2"]."-".$nascimento["1"]."-".$nascimento["0"],date("Y-m-d"));
				$dados["mensalidade"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Valor_Plano?Codigo_Empresa=".$dados_plano["Codigo_Empresa"]."&Numero_Contrato=".$dados_plano["Numero_Contrato"]."&Versao_Contrato=".$dados_plano["Versao_Contrato"]."&Numero_SubContrato=".$dados_plano["Numero_SubContrato"]."&Versao_SubContrato=".$dados_plano["Versao_SubContrato"]."&Codigo_Plano=".$dados_titular["codplano"]."&Versao_plano=".$dados_titular["versaoplano"]."&Tipo_Usuario=T&Idade=".$dados["idade"]."&Grau_Parentesco=".$dados["parentesco"]."&UF_TITULAR=".$dados_titular["uf"]);
				$i = array_push($dependentes,$dados);
				$this->session->set_userdata("dados_dependentes",$dependentes);
				
				}else{
					$dependentes = $this->session->userdata("dados_dependentes");
					}

			
			}else{

				$nascimento = explode("/", $dados["dataNascimento"]);
				$dados["idade"] = $this->calcula_idade($nascimento["2"]."-".$nascimento["1"]."-".$nascimento["0"],date("Y-m-d"));
				$dados["mensalidade"] = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Valor_Plano?Codigo_Empresa=".$dados_plano["Codigo_Empresa"]."&Numero_Contrato=".$dados_plano["Numero_Contrato"]."&Versao_Contrato=".$dados_plano["Versao_Contrato"]."&Numero_SubContrato=".$dados_plano["Numero_SubContrato"]."&Versao_SubContrato=".$dados_plano["Versao_SubContrato"]."&Codigo_Plano=".$dados_titular["codplano"]."&Versao_plano=".$dados_titular["versaoplano"]."&Tipo_Usuario=T&Idade=".$dados["idade"]."&Grau_Parentesco=".$dados["parentesco"]."&UF_TITULAR=".$dados_titular["uf"]);
				$this->session->set_userdata("dados_dependentes",array($dados));
				}

		redirect("alianca/formulario");
	} 
	public function excluirbeneficiario($id){
		$dependentes = $this->session->userdata("dados_dependentes");
		unset($dependentes[$id]);
		sort($dependentes);
		$this->session->set_userdata("dados_dependentes",$dependentes);
		redirect("alianca/formulario");
		}
	public function excluirtitular(){
		$this->session->unset_userdata("dados_titular");
		$this->session->unset_userdata("dados_cobranca");
		redirect("alianca/formulario");
		}
		
	public function salvar_dados_cobranca(){
		$dados = $_POST;
		
		$this->session->set_userdata("dados_cobranca",$dados);
		
		redirect("alianca/formulario");
	}
	
	public function salvar_contrato(){
		if($_POST){
			
			$dados_titular = $this->session->userdata('dados_titular');
			$dados_cobranca = $this->session->userdata('dados_cobranca');
			$dados_plano = $this->session->userdata('dados_plano');
			
			$atividades = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_Atividades");
			$tipodocumento = (array) simplexml_load_file("http://www.aliancaadm.com.br/ws/ga_auto.asmx/Lista_Tipo_Documento");
			
			foreach($tipodocumento["Lista"] as $documento){
            	if($documento->Codigo == $dados_titular["tipodocumento"]){
                	$nome_documento = $documento->Descricao;
                }
            } 
			foreach($atividades["Lista"] as $atividade){
            	if($atividade->Codigo == $dados_titular["Atividade"]){
                	$nome_atividade = $atividade->Descricao;
                }
            }

			$dados_query = array(
				"alianca_plano" => $dados_titular["codplano"],
				"alianca_nome_plano" => $dados_titular["nomeplano"],
				"alianca_versao_plano" => $dados_titular["versaoplano"],
				"alianca_matricula" => $this->input->post("matricula"),
				"alianca_convenio" => $this->input->post("convenio"),
				"alianca_vigencia" => $this->input->post("vigencia"),
				"alianca_lotacao" => $this->input->post("lotacao"),
				"alianca_cpf" => $dados_titular["cpf"],
				"alianca_nome" => $dados_titular["nome"],
				"alianca_nascimento" => $dados_titular["dataNascimento"],
				"alianca_estado_civil" => $dados_titular["estadocivil"],
				"alianca_sexo" => $dados_titular["sexo"],
				"alianca_n_documento" => $dados_titular["documento"],
				"alianca_tipo_documento" => $dados_titular["tipodocumento"],
				"alianca_nome_tipo_documento" => "'".$nome_documento."'",
				"alianca_orgao_emissor" => $dados_titular["orgaoemissor"],
				"alianca_data_expedicao" => $dados_titular["dataexpedicao"],
				"alianca_uf_orgao" => $dados_titular["orgaouf"],
				"alianca_principal_atividade" => $dados_titular["Atividade"],
				"alianca_principal_atividade_nome" => "'".$nome_atividade."'",
				"alianca_nome_mae" => $dados_titular["nomemae"],
				"alianca_nascido_vivo" => $dados_titular["nascidovivo"],
				"alianca_n_cartao_saude" => $dados_titular["cartaosaude"],
				"alianca_pis" => $dados_titular["pis"],
				"alianca_cep" => $dados_titular["cep"],
				"alianca_endereco" => $dados_titular["endereco"],
				"alianca_numero" => $dados_titular["numero"],
				"alianca_complemento" => $dados_titular["complemento"],
				"alianca_bairro" => $dados_titular["bairro"],
				"alianca_cidade" => $dados_titular["cidade"],
				"alianca_uf" => $dados_titular["uf"],
				"alianca_tipo_endereco" => $dados_titular["tipoendereco"],
				"alianca_tel_residencial" => $dados_titular["telresidencial"],
				"alianca_tel_comercial" => $dados_titular["telcomercial"],
				"alianca_tel_ramal" => $dados_titular["telramal"],
				"alianca_tel_celular" => $dados_titular["celular"],
				"alianca_email" => $dados_titular["email"],
				"alianca_forma_pagamento" => $dados_cobranca["formaPagamento"],
				"alianca_unidade_pagamento" => $dados_cobranca["unidadePagamento"],
				"alianca_matr_serv" => $dados_cobranca["matriculaSiape"],
				"alianca_tipo_servidor" => $dados_cobranca["tipoServidor"],
				"alianca_matr_pensionista" => $dados_cobranca["matPensionista"],
				"alianca_banco" => $dados_cobranca["banco"],
				"alianca_agencia" => $dados_cobranca["agencia"],
				"alianca_agencia_dv" => $dados_cobranca["digitoAgencia"],
				"alianca_operacao" => $dados_cobranca["operacao"],
				"alianca_conta" => $dados_cobranca["conta"],
				"alianca_conta_dv" => $dados_cobranca["digitoConta"],
				"alianca_tipo_conta" => $dados_cobranca["TPConta"],
				"alianca_responsavel_financeiro" => "",
				"alianca_nome_responsavel" => "",
				"alianca_cpf_cnpj_responsavel" => "" 

			
			);
			$id = $this->alianca_cadastro_model->add_record($dados_query);
			
			if($this->session->userdata('dados_dependentes')){
				$dados_dependentes = $this->session->userdata('dados_dependentes');
				foreach($dados_dependentes as $dependente){
					$dados_query_dependentes = array(
						"alianca_id_cadastro" => $id,
						"alianca_dependente_cpf" => $dependente["cpf"],
						"alianca_dependente_nome_completo" => $dependente["nome"],
						"alianca_dependente_data_nascimento" => $dependente["dataNascimento"],
						"alianca_dependente_parentesco" => $dependente["parentesco"],
						"alianca_dependente_estado_civil" => $dependente["estadocivil"],
						"alianca_dependente_sexo" => $dependente["sexo"],
						"alianca_dependente_n_documento" => $dependente["documento"],
						"alianca_dependente_tipo_documento" => $dependente["tipodocumento"],
						"alianca_dependente_orgao_emissor" => $dependente["orgaoemissor"],
						"alianca_dependente_data_expedicao" => $dependente["dataexpedicao"],
						"alianca_dependente_uf_orgao" => $dependente["orgaouf"],
						"alianca_dependente_nome_mae" => $dependente["nomemae"],
						"alianca_dependente_nascido_vivo" => $dependente["nascidovivo"],
						"alianca_dependente_n_cartao_saude" => $dependente["cartaosaude"]
		
					);
					$this->alianca_dependente_model->add_record($dados_query_dependentes);
				}
			}
			$this->session->sess_destroy();
			redirect("alianca/site/sucesso/".$id);	
			}else{
				redirect("alianca/formulario");
				}
	} 
	
	public function sucesso($id){
		$data["id"] = $id;
		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/sucesso_view', $data);
		$this->load->view('alianca/rodape_view');
		}	
		
	public function calcula_idade($data_nascimento, $data_calcula){

		$data_nascimento = strtotime($data_nascimento." 00:00:00");
		$data_calcula = strtotime($data_calcula." 00:00:00");
		$idade = floor(abs($data_calcula-$data_nascimento)/60/60/24/365);
		return($idade);
	
	}
	public function cadastrado($id){
		$data["cadastro"] = $this->alianca_cadastro_model->get_by_id($id);
		$this->session->set_userdata('dados_plano', $data["cadastro"]);
		$data["nome"] = explode(" ", $data["cadastro"]->alianca_nome);

		$this->load->view('alianca/topo_view');
		$this->load->view('alianca/cadastrado_view', $data);
		$this->load->view('alianca/rodape_view');
		}
	
	public function enviar_arquivos(){
		$data;
		if($this->session->userdata('dados_plano')){
			$dados_usuario = $this->session->userdata('dados_plano');
			
			if($_FILES){
				
					$arquivos = $_FILES;
					foreach($arquivos as $arquivo=>$campo){
						
							$html = "";
							if($arquivo == "proposta"){
								$html = "";			
								foreach( $campo["tmp_name"] as $file ) {
									$html .= '<img src="'.$file.'" /><pagebreak />';
								}
							}else{
								$html = $campo["tmp_name"];
								}
	
							if($arquivo == "proposta"){
									$nome = "Proposta de adesao";
								}
							if($arquivo == "rg"){
									$nome = "RG";
								}
							if($arquivo == "cpf"){
									$nome = "CPF";
								}
							if($arquivo == "vinculo"){
									$nome = "Comprovante de vinculo";
								}
							if($arquivo == "residencia"){
									$nome = "Comprovante de residencia";
								}
							if($arquivo == "posse"){
									$nome = "Termo de Posse";
								}
							
							
						if($html != ""){
							$this->load->library('mpdf');
							$mpdf=new mPDF('c','A4','12','Arial' , 5 , 5 , 5 , 6 , 0 , 0);
							$mpdf->SetDisplayMode('fullpage');
							$mpdf->WriteHTML($html);
							$nome_arquivo = 'arquivos_alianca/'.$nome.'_'.preg_replace("/[^0-9\s]/", "", $dados_usuario->alianca_cpf).'_'.$dados_usuario->alianca_id.'_'.$dados_usuario->alianca_convenio.'_'.preg_replace("/[^0-9\s]/", "",$dados_usuario->alianca_vigencia).'_UNIODONTO.pdf';
							$mpdf->Output($nome_arquivo, "F");
							$this->alianca_cadastro_model->update_record(array("alianca_id"=> $dados_usuario->alianca_id, "alianca_copia_contrato" => $nome_arquivo));
							
							}
					}
				$data["cadastro"] = $this->alianca_cadastro_model->get_by_id($dados_usuario->alianca_id);
				$this->session->set_userdata('dados_plano', $data["cadastro"]);
				
			}
			$this->load->view('alianca/topo_view');
			$this->load->view('alianca/enviardocs_view',$data);
			$this->load->view('alianca/rodape_view');
			}else{
				redirect(site_url("alianca/contratar"));
				}
			
		}
	

	public function verificacpf($cpf,$tipo = 0){
		   $s = preg_replace("/[^0-9\s]/", "", $cpf);
		   $c = substr($s, 0, 9);
		   $dv = substr($s, 9, 2);
		   $d1 = 0;
		   $v = false;
		 
			for ($i = 0; $i < 9; $i++){
				$d1 = $d1 + substr($c, $i, 1) * (10 - $i);
			}
			if($d1 == 0){
				if($tipo == 0){
					return 0;
					}else{
						print "0";	
					}
				$v = true;
			}
			$d1 = 11 - ($d1 % 11);
			if($d1 > 9){
				$d1 = 0;
			}
			if(substr($dv, 0, 1) != $d1){
				if($tipo == 0){
					return 0;
					}else{
						print "0";	
					}
				$v = true;
			}
			$d1 = $d1 * 2;
			for ($i = 0; $i < 9; $i++){
				$d1 = $d1 + substr($c, $i, 1) * (11 - $i);
			}
			$d1 = 11 - ($d1 % 11);
			if($d1 > 9){
				$d1 = 0;
			}
			if(substr($dv, 1, 1) != $d1){
				if($tipo == 0){
					return 0;
					}else{
						print "0";	
					}
				$v = true;
			}
			if(!$v){
				$resultado = $this->alianca_cadastro_model->get_by_cpf($cpf);
				if($resultado["qt"] == 0){
					if($tipo == 0){
					return 1;
						}else{
							print "1";	
						}
					}else{
						if($tipo == 0){
							return 2;
							}else{
								print "2";	
							}
						}
			}
		}

	function imprimir_proposta($id){
		$data["dados_contrato"] = $this->alianca_cadastro_model->get_by_id($id);
		$data["dados_dependentes"] = $this->alianca_dependente_model->get_by_cadastro($id);
		
		$this->load->library('mpdf');
						
		$html_topo ="<img src='".site_url()."images/alianca/topo-proposta.jpg'>";
		$html_bottom ="<img src='".site_url()."images/alianca/rodape-proposta.jpg'>";
		//$html = utf8_encode($this->load->view('alianca/proposta_pdf_view',$data, TRUE));
		$html = "Teste";
						
		$mpdf=new mPDF('c','A4','12','Arial' , 5 , 5 , 5 , 6 , 0 , 0);
			
		$mpdf->SetDisplayMode('fullpage');
			
		//$mpdf->list_indent_first_level = 0;
		//$mpdf->StartProgressBarOutput(2);
		$mpdf->SetHTMLHeader ($html_topo);
		$mpdf->SetHTMLFooter ($html_bottom);
		$mpdf->WriteHTML($html);
		
		
		
		header('Set-Cookie: fileDownload=true; path=/');
		header('Cache-Control: max-age=60, must-revalidate');
		header("Content-type: text/csv");
		header('Content-Disposition: attachment; filename=proposta-alianca.pdf');
		$mpdf->Output('tmp/proposta/proposta-alianca.pdf', "D");
		
		}		

}

