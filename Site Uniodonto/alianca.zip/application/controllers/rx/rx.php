<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class rx extends CI_Controller {
    
    function __construct() {
        parent::__construct();
		$this->auth->check_logged($this->router->class , $this->router->method, $this->uri->segment(1));		
    }
    
    public function index() {
		if($_POST){
		
			$pesquisa = array_filter($_POST);
			
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->rx_model->count_rx($pesquisa);
		$config['base_url'] = site_url() . 'rx/rx/index/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$data['qt'] = $this->rx_model->count_rx($pesquisa);
		$data['rxs'] = $this->rx_model->get_all($pesquisa, $config['per_page'], $pag);
		$data['paginacao'] = $this->pagination->create_links();
        $this->load->view('rx/rx_view',$data);
        
    }
	
	public function adicionar() {
		$data["msg"] = "";
		if($_POST){
			
			$codrx = preg_split( "/(\\r)?\\n/i", $this->input->post('codrx') );
			$i = 0;
			
			foreach($codrx as $cod){
				
				if($cod != ""){
					$dados_query = array(
							"rx_cro" => $this->input->post("cro"),
							"rx_nome" => $this->input->post("nome", ENT_QUOTES, "UTF-8"),
							"rx_cidade" => $this->input->post("cidade", ENT_QUOTES, "UTF-8"),
							"rx_uf" => $this->input->post("uf"),
							"rx_lote" => $this->input->post("lote"),
							"rx_cod" => $cod,
							"rx_status" => 0,
							"rx_data_saida" => date("Y-m-d H:m:s")
							
						);
					$confere_ja_cadastrado = $this->rx_model->get_by_cod_lote($dados_query['rx_cod'], $dados_query['rx_lote']);	
					if($confere_ja_cadastrado["qt"] != 0){
						$data['msg'] .= "<p class='erro-rx-1'>C&oacute;digo ".$dados_query['rx_cod']." n&atilde;o cadastrado: J&aacute; est&aacute; cadastrado no sistema!</p>";
						}else{	
							$confere_cod = $this->rx_qtd_model->confere_cod($dados_query);

							if($confere_cod['qt'] != 0){
							
								//cadastra evento e recebe o id
								$id[] = $this->rx_model->add_record($dados_query);
								$dados_query_alteracoes = array(
									"rx_alteracoes_rx_id" => $id[$i],
									"rx_alteracoes_user_id" => $this->session->userdata("user_id"),
									"rx_alteracoes_user_nome" => $this->session->userdata("user_nome"),
									"rx_alteracoes_tipo" => 0
								
									);
								$this->rx_alteracoes_model->add_record($dados_query_alteracoes);
								$data['msg'] .= "<p class='erro-rx-0'>C&oacute;digo ".$dados_query['rx_cod']." cadastrado com sucesso!</p>";
								$dados_query_lote = array(
									"rx_qtd_id" => $confere_cod['rows'][0]->rx_qtd_id,
									"rx_qtd" => $confere_cod['rows'][0]->rx_qtd - 1
								
									);
								$this->rx_qtd_model->update_record($dados_query_lote);
									
								
								$i ++;
								}else{
									$data['msg'] .= "<p class='erro-rx-2'>C&oacute;digo ".$dados_query['rx_cod']." n&atilde;o cadastrado: C&oacute;digo ou lote n&atilde;o encontrados!</p>";
									
									}
							}
							
						}
					
					}
			}
		$this->load->view('rx/adicionar_view',$data);
        
    }
	public function busca() {
		
		if($_POST){
			$result = $this->rx_model->get_by_cod_lote($_POST['cod'], $_POST['lote']);
			if($result["qt"] != 0){
				print json_encode($result["rows"]);				
				}else{
					print "false";
					}
			}else{
				$this->load->view('rx/busca_view');
				}
		}
	public function editar($id) {
		$data['rx'] = $this->rx_model->get_by_id($id);
		$data['alteracoes'] = $this->rx_alteracoes_model->get_by_rx($id);
		if($_POST){
			$img_final  = $data['rx']->rx_img;
			if($_FILES){
			//UPLOAD IMAGENS
			$pathToSave = './upload/rx/';

			$i = 0;
			$msg = array( );
			$arquivos = array( array( ) );
			foreach(  $_FILES as $key=>$info ) {
				foreach( $info as $key=>$dados ) {
					for( $i = 0; $i < sizeof( $dados ); $i++ ) {
						$arquivos[$i][$key] = $info[$key][$i];
					}
				}
			}

			$i = 0;

			
			foreach( $arquivos as $file ) {

				// Verificar se o campo do arquivo foi preenchido
				if( $file['name'] != '' ) {
					$arquivoTmp = $file['tmp_name'];
					$nome_arquivo = explode(".",$file['name']);
					
					$arquivo[$i] = $pathToSave.$id."_".$i.strtotime("now").".".strtolower ($nome_arquivo[1]);


					if( !move_uploaded_file( $arquivoTmp, $arquivo[$i] ) ) {
						$msg[$i] = 'Erro no upload do arquivo '.$i;
					} else {
					
						$this->thumb($arquivo[$i]);

						
					}
				} else {
					$msg[$i] = sprintf('O arquivo %d nao foi preenchido',$i);
				}
					
		
				$i++;
			}
			//adiciona as imagens na query
			if(isset($arquivo)){
					foreach($arquivo as $img){
						$img_final .= end(explode("/",$img)).";"; 
					}
				}
			}
			
			$data_producao = explode("/", $this->input->post("data_producao"));
			$data_entrega = explode("/", $this->input->post("data_entrega"));
			$dados_query = array(
				"rx_id" => $id,
				"rx_cro" => $this->input->post("cro"),
				"rx_nome" => $this->input->post("nome"),
				"rx_cidade" => $this->input->post("cidade"),
				"rx_uf" => $this->input->post("uf"),
				"rx_guia" => $this->input->post("guia"),
				"rx_data_producao" => $data_producao[2]."-".$data_producao[1]."-".$data_producao[0],
				"rx_data_entrega" => $data_entrega[2]."-".$data_entrega[1]."-".$data_entrega[0],
				"rx_qtd" => $this->input->post("qtd"),
				"rx_obs" => $this->input->post("obs"),
				"rx_img" => $img_final,
				"rx_status" => $data['rx']->rx_status
				
				);
			if($dados_query["rx_data_producao"] != "0000-00-00" and $dados_query["rx_data_entrega"] == "0000-00-00"){
				$dados_query["rx_status"] = 1;
				}
			if($dados_query["rx_data_entrega"] != "0000-00-00"){
				$dados_query["rx_status"] = 2;
				}
			$this->rx_model->update_record($dados_query);
			
			$dados_query_alteracoes = array(
				"rx_alteracoes_rx_id" => $id,
				"rx_alteracoes_user_id" => $this->session->userdata("user_id"),
				"rx_alteracoes_user_nome" => $this->session->userdata("user_nome"),
				"rx_alteracoes_data" => date("Y-m-d H:m:s"),
				"rx_alteracoes_tipo" => 1,
				"rx_alteracoes_dados" => ""
				);

			if($dados_query["rx_cro"] != $data['rx']->rx_cro){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterado o CRO <br />";
				}
			if($dados_query["rx_guia"] != $data['rx']->rx_guia){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterado o n&ordm; da guia <br />";
				}
			if($dados_query["rx_data_producao"] != $data['rx']->rx_data_producao){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterada a data entrega de produ&ccedil;&atilde;o<br />";
				}
			if($dados_query["rx_data_entrega"] != $data['rx']->rx_data_entrega){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterada a data de entrega do RX<br />";
				}
			if($dados_query["rx_qtd"] != $data['rx']->rx_qtd){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterada a quantidade de RX<br />";
				}
			if($dados_query["rx_obs"] != $data['rx']->rx_obs){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Alterada as observa&ccedil;&otilde;es<br />";
				}
			if($dados_query["rx_img"] != $data['rx']->rx_img){
				$dados_query_alteracoes["rx_alteracoes_dados"] .= "Altera&ccedil;&otilde;es nas images<br />";
				}
			
			
			$this->rx_alteracoes_model->add_record($dados_query_alteracoes);
			

			redirect('rx/rx/editar/'.$id,'refresh');
			
			}else{

				$this->load->view('rx/editar_view', $data);
				}
		
		}
	function exclui_img($id, $image){
		$rx = $this->rx_model->get_by_id($id);;
		$rx_imgs = explode(";",$rx->rx_img);
				
		$rx_imgs_final ="";
		foreach($rx_imgs as $img){
			if($img != $image and $img != ""){
				$rx_imgs_final .= $img.";";	
				}
				
			}
		
		$dados_query = array(
			"rx_id" => $id,	
			"rx_img" => $rx_imgs_final	
		);
											
		$result = $this->rx_model->update_record($dados_query);
		$dados_query_alteracoes = array(
				"rx_alteracoes_rx_id" => $id,
				"rx_alteracoes_user_id" => $this->session->userdata("user_id"),
				"rx_alteracoes_user_nome" => $this->session->userdata("user_nome"),
				"rx_alteracoes_data" => date("Y-m-d H:m:s"),
				"rx_alteracoes_tipo" => 1,
				"rx_alteracoes_dados" => "Altera&ccedil;&otilde;es nas images"
				);
		$this->rx_alteracoes_model->add_record($dados_query_alteracoes);
						
		@unlink("./upload/rx/".$image);
		$rx_img_thumb = explode(".",$image);
		@unlink("./upload/rx/".$noticia_img_thumb[0]."_small.".$noticia_img_thumb[1]);
		
		redirect('rx/rx/editar/'.$id,'refresh');

	}
	
	function thumb($img){
		$nomeimg = explode(".",$img);
		$this->image_moo->load($img)->resize(120,120)->save(".".$nomeimg[1]."_small.".$nomeimg[2]);

		}
	
}