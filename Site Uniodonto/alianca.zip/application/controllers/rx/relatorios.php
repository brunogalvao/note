<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class relatorios extends CI_Controller {
    
    function __construct() {
        parent::__construct();
		$this->auth->check_logged($this->router->class , $this->router->method, $this->uri->segment(1));		
    }
	
	public function index() {
		if($_POST){
			$data_menor = explode("/", $this->input->post("data_menor"));
			$data_maior = explode("/", $this->input->post("data_maior"));
			
			$mes_inicio = $data_menor['0'];
			$mes_fim = $data_maior['0'];
			$ano = $data_maior[1];
			}else{
				$mes_inicio = date('m', strtotime("-60 days"));
				$mes_fim = date('m', strtotime("+60 days"));
				$ano = date('Y');
				}
		
		$data["mes_inicio"]= $mes_inicio;
		$data["mes_fim"]= $mes_fim;
		$data["ano"]= $ano;
		$data["meses"]="";
		$data["aberto"]="";
		$data["producao"]="";
		$data["concluido"]="";
		$this->lang->load('site', "ptBR");
		for ($i = $mes_inicio; $i <= $mes_fim; $i++) {
			$mes = str_pad($i, 2, "0", STR_PAD_LEFT);
			$data["meses"] .= "'".$mes."/".$ano."'";
			$aberto = $this->rx_model->relatorio_rx_mes_aberto($mes,$ano);
			if($aberto["qt"] > 0){
				$data["aberto"] .=  $aberto["row"]->qt;
				}else{
					$data["aberto"] .=  0;
					}
			$producao = $this->rx_model->relatorio_rx_mes_producao($mes,$ano); 
			if($producao["qt"] > 0){
				$data["producao"] .=  $producao["row"]->qt;
				}else{
					$data["producao"] .=  0;
					}
			$concluido = $this->rx_model->relatorio_rx_mes_concluido($mes,$ano); 
			if($concluido["qt"] > 0){
				$data["concluido"] .=  $concluido["row"]->qt;
				}else{
					$data["concluido"] .=  0;
					}
			if($i < $mes_fim){
				$data["meses"] .= ",";
				$data["aberto"] .= ",";
				$data["producao"] .= ",";
				$data["concluido"] .= ",";
				}
		}
		
		$data["totalaberto"] = $this->rx_model->relatorio_rx_mes_total_aberto($mes_inicio,$mes_fim,$ano);
		$data["totalrecebido"] = $this->rx_model->relatorio_rx_mes_total_producao($mes_inicio,$mes_fim,$ano);
		$data["totalconcluido"] = $this->rx_model->relatorio_rx_mes_total_concluido($mes_inicio,$mes_fim,$ano);
		

		
		
		$data["porcentagemrecebido"] = number_format(($data["totalrecebido"] / $data["totalaberto"]) * 100, 2, '.', '');
		
		$data["porcentagemconcluido"] = number_format(($data["totalconcluido"] / $data["totalaberto"]) * 100, 2, '.', '');
		$data["porcentagemaberto"] = number_format(100 - ($data["porcentagemrecebido"] + $data["porcentagemconcluido"]) , 2, '.', '');
		
		$this->load->view('rx/relatorio_mes_view', $data);
    }
	
	
	
}