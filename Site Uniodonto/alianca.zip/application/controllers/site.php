<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {
	
	
	
	public $link_sistema = "http://sio.uniodontocuritiba.com.br/Uniodonto/";
	public $data;

	
    function __construct() {
        parent::__construct();
		if(!$this->session->userdata("idioma")){
			$this->session->set_userdata("idioma","ptBR");
			}
		$this->lang->load('site', $this->session->userdata("idioma"));
		$this->data["link_sistema"] = $this->link_sistema;
		$this->data["menu_uniodonto"] = $this->textos_model->pesquisa_textos(1);
		$this->data["menu_planos"] = $this->textos_model->pesquisa_textos(2);
		$this->data["menu_dental"] = $this->textos_model->pesquisa_textos(3);
		$this->data["menu_clinica"] = $this->textos_model->pesquisa_textos(4);
		$this->data["menu_contato"] = $this->textos_model->pesquisa_textos(5);
		$this->data["menu_sustentabilidade"] = $this->textos_model->pesquisa_textos(6);
		$this->data["banners"] = $this->banners_model->banners();
		if($this->session->userdata("logged") == true){
			$this->data["menus_logado"] = $this->menus_logado();
		}
			
    }

	
	function trocaidioma($idioma){
		if($idioma == "ptBR"){
			$this->session->set_userdata("idioma",$idioma);	
		}
		if($idioma == "en"){
			$this->session->set_userdata("idioma",$idioma);	
		}
		if($idioma == "es"){
			$this->session->set_userdata("idioma",$idioma);	
		}
		redirect(base_url());
		}
	
	function index() {
		#PÃ¡gina inicial
		#array com as informaÃ§oes para a busca no banco 1 quer dizer ativo
		$dados_query = array(
		"noticia_destaque" => 1,
		"noticia_status" => 1,
		"noticia_home" => 1,
			);
		#Recebe as informaÃ§oes do banco	
		$this->data["noticias_destaque"] = $this->noticias_model->get_noticia_principal_destaque($dados_query);	
		$dados_query["noticia_id"] = $this->data["noticias_destaque"][0]['noticia_id'];
		
		
		for ($i = 1; $i < 5; $i++) {
			$dados_query['noticia_posicao'] = $i;
			$this->data["noticias"][$i] = $this->noticias_model->get_noticia_principal($dados_query);
			
			
		}
	
	
        $this->load->view('home_view',$this->data);

    }
	
	
	private function menus_logado(){
		$links_pronto = array();
		if($this->session->userdata("pagina")){
			$links_logado = $this->joins_model->get_links_abas_and_textos_abas($this->session->userdata("pagina"));
			if(count($links_logado["texto"])!=0){
				foreach($links_logado["texto"] as $link_texto){
						$links_pronto[] = array( 
							'titulo' => $link_texto['texto_aba_titulo_'.$this->session->userdata("idioma")],
							'link' => '<a href="'.site_url("pagina-restrita/".$link_texto['texto_aba_id']).'">'.$link_texto['texto_aba_titulo_'.$this->session->userdata("idioma")].'</a>',
							'menu' => $link_texto['texto_aba_menu']
							
							);	
								
					}
				}
			if(count($links_logado["links"])!=0){
				foreach($links_logado["links"] as $links){
						$links_pronto[] = array( 
							'titulo' => $links['link_aba_titulo_'.$this->session->userdata("idioma")],
							'link' => '<a href="'.$links['link_aba_link'].'">'.$links['link_aba_titulo_'.$this->session->userdata("idioma")].'</a>',
							'menu' => $links['link_aba_menu']
							
							);	
								
					}
				}	
			
			
			
			return $links_pronto;
			}
		
		
	}		
	    
	function pagina($id, $titulo) {
		#busca no banco os textos de acordo com o id informado
		$this->data['texto'] = $this->textos_model->get_by_id_array($id);
        $this->load->view('textos_view',$this->data);

    }
	
	function paginaaba($id) {
		#busca no banco os textos de acordo com o id informado
		$this->data['texto'] = $this->textos_abas_model->get_by_id_array($id);
		if($this->login_model->logged_users() and $this->data['texto'][0]['texto_aba_aba'] == $this->session->userdata("pagina")){
        	$this->load->view('paginaaba_view',$this->data);
		}else{
			redirect(site_url());
			}

    }
	
	function menu_link($id) {
		
		$this->data['texto'] = $this->textos_abas_model->get_by_id($id);



		if($this->login_model->logged_users() and $this->data['texto']->texto_pagina == $this->session->userdata("pagina")){
			$this->load->view('textos_view',$this->data);
			}else{
				redirect(site_url());
			}
		
        

    }
	
	function noticia($id ,$titulo) {
		#PÃ¡gina da noticia
		#array com as informaÃ§oes para a busca no banco 1 quer dizer ativo
		$dados_query = array(
		"noticia_destaque" => 1,
		"noticia_status" => 1,
		"noticia_home" => 1,
			);
		#verifica qual aba esta liberada e adiciona a query
		if($this->session->userdata("pagina") != ""){
			$dados_query["noticia_".$this->session->userdata("pagina")] = 1;
			}	
		
		#Busca as noticias recentes
		$this->data["noticias"] = $this->noticias_model->get_noticias_recentes($dados_query);
		#Adiciona o id da noticia principal a query e busca resultado
		$dados_query["noticia_id"] = $id;
		$this->data['noticia'] = $this->noticias_model->get_by_id_array($id);
		#Cria a breve descricao
		$breve_desc = strip_tags($this->data['noticia'][0]['noticia_texto_'.$this->session->userdata("idioma")]);
        $this->data['breve_desc'] = substr($breve_desc, 0, strrpos(substr($breve_desc, 0, 120), ' '));
        $this->load->view('noticias_view',$this->data);

    }
	
	function retorna_estados($id){
		
		// Inicia o cURL acessando uma URL
		$cURL = curl_init("http://unioweb.uniodontocuritiba.com.br/Uniodonto/ListComboSiteServlet?lista=cidades&estado=".$id);
		// Define a opção que diz que você quer receber o resultado encontrado
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		// Executa a consulta, conectando-se ao site e salvando o resultado na variável $resultado
		print utf8_encode(curl_exec($cURL));
		// Encerra a conexão com o site
		curl_close($cURL);
		/*
		#carrega estados para formulÃ¡rio ajax direto do sistema
		print utf8_encode(file_get_contents( "http://unioweb.uniodontocuritiba.com.br/Uniodonto/ListComboSiteServlet?lista=cidades&estado=".$id));
		*/
		}
	function retorna_especialidades(){
		// Inicia o cURL acessando uma URL
		$cURL = curl_init("http://unioweb.uniodontocuritiba.com.br/Uniodonto/ListComboSiteServlet?lista=especialidades");
		// Define a opção que diz que você quer receber o resultado encontrado
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		// Executa a consulta, conectando-se ao site e salvando o resultado na variável $resultado
		print utf8_encode(curl_exec($cURL));
		// Encerra a conexão com o site
		curl_close($cURL);
		/*#carrega especialidades para formulÃ¡rio ajax direto do sistema
		print utf8_encode(file_get_contents( "http://unioweb.uniodontocuritiba.com.br/Uniodonto/ListComboSiteServlet?lista=especialidades"));
		*/
	}	
	
	function serverRequest(){
		// Inicia o cURL acessando uma URL
		$cURL = curl_init("http://unioweb.uniodontocuritiba.com.br/Uniodonto/".$_GET["call"]."?option=".$_GET["option"]."&cod=".$_GET["cod"]."&month=".$_GET["month"]);
		// Define a opção que diz que você quer receber o resultado encontrado
		curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
		// Executa a consulta, conectando-se ao site e salvando o resultado na variável $resultado
		print utf8_encode(curl_exec($cURL));
		// Encerra a conexão com o site
		curl_close($cURL);
		
		/*print print utf8_encode(file_get_contents("http://unioweb.uniodontocuritiba.com.br/Uniodonto/".$_GET["call"]."?option=".$_GET["option"]."&cod=".$_GET["cod"]."&month=".$_GET["month"]));*/

	}
	
	
	public function historico() {
		#Verifica se existe uma busca caso houver carrega resultados referente a busca se nao tiver retorna todas as notÃ­cias	
		if($_POST){
			#Carrega dados da busca
			$pesquisa['noticia_titulo'] = $this->input->post('busca');
			$pesquisa['noticia_home'] = 1;
			$pesquisa['noticia_status'] = 1;
			#Verifica qual aba esta liberada e adiciona na query
			if($this->session->userdata("pagina")){
			$pesquisa["noticia_".$this->session->userdata("pagina")] = 1;
			}
			#Coloca os dados da pesquisa na sessao					
			$this->session->set_userdata("pesquisa",$pesquisa);
				if($this->session->userdata("idioma") == "en"){
							$this->data['titulo'] = 'Resultado da busca por: "'.$pesquisa['noticia_titulo'].'"';
						}else{
							$this->data['titulo'] = 'Resultado da busca por: "'.$pesquisa['noticia_titulo'].'"';
							}	
			}else{
				#Verifica paginaÃ§ao
				if($this->uri->segment(2) != ""){
					$pesquisa = $this->session->userdata('pesquisa');
					
					if($this->session->userdata("idioma") == "en"){
							$this->data['titulo'] = 'Resultado da busca por: "'.$pesquisa['noticia_titulo'].'"';
						}else{
							$this->data['titulo'] = 'Resultado da busca por: "'.$pesquisa['noticia_titulo'].'"';
							}
					
					}else{
						$pesquisa['noticia_titulo'] = "";
						$pesquisa['noticia_home'] = 1;
						$pesquisa['noticia_status'] = 1;
						if($this->session->userdata("pagina")){
							$pesquisa["noticia_".$this->session->userdata("pagina")] = 1;
						}
						$this->session->set_userdata("pesquisa",$pesquisa);
						if($this->session->userdata("idioma") == "en"){
							$this->data['titulo'] = 'News';
						}else{
							$this->data['titulo'] = 'Not&iacute;cias';
							}
						
						
						}
					
				
				}
			
		$config['total_rows'] = $this->noticias_model->count_noticias($pesquisa);
		$config['base_url'] = site_url() . 'historico';
		$config['per_page'] = '30';
		$config['uri_segment'] = '2';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(2) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
			
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->noticias_model->count_noticias($pesquisa);
		$pesquisa['tipo'] = "array";
		$this->data['noticias'] = $this->noticias_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('historico_view', $this->data);
        
    }
	

	
	function login(){
		#limpa a sessao para eliminar qualquer login ativo
		$dados_usuario = array(
				"tipo" => '',
				"nome" => '',
				"codigo" => '',
				"representante" => '',
				"logged" => false,
			);
		$this->session->set_userdata("teste","0");	
		#coloca os dados na sessao
		$this->session->set_userdata($dados_usuario);

		if($_POST){
			#pega os dados que retornaram por POST do sistema
			$dados_usuario = array(
				"tipo" => strip_tags($_POST["tipo"]),
				"nome" => strip_tags($_POST["nome"]),
				"codigo" => strip_tags($_POST["codigo"]),
				'logged' => true
			);
			#coloca os dados na sessao
			$this->session->set_userdata($dados_usuario);
				#Verifica e redireciona o usuÃ¡rio para aba correta do login
				if($this->session->userdata("tipo") == "associado") {
						$this->session->set_userdata("pagina","beneficiario");
						redirect(site_url("acesso/beneficiario"));
				}
				if($this->session->userdata("tipo") == "empresa") {
						$this->session->set_userdata("pagina","empresa");
						redirect(site_url("acesso/empresa"));
				}
				if($this->session->userdata("tipo") == "cooperado" or $this->session->userdata("tipo") == "coopInter" or $this->session->userdata("tipo") == "credenciadoPF" or $this->session->userdata("tipo") == "credenciadoPJ" or $this->session->userdata("tipo") == "credenciadoPJPrestador") {		
						$this->session->set_userdata("teste","3");
						$this->session->set_userdata("pagina","dentista");
						redirect(site_url("acesso/dentista"));
				}
				if($this->session->userdata("tipo") == "uniodonto") {		
						$this->session->set_userdata("pagina","uniodonto");
						redirect(site_url("acesso/uniodonto"));
				}
				if($this->session->userdata("tipo") == "colaborador") {		
						$this->session->set_userdata("pagina","colaborador");
						redirect(site_url("acesso/colaborador"));
				}
				if($this->session->userdata("tipo") == "vendedor") {		
						$this->session->set_userdata("representante",1);
						$this->session->set_userdata("pagina","representante");
						redirect(site_url("acesso/representante"));
				}
				if($this->session->userdata("tipo") == "representante") {		
						$this->session->set_userdata("representante",0);
						$this->session->set_userdata("pagina","representante");
						redirect(site_url("acesso/representante"));
				}
				$this->session->set_userdata("teste","2");
				redirect(site_url());
			}else{
				$this->session->set_userdata("teste","1");
				#se nao estiver logado redireciona para a home
				redirect(site_url());
				}	
		}
	function alterarcidade(){
		#funÃ§ao de logout
		$data['link'] = $this->link_sistema."Logout.do";
		$data['tipo'] = 1;
 		$this->load->view('logout_view',$data);
		}
	function logout(){
		#funÃ§ao de logout
		#limpa a sessao para eliminar qualquer login ativo
		$dados_usuario = array(
				"tipo" => '',
				"nome" => '',
				"codigo" => '',
				'logged' => false
			);
		#coloca os dados na sessao
		$this->session->set_userdata($dados_usuario);
		$data['link'] = $this->link_sistema."Logout.do";
		$data['tipo'] = 1;
 		$this->load->view('logout_view',$data);
		
		
		}	

	
	function acesso($pagina) {
		
		#verifica se o usuÃ¡rio esta logado e se a pÃ¡gina confere com a liberada
		if($this->login_model->logged_users() == true and $pagina == $this->session->userdata("pagina")){		
					$dados_query = array(
					"noticia_destaque" => 1,
					"noticia_status" => 1,
					"noticia_".$pagina => 1
						);
					#Carrega as noticias para exibiÃ§ao	
					$this->data["noticias_destaque"] = $this->noticias_model->get_noticia_principal_destaque($dados_query);	
					$dados_query["noticia_id"] = $this->data["noticias_destaque"][0]['noticia_id'];
					for ($i = 1; $i < 5; $i++) {
						$dados_query['noticia_posicao'] = $i;
						$this->data["noticias"][$i] = $this->noticias_model->get_noticia_principal($dados_query);

						
					}
					
					$this->data["pagina"] = $pagina;
					$this->load->view('home_view',$this->data);
				
			}else{
				#se nao estiver logado redireciona para a home
				redirect(site_url());
			
			}
		
    }
	#PÃ¡ginas de relatÃ³rios cooperado
	function relatorios_cooperado(){
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_dentista_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	#PÃ¡ginas de relatÃ³rios empresa	
	function relatorios_empresa_atendimentomes(){
		if($this->login_model->logged_users() and "empresa" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_empresa_atendimentomes_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	function relatorios_empresa_statusguias(){
		if($this->login_model->logged_users() and "empresa" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_empresa_statusguias_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	function relatorios_empresa_atendimentoespecialidade(){
		if($this->login_model->logged_users() and "empresa" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_empresa_atendimentoespecialidade_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	function relatorios_empresa_faturamento(){
		if($this->login_model->logged_users() and "empresa" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_empresa_faturamento_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	#PÃ¡ginas de relatÃ³rios uniodonto
	function relatorios_uniodonto_faturamento(){
		if($this->login_model->logged_users() and "uniodonto" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_uniodonto_faturamento_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	function relatorios_uniodonto_faturamentointercambio(){
		if($this->login_model->logged_users() and "uniodonto" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_uniodonto_faturamentointercambio_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
	function relatorios_uniodonto_qtbeneficiarios(){
		if($this->login_model->logged_users() and "uniodonto" == $this->session->userdata("pagina")){
			$this->data["link_sistema"] = $this->link_sistema[1];
			$this->load->view('relatorios_uniodonto_qtbeneficiarios_view',$this->data);
		}else{
			redirect(site_url());
			}
		}
		
	#classes de redirecionamento para o sistema	
	function links_beneficiario($pagina){
		if($this->login_model->logged_users() and "beneficiario" == $this->session->userdata("pagina")){
			if($pagina == "alteradados"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAlteraAssociado.do?modulo=15";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "impostoderenda"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDeclaracaoImpostoRenda.do?reset=true&disabled=true";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "boleto"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDuplicataTipoSacadoView.do?reset=true&modulo=16";
				$this->load->view('link_unioweb_view',$data);
				}
			
		}else{
			redirect(site_url());
			}							
		}
	function links_empresa($pagina){
		if($this->login_model->logged_users() and "empresa" == $this->session->userdata("pagina")){
			if($pagina == "movimentacao-cadastral"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoMovimentacaoCadastral.do?modulo=11&descModulo=Movimentacao Cadastral";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "liberacao-online"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoOrcamento.do?reset=yes&disabled=true&modulo=1";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "consulta-notafiscal"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoNotaFiscalView.do?reset=true&modulo=16";
				$this->load->view('link_unioweb_view',$data);
				}	
			if($pagina == "relatorio-beneficiarios"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "UsuariosClienteMC.do?reset=true&modulo=11";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "alterar-dados"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoCarregarValidaEmpresa.do?modulo=15";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "alterar-senha"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAlterarSenha.do?reset=true&modulo=15";
				$this->load->view('link_unioweb_view',$data);
				}								
			if($pagina == "boleto"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDuplicataTipoSacadoView.do?reset=true&modulo=16";
				$this->load->view('link_unioweb_view',$data);
				}
		}else{
			redirect(site_url());
		}					
			
				
		}
	function links_dentista($pagina){
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){
			if($pagina == "dados-cadastrais"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAlteraDadosCooperado.do?modulo=15";
				$this->load->view('link_unioweb_view',$data);
				}				
			if($pagina == "informe-de-rendimentos"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAvisoCredito.do?reset=true&disabled=true&modulo=13";
				$this->load->view('link_unioweb_view',$data);
				}	
			if($pagina == "boleto"){
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDuplicataTipoSacadoView.do?reset=true&modulo=16";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "liberacao-online"){
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAtendimento.do?modulo=1&descModulo=Atendimento";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "impostoderenda"){
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDeclaracaoImpostoRenda.do?reset=true&disabled=true";
				$this->load->view('link_unioweb_view',$data);
				}								
			
		}else{
			redirect(site_url());
		}					
			
				
		}
	function links_uniodonto($pagina){
		if($this->login_model->logged_users() and "uniodonto" == $this->session->userdata("pagina")){
			if($pagina == "dados-cadastrais"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAlteraUniodonto.do?reset=true&modulo=15";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "boleto"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoDuplicataTipoSacadoView.do?reset=true&modulo=16";
				$this->load->view('link_unioweb_view',$data);
				}
			if($pagina == "liberacao-online"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAtendimento.do?modulo=1&descModulo=Atendimento";
				$this->load->view('link_unioweb_view',$data);
				}

		}else{
			redirect(site_url());
		}					
			
				
		}
	
	function links_representante($pagina){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			if($pagina == "senha"){
				$this->session->sess_destroy();
				$data['link'] = $this->link_sistema."/Uniweb.do";
				$data['action'] = "GoAlterarSenha.do?reset=yestrue=true";
				$this->load->view('link_unioweb_view',$data);
				}
			
		}else{
			redirect(site_url());
		}					
			
				
		}
	function calcula_planos(){
		
		$dados_query = array(
			"plano_tipo" => $_REQUEST["plano_tipo"],
			"plano_pagamento" => $_REQUEST["plano_pagamento"],
			"plano_modalidade" => $_REQUEST["plano_modalidade"],
			"plano_qtd" => $_REQUEST["plano_qtd"]
		);
		$plano = ($this->planos_model->pesquisa_planos($dados_query));
		print $this->lang->line('valor_por_beneficiario').number_format($plano[0]->plano_preco, 2, '.', ',')." <br />";
        print $this->lang->line('valor_total').number_format($plano[0]->plano_qtd * $plano[0]->plano_preco, 2, '.', ',');
		
		}	
		
	function localizacao(){
		$this->data["localizacao"] = $this->localizacao_model->get_localizacao();
		$this->data["localizacao"] = $this->data["localizacao"]["rows"];
		$this->load->view('localizacao_view',$this->data);
		
		}
	function calendario(){
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){
			$this->load->view('calendario_view',$this->data);
			}else{
				redirect(site_url());
			}
		
		}	
	
	function evento($id){
		$this->data["evento"] = $this->eventos_model->get_by_id_array($id);
		$breve_desc = strip_tags($this->data['evento']->evento_texto);
        $this->data['breve_desc_evento'] = substr($breve_desc, 0, strrpos(substr($breve_desc, 0, 120), ' '));
 		if($this->session->userdata("logged") == true){
			$this->load->view('evento_view',$this->data);	
			}else{
				redirect(site_url());
				}
		}
		
	function eventos(){
		if($_REQUEST['start'] == ""){
			$query["evento_inicio_maior"] = date("Y-m-d", strtotime("now"));
			$query["evento_fim_menor"] = date('Y-m-d', strtotime("+365 days"));
			}else{
				$query["evento_inicio_maior"] = date("Y/m/d", $_GET["start"]);
				$query["evento_fim_menor"] = date("Y/m/d", $_GET["end"]);
			}		
			$query["tipo"] = "array";
			$eventos = $this->eventos_model->pesquisa_eventos($query);
			
			$charset    = 'utf-8';
			$encoding   = "\"".$charset."\"";
			$xml        = '<events>';
			$i = 1;
			foreach($eventos as $evento){
				$xml .= '<event id="'.$i.'" url="'.site_url("evento/".$evento['evento_id']).'" start="'.$evento['evento_inicio'].'" end="'.$evento['evento_fim'].'" color="'.$evento['evento_corfont'].'" backgroundColor="'.$evento['evento_corbg'].'" ><titulo><![CDATA['.$evento['evento_titulo_'.$this->session->userdata("idioma")].']]></titulo></event>';
				$i ++;
			}
			$xml        .= '</events>';
			$header     = '<?xml version="1.0" encoding='.$encoding.' ?>';
			$output     = $header.$xml;
			header("Content-type: application/xml; $charset");
			print $output;
			
		}


	function contato(){
		
		if ($this->captcha->create()) {
			$this->data['captcha'] = $this->captcha->html_data;
			} else {
			$this->data['captcha'] = 'Captcha : ' . $this->captcha->debug;
			}
		
		if($_POST){
		 $resposta['captcha'] = $this->data['captcha']['src'];
		 if ($this->captcha->check($this->input->post('captcha'))) {
			$this->form_validation->set_rules('nome', 'nome', 'required');	
			$this->form_validation->set_rules('email', 'email', 'required|valid_email');
			$this->form_validation->set_rules('msg', 'msg', 'required');
			
			if($this->form_validation->run()){
				$dados["nome"] = $this->input->post('nome');
				$dados["email"] = $this->input->post('email');
				$dados["titulo"] = "Contato Site";
				$dados["emailto"] = "beneficiario@uniodontocuritiba.com.br";
				$dados["texto"] = "
									Nome: ".$this->input->post("nome")."<br />
									Email: ".$this->input->post("email")."<br />
									Telefone: ".$this->input->post("telefone")."<br />
									J&aacute; &eacute; cliente: ".$this->input->post("cliente")."<br />
									N&ordm; do cart&atilde;o: ".$this->input->post("ncartao")."<br />
									
				
				";
				
				
				$dados["texto"] .= '<br />Mensagem: <br />'.$this->input->post('msg');
				$return = $this->envia($dados);
				$resposta['msg'] =  $return;
			}else{
				//Volta para a pÃ¡gina de contato
				$resposta['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');
													
				}
			print json_encode($resposta);
		 }else{
			 $resposta['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');
			 print json_encode($resposta);
			 
			 }
		}else{
			$this->load->view('contato_view',$this->data);
			
			}
		
		
				
		}
	
	function contatohotsitecnh(){	
		
		if($_POST){
			if($_POST['nome'] != "" and $_POST['email'] != "" and $_POST['msg'] != "" and $_POST['dentista'] != "" and $_POST['cro'] != "" and $_POST['matricula'] != "" and $_POST['beneficiario'] != ""){
					
					
				$dados["nome"] = $this->input->post('nome');
				$dados["email"] = $this->input->post('email');
				$dados["titulo"] = "Mensagem de contato CNH";
				$dados["emailto"] = "clientecnh@uniodontocuritiba.com.br";
				$dados["emailbcc"] = $bcc;
				$dados["texto"] = "	
									PAB: ".$this->input->post("pab")."<br />
									Nome: ".$this->input->post("nome")."<br />
									Email: ".$this->input->post("email")."<br />
									Telefone: ".$this->input->post("telefone")."<br />
									N&ordm; Matr&iacute;cula: ".$this->input->post("matricula")."<br />
									Benefici&aacute;rio atendido: ".$this->input->post("beneficiario")."<br />
									Dentista: ".$this->input->post("dentista")."<br />
									CRO: ".$this->input->post("cro")."<br />
									Data: ".$this->input->post("data")."<br />
									Hora: ".$this->input->post("horario")."<br />
									<br />Relato: <br />".$this->input->post('msg');
									
				$return = $this->envia($dados);
				$resposta['msg'] =  $return;
			}else{
				$resposta['msg'] = '&Eacute; necess&aacute;rio preencher todos os campos!';
									
				}
			print json_encode($resposta);
		}
	}
	
	function contato_hotsite(){	
		
		if($_POST){
			if($_POST['nome'] != "" and $_POST['email'] != "" and $_POST['msg'] != ""){
				$dados["nome"] = $this->input->post('nome');
				$dados["email"] = $this->input->post('email');
				$dados["titulo"] = $this->input->post('assunto');
				$dados["emailto"] = "sitevendas@uniodontocuritiba.com.br";
				$dados["texto"] = "
									Nome: ".$this->input->post("nome")."<br />
									Email: ".$this->input->post("email")."<br />
									Telefone: ".$this->input->post("telefone")."<br />
									<br />Mensagem: <br />".$this->input->post('msg');
									
				$return = $this->envia($dados);
				$resposta['msg'] =  $return;
			}else{
				//Volta para a pÃ¡gina de contato
				if($this->session->userdata("idioma") == "en"){
					$resposta['msg'] = 'Select  all the fields.';
					}else{
						$resposta['msg'] = '&Eacute; necess&aacute;rio preencher todos os campos!';
						}
									
				}
			print json_encode($resposta);
		}
	}
	
	function proposta_hotsite(){	
		
		if($_POST){
					$dados["nome"] = $_REQUEST["razaosocial"];
					$dados["email"] = $_REQUEST["emailpessoacontato"];
					$dados["titulo"] = "Contato Site - Contratar Plano PME ".$_REQUEST["tipo_plano"];
					$dados["emailto"] = "sitevendas@uniodontocuritiba.com.br";
					$dados["texto"] = "
							<h1>Contratar Plano PME - ".$_REQUEST["tipo_plano"]."</h1>
							Valor do plano: ".$_REQUEST["valor_plano"]."
							
							<h1>Dados </h1>
							Raz&atilde;o Social: ".$_REQUEST["razaosocial"]."<br />
							Nome Fantasia: ".$_REQUEST["fantasia"]."<br />
							CNPJ: ".$_REQUEST["cnpj"]."<br />
							Insc. Estadual: ".$_REQUEST["insc_estadual"]."<br />
							Insc. Municipal: ".$_REQUEST["insc_municipal"]."<br />
							NAE: ".$_REQUEST["nae"]."<br />
							Ramo de atividade: ".$_REQUEST["ramo"]."<br />


							<h1>Endere&ccedil;o</h1>
							Endere&ccedil;o: ".$_REQUEST["tipoEndereco"]." ".$_REQUEST["endereco"]."<br />
							Bairro: ".$_REQUEST["bairro"]."<br />
							Cidade: ".$_REQUEST["cidade"]."<br />
							Estado: ".$_REQUEST["estado"]."<br />
							CEP: ".$_REQUEST["cep"]."<br />
							
							<h1>Contato</h1>
							Pessoa de contato: ".$_REQUEST["pessoacontato"]."<br />
							Data de nascimento: ".$_REQUEST["nascimentopessoacontato"]."<br />
							Fun&ccedil;&atilde;o: ".$_REQUEST["funcaopessoacontato"]."<br />
							Email: ".$_REQUEST["emailpessoacontato"]."<br />
							
							<h1>Correpond&ecirc;ncia</h1>
							Endere&ccedil;o: ".$_REQUEST["tipoEnderecocorrespondencia"]." ".$_REQUEST["enderecocorrespondencia"]."<br />
							Bairro: ".$_REQUEST["bairrocorrespondencia"]."<br />
							Cidade: ".$_REQUEST["cidadecorrespondencia"]."<br />
							Estado: ".$_REQUEST["estadocorrespondencia"]."<br />
							Correpond&ecirc;ncia: ".$_REQUEST["cepcorrespondencia"]."<br />
							Email: ".$_REQUEST["emailcorrespondencia"]."<br />
						";
									
				$return = $this->envia($dados);
				$resposta['msg'] =  $return;
			
			print json_encode($resposta);
		}


		
				
	}
	
	function revisaovalores(){
		if($this->session->userdata("pagina") == "dentista"){	
		if($_POST){
			
			$this->form_validation->set_rules('cro', 'cro', 'required');	
			$this->form_validation->set_rules('guia', 'guia', 'required');
			$this->form_validation->set_rules('quantidade', 'quantidade', 'required');
			
			if($this->form_validation->run()){
				$dados["cro"] = $this->input->post('cro');
				$dados["guia"] = $this->input->post('guia');
				$dados["quantidade"] = $this->input->post('quantidade');
				$dados["titulo"] = "Contato Site - Revis&atilde;o de valores";
				$dados["emailto"] = "grc@uniodontocuritiba.com.br";
				$dados["texto"] = "
									<h1>Revis&atilde;o de valores</h1>
									CRO: ".$this->input->post("cro")."<br />
									N&ordm; Guia: ".$this->input->post("guia")."<br />
									Quantidade U.S.O: ".$this->input->post("quantidade")."<br />
									Descri&ccedil;&atilde;o do Problema: <br />".$this->input->post("msg")."<br />
									
				
				";
				
				$return = $this->envia($dados);
				print $return;
			}else{
				//Volta para a pÃ¡gina de contato
				$this->lang->line('e_necessario_preencher_todos_os_campos');
									
				}
		}else{
			$this->load->view('revisaovalores_view',$this->data);
			
			}
		}else{
			redirect(site_url());
			
		}
		
		
				
	}
		
	
		
	function analise(){
		
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			if($_POST){
				
				$this->form_validation->set_rules("razao","razao", 'required');
				$this->form_validation->set_rules("fantasia","fantasia", 'required');
				$this->form_validation->set_rules("cnpj","cnpj", 'required');
				$this->form_validation->set_rules("endereco","endereco", 'required');
				$this->form_validation->set_rules("numero","numero", 'required');
				$this->form_validation->set_rules("bairro","bairro", 'required');
				$this->form_validation->set_rules("cidade","cidade", 'required');
				$this->form_validation->set_rules("uf","uf", 'required');
				$this->form_validation->set_rules("ramo","ramo", 'required');
				$this->form_validation->set_rules("fone","fone", 'required');
				$this->form_validation->set_rules("fax","fax", 'required');
				$this->form_validation->set_rules("pessoa","pessoa", 'required');
				$this->form_validation->set_rules("cargo","cargo", 'required');
				$this->form_validation->set_rules("email","email", 'required');
				$this->form_validation->set_rules("numeroFuncionario","numeroFuncionario", 'required');
				$this->form_validation->set_rules("quantosParticipa","quantosParticipa", 'required');
				$this->form_validation->set_rules("possuiconvenio","possuiconvenio", 'required');
				$this->form_validation->set_rules("operadoraMedico","operadoraMedico", 'required');
				$this->form_validation->set_rules("possuiconvenioOdonto","possuiconvenioOdonto", 'required');
				$this->form_validation->set_rules("operadoraOdonto","operadoraOdonto", 'required');
				$this->form_validation->set_rules("motivo","motivo", 'required');
				$this->form_validation->set_rules("temFiliais","temFiliais", 'required');
				$this->form_validation->set_rules("cidadesFilial","cidadesFilial", 'required');
				$this->form_validation->set_rules("SeraExtensivo","SeraExtensivo", 'required');
				$this->form_validation->set_rules("extensivoFuncionarios","extensivoFuncionarios", 'required');
				$this->form_validation->set_rules("percentual","percentual", 'required');
				$this->form_validation->set_rules("plano","plano", 'required');
				$this->form_validation->set_rules("TipoPlano","TipoPlano", 'required');
				$this->form_validation->set_rules("qtdpessoas","qtdpessoas", 'required');

				
				if($this->form_validation->run()){
					
					
					$dados["titulo"] = "Contato Site - Formul&aacute;rio an&aacute;lise cr&iacute;tica";
					$dados["emailto"] = "ivana@uniodontocuritiba.com.br";
					$dados["texto"] = "
							<h1>Formul&aacute;rio an&aacute;lise cr&iacute;tica Site</h1>
							Raz&atilde;o Social:".$this->input->post("razao")."<br />
							Nome Fantasia:".$this->input->post("fantasia")."<br />
							CNPJ:".$this->input->post("cnpj")."<br />
							Endere&ccedil;po:".$this->input->post("endereco")."<br />
							N&uacute;mero:".$this->input->post("numero")."<br />
							Bairro:".$this->input->post("bairro")."<br />
							Cidade:".$this->input->post("cidade")."<br />
							Estado:".$this->input->post("uf")."<br />
							Ramo de atividade:".$this->input->post("ramo")."<br />
							Tel:".$this->input->post("fone")."<br />
							Fax:".$this->input->post("fax")."<br />
							Pessoa de contato:".$this->input->post("pessoa")."<br />
							Cargo:".$this->input->post("cargo")."<br />
							Email:".$this->input->post("email")."<br />
							N&uacute;mero de funcion&aacute;rios:".$this->input->post("numeroFuncionario")."<br />
							Quantos participar&atilde;o do plano:".$this->input->post("quantosParticipa")."<br />
							Possui conv&ecirc;nio:".$this->input->post("possuiconvenio")."<br />
							Operadora:".$this->input->post("operadoraMedico")."<br />
							Possui conv&ecirc;nio odontol&oacute;gico:".$this->input->post("possuiconvenioOdonto")."<br />
							Operadora:".$this->input->post("operadoraOdonto")."<br />
							Motivo da mudan&ccedil;a:".$this->input->post("motivo")."<br />
							Possui filiais:".$this->input->post("temFiliais")."<br />
							Cidades:".$this->input->post("cidadesFilial")."<br />
							Ser&aacute; extensivo para filiais:".$this->input->post("SeraExtensivo")."<br />
							Ser&aacute; extensivo aos dependentes dos funcion&aacute;rios:".$this->input->post("extensivoFuncionarios")."<br />
							Percentual de participa&ccedil;&atilde;o do funcion&aacute;rio:".$this->input->post("percentual")."<br />
							Plano:".$this->input->post("plano")."<br />
							Tipo de plano:".$this->input->post("TipoPlano")."<br />
							Quantidade de pessoas:".$this->input->post("qtdpessoas")."<br /> 
					";
					$dados["texto"] .= '<br /><br /><br />ObservaÃ§Ãµes: <br />'.$this->input->post('obs');
					
					$return = $this->envia($dados);
					$this->session->set_flashdata('msg', $return);
				}else{
					//Volta para a pÃ¡gina de contato
					$this->lang->line('e_necessario_preencher_todos_os_campos');					
					}
			}
			
			$this->load->view('analise_view',$this->data);
			}else{
				redirect(site_url());
				}
			
		}
		
	function encontreseudentista(){
		$this->load->view('encontreseudentista_view',$this->data);
		}	
	
		
	private function envia($dados){
				
			
		$mensagem = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
					<html xmlns="http://www.w3.org/1999/xhtml">
					<head>
					<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
					<title>'.$dados["titulo"].'</title>
					<style>
						body{
							font-family: "Tahoma", Arial;
							font-size: 13px;
						}
						h1{
							font-size: 15px;
							color: #af2638;
						}
					</style>
					
					</head>
					
					<body>'.$dados["texto"].'</body>
					</html>';
				
		
		if(isset($dados['email'])){
			$this->email->from($dados['email']);
		}else{
			$this->email->from($dados['emailto']);
		}
		if(isset($dados['emailbcc'])){
			$this->email->bcc($dados['emailbcc']);
		}
		$this->email->to($dados['emailto']);
		$this->email->subject($dados["titulo"]);
		$this->email->message($mensagem);
		if(isset($dados["anexo"][0])){
			$this->email->attach($dados["anexo"][0]);			
		}
		if(isset($dados["anexo"][1])){
			$this->email->attach($dados["anexo"][1]);			
		}
		if(isset($dados["anexo"][2])){
			$this->email->attach($dados["anexo"][2]);			
		}
		

		
			if($this->email->send()){
					if(isset($dados["anexo"])){
						foreach($dados["anexo"] as $anexo){
							$files[] = $anexo;
							}
						$this->excluifiles($files);
						}
					
					return $this->lang->line('email_enviado_com_sucesso');
					
					}else{
						if(isset($dados["anexo"])){
							foreach($dados["anexo"] as $anexo){
								$files[] = $anexo;
								}
								$this->excluifiles($files);
														
							}
						return $this->lang->line('n�o_foi_possivel_enviar_o_email_tente_novamente');
						
						}
				
		}
		
	function excluifiles($files){
			foreach($files as $file){
				@unlink($file);
				}
			}
		
	function trabalheconoscodentista(){
			
			
			if($_POST){
				
				$this->form_validation->set_rules("nome","nome", 'required');
				$this->form_validation->set_rules("cro","cro", 'required');
				$this->form_validation->set_rules("sexo","sexo", 'required');
				$this->form_validation->set_rules("dataNascimento","dataNascimento", 'required');
				$this->form_validation->set_rules("estadoCivil","estadoCivil", 'required');
				$this->form_validation->set_rules("tipoEndereco","tipoEndereco", 'required');
				$this->form_validation->set_rules("endereco","endereco", 'required');
				$this->form_validation->set_rules("bairro","bairro", 'required');
				$this->form_validation->set_rules("cidade","cidade", 'required');
				$this->form_validation->set_rules("estado","estado", 'required');
				$this->form_validation->set_rules("cep","cep", 'required');
				$this->form_validation->set_rules("telefoneResidencial","telefoneResidencial", 'required');
				$this->form_validation->set_rules("celular","celular", 'required');
				$this->form_validation->set_rules("telefoneRecado","telefoneRecado", 'required');
				$this->form_validation->set_rules("falarCom","falarCom", 'required');
				$this->form_validation->set_rules("email","email", 'required');
				$this->form_validation->set_rules("rg","rg", 'required');
				$this->form_validation->set_rules("cpf","cpf", 'required');
				$this->form_validation->set_rules("pis","pis", 'required');
				$this->form_validation->set_rules("carteiraTrabalho","carteiraTrabalho", 'required');
				$this->form_validation->set_rules("serieCarteiraTrabalho","serieCarteiraTrabalho", 'required');
				$this->form_validation->set_rules("CNES","CNES", 'required');
				$this->form_validation->set_rules("licencaSanitaria","licencaSanitaria", 'required');
				$this->form_validation->set_rules("alvara","alvara", 'required');
				$this->form_validation->set_rules("indicacaoUniodonto","indicacaoUniodonto", 'required');
				
				if($this->form_validation->run()){
					
					$dados['nome'] = $this->input->post("nome");
					$dados['email'] = $this->input->post("email");
					$dados["titulo"] = "Fomul&aacute;rio Trabalhe Conosco - Dentista";
					$dados["emailto"] = "kettlin.anjos@uniodontocuritiba.com.br";
					$dados["texto"] = "
									<h1>Candidato</h1>
									Nome:".$this->input->post("nome")."<br />
									CRO:".$this->input->post("cro")."<br />
									Sexo:".$this->input->post("sexo")."<br />
									Data de Nascimento:".$this->input->post("dataNascimento")."<br />
									Estado Civil:".$this->input->post("estadoCivilsolteiro")."<br />
									<h1>Endere&ccedil;o</h1>
									Endere&ccedil;o:".$this->input->post("tipoEnderecorua")." ".$this->input->post("endereco")."<br
									Bairro :".$this->
									input->post("bairro")."<br />
									Cidade:".$this->input->post("cidade")."<br />
									UF:".$this->input->post("estado")."<br />
									CEP:".$this->input->post("cep")."<br />
									<h1>Contato</h1>
									Tel Resid&ecirc;ncial:".$this->input->post("telefoneResidencial")."<br />
									Cel:".$this->input->post("celular")."<br />
									Tel Recado:".$this->input->post("telefoneRecado")."<br />
									Falar Com:".$this->input->post("falarCom")."<br />
									Email:".$this->input->post("email")."<br />
									<h1>Documenta&ccedil;&atilde;o</h1>
									RG:".$this->input->post("rg")."<br />
									CPF:".$this->input->post("cpf")."<br />
									PIS:".$this->input->post("pis")."<br />
									Carteira de Trabalho:".$this->input->post("carteiraTrabalho")."<br />
									S&eacute;rie:".$this->input->post("serieCarteiraTrabalho")."<br />
									CNES:".$this->input->post("CNES")."<br />
									Licen&ccedil;a Sanit&aacute;ria:".$this->input->post("licencaSanitaria")."<br />
									Alvar&aacute;:".$this->input->post("alvara")."<br />
									<h1>Especialidades</h1>".$_POST["tabelaEspecialidade"]."<br />
									<h1>EndereÃ§o Comercial</h1>".$_POST["tabelaComercial"]."<br />
									<h1>AperfeiÃ§oamento</h1>".$_POST["tabelaAperfeicoamento"]."<br />
									<h1>EspecializaÃ§Ã£o</h1>".$_POST["tabelaEspecializacao"]."<br />
									<h1>Palestras</h1>".$_POST["tabelaPalestra"]."<br />
									<h1>IndicaÃ§Ã£o</h1>
									Algu&eacute;mm da Uniodonto est&aacute; lhe indicando? Quem?:".$this->input->post("indicacaoUniodonto")."<br />


					";
					if($_FILES["fotoAnexo1"] ){		
						$config['upload_path'] = "./upload/outros/";
						$field_name = "fotoAnexo1";
						$config['allowed_types'] = 'gif|jpg|png';
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '100000';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$dados["anexo"][] = $dados_upload['full_path'];
						}
					if($_FILES["fotoAnexo2"]){		
						$config['upload_path'] = "./upload/outros/";
						$field_name = "fotoAnexo2";
						$config['allowed_types'] = 'gif|jpg|png';
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '100000';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$dados["anexo"][] = $dados_upload['full_path'];
						}
					if($_FILES["curriculum"]){		
						$config['upload_path'] = "./upload/outros/";
						$field_name = "curriculum";
						$config['allowed_types'] = 'docx|doc|pdf';
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '100000';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$dados["anexo"][] = $dados_upload['full_path'];
						}
					$return = $this->envia($dados);
					$this->data['msg'] = $return;
					
					
				}else{
					
					//Volta para a pÃ¡gina de contato
					$this->data['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');					
					}


				
				
			}
			
			$this->load->view('trabalheconoscodentista_view',$this->data);
			

		}
			
	function trabalheconoscocolaborador(){
			if($_POST){
				$this->form_validation->set_rules("nome","nome", 'required');
				$this->form_validation->set_rules("dataNascimento","dataNascimento", 'required');
				$this->form_validation->set_rules("tipoEndereco","tipoEndereco", 'required');
				$this->form_validation->set_rules("endereco","endereco", 'required');
				$this->form_validation->set_rules("bairro","bairro", 'required');
				$this->form_validation->set_rules("cidade","cidade", 'required');
				$this->form_validation->set_rules("estado","estado", 'required');
				$this->form_validation->set_rules("cep","cep", 'required');
				$this->form_validation->set_rules("telefoneResidencial","telefoneResidencial", 'required');
				$this->form_validation->set_rules("celular","celular", 'required');
				$this->form_validation->set_rules("telefoneRecado","telefoneRecado", 'required');
				$this->form_validation->set_rules("falarCom","falarCom", 'required');
				$this->form_validation->set_rules("email","email", 'email|required');
				$this->form_validation->set_rules("rg","rg", 'required');
				$this->form_validation->set_rules("cpf","cpf", 'required');
				$this->form_validation->set_rules("pis","pis", 'required');
				$this->form_validation->set_rules("carteiraTrabalho","carteiraTrabalho", 'required');
				$this->form_validation->set_rules("serieCarteiraTrabalho","serieCarteiraTrabalho", 'required');
				$this->form_validation->set_rules("cnh","cnh", 'required');
				$this->form_validation->set_rules("nivelEscolaridade","nivelEscolaridade", 'required');
				$this->form_validation->set_rules("cursoFormacao","cursoFormacao", 'required');
				$this->form_validation->set_rules("escolaInstituicao","escolaInstituicao", 'required');
				$this->form_validation->set_rules("anoConclusao","anoConclusao", 'required');
				$this->form_validation->set_rules("outrosCursos","outrosCursos", 'required');
				$this->form_validation->set_rules("palestrasTreinamentos","palestrasTreinamentos", 'required');
				$this->form_validation->set_rules("nomeUltimaEmpresa","nomeUltimaEmpresa", 'required');
				$this->form_validation->set_rules("ramoUltimaEmpresa","ramoUltimaEmpresa", 'required');
				$this->form_validation->set_rules("telefoneUltimaEmpresa","telefoneUltimaEmpresa", 'required');
				$this->form_validation->set_rules("dataAdmissaoUltimaEmpresa","dataAdmissaoUltimaEmpresa", 'required');
				$this->form_validation->set_rules("funcaoUltimaEmpresa","funcaoUltimaEmpresa", 'required');
				$this->form_validation->set_rules("salarioUltimaEmpresa","salarioUltimaEmpresa", 'required');
				$this->form_validation->set_rules("tarefasUltimaEmpresa","tarefasUltimaEmpresa", 'required');
				$this->form_validation->set_rules("departamento","departamento", 'required');
				$this->form_validation->set_rules("salarioPretendido","salarioPretendido", 'required');

				
				if($this->form_validation->run()){
					$dados['nome'] = $this->input->post("nome");
					$dados['email'] = $this->input->post("email");
					$dados["titulo"] = "Fomul&aacute;rio Trabalhe Conosco - Colaborador";
					$dados["emailto"] = "kettlin.anjos@uniodontocuritiba.com.br";
					$dados["texto"] = "
							<h1>Candidato</h1>
							Nome: ".$this->input->post("nome")."<br />
							Sexo: ".$this->input->post("sexo")."<br />
							Data de Nascimento: ".$this->input->post("dataNascimento")."<br />
							Estado Civil: ".$this->input->post("estadoCivil")."<br />
							<h1>Endere&ccedil;o</h1>
							Endereco: ".$this->input->post("tipoEndereco")." ".$this->input->post("endereco")."<br />
							Bairro: ".$this->input->post("bairro")."<br />
							Cidade: ".$this->input->post("cidade")."<br />
							Estado: ".$this->input->post("estado")."<br />
							CEP: ".$this->input->post("cep")."<br />
							<h1>Contato</h1>
							Telefone Resid&ecirc;ncial: ".$this->input->post("telefoneResidencial")."<br />
							Celular: ".$this->input->post("celular")."<br />
							Telefone Recado: ".$this->input->post("telefoneRecado")."<br />
							Falar Com: ".$this->input->post("falarCom")."<br />
							Email: ".$this->input->post("email")."<br />
							<h1>Documenta&ccedil;&atilde;o</h1>
							RG: ".$this->input->post("rg")."<br />
							CPF: ".$this->input->post("cpf")."<br />
							PIS: ".$this->input->post("pis")."<br />
							Carteira de Trabalho: ".$this->input->post("carteiraTrabalho")."
							SÃ©rie: ".$this->input->post("serieCarteiraTrabalho")."<br />
							CNH: ".$this->input->post("cnh")."<br />
							<h1>Escolaridade</h1>
							Escolaridade: ".$this->input->post("nivelEscolaridade")."<br />
							Curso de Forma&ccedil;&atilde;o: ".$this->input->post("cursoFormacao")."<br />
							Institui&ccedil;&atilde;o: ".$this->input->post("escolaInstituicao")."<br />
							Ano de Conclus&atilde;o: ".$this->input->post("anoConclusao")."<br />
							Outros Cursos: ".$this->input->post("outrosCursos")."<br />
							Palestras e Treinamentos: ".$this->input->post("palestrasTreinamentos")."<br />
							<h1>&Uacute;ltima Empresa</h1>
							Nome: ".$this->input->post("nomeUltimaEmpresa")."<br />
							Ramo: ".$this->input->post("ramoUltimaEmpresa")."<br />
							Telefone: ".$this->input->post("telefoneUltimaEmpresa")."<br />
							Data Admiss&atilde;o: ".$this->input->post("dataAdmissaoUltimaEmpresa")."<br />
							Data Demiss&atilde;o: ".$this->input->post("dataDemissaoUltimaEmpresa")."<br />
							Fun&ccedil;&atilde;o: ".$this->input->post("funcaoUltimaEmpresa")."<br />
							Sal&aacute;rio: ".$this->input->post("salarioUltimaEmpresa")."<br />
							Tarefas:<br />".$this->input->post("tarefasUltimaEmpresa")."<br />
							<h1>Pen&uacute;ltima Empresa</h1>
							Nome: ".$this->input->post("nomePenultimaEmpresa")."<br />
							Ramo: ".$this->input->post("ramoPenultimaEmpresa")."<br />
							Telefone: ".$this->input->post("telefonePenultimaEmpresa")."<br />
							Data Admiss&atilde;o: ".$this->input->post("dataAdmissaoPenultimaEmpresa")."<br />
							Data Demiss&atilde;o: ".$this->input->post("dataDemissaoPenultimaEmpresa")."<br />
							Fun&ccedil;&atilde;o: ".$this->input->post("funcaoPenultimaEmpresa")."<br />
							Sal&aacute;rio: ".$this->input->post("salarioPenultimaEmpresa")."<br />
							Tarefas:<br />".$this->input->post("tarefasPenultimaEmpresa")."<br />
							<h1>Antepen&uacute;ltima Empresa</h1>
							Nome: ".$this->input->post("nomeAntePenultimaEmpresa")."<br />
							Ramo: ".$this->input->post("ramoAntePenultimaEmpresa")."<br />
							Telefone: ".$this->input->post("telefoneAntePenultimaEmpresa")."<br />
							Data Admiss&atilde;o: ".$this->input->post("dataAdmissaoAntePenultimaEmpresa")."<br />
							Data Demiss&atilde;o: ".$this->input->post("dataDemissaoAntePenultimaEmpresa")."<br />
							Fun&ccedil;&atilde;o: ".$this->input->post("funcaoAntePenultimaEmpresa")."<br />
							Sal&aacute;rio: ".$this->input->post("salarioAntePenultimaEmpresa")."<br />
							Tarefas:<br />".$this->input->post("tarefasAntePenultimaEmpresa")."<br />
							<h1>Pretens&otilde;es</h1>
							Departamento: ".$this->input->post("departamento")."<br />
							Sal&aacute;rio: ".$this->input->post("salarioPretendido")."<br />
							Observa&ccedil;&otilde;es:<br />
							".$this->input->post("observacoesPretencoes")."<br />
							Possui defici&ecirc;ncia: ".$this->input->post("deficiencia")."<br />
							Defici&ecirc;ncia Obs:<br />
							".$this->input->post("deficienciaObs")."<br />
							Disponibilidade para trabalhar em outra cidade: ".$this->input->post("disponibilidadeOutraCidade")."<br />

					";
					if($_FILES["fotoAnexo"] ["error"] == 0 ){		
						$config['upload_path'] = "./upload/outros/";
						$field_name = "fotoAnexo";
						$config['allowed_types'] = 'gif|jpg|png';
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '100000';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$dados["anexo"] = array("1" => $dados_upload['full_path']);
						}
						
					$return = $this->envia($dados);
					$this->data['msg'] = $return;
				}else{
					//Volta para a pÃ¡gina de contato
					$this->data['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');					
					}
				}
				$this->load->view('trabalheconoscocolaborador_view',$this->data);
			
			}
	function video(){
			
			$this->load->view('video_view',$this->data);
			}

			
	function mapa(){
			$this->data['mapa'] = $_GET['mapa'];
			$this->load->view('mapa_view',$this->data);
		}

	
	function busca() {
		
		if($_POST){
			$busca = htmlentities($_POST['busca'], ENT_QUOTES, "UTF-8");
			#Carrega dados da busca
			$pesquisa['busca'] = $_POST['busca'];
			$pesquisa['noticia_home'] = 1;
			$pesquisa['noticia_status'] = 1;
			if($this->session->userdata("pagina")){
				$pesquisa["noticia_".$this->session->userdata("pagina")] = 1;
				}
			#Verifica qual aba esta liberada e adiciona na query
			if($this->session->userdata("pagina")){
			$pesquisa["noticia_".$this->session->userdata("pagina")] = 1;
			}
			#Coloca os dados da pesquisa na sessao					
			$this->session->set_userdata("pesquisa",$pesquisa);
			$this->data['titulo'] = $this->lang->line('e_necessario_preencher_todos_os_campos')." ".$busca;
				
			
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				//print_r($pesquisa);
				$this->data['titulo'] = $this->lang->line('e_necessario_preencher_todos_os_campos')." ".$pesquisa["busca"].'"';
			
			}
	
		
		$config['total_rows'] = $this->joins_model->count_pesquisa($pesquisa);
		$config['base_url'] = site_url() . 'busca/';
		$config['per_page'] = '15';
		$config['uri_segment'] = '2';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(2) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->joins_model->count_pesquisa($pesquisa);
		$this->data['busca'] = $this->joins_model->pesquisa($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('busca_view', $this->data);
        
    }	

	function revista(){
		if($this->login_model->logged_users()){
			$this->data['revistas'] = $this->revistas_model->get_revistas();	
			$this->load->view('revista_view', $this->data);
		}else{
			redirect(site_url());
			}
	}
	function ver_revista($id){
		if($this->login_model->logged_users()){	
			$revista = $this->data['revistas'] = $this->revistas_model->get_by_id($id);
					
			$file = "././".$revista->revista_pdf;
			
			$length = filesize($file);
			header("Content-type: application/pdf");
			header("Content-Disposition: inline; filename=".$file);
			header("Content-Length: ".$length);
			readfile ($file);

		}else{
			redirect(site_url());
			}

	}					
	
	
	
	function arquivos(){
		if(!$_GET or $_GET["p"] == "" or $_GET["a"] == ""){
			redirect(site_url());
			}
		$pasta = $_GET["p"];
		$arquivo = $_GET["a"];
		if($pasta == "files"){
				$info = get_file_info("./upload/files/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				
		}
		if($pasta == "dentista"){
			if($this->login_model->logged_users() and $pasta == $this->session->userdata("pagina")){
			
				
				$info = get_file_info("./upload/files/".$pasta."/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$pasta."/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				}else{
					redirect(site_url());
					}
		}
		
		if($pasta == "beneficiario"){
			if($this->login_model->logged_users() and $pasta == $this->session->userdata("pagina")){
			
				
				$info = get_file_info("./upload/files/".$pasta."/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$pasta."/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				}else{
					redirect(site_url());
					}
		}
		if($pasta == "empresa"){
			if($this->login_model->logged_users() and $pasta == $this->session->userdata("pagina")){
			
				
				$info = get_file_info("./upload/files/".$pasta."/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$pasta."/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				}else{
					redirect(site_url());
					}
		}
		if($pasta == "uniodonto"){
			if($this->login_model->logged_users() and $pasta == $this->session->userdata("pagina")){
			
				
				$info = get_file_info("./upload/files/".$pasta."/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$pasta."/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				}else{
					redirect(site_url());
					}
		}
		if($pasta == "representante"){
			if($pasta == $this->session->userdata("pagina") or "vendedor" == $this->session->userdata("pagina")){
			
				
				$info = get_file_info("./upload/files/".$pasta."/".$arquivo);
				$ext = get_mime_by_extension("./upload/files/".$pasta."/".$arquivo);

				header("Content-Type: ".$ext); // informa o tipo do arquivo ao navegador
			    header("Content-Length: ".$info['size']); // informa o tamanho do arquivo ao navegador
			    header("Content-Disposition: attachment; filename=".basename($info['server_path'])); // informa ao navegador que é tipo anexo e faz abrir a janela de download, tambem informa o nome do arquivo
			    readfile($info['server_path']); // lê o arquivo
			    exit; // aborta pós-ações


				}else{
					redirect(site_url());
					}
		}
			

	
	
	}
	
		
	function orcamento_empresa(){
		if ($this->captcha->create()) {
			$this->data['captcha'] = $this->captcha->html_data;
		} else {
			$this->data['captcha'] = 'Captcha : ' . $this->captcha->debug;
		}
		
		if($_POST){
		 $resposta['captcha'] = $this->data['captcha']['src'];
		 if ($this->captcha->check($this->input->post('captcha'))) {
			$this->form_validation->set_rules('empresa', 'empresa', 'required');	
			$this->form_validation->set_rules('email', 'email', 'required');
			$this->form_validation->set_rules('telefone', 'telefone', 'required');
			
			if($this->form_validation->run()){

				
				$dados["empresa"] = $this->input->post('empresa');
				$dados["email"] = $this->input->post('email');
				$dados["titulo"] = "Contato Site - Or�amento empresa";
				$dados["emailto"] = "sitevendas@uniodontocuritiba.com.br";
				$dados["texto"] = "
									Empresa: ".$this->input->post("empresa")."<br />
									Respons&aacute;vel: ".$this->input->post("responsavel")."<br />
									Email: ".$this->input->post("email")."<br />
									Telefone: ".$this->input->post("telefone")."<br />
									Endere&ccedil;o: ".$this->input->post("endereco")."<br />
									Cidade/Estado: ".$this->input->post("cidade")."<br />
									Qtd. Funcion&aacute;rios: ".$this->input->post("qtd_funcionarios")."<br />
																	
				
				";

				$return = $this->envia($dados);
				$resposta['msg'] = $return;
			}else{
				//Volta para a pÃ¡gina de contato
				$resposta['msg'] =  $this->lang->line('e_necessario_preencher_todos_os_campos');
				
									
				}
			print json_encode($resposta);	
		 }else{
			 $resposta['msg'] =  $this->lang->line('preencha_o_codigo_verificador_corretamente');
			 print json_encode($resposta);
			 }
		}else{
			$this->load->view('orcamentoempresa_view',$this->data);
			
			}
	}
	
	function contratar_plano(){
		if(isset($_POST['envia'])){
			$this->form_validation->set_rules("nome", "nome", "required"); 
			$this->form_validation->set_rules("sexo", "sexo", "required"); 
			$this->form_validation->set_rules("dataNascimento", "dataNascimento", "required"); 
			$this->form_validation->set_rules("estadoCivil", "estadoCivil", "required"); 
			$this->form_validation->set_rules("tipoEndereco", "tipoEndereco", "required"); 
			$this->form_validation->set_rules("endereco", "endereco", "required"); 
			$this->form_validation->set_rules("bairro", "bairro", "required"); 
			$this->form_validation->set_rules("cidade", "cidade", "required"); 
			$this->form_validation->set_rules("estado", "estado", "required"); 
			$this->form_validation->set_rules("cep", "cep", "required"); 
			$this->form_validation->set_rules("telefoneResidencial", "telefoneResidencial", "required"); 
			$this->form_validation->set_rules("celular", "celular", "required"); 
			$this->form_validation->set_rules("telefoneRecado", "telefoneRecado", "required"); 
			$this->form_validation->set_rules("falarCom", "falarCom", "required"); 
			$this->form_validation->set_rules("email", "email", "required|valid_email"); 
			$this->form_validation->set_rules("rg", "rg", "required"); 
			$this->form_validation->set_rules("orgao-rg", "orgao-rg", "required"); 
			$this->form_validation->set_rules("data-rg", "data-rg", "required"); 
			$this->form_validation->set_rules("cpf", "cpf", "required"); 
			$this->form_validation->set_rules("nivelEscolaridade", "nivelEscolaridade", "required"); 
			$this->form_validation->set_rules("nome-mae", "nome-mae", "required"); 
			$this->form_validation->set_rules("empresa-comercial", "empresa-comercial", "required"); 
			$this->form_validation->set_rules("autonomo", "autonomo", "required"); 
			$this->form_validation->set_rules("tipoEndereco-comercial", "tipoEndereco-comercial", "required"); 
			$this->form_validation->set_rules("endereco-comercial", "endereco-comercial", "required"); 
			$this->form_validation->set_rules("bairro-comercial", "bairro-comercial", "required"); 
			$this->form_validation->set_rules("cidade-comercial", "cidade-comercial", "required"); 
			$this->form_validation->set_rules("estado-comercial", "estado-comercial", "required"); 
			$this->form_validation->set_rules("cep-comercial", "cep-comercial", "required"); 
			$this->form_validation->set_rules("telefone-comercial", "telefone-comercial", "required"); 
			$this->form_validation->set_rules("cargo-comercial", "cargo-comercial", "required"); 
			$this->form_validation->set_rules("renda-comercial", "renda-comercial", "required"); 
			$this->form_validation->set_rules("vinculo-comercial", "vinculo-comercial", "required"); 
			if($this->form_validation->run()){
					$dados['nome'] = $this->input->post("nome");
					$dados['email'] = $this->input->post("email");
					$dados["titulo"] = "Contato Site - Contratar Plano";
					$dados["emailto"] = "sitevendas@uniodontocuritiba.com.br";
					$dados["texto"] = "
							<h1>Contratar Plano ".$this->input->post("nome_plano")."</h1>
							<h1>Dados Pessoais do titular do contrato</h1>
							Nome:".$this->input->post("nome")."<br />
							Sexo:".$this->input->post("sexo")."<br />
							Data de Nascimento:".$this->input->post("dataNascimento")."<br />
							Estado Civil:".$this->input->post("estadoCivil")."<br />
							<h1>Endere&ccedil;o</h1>
							".$this->input->post("tipoEndereco")." ".$this->input->post("endereco")."<br />
							Bairro:".$this->input->post("bairro")."<br />
							Cidade:".$this->input->post("cidade")."<br />
							Estado:".$this->input->post("estado")."<br />
							CEP:".$this->input->post("cep")."<br />
							Telefone Residencial:".$this->input->post("telefoneResidencial")."<br />
							Celular:".$this->input->post("celular")."<br />
							Telefone de Recado:".$this->input->post("telefoneRecado")."<br />
							Falar Com:".$this->input->post("falarCom")."<br />
							Email:".$this->input->post("email")."<br />
							<h1>Documenta&ccedil;&atilde;o</h1>
							RG:".$this->input->post("rg")."<br />
							Org&atilde;o Expedidor:".$this->input->post("orgao-rg")."<br />
							Data expedi&ccedil;&atilde;o RG:".$this->input->post("data-rg")."<br />
							CPF:".$this->input->post("cpf")."<br />
							<h1>Escolaridade</h1>
							N&iacute;vel:".$this->input->post("nivelEscolaridade")."<br />
							<h1>Nome completo da m&atilde;e do titular do contrato</h1>
							Nome:".$this->input->post("nome-mae")."<br />
							<h1>Dados Comerciais do Titular Respons&aacute;vel</h1>
							Empresa:".$this->input->post("empresa-comercial")."<br />
							Aut&ocirc;nomo:".$this->input->post("autonomo")."<br />
							Endere&ccedil;o:".$this->input->post("tipoEndereco-comercial")." ".$this->input->post("endereco-comercial")."<br />
							Bairro:".$this->input->post("bairro-comercial")."<br />
							Cidade:".$this->input->post("cidade-comercial")."<br />
							Estado:".$this->input->post("estado-comercial")."<br />
							CEP:".$this->input->post("cep-comercial")."<br />
							Telefone:".$this->input->post("telefone-comercial")."<br />
							Cargo:".$this->input->post("cargo-comercial")."<br />
							Renda Familiar:".$this->input->post("renda-comercial")."<br />
							V&iacute;nculo Empregat&iacute;cio:".$this->input->post("vinculo-comercial")."<br />
					
					
					";	
					for ($i = 1; $i <= $this->input->post("plano_qtd"); $i++){
					
					$dados["texto"] .= "
							<h1>Dependente ".$i."</h1>
							Nome:".$this->input->post("dependente".$i."_nome")."<br />
							Data de nascimento:".$this->input->post("dependente".$i."_data_nascimento")."<br />
							CPF:".$this->input->post("dependente".$i."_cpf")."<br />
							RG:".$this->input->post("dependente".$i."_rg")."<br />
							Org&atilde;o Expedidor:".$this->input->post("dependente".$i."_orgao_expedidor")."<br />
							Data expedi&ccedil;&atilde;o RG:".$this->input->post("dependente".$i."_data_expedicao")."<br />
							Estado Civil:".$this->input->post("dependente".$i."_estado_civil")."<br />
							Grau Parentesco:".$this->input->post("dependente".$i."_parentesco")."<br />
							Sexo:".$this->input->post("dependente".$i."_sexo")."<br />
							Nome da m&atilde;e:".$this->input->post("dependente".$i."_mae")."<br />";
					}
			}
				$return = $this->envia($dados);
				$this->data['msg'] = $return;
				$this->data["nome_plano"] = $this->input->post('nome_plano');
				$this->data["valor_por_pessoa"] = $this->input->post('valor_por_pessoa');
				$this->data["valor_total"] = $this->input->post('valor_total');
				$this->data["plano_qtd"] = $this->input->post('plano_qtd');
				$this->data["plano_tipo"] = $this->input->post('plano_tipo');
			}else{
				$this->data["plano_tipo"] = $this->input->post('plano_tipo');
				$this->data["plano_pagamento"] = $this->input->post('plano_pagamento');
				$this->data["plano_modalidade"] = $this->input->post('plano_modalidade');
				$this->data["plano_qtd"] = $this->input->post('plano_qtd');
				if($this->data["plano_tipo"] == 1){
					$this->data["nome_plano"] = $this->lang->line('superior');
										
					}
				if($this->data["plano_tipo"] == 2){
					$this->data["nome_plano"] = $this->lang->line('avancado');
					}	
					
				$dados_query = array(
					"plano_tipo" => $this->data["plano_tipo"],
					"plano_pagamento" => $this->data["plano_pagamento"],
					"plano_modalidade" => $this->data["plano_modalidade"],
					"plano_qtd" => $this->data["plano_qtd"]
				);
				$plano = ($this->planos_model->pesquisa_planos($dados_query));
				$this->data['valor_por_pessoa'] = number_format($plano[0]->plano_preco, 2, '.', ',');	
				$this->data['valor_total'] = number_format($plano[0]->plano_qtd * ($plano[0]->plano_preco), 2, '.', ',');

			}
				
		
		
		$this->load->view('contratarplano_view',$this->data);
		


	}
	
	function tabeladeatos($pag = ""){
		
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){

			if($pag == ""){
				$this->load->view("tabeladeatos1_view",$this->data);
				}
			
			if($pag == 1){
				$this->load->view("tabeladeatos1_view",$this->data);
				}
			if($pag == 2){
				$this->load->view("tabeladeatos2_view",$this->data);
				}
			if($pag == 3){
				$this->load->view("tabeladeatos3_view",$this->data);
				}
			if($pag == 4){
				$this->load->view("tabeladeatos4_view",$this->data);
				}
			if($pag == 5){
				$this->load->view("tabeladeatos5_view",$this->data);
				}		
			

			}else{
				redirect(site_url());
				}
		}
	function tabeladeatos2013($pag = ""){
		
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){

			if($pag == ""){
				$this->load->view("tabeladeatos2013-1_view",$this->data);
				}
			
			if($pag == 1){
				$this->load->view("tabeladeatos2013-1_view",$this->data);
				}
			if($pag == 2){
				$this->load->view("tabeladeatos2013-2_view",$this->data);
				}
			if($pag == 3){
				$this->load->view("tabeladeatos2013-3_view",$this->data);
				}
			if($pag == 4){
				$this->load->view("tabeladeatos2013-4_view",$this->data);
				}
			if($pag == 5){
				$this->load->view("tabeladeatos2013-5_view",$this->data);
				}		
			

			}else{
				redirect(site_url());
				}
		}
	function sustentabilidade(){
		$this->load->view("sustentabilidade_view",$this->data);
		
		
		}
	function sitemap(){
		$this->data["noticias"] = $this->noticias_model->get_noticias_sitemap();

        $this->load->view("sitemap_view",$this->data);
    }
	
	function naoencontrada(){
		$this->load->view("paginanaoencontrada_view",$this->data);
    }
	
	function clientes(){
		$this->load->view("clientes_view",$this->data);
    }	
	
	
	
	
	function beneficios($pag){
		
		if($this->login_model->logged_users() and "dentista" == $this->session->userdata("pagina")){
			if($pag == ""){
				redirect(site_url());
				}
			
			if($pag == 1){
				$this->load->view("beneficio_cavo_view",$this->data);
				}
			if($pag == 2){
				$this->load->view("beneficio_nissei_view",$this->data);
				}
			if($pag == 3){
				$this->load->view("beneficio_unimed_view",$this->data);
				}
						
			
			}else{
				redirect(site_url());
				}
		}
	
	function gerarproposta(){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			
			$this->load->view("prospect/gerar_proposta_view",$this->data);

		}else{
			redirect(site_url());
			}
    }	
	
	function contratospropostas(){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			$this->load->view("prospect/contratos_proposta_view",$this->data);
		}else{
			redirect(site_url());
			}
    }
	
	function verpropostas(){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			
		if($_POST){
			if($_POST['proposta_n'] != ""){
				$pesquisa['proposta_n'] = $_POST['proposta_n'];
				}
			if($_POST['datade'] != ""){
				$datade = explode("/",$_POST['datade']);
				$pesquisa['datade'] = $datade[2]."-".$datade[1]."-".$datade[0];
				}
			if($_POST['dataate'] != ""){
				$dataate = explode("/",$_POST['dataate']);
				$pesquisa['dataate'] = $dataate[2]."-".$dataate[1]."-".$dataate[0];
				}	
			if($_POST['empresa'] != ""){
				$pesquisa['proposta_empresa'] = $_POST['empresa'];
				}
			if($_POST['cnpj'] != ""){
				$pesquisa['proposta_cnpj'] = $_POST['cnpj'];
				}
			if($_POST['email'] != ""){
				$pesquisa['proposta_email'] = $_POST['email'];
				}
			if($_POST['cidade'] != ""){
				$pesquisa['proposta_cidade'] = $_POST['cidade'];
				}
			if($_POST['uf'] != ""){
				$pesquisa['proposta_uf'] = $_POST['uf'];
				}

			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			if($this->session->userdata("representante") == 1){ 
				$pesquisa['proposta_cod_consultor'] = $this->session->userdata('codigo');	
			}else{
				$pesquisa['proposta_cod_rep'] = $this->session->userdata('codigo');	
				}
			
		$config['total_rows'] = $this->proposta_model->count_propostas($pesquisa);
		$config['base_url'] = site_url() . 'verpropostas/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '2';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(2) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->proposta_model->count_propostas($pesquisa);
		$this->data['propostas'] = $this->proposta_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view("prospect/ver_propostas_view",$this->data);
		}else{
			redirect(site_url());
			}
    }
	
	function limpar_pesquisa(){
		
		$this->session->unset_userdata('pesquisa');
		redirect('verpropostas/1','refresh');
		}
	function materialgraficopropostas(){
		$this->load->view("prospect/material_grafico_view",$this->data);
		}
	function consultacnpj(){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			$cnpj = $_POST['cnpj'];
			$cnpj_limpo = preg_replace("/[^a-zA-Z0-9\s]/", "", $cnpj);
			$cadastro_cnpj = json_decode(file_get_contents( "http://sio.uniodontocuritiba.com.br/Uniodonto/BuscaDadosEmpresaSiteServlet?cnpj=".$cnpj_limpo));
			if($cadastro_cnpj->qntEmpresasAtivas == "0"){
				
				if($this->proposta_model->get_by_cnpj($cnpj) != 0){
					print $this->lang->line('empresa_reservada_consulte_o_departamento_comercial');
					}else{
						print 0;
						}
				}else{
					if($cadastro_cnpj->qntEmpresasDesativadas != "0"){
						print $this->lang->line('empresa_inativada_no_sistema_uniodonto_entre_em_contato_com_o_comercial');
						}else{
							print $this->lang->line('esta_empresa_ja_e_cliente_uniodonto');
						}
					}
			}else{
				redirect(site_url());
			}
		}	
	function novaproposta() {
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
		if($_POST){
			
			$this->form_validation->set_rules('nome', 'nome', 'required');
			$this->form_validation->set_rules('cnpj', 'cnpj', 'required');	
			$this->form_validation->set_rules('tel', 'tel', 'required');	
			$this->form_validation->set_rules('email', 'email', 'required|valid_email');
			$this->form_validation->set_rules('qtd', 'qtd', 'required');	
			$this->form_validation->set_rules('adesao', 'adesao', 'required');	
			$this->form_validation->set_rules('cidade', 'cidade', 'required');	

			
			
			if($this->form_validation->run()){
				
					if($this->proposta_model->get_by_cnpj($this->input->post("cnpj")) == 0){
					
						$cadastro_vendedor = json_decode(file_get_contents( "http://sio.uniodontocuritiba.com.br/Uniodonto/BuscaDadosRepresentanteVendedorSiteServlet?codigo=".$this->input->post('codvendedor')."&tipo=vendedor".$cnpj));
					
						$plano = $this->proposta_planos_model->get_plano($this->input->post("qtd"),$this->input->post('plano'));
						$data["proposta_cod_rep"] = $cadastro_vendedor->codigoRepresentanteVendedor;
						$data["proposta_nome_rep"] = $cadastro_vendedor->nomeRepresentanteVendedor;
						$data["proposta_cod_consultor"] = $this->input->post('codvendedor');
						$data["proposta_nome_consultor"] = $cadastro_vendedor->nomeVendedor;
						$data["proposta_email_consultor"] = $cadastro_vendedor->email;
						$data["proposta_data"] = date("Y-m-d");
						$data["proposta_validade"] = date("Y-m-d", strtotime("+90 days"));
						$data["proposta_validade_contrato"] = date("Y-m-d", strtotime("+30 days"));
						$data["proposta_empresa"] = $this->input->post('nome');
						$data["proposta_cnpj"] = $this->input->post('cnpj');
						$data["proposta_contato"] = $this->input->post('contato');
						$data["proposta_tel"] = $this->input->post('tel');
						$data["proposta_email"] = $this->input->post('email');
						$data["proposta_qtd_vidas"] = $this->input->post('qtd');
						$data["proposta_adesao"] = $this->input->post('adesao');
						$data["proposta_carencia"] = $this->input->post('carencia');
						$data["proposta_cidade"] = ucfirst($this->input->post('cidade'));
						$data["proposta_uf"] = $this->input->post('uf');
						$data["proposta_plano"] = $plano[0]->plano_nome;
						$data["proposta_valor_beneficiario"] = $plano[0]->plano_valor;
						$data["id_proposta"] = str_pad($this->proposta_model->add_record($data), 11, "0", STR_PAD_LEFT);
						$proposta = $this->proposta_model->get_by_id($data["id_proposta"]);
						$query["proposta_id"] = $data["id_proposta"];
						$query["proposta_n"] = $proposta->proposta_cod_rep.".".$proposta->proposta_cod_consultor.".".$proposta->proposta_id;
						$this->proposta_model->update_record($query);
						
						redirect(site_url("verpropostas/1"));
						}else{
							$this->data['msg'] = $this->lang->line('ja_existe_uma_proposta_ativa_para_esta_empresa');
						}
				
				}else{
					$this->data['msg'] = $this->lang->line('preencha_todos_os_campos_antes_de_gerar_a_proposta');
					}
				
			}
			$this->load->view('prospect/form_proposta_view',$this->data);
		}else{
			redirect(site_url());
			}
    }
	function baixarproposta($id){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
						$proposta = $this->proposta_model->get_by_id($id);
						$data["proposta_n"] = $proposta->proposta_n;
						$data["proposta_cod_rep"] = $proposta->proposta_cod_rep;
						$data["proposta_nome_rep"] = $proposta->proposta_nome_rep;
						$data["proposta_cod_consultor"] = $proposta->proposta_cod_consultor;
						$data["proposta_nome_consultor"] = $proposta->proposta_nome_consultor;
						$data["proposta_email_consultor"] = $proposta->proposta_email_consultor;
						$data["proposta_data"] = $proposta->proposta_data;
						$data["proposta_validade"] = $proposta->proposta_validade;
						$data["proposta_validade_contrato"] = $proposta->proposta_validade_contrato;
						$data["proposta_empresa"] = $proposta->proposta_empresa;
						$data["proposta_cnpj"] = $proposta->proposta_cnpj;
						$data["proposta_contato"] = $proposta->proposta_contato;
						$data["proposta_tel"] = $proposta->proposta_tel;
						$data["proposta_email"] = $proposta->proposta_email;
						$data["proposta_qtd_vidas"] = $proposta->proposta_qtd_vidas;
						$data["proposta_adesao"] = $proposta->proposta_adesao;
						$data["proposta_carencia"] = $proposta->proposta_carencia;
						$data["proposta_cidade"] = $proposta->proposta_cidade;
						$data["proposta_uf"] = $proposta->proposta_uf;
						$data["proposta_plano"] = $proposta->proposta_plano;
						$data["proposta_valor_beneficiario"] = $proposta->proposta_valor_beneficiario;
						$data["id_proposta"] = $id;
						
						
						$this->load->library('mpdf');
						
						$html_topo ="<img src='".site_url()."images/pdf/bg-topo.jpg'>";
						$html_bottom ="<img src='".site_url()."images/pdf/bg-bottom.jpg'>";
						$html = $this->load->view('prospect/proposta_view',$data, TRUE);
						
						
						$mpdf=new mPDF('c','A4','12','Arial' , 0 , 0 , 15 , 15 , 0 , 0);
			
						$mpdf->SetDisplayMode('fullpage');
			
						$mpdf->list_indent_first_level = 0;
						//$mpdf->StartProgressBarOutput(1);
						$mpdf->SetHTMLHeader ($html_topo);
						$mpdf->SetHTMLFooter ($html_bottom);
						$mpdf->WriteHTML($html);
						
						print $mpdf->Output('proposta-'.$data["proposta_n"].'.pdf', "D");
						exit;
		}else{
			redirect(site_url());
			}
    }
	function enviarproposta($id){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
						$proposta = $this->proposta_model->get_by_id($id);
						$data["proposta_n"] = $proposta->proposta_n;
						$data["proposta_cod_rep"] = $proposta->proposta_cod_rep;
						$data["proposta_nome_rep"] = $proposta->proposta_nome_rep;
						$data["proposta_cod_consultor"] = $proposta->proposta_cod_consultor;
						$data["proposta_email_consultor"] = $proposta->proposta_email_consultor;
						$data["proposta_nome_consultor"] = $proposta->proposta_nome_consultor;
						$data["proposta_data"] = $proposta->proposta_data;
						$data["proposta_validade"] = $proposta->proposta_validade;
						$data["proposta_validade_contrato"] = $proposta->proposta_validade_contrato;
						$data["proposta_empresa"] = $proposta->proposta_empresa;
						$data["proposta_cnpj"] = $proposta->proposta_cnpj;
						$data["proposta_contato"] = $proposta->proposta_contato;
						$data["proposta_tel"] = $proposta->proposta_tel;
						$data["proposta_email"] = $proposta->proposta_email;
						$data["proposta_qtd_vidas"] = $proposta->proposta_qtd_vidas;
						$data["proposta_adesao"] = $proposta->proposta_adesao;
						$data["proposta_carencia"] = $proposta->proposta_carencia;
						$data["proposta_cidade"] = $proposta->proposta_cidade;
						$data["proposta_uf"] = $proposta->proposta_uf;
						$data["proposta_plano"] = $proposta->proposta_plano;
						$data["proposta_valor_beneficiario"] = $proposta->proposta_valor_beneficiario;
						$data["id_proposta"] = $id;
						
						$this->load->library('mpdf');
						
						$html_topo ="<img src='".site_url()."images/pdf/bg-topo.jpg'>";
						$html_bottom ="<img src='".site_url()."images/pdf/bg-bottom.jpg'>";
						$html = $this->load->view('proposta_view',$data, TRUE);
						
						
						$mpdf=new mPDF('c','A4','12','Arial' , 0 , 0 , 15 , 15 , 0 , 0);
			
						$mpdf->SetDisplayMode('fullpage');
			
						$mpdf->list_indent_first_level = 0;
						//$mpdf->StartProgressBarOutput(1);
						$mpdf->SetHTMLHeader ($html_topo);
						$mpdf->SetHTMLFooter ($html_bottom);
						$mpdf->WriteHTML($html);
						
						$mpdf->Output('tmp/proposta/proposta-'.$data["proposta_n"].'.pdf', "F");
											
						
						
						$dados['nome'] = $data["proposta_nome_rep"];
						$dados['email'] = $data["proposta_email_consultor"];
						$dados["titulo"] = "Proposta Uniodonto Curitiba";
						$dados["emailto"] = $data["proposta_email"];
						$dados["emailbcc"] = $data["proposta_email_consultor"];
						$dados["texto"] = "<h1>Prezado(a) ".$data["proposta_contato"].",</h1>
							Conforme sua solicita&ccedil;&atilde;o, segue anexo a este e-mail a Proposta de Ades&atilde;o ao Plano.<br /><br /><br />Atenciosamente,<br />".$data["proposta_nome_consultor"];
					
						$dados["anexo"] = array("1" => 'tmp/proposta/proposta-'.$data["proposta_n"].'.pdf');
						
						
						print $this->envia($dados);
						exit;
		}else{
			redirect(site_url());
			}
    }
	
	function emailproposta(){
		if($this->login_model->logged_users() and "representante" == $this->session->userdata("pagina")){
			if($_POST){
				$this->form_validation->set_rules('nome', 'nome', 'required');
				$this->form_validation->set_rules('emailto', 'emailto', 'required|valid_email');
					
				if($this->form_validation->run()){
					$dados["nome"] = $this->input->post('nome');
					$dados["email"] = $this->input->post('emailde');;
					$dados["titulo"] = "Uniodonto Curitiba";
					$dados["emailto"] = $this->input->post('emailto');
					$dados["emailbcc"] = $this->input->post('emailde');;
					$dados["texto"] = $this->load->view('prospect/email_propostas_view',$dados,TRUE);
					$return = $this->envia($dados);
					$resposta['msg'] =  $return;
				}else{
					//Volta para a pÃ¡gina de contato
					$resposta['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');
														
					}
				print json_encode($resposta);
	
			}else{
				$this->load->view('prospect/envia_email_proposta_view',$this->data);
				
				}
		
		}else{
			redirect(site_url());
			}
				
		}
	function dadosemailproposta($email){
			if($_POST){
				$this->form_validation->set_rules('nome', 'nome', 'required');
				$this->form_validation->set_rules('emailto', 'emailto', 'required|valid_email');
					
				if($this->form_validation->run()){
					$dados["nome"] = $this->input->post('nome');
					$dados["email"] = $this->input->post('email');
					$dados["titulo"] = "Retorno email proposta";
					$dados["emailto"] = $this->input->post('emailto');
					$dados["texto"] = "
									CNPJ: ".$this->input->post("cnpj")."<br />
									Empresa: ".$this->input->post("nome")."<br />
									Pessoa de contato: ".$this->input->post("contato")."<br />
									Email: ".$this->input->post("email")."<br />
									Telefone: ".$this->input->post("tel")."<br />
									Qtd. vidas: ".$this->input->post("qtd")."<br />
									Cidade/UF: ".$this->input->post("cidade")."/".$this->input->post("uf")."<br />";
					$return = $this->envia($dados);
					$resposta['msg'] =  $return;
				}else{
					//Volta para a pÃ¡gina de contato
					$resposta['msg'] = $this->lang->line('e_necessario_preencher_todos_os_campos');
														
					}
				print json_encode($resposta);
	
			}else{
				$data["emailto"] = $email;
				$this->load->view('prospect/form_dados_email_proposta_view', $data);
				
				}
				
			
			}
	
	
				
	 
}
