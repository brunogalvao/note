<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('cookie');
    }

    function index(){
        redirect(base_url().'admin/login/logar', 'refresh');
    }

  
    function sempermissao(){

        $this->load->view('admin/sempermissao_view');
    }

    function logar(){
        $this->load->view('admin/login_view');
    }

    function dologin(){
		// VALIDATION RULES
        $this->load->library('form_validation');
        $this->form_validation->set_rules('user_email', 'email', 'valid_email|required');
        $this->form_validation->set_rules('user_senha', 'senha', 'required');
        $this->form_validation->set_error_delimiters('<p class="error">', '</p>');

        if ($this->form_validation->run() == FALSE) {

            $this->load->view('admin/login_view');
        } else {
			$usuario = $this->input->post('user_email');
			$senha = $this->input->post('user_senha');
	
			if($usuario=="" || $this->input->post('user_senha')==""){
				redirect(base_url().'admin/login', 'refresh');
				exit();
			}
	
			if(isset($_POST['lembrar'])){           
				setcookie("user_nome", $usuario);
				setcookie("lembrar", "checked");
			}
	
			$sql = "SELECT user_id,user_nome,user_email
					FROM user
					WHERE user_email ='" . $usuario . "'
					AND user_senha ='" . $senha . "'";
	
			$query = $this->db->query($sql);
			$result = $query->result();
			if(count($result)<1){           
				redirect(base_url().'admin/login', 'refresh');
				exit();
			}
			else{
				$login = array(
						'user_id'   =>     $result[0]->user_id,
						'user_nome'      =>    $result[0]->user_nome,
						'user_email'     =>     $result[0]->user_email,
						'login_sistema'  =>  	FALSE,
						'logged_in' => TRUE,
						'data' => date("d/m/Y h:i:s")
				   );
	
				$this->session->set_userdata($login);
				redirect(base_url().'admin/home', 'refresh');
			}
		}
    }

    function logout()
    {
        $this->session->sess_destroy();
        $this->login();
    }   

}

