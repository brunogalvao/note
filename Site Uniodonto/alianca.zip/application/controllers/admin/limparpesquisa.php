<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class limparpesquisa extends CI_Controller {
    
    function __construct() {
        parent::__construct();
	
    }
    
    public function index($pagina) {
		$this->session->unset_userdata('pesquisa');
        redirect(site_url("admin/".$pagina),'refresh');
        
    }
}