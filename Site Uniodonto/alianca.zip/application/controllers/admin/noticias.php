<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Noticias extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			$pesquisa['noticia_titulo'] = htmlentities($this->input->post('pesquisa'), ENT_QUOTES, "UTF-8");
			$pesquisa['tipo'] = "normal";
			if($this->input->post('data-inicial') != ""){
				$data = explode("/",$this->input->post('data-inicial'));
				$pesquisa['data-inicial'] = $data[2].'-'.$data[1].'-'.$data[0]." 00:00:00";
				
				}
			if($this->input->post('data-final') != ""){
				$data = explode("/",$this->input->post('data-final'));
				$pesquisa['data-final'] = $data[2].'-'.$data[1].'-'.$data[0]." 23:59:99";
				
				}	
			
			if($this->input->post('aba') != ""){
				$pesquisa[$this->input->post('aba')] = 1;
				
				}
			if($this->input->post('status') != ""){
				$pesquisa['noticia_status'] = $this->input->post('status');
				
				}
			if($this->input->post('destaque') != ""){
				$pesquisa['noticia_destaque'] = $this->input->post('destaque');
				
				}		
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->noticias_model->count_noticias($pesquisa);
		$config['base_url'] = site_url() . 'admin/noticias/index/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->noticias_model->count_noticias($pesquisa);
		$this->data['noticias'] = $this->noticias_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/noticias_view', $this->data);
        
    }
	
	// funçăo adicionar noticia
	public function adicionar(){
		
	
		if($_POST){
			
		$this->form_validation->set_rules('noticia_titulo_ptBR', 'noticia_titulo_ptBR', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
			if($_FILES){
			//UPLOAD IMAGENS
			$pathToSave = './images/noticias/';

			$i = 0;
			$msg = array( );
			$arquivos = array( array( ) );
			foreach(  $_FILES as $key=>$info ) {
				foreach( $info as $key=>$dados ) {
					for( $i = 0; $i < sizeof( $dados ); $i++ ) {
						$arquivos[$i][$key] = $info[$key][$i];
					}
				}
			}

			$i = 0;

			
			foreach( $arquivos as $file ) {

				// Verificar se o campo do arquivo foi preenchido
				if( $file['name'] != '' ) {
					$arquivoTmp = $file['tmp_name'];
					$nome_arquivo = explode(".",$file['name']);
					
					$arquivo[$i] = $pathToSave.md5($nome_arquivo[0]).time().".".strtolower ($nome_arquivo[1]);
					

					if( !move_uploaded_file( $arquivoTmp, $arquivo[$i] ) ) {
						$msg[$i] = 'Erro no upload do arquivo '.$i;
					} else {
						$sizes = array();
						$sizes['small'] = array(170, 75);
						$sizes['medium'] = array(120, 120);
						$sizes['large'] = array(280, 210);
								
						$data = Batch_cropper::run($arquivo[$i], '././././images/noticias/', $sizes, 100);
					}
				} else {
					$msg[$i] = sprintf('O arquivo %d nao foi preenchido',$i);
				}
					

				$i++;
			}
			//adiciona as imagens na query
				if(isset($arquivo)){
					foreach($arquivo as $img){
						$img_final .= end(explode("/",$img)).";"; 
					}
				}
			}else{
				$img_final  = "";
			}
		//FIM UPLOAD IMAGENS
				$data = explode("/", $this->input->post("noticia_data"));
				$data = $data[2]."-".$data[1]."-".$data[0]." ".date("H:m:s"); 

				$dados_query = array(
					"noticia_id" => "",
					"noticia_titulo_ptBR" => htmlentities($this->input->post("noticia_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"noticia_titulo_en" => htmlentities($this->input->post("noticia_titulo_en"), ENT_QUOTES, "UTF-8"),
					"noticia_titulo_es" => htmlentities($this->input->post("noticia_titulo_es"), ENT_QUOTES, "UTF-8"),
					"noticia_data" => $data,
					"noticia_destaque" => $this->input->post("noticia_destaque"),
					"noticia_posicao" => $this->input->post("noticia_posicao"),
					"noticia_texto_ptBR" => $this->input->post("noticia_texto_ptBR"),
					"noticia_texto_en" => $this->input->post("noticia_texto_en"),
					"noticia_texto_es" => $this->input->post("noticia_texto_es"),
					"noticia_img_principal" => "",
					"noticia_status" => $this->input->post("noticia_status"),
					"noticia_home" => $this->input->post("noticia_home"),
					"noticia_beneficiario" => $this->input->post("noticia_beneficiario"),
					"noticia_empresa" => $this->input->post("noticia_empresa"),
					"noticia_dentista" => $this->input->post("noticia_dentista"),
					"noticia_uniodonto" => $this->input->post("noticia_uniodonto"),
					"noticia_colaborador" => $this->input->post("noticia_colaborador"),
					"noticia_representante" => $this->input->post("noticia_representante"),
					"noticia_imgs" => $img_final 

				);
				
				
				//cadastra noticia e recebe o id
				$id = $this->noticias_model->add_record($dados_query);
						
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Notícia cadastrada com sucesso!');					
				redirect('admin/noticias/','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a esta notícia!');
							redirect('admin/noticias/adicionar/','refresh');
							}
			}
		
		$this->load->view('admin/add_noticias_view');
		
		
		}
		

		//funçăo para excluir apenas imagem
		function exclui_img($id,$image){
		$noticia = $this->noticias_model->get_by_id($id);
		$noticia_imgs = explode(";",$noticia->noticia_imgs);
				
		$noticia_imgs_final ="";
		foreach($noticia_imgs as $img){
			if($img != $image and $img != ""){
				$noticia_imgs_final .= $img.";";	
				}
				
			}
			
		$dados_query = array(
					"noticia_id" => $id,
					"noticia_titulo_ptBR" => $noticia->noticia_titulo_ptBR,
					"noticia_titulo_en" => $noticia->noticia_titulo_en,
					"noticia_titulo_es" => $noticia->noticia_titulo_es,
					"noticia_data" => $noticia->noticia_data,
					"noticia_destaque" => $noticia->noticia_destaque,
					"noticia_posicao" => $noticia->noticia_posicao,
					"noticia_texto_ptBR" => $noticia->noticia_texto_ptBR,
					"noticia_texto_en" => $noticia->noticia_texto_en,
					"noticia_texto_es" => $noticia->noticia_texto_es,
					"noticia_img_principal" => "",
					"noticia_status" => $noticia->noticia_status,
					"noticia_home" => $noticia->noticia_home,
					"noticia_beneficiario" => $noticia->noticia_beneficiario,
					"noticia_empresa" => $noticia->noticia_empresa,
					"noticia_dentista" => $noticia->noticia_dentista,
					"noticia_uniodonto" => $noticia->noticia_uniodonto,
					"noticia_colaborador" => $noticia->noticia_colaborador,
					"noticia_representante" => $noticia->noticia_representante,
					"noticia_imgs" => $noticia_imgs_final
					
					

				);
											
				//Atualiza noticia
				$this->noticias_model->update_record($dados_query);
				
				@unlink("./images/noticias/".$image);
				$noticia_img_thumb = explode(".",$image);
				@unlink("./images/noticias/".$noticia_img_thumb[0]."_small.".$noticia_img_thumb[1]);
				@unlink("./images/noticias/".$noticia_img_thumb[0]."_medium.".$noticia_img_thumb[1]);
				@unlink("./images/noticias/".$noticia_img_thumb[0]."_large.".$noticia_img_thumb[1]);
				
				redirect('admin/noticias/editar/'.$id,'refresh');
		}
		
		//Funçăo para visualizar noticia de acordo com id informado
		public function visualizar($id){
			$this->session->set_userdata("idioma","ptBR");
			$dados_query = array(
		"noticia_destaque" => 1,
		"noticia_status" => 1,
		"noticia_home" => 1,
			);
	
		#Busca as noticias recentes
		$this->data["noticias"] = $this->noticias_model->get_noticias_recentes($dados_query);
		#Adiciona o id da noticia principal a query e busca resultado
		$dados_query["noticia_id"] = $id;
		$this->data['noticia'] = $this->noticias_model->get_by_id_array($id);
		#Cria a breve descricao
		$breve_desc = strip_tags($this->data['noticia'][0]['noticia_texto_'.$this->session->userdata("idioma")]);
        $this->data['breve_desc'] = substr($breve_desc, 0, strrpos(substr($breve_desc, 0, 120), ' '));
        $this->load->view('noticias_view',$this->data);	
		}
		
		//Funçăo para excluir noticia de acordo com id informado
		public function excluir($id){
		$noticia = 	$this->noticias_model->get_by_id($id);
		
		$resultado = $this->noticias_model->delete_record($id);
		if($resultado != 0){
			$noticia_imgs = explode(";",$noticia->noticia_imgs);
		
		foreach($noticia_imgs as $noticia_img){
			@unlink("./images/noticias/".$noticia_img);
			$noticia_img_thumb = explode(".",$noticia_img);
			@unlink("./images/noticias/".$noticia_img_thumb[0]."_small.".$noticia_img_thumb[1]);
			@unlink("./images/noticias/".$noticia_img_thumb[0]."_medium.".$noticia_img_thumb[1]);
			@unlink("./images/noticias/".$noticia_img_thumb[0]."_large.".$noticia_img_thumb[1]);
		}
			$this->session->set_flashdata('msg', 'Notícia excluída com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Notícia năo pode ser excluída!');
				}
		redirect(base_url().'admin/noticias/index/1');	
		}
		
		public function editar($id){
			
			if($_POST){
			$this->form_validation->set_rules('noticia_titulo_ptBR', 'noticia_titulo_ptBR', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
			
			if($_FILES){
			//UPLOAD IMAGENS
			$pathToSave = './images/noticias/';

			$i = 0;
			$msg = array( );
			$arquivos = array( array( ) );
			foreach(  $_FILES as $key=>$info ) {
				foreach( $info as $key=>$dados ) {
					for( $i = 0; $i < sizeof( $dados ); $i++ ) {
						$arquivos[$i][$key] = $info[$key][$i];
						}
					}
				}

			$i = 0;

			
			foreach( $arquivos as $file ) {

				// Verificar se o campo do arquivo foi preenchido
				if( $file['name'] != '' ) {
					$arquivoTmp = $file['tmp_name'];
					$nome_arquivo = explode(".",$file['name']);
					
					$arquivo[$i] = $pathToSave.md5($nome_arquivo[0]).time().".".strtolower ($nome_arquivo[1]);
					

					if( !move_uploaded_file( $arquivoTmp, $arquivo[$i] ) ) {
						$msg[$i] = 'Erro no upload do arquivo '.$i;
					} else {

						$sizes = array();
						$sizes['small'] = array(170, 75);
						$sizes['medium'] = array(120, 120);
						$sizes['large'] = array(280, 210);
								
						$data = Batch_cropper::run($arquivo[$i], '././././images/noticias/', $sizes, 100);
						
					}
				} else {
					$msg[$i] = sprintf('O arquivo %d nao foi preenchido',$i);
				}
					

				$i++;
			}
			//adiciona as imagens na query
				if(isset($arquivo)){
					foreach($arquivo as $img){
						$img_final .= end(explode("/",$img)).";"; 
						}
					}
			}else{
				$img_final = "";
			}
			//FIM UPLOAD IMAGENS
			
			$noticia = $this->noticias_model->get_by_id($id);
			$data = explode("/", $this->input->post("noticia_data"));
			$data = $data[2]."-".$data[1]."-".$data[0]." ".date("H:m:s");

			$dados_query = array(
					"noticia_id" => $id,
					"noticia_titulo_ptBR" => htmlentities($this->input->post("noticia_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"noticia_titulo_en" => htmlentities($this->input->post("noticia_titulo_en"), ENT_QUOTES, "UTF-8"),
					"noticia_titulo_es" => htmlentities($this->input->post("noticia_titulo_es"), ENT_QUOTES, "UTF-8"),
					"noticia_data" => $data,
					"noticia_destaque" => $this->input->post("noticia_destaque"),
					"noticia_posicao" => $this->input->post("noticia_posicao"),
					"noticia_texto_ptBR" => $this->input->post("noticia_texto_ptBR"),
					"noticia_texto_en" => $this->input->post("noticia_texto_en"),
					"noticia_texto_es" => $this->input->post("noticia_texto_es"),
					"noticia_img_principal" => "",
					"noticia_status" => $this->input->post("noticia_status"),
					"noticia_home" => $this->input->post("noticia_home"),
					"noticia_beneficiario" => $this->input->post("noticia_beneficiario"),
					"noticia_empresa" => $this->input->post("noticia_empresa"),
					"noticia_dentista" => $this->input->post("noticia_dentista"),
					"noticia_uniodonto" => $this->input->post("noticia_uniodonto"),
					"noticia_colaborador" => $this->input->post("noticia_colaborador"),
					"noticia_representante" => $this->input->post("noticia_representante"),
					"noticia_imgs" => $noticia->noticia_imgs.$img_final,
					
					

				);
								
				//cadastra noticia e recebe o id
				$id = $this->noticias_model->update_record($dados_query);
				
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Notícia alterada com sucesso!');					
				redirect('admin/noticias/editar/'.$dados_query["noticia_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a esta notícia!');
							redirect('admin/noticias/editar/'.$id,'refresh');
							}
			}				
			
					
		$data['noticia'] = $this->noticias_model->get_by_id($id);
		
		$this->load->view('admin/edit_noticias_view',$data);
		}
		
		
		
		

}
