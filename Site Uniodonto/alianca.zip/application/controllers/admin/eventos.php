<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class eventos extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			
			if($this->input->post('evento_inicio')){
			$data = explode("/",$this->input->post('evento_inicio'));
			$evento_inicio = $data[2].'-'.$data[1].'-'.$data[0];
			}else{ $evento_inicio = "";}
			if($this->input->post('evento_fim')){
			$data = explode("/",$this->input->post('evento_fim'));
			$evento_fim = $data[2].'-'.$data[1].'-'.$data[0];
			}else{ $evento_fim = ""; }
			$pesquisa["evento_titulo"] = htmlentities($this->input->post('evento_titulo'), ENT_QUOTES, "UTF-8");
			$pesquisa["evento_aba"] = $this->input->post('evento_aba');
			$pesquisa["evento_inicio"] = $evento_inicio;
			$pesquisa["evento_fim"] = $evento_fim;
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->eventos_model->count_eventos($pesquisa);
		$config['base_url'] = site_url() . 'admin/eventos/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_evento'] = "<<";
		$config['last_evento'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->eventos_model->count_eventos($pesquisa);
		$this->data['eventos'] = $this->eventos_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/eventos_view', $this->data);
        
    }

	
	// funçăo adicionar evento
	public function adicionar(){
		if($_POST){
			
		$this->form_validation->set_rules('evento_titulo_ptBR', 'evento_titulo_ptBR', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
				$data = explode("/",$this->input->post('evento_inicio'));
				$evento_inicio = $data[2].'-'.$data[1].'-'.$data[0];	
				$data = explode("/",$this->input->post('evento_fim'));
				$evento_fim = $data[2].'-'.$data[1].'-'.$data[0];

				$dados_query = array(
					"evento_id" => "",
					"evento_titulo_ptBR" => $this->input->post("evento_titulo_ptBR", ENT_QUOTES, "UTF-8"),
					"evento_titulo_en" => $this->input->post("evento_titulo_en", ENT_QUOTES, "UTF-8"),
					"evento_titulo_es" => $this->input->post("evento_titulo_es", ENT_QUOTES, "UTF-8"),
					"evento_aba" => 1,
					"evento_inicio" => $evento_inicio,
					"evento_fim" => $evento_fim,
					"evento_link" => $this->input->post("evento_link"),
					"evento_corbg" => $this->input->post("evento_corbg"),
					"evento_corfont" => $this->input->post("evento_corfont"),
					"evento_texto_ptBR" => $this->input->post("evento_texto_ptBR"),
					"evento_texto_en" => $this->input->post("evento_texto_en"),
					"evento_texto_es" => $this->input->post("evento_texto_es")

				);
				
				
				//cadastra evento e recebe o id
				$id = $this->eventos_model->add_record($dados_query);
						
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Evento cadastrado com sucesso!');					
				redirect('admin/eventos/','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este evento!');
							redirect('admin/eventos/adicionar/','refresh');
							}
			}
		
		$this->load->view('admin/add_eventos_view');
		
		
		}
		
				
		//Funçăo para excluir evento de acordo com id informado
		public function excluir($id){
		$evento = 	$this->eventos_model->get_by_id($id);
		
		$resultado = $this->eventos_model->delete_record($id);
		if($resultado != 0){
			$this->session->set_flashdata('msg', 'Evento excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Evento năo pode ser excluído!');
				}
		redirect(base_url().'admin/eventos/index/1');	
		}
		
		public function editar($id){
			
			$evento = $this->eventos_model->get_by_id($id);
			if($_POST){
			$this->form_validation->set_rules('evento_titulo_ptBR', 'evento_titulo_ptBR', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
			
				
			
			$data = explode("/",$this->input->post('evento_inicio'));
			$evento_inicio = $data[2].'-'.$data[1].'-'.$data[0];	
			$data = explode("/",$this->input->post('evento_fim'));
			$evento_fim = $data[2].'-'.$data[1].'-'.$data[0];
			$dados_query = array(
					"evento_id" => $id,
					"evento_titulo_ptBR" =>  $this->input->post("evento_titulo_ptBR"), ENT_QUOTES, "UTF-8",
					"evento_titulo_en" =>  $this->input->post("evento_titulo_en"), ENT_QUOTES, "UTF-8",
					"evento_titulo_es" =>  $this->input->post("evento_titulo_es"), ENT_QUOTES, "UTF-8",
					"evento_aba" => 1,
					"evento_inicio" => $evento_inicio,
					"evento_fim" => $evento_fim,
					"evento_link" => $this->input->post("evento_link"),
					"evento_corbg" => $this->input->post("evento_corbg"),
					"evento_corfont" => $this->input->post("evento_corfont"),
					"evento_texto_ptBR" => $this->input->post("evento_texto_ptBR"),
					"evento_texto_en" => $this->input->post("evento_texto_en"),
					"evento_texto_es" => $this->input->post("evento_texto_es")
					

				);
							
				//cadastra evento e recebe o id
				$id = $this->eventos_model->update_record($dados_query);
				
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Evento alterado com sucesso!');					
				redirect('admin/eventos/editar/'.$dados_query["evento_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este evento!');
							redirect('admin/eventos/editar/'.$id,'refresh');
							}
			}				
		$data["eventos"] = $evento;	
		$this->load->view('admin/edit_eventos_view',$data);
		}
	
}
