<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Textos_abas extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index($pagina) {
		
		if($_POST){
			$pesquisa["texto_aba_titulo"] = htmlentities($this->input->post('texto_aba_titulo'), ENT_QUOTES, "UTF-8");
			$pesquisa["texto_aba_aba"] = $this->input->post('aba');
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->textos_abas_model->count_textos_abas($pesquisa);
		$config['base_url'] = site_url() . 'admin/textos_abas/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->textos_abas_model->count_textos_abas($pesquisa);
		$this->data['textos_abas'] = $this->textos_abas_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/textos_abas_view', $this->data);
        
    }
	
	// funçăo adicionar texto
	public function adicionar($pagina){
		if($_POST){
			
		$this->form_validation->set_rules('texto_aba_titulo_ptBR', 'texto_aba_titulo_ptBR', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
			if($_FILES){
			//UPLOAD IMAGENS
			$pathToSave = './images/textos_abas/';

			$i = 0;
			$msg = array( );
			$arquivos = array( array( ) );
			foreach(  $_FILES as $key=>$info ) {
				foreach( $info as $key=>$dados ) {
					for( $i = 0; $i < sizeof( $dados ); $i++ ) {
						$arquivos[$i][$key] = $info[$key][$i];
					}
				}
			}

			$i = 0;

			
			foreach( $arquivos as $file ) {

				// Verificar se o campo do arquivo foi preenchido
				if( $file['name'] != '' ) {
					$arquivoTmp = $file['tmp_name'];
					$nome_arquivo = explode(".",$file['name']);
					
					$arquivo[$i] = $pathToSave.md5($nome_arquivo[0]).time().".".strtolower ($nome_arquivo[1]);
					

					if( !move_uploaded_file( $arquivoTmp, $arquivo[$i] ) ) {
						$msg[$i] = 'Erro no upload do arquivo '.$i;
					} else {
						$sizes = array();
						$sizes['small'] = array(170, 75);
						$sizes['medium'] = array(120, 120);
						$sizes['large'] = array(280, 210);
								
						$data = Batch_cropper::run($arquivo[$i], '././././images/noticias/', $sizes, 100);
					}
				} else {
					$msg[$i] = sprintf('O arquivo %d nao foi preenchido',$i);
				}
					

				$i++;
			}
			//adiciona as imagens na query
				foreach($arquivo as $img){
					$img_final .= end(explode("/",$img)).";"; 
				}
			}else{
				$img_final  = "";
			}
		//FIM UPLOAD IMAGENS
			
				$dados_query = array(
					"texto_aba_id" => "",
					"texto_aba_titulo_ptBR" => htmlentities($this->input->post("texto_aba_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"texto_aba_titulo_en" => htmlentities($this->input->post("texto_aba_titulo_en"), ENT_QUOTES, "UTF-8"),
					"texto_aba_titulo_es" => htmlentities($this->input->post("texto_aba_titulo_es"), ENT_QUOTES, "UTF-8"),
					"texto_aba_aba" => $this->input->post("texto_aba_aba"),
					"texto_aba_menu" => $this->input->post("texto_aba_menu"),
					"texto_aba_texto_ptBR" => $this->input->post("texto_aba_texto_ptBR"),
					"texto_aba_texto_en" => $this->input->post("texto_aba_texto_en"),
					"texto_aba_texto_es" => $this->input->post("texto_aba_texto_es"),
					"texto_aba_img" => $img_final
				);
							
				//cadastra texto e recebe o id
				$id = $this->textos_abas_model->add_record($dados_query);
						
				//Volta para a página inicial de textos
				$this->session->set_flashdata('msg', 'Texto cadastrado com sucesso!');					
				redirect('admin/textos_abas/','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este texto!');
							redirect('admin/textos_abas/adicionar/','refresh');
							}
			}
		if($pagina == "beneficiario"){
			
			$data["menus_texto"] = '<option value="1">Você benefici&aacute;rio</option>
									<option value="2">Como utilizar seu plano</option>';
			}
		if($pagina == "empresa"){
			$data["menus_texto"] = '<option value="1">Sistema SIO</option>
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Relat&oacute;rios</option>';
			}
		if($pagina == "dentista"){
			$data["menus_texto"] = '<option value="1">A Uniodonto e voc&ecirc;</option>	
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Tabelas</option>
									<option value="4">Fique por dentro</option>
									<option value="5">Manuais</option>';
			}
		if($pagina == "uniodonto"){
			$data["menus_texto"] = '<option value="1">A Uniodonto e você</option>	
									<option value="2">Sistema SIO</option>
									<option value="3">Relatórios</option>';
			}
		if($pagina == "colaborador"){
			$data["menus_texto"] = '<option value="1">Fique por dentro</option>
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Recursos humanos</option>
									<option value="4">Odontom&oacute;vel</option>
									<option value="5">Processo seletivo</option>';
			}
		if($pagina == "representante"){
			$data["menus_texto"] = '<option value="1">An&aacute;lise Cr&iacute;tica</option>
									<option value="2">Contrato</option>
									<option value="3">Marketing</option>';
			}
		
		
		$data["texto_aba_aba"] = $pagina;
		$this->load->view('admin/add_textos_abas_view',$data);
		
		
		}
		
		//funçăo para excluir apenas imagem
		function exclui_img($id,$image){
		$texto = $this->textos_abas_model->get_by_id($id);
		$texto_aba_img = explode(";",$texto->texto_aba_img);
				
		$texto_aba_img_final ="";
		foreach($texto_aba_img as $img){
			if($img != $image and $img != ""){
				$texto_aba_img_final .= $img.";";	
				}
				
			}
			
		$dados_query = array(
					"texto_aba_id" => $id,
					"texto_aba_titulo_ptBR" => $texto->texto_aba_titulo_ptBR,
					"texto_aba_titulo_en" => $texto->texto_aba_titulo_en,
					"texto_aba_titulo_es" => $texto->texto_aba_titulo_es,
					"texto_aba_menu" => $this->input->post("texto_aba_menu"),
					"texto_aba_texto_ptBR" => $texto->texto_aba_texto_ptBR,
					"texto_aba_texto_en" => $texto->texto_aba_texto_en,
					"texto_aba_texto_es" => $texto->texto_aba_texto_es,
					"texto_aba_img" => $texto_aba_img_final
				);
											
				//Atualiza texto
				$this->textos_abas_model->update_record($dados_query);
				
				@unlink("./images/textos_abas/".$image);
				$texto_aba_img_thumb = explode(".",$image);
				@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_small.".$texto_aba_img_thumb[1]);
				@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_medium.".$texto_aba_img_thumb[1]);
				@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_large.".$texto_aba_img_thumb[1]);
				
				redirect('admin/textos_abas/editar/'.$id,'refresh');
		}
		
		//Funçăo para excluir texto de acordo com id informado
		public function excluir($id){
		$texto = 	$this->textos_abas_model->get_by_id($id);
		
		$resultado = $this->textos_abas_model->delete_record($id);
		if($resultado != 0){
			$texto_aba_img = explode(";",$texto->texto_aba_img);
		
		foreach($texto_aba_img as $texto_aba_img){
			@unlink("./images/textos_abas/".$texto_aba_img);
			$texto_aba_img_thumb = explode(".",$texto_aba_img);
			@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_small.".$texto_aba_img_thumb[1]);
			@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_medium.".$texto_aba_img_thumb[1]);
			@unlink("./images/textos_abas/".$texto_aba_img_thumb[0]."_large.".$texto_aba_img_thumb[1]);
		}
			$this->session->set_flashdata('msg', 'Texto excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Texto năo pode ser excluído!');
				}
		redirect(base_url().'admin/textos_abas/index/1');	
		}
		
		public function editar($id){
		
			if($_POST){
			$this->form_validation->set_rules('texto_aba_titulo_ptBR', 'texto_aba_titulo_ptBR', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
			
			if($_FILES){
			//UPLOAD IMAGENS
			$pathToSave = './images/textos_abas/';

			$i = 0;
			$msg = array( );
			$arquivos = array( array( ) );
			foreach(  $_FILES as $key=>$info ) {
				foreach( $info as $key=>$dados ) {
					for( $i = 0; $i < sizeof( $dados ); $i++ ) {
						$arquivos[$i][$key] = $info[$key][$i];
					}
				}
			}

			$i = 0;

			
			foreach( $arquivos as $file ) {

				// Verificar se o campo do arquivo foi preenchido
				if( $file['name'] != '' ) {
					$arquivoTmp = $file['tmp_name'];
					$nome_arquivo = explode(".",$file['name']);
					
					$arquivo[$i] = $pathToSave.md5($nome_arquivo[0]).time().".".strtolower ($nome_arquivo[1]);
					

					if( !move_uploaded_file( $arquivoTmp, $arquivo[$i] ) ) {
						$msg[$i] = 'Erro no upload do arquivo '.$i;
					} else {
						$sizes = array();
						$sizes['small'] = array(170, 75);
						$sizes['medium'] = array(120, 120);
						$sizes['large'] = array(280, 210);
								
						$data = Batch_cropper::run($arquivo[$i], '././././images/noticias/', $sizes, 100);
					}
				} else {
					$msg[$i] = sprintf('O arquivo %d nao foi preenchido',$i);
				}
					

				$i++;
			}
			$img_final = "";
				if(isset($arquivo)){
					//adiciona as imagens na query
					foreach($arquivo as $img){
						$img_final .= end(explode("/",$img)).";"; 
					}
				}
			}else{
				$img_final = "";
			}
			//FIM UPLOAD IMAGENS
			
			$texto = $this->textos_abas_model->get_by_id($id);
			$dados_query = array(
					"texto_aba_id" => $id,
					"texto_aba_titulo_ptBR" => htmlentities($this->input->post("texto_aba_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"texto_aba_titulo_en" => htmlentities($this->input->post("texto_aba_titulo_en"), ENT_QUOTES, "UTF-8"),
					"texto_aba_titulo_es" => htmlentities($this->input->post("texto_aba_titulo_es"), ENT_QUOTES, "UTF-8"),
					"texto_aba_menu" => $this->input->post("texto_aba_menu"),
					"texto_aba_texto_ptBR" => $this->input->post("texto_aba_texto_ptBR"),
					"texto_aba_texto_en" => $this->input->post("texto_aba_texto_en"),
					"texto_aba_texto_es" => $this->input->post("texto_aba_texto_es"),
					"texto_aba_img" => $texto->texto_aba_img.$img_final
				);
							
				//cadastra texto e recebe o id
				$id = $this->textos_abas_model->update_record($dados_query);
				
				//Volta para a página inicial de textos
				$this->session->set_flashdata('msg', 'Texto atualizado com sucesso!');					
				redirect('admin/textos_abas/editar/'.$dados_query["texto_aba_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este texto!');
							redirect('admin/textos_abas/editar/'.$id,'refresh');
							}
			}				
			
		$data['texto'] = $this->textos_abas_model->get_by_id($id);
		$pagina = $data['texto']->texto_aba_aba;	
		if($pagina == "beneficiario"){
			$data["menus_texto"] = '<option value="1"';
			if($data['texto']->texto_aba_menu == 1){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Você benefici&aacute;rio</option>';
			
			$data["menus_texto"] .= '<option value="2"';
			if($data['texto']->texto_aba_menu == 2){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Como utilizar seu plano</option>';	
			}
		if($pagina == "empresa"){
			$data["menus_texto"] = '<option value="1"';
			if($data['texto']->texto_aba_menu == 1){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Sistema SIO</option><option value="2"';
			if($data['texto']->texto_aba_menu == 2){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Formul&aacute;rios</option>';
			$data["menus_texto"] .= '<option value="3"';
			if($data['texto']->texto_aba_menu == 3){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Relat&oacute;rios</option>';
			}
		if($pagina == "dentista"){
			$data["menus_texto"] = '<option value="1"';
			if($data['texto']->texto_aba_menu == 1){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>A Uniodonto e Voc&ecirc;</option>';			
			$data["menus_texto"] .= '<option value="2"';
			if($data['texto']->texto_aba_menu == 2){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Formul&aacute;rios</option>';
			$data["menus_texto"] .= '<option value="3"';
			if($data['texto']->texto_aba_menu == 3){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Tabelas</option>';
			
			$data["menus_texto"] .= '<option value="4"';
			if($data['texto']->texto_aba_menu == 4){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Fique por dentro</option>';
			
			$data["menus_texto"] .= '<option value="5"';
			if($data['texto']->texto_aba_menu == 5){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Manuais</option>';
			}
			
		if($pagina == "uniodonto"){
			$data["menus_texto"] = '<option value="1"';
			if($data['texto']->texto_aba_menu == 1){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>A Uniodonto e você</option>	
									<option value="2" ';
			if($data['texto']->texto_aba_menu == 2){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Sistema SIO</option>
									<option value="3" ';
			if($data['texto']->texto_aba_menu == 3){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Relat&oacute;rios</option>';
			}
		
		if($pagina == "representante"){
			$data["menus_texto"] = '<option value="1"';
			if($data['texto']->texto_aba_menu == 1){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>An&aacute;lise Cr&iacute;tica</option>';
			$data["menus_texto"] .= '<option value="2"';
			if($data['texto']->texto_aba_menu == 2){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Contrato</option>';
			$data["menus_texto"] .= '<option value="3"';
			if($data['texto']->texto_aba_menu == 3){
				$data["menus_texto"] .= ' selected ';
				}
			$data["menus_texto"] .= '>Marketing</option>';
			
			}	
					
		$data["texto_aba_aba"] = $pagina;
		$this->load->view('admin/edit_textos_abas_view',$data);
		}
}
