<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Localizacao extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			$pesquisa = htmlentities($this->input->post('pesquisa'), ENT_QUOTES, "UTF-8");
			}else{
				$pesquisa = "";
				}
			
		$config['total_rows'] = $this->localizacao_model->count_localizacao($pesquisa);
		$config['base_url'] = site_url() . 'admin/localizacao/index/';
		$config['per_page'] = '15';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->localizacao_model->count_localizacao($pesquisa);
		$this->data['localizacao'] = $this->localizacao_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/localizacao_view', $this->data);
        
    }
	
	public function adicionar(){
		if($_POST){
			
		$this->form_validation->set_rules('localizacao_titulo_ptBR', 'localizacao_titulo_ptBR', 'trim|required');
		if($this->form_validation->run()){
				$dados_query = array(
					'localizacao_id' => "",
					'localizacao_titulo_ptBR' => htmlentities($this->input->post('localizacao_titulo_ptBR'), ENT_QUOTES, "UTF-8"),
					'localizacao_titulo_en' => htmlentities($this->input->post('localizacao_titulo_en'), ENT_QUOTES, "UTF-8"),
					'localizacao_titulo_es' => htmlentities($this->input->post('localizacao_titulo_es'), ENT_QUOTES, "UTF-8"),
					'localizacao_ordem' => $this->input->post('localizacao_ordem'),
					'localizacao_tel_ptBR' => $this->input->post('localizacao_tel_ptBR'),
					'localizacao_tel_en' => $this->input->post('localizacao_tel_en'),
					'localizacao_tel_es' => $this->input->post('localizacao_tel_es'),
					'localizacao_endereco_ptBR' => htmlentities($this->input->post('localizacao_endereco_ptBR'), ENT_QUOTES, "UTF-8"),
					'localizacao_endereco_en' => htmlentities($this->input->post('localizacao_endereco_en'), ENT_QUOTES, "UTF-8"),
					'localizacao_endereco_es' => htmlentities($this->input->post('localizacao_endereco_es'), ENT_QUOTES, "UTF-8"),
					'localizacao_mapa' => $this->input->post('localizacao_mapa')

				);
				
				
				//cadastra localização
						$id = $this->localizacao_model->add_record($dados_query);
						
							//Volta para a página inicial de localização
							$this->session->set_flashdata('msg', 'Local cadastrado com sucesso!');					
							redirect('admin/localizacao/index/1','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect('admin/localizacao/adicionar/','refresh');
							}
				
		}
		$this->load->view('admin/add_localizacao_view');
		
		
		}
		
		//Função para excluir local de acordo com id informado
		public function excluir($id){
				
		$resultado = $this->localizacao_model->delete_record($id);
		if($resultado != 0){
			$this->session->set_flashdata('msg', 'Local excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Local não pode ser excluído!');
				}
		redirect(base_url().'admin/localizacao/');	
		}
		
		public function editar($id){
			
			
			if($_POST){
			
				$this->form_validation->set_rules('localizacao_titulo_ptBR', 'localizacao_titulo_ptBR', 'trim|required');
				if($this->form_validation->run()){
						$dados_query = array(
							'localizacao_id' => $this->input->post('localizacao_id'),
							'localizacao_titulo_ptBR' => htmlentities($this->input->post('localizacao_titulo_ptBR'), ENT_QUOTES, "UTF-8"),
							'localizacao_titulo_en' => htmlentities($this->input->post('localizacao_titulo_en'), ENT_QUOTES, "UTF-8"),
							'localizacao_titulo_es' => htmlentities($this->input->post('localizacao_titulo_es'), ENT_QUOTES, "UTF-8"),
							'localizacao_ordem' => $this->input->post('localizacao_ordem'),
							'localizacao_tel_ptBR' => $this->input->post('localizacao_tel_ptBR'),
							'localizacao_tel_en' => $this->input->post('localizacao_tel_en'),
							'localizacao_tel_es' => $this->input->post('localizacao_tel_es'),
							'localizacao_endereco_ptBR' => htmlentities($this->input->post('localizacao_endereco_ptBR'), ENT_QUOTES, "UTF-8"),
							'localizacao_endereco_en' => htmlentities($this->input->post('localizacao_endereco_en'), ENT_QUOTES, "UTF-8"),
							'localizacao_endereco_es' => htmlentities($this->input->post('localizacao_endereco_es'), ENT_QUOTES, "UTF-8"),
							'localizacao_mapa' => $this->input->post('localizacao_mapa')
		
						);
						     	//cadastra local
								$id = $this->localizacao_model->update_record($dados_query);
								
									//Volta para a página inicial de local
									$this->session->set_flashdata('msg', 'Local alterado com sucesso!');					
									redirect(base_url().'admin/localizacao/index/1');
									
								
											
							
					
							
						}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect(base_url().'admin/localizacao/editar/'.$this->input->post('localizacao_id'));
							}
				}
		$data['local'] = $this->localizacao_model->get_by_id($id);
		
		$this->load->view('admin/edit_localizacao_view',$data);
		}
}
