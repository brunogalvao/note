<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class proposta extends CI_Controller {
	


	
    function __construct() {
        parent::__construct();
		$this->lang->load('site', "ptBR");
			
    }

	function index() {
		
		if($_POST){
			
			$this->form_validation->set_rules('nome', 'nome', 'required');
			$this->form_validation->set_rules('cnpj', 'cnpj', 'required');	
			$this->form_validation->set_rules('tel', 'tel', 'required');	
			$this->form_validation->set_rules('email', 'email', 'required|valid_email');
			$this->form_validation->set_rules('qtd', 'qtd', 'required');	
			$this->form_validation->set_rules('adesao', 'adesao', 'required');	
			$this->form_validation->set_rules('cidade', 'cidade', 'required');	

			$cadastro_cnpj = true;
			
			if($this->form_validation->run()){
				if($cadastro_cnpj == false){
					print "aki";
					if($this->proposta_model->get_by_cnpj($this->input->post("cnpj")) == 0){
					
						$plano = $this->proposta_planos_model->get_plano($this->input->post("qtd"),$this->input->post('plano'));
						$data["proposta_cod_rep"] = $this->session->userdata("codigo");
						$data["proposta_nome_rep"] = $this->session->userdata("nome");
						$data["proposta_data"] = date("Y-m-d");
						$data["proposta_validade"] = date("Y-m-d", strtotime("+90 days"));
						$data["proposta_empresa"] = $this->input->post('nome');
						$data["proposta_cnpj"] = $this->input->post('nome');
						$data["proposta_contato"] = $this->input->post('nome');
						$data["proposta_tel"] = $this->input->post('nome');
						$data["proposta_email"] = $this->input->post('nome');
						$data["proposta_qtd_vidas"] = $this->input->post('qtd');
						$data["proposta_adesao"] = $this->input->post('adesao');
						$data["proposta_carencia"] = $this->input->post('carencia');
						$data["proposta_cidade"] = ucfirst($this->input->post('cidade'));
						$data["proposta_uf"] = $this->input->post('uf');
						$data["proposta_plano"] = $plano[0]->plano_nome;
						$data["proposta_valor_beneficiario"] = $plano[0]->plano_valor;
						$data["id_proposta"] = str_pad($this->proposta_model->add_record($data), 11, "0", STR_PAD_LEFT);
						$data["proposta_validade"] = date('Y-m-d', strtotime("+30 days"));
						$this->load->library('mpdf');
						
						$html_topo ="<img src='".site_url()."images/pdf/bg-topo.jpg'>";
						$html_bottom ="<img src='".site_url()."images/pdf/bg-bottom.jpg'>";
						$html = $this->load->view('proposta_view',$data, TRUE);
						
						
						$mpdf=new mPDF('c','A4','12','Arial' , 0 , 0 , 15 , 15 , 0 , 0);
			
						$mpdf->SetDisplayMode('fullpage');
			
						$mpdf->list_indent_first_level = 0;
						//$mpdf->StartProgressBarOutput(1);
						$mpdf->SetHTMLHeader ($html_topo);
						$mpdf->SetHTMLFooter ($html_bottom);
						$mpdf->WriteHTML($html);
						
						print $mpdf->Output('proposta-'.$data["id_proposta"].'.pdf', "D");
						}else{
							$dados['msg'] = "J� existe uma proposta ativa para esta empresa!";
						}
					}else{
						$dados['msg'] = "Esta empresa j� possui contrato!";
					}
				}else{
					$dados['msg'] = "Preencha todos os campos antes de gerar a proposta!";
					}
				
			}
			$this->load->view('form_proposta_view',$this->data);
			
    }
	

		
}