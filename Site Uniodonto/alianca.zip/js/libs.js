$(function($){
	$(".data").mask("99/99/9999");
	$(".mes").mask("99/9999");
	$(".tel").mask("(99) 9999-9999");
	$(".cep").mask("99999-999");
	$(".cpf").mask("999.999.999-99");
	$(".cnpj").mask("99.999.999/9999-99");
	$(".hora").mask("99:99");	
	});

$(function() {
      $('#ei-slider').eislideshow({
			easing		: 'easeOutExpo',
			titleeasing	: 'easeOutExpo',
			titlespeed	: 1200
		});
   });

