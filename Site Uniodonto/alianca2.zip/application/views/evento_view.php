<? include("header_view.php");?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <a href="<?=site_url()?>calendario"><?= $this->lang->line('eventos') ?></a> / <?= ucfirst($evento[0]['evento_titulo_'.$this->session->userdata("idioma")])?>
</div>
<div class="conteudo-left">
    <div class="texto">
    	<h1><?= ucfirst($evento[0]['evento_titulo_'.$this->session->userdata("idioma")])?></h1>
        <? $data = explode(" ",$evento[0]['evento_inicio'] );
           $data = explode("-",$data[0] ); ?>
            	
    	
		<?= $evento[0]['evento_texto_'.$this->session->userdata("idioma")]?>
        
        
    
    </div> 
    
      
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>