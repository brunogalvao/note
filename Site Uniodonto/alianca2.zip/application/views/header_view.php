<!doctype html>
<html>
<head>
<meta charset="utf-8">

<? if(isset($breve_desc)){?>
	<title><?= ucfirst($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?></title>
    <link type="image/x-icon" href="<?= site_url()?>images/favicon.ico" rel="shortcut icon">
	<meta content="<?= ucfirst($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?>" name="title">
    <meta content="<?= $breve_desc?>" name="description">
<? }else{?>
    <title><?= $this->lang->line('title');?></title>
    <meta name="description" content="<?= $this->lang->line('description');?>" />		
		
<? } ?>

<link media="screen" href="<?= site_url()?>css/css.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?= site_url()?>includes/slideshow/css/style.css" />
<link rel="stylesheet" type="text/css" href="<?= site_url()?>includes/fancybox/jquery.fancybox-1.3.4.css" media="screen" />

<link href="<?= site_url()?>css/input.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="<?=site_url()?>js/nivo-slider/themes/light/light.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?=site_url()?>js/nivo-slider/nivo-slider.css" type="text/css" media="screen" />


<script type='text/javascript' src="<?= site_url()?>js/jquery-latest.js"></script>

<script type='text/javascript' src='<?= site_url()?>js/js.js'></script>
<script type='text/javascript' src='<?= site_url()?>js/jquery.cycle.all.js'></script>

<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>js/libs.js" type="text/javascript" charset="utf-8"></script>


<script type="text/javascript" src="<?= site_url()?>includes/fancybox/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="<?= site_url()?>includes/fancybox/jquery.fancybox.js?v=2.1.0"></script>
<link rel="stylesheet" type="text/css" href="<?= site_url()?>includes/fancybox/jquery.fancybox.css?v=2.1.0" media="screen" />	


<script type="text/javascript" src="<?= site_url()?>includes/slideshow/js/jquery.eislideshow.js"></script>
<script type="text/javascript" src="<?= site_url()?>includes/slideshow/js/jquery.easing.1.3.js"></script>

<script src="<?= site_url()?>js/jquery.qtip.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>
<script src='<?=site_url() ?>js/sessionstorage-localstorage.js' type="text/javascript" language="javascript"></script>
    <script type="text/javascript" charset="utf-8">
      $(function(){
			$("input:text, input:checkbox, input:radio, input:file, textarea").uniform();
			$("select").uniform();
			
			if(typeof(Storage)!=="undefined") {
					sessionStorage.setItem('ss', '1');
					localStorage.setItem('ls', '1');
				}else{
					sessionStorage.setItem('ss', '1');
					store.set('ls', '1');
				}
						
		});
		
		
	  

    </script>

	
<link rel="stylesheet" href="<?= site_url()?>includes/validation/css/validationEngine.jquery.css" type="text/css"/>
<script src="<?= site_url()?>includes/validation/js/languages/jquery.validationEngine-<?= $this->session->userdata("idioma") ?>.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>includes/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>







    
<!--[if IE]>
<style type="text/css">
    .menu li {
		position:static;
	}
    .conteudo-left{
        float: left;
 		}
    .conteudo-right{
        position: relative;
        }
     .rodape{
     	float: left;
     } 
     
     .busca .bt-busca{
		margin-bottom: 5px;

			}	 
</style>
<![endif]--> 
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37653907-1']);
  _gaq.push(['_setDomainName', 'sistemauniodonto.com.br']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body>

<div class="site">
	<div class="topo-full">
        <div class="topo">
            <div class="logo">
                <a href="<?= site_url()?>"><img src="<?= site_url()?>images/logo_<?= $this->session->userdata("idioma")?>.png" alt="<?= $this->lang->line('title');?>" border="0"></a>
            </div>
            
            
            <div class="user">
                
                <span>
                <? if($this->session->userdata("logged") == true){?>
                    <?= $this->lang->line('ola');?> <?=$this->session->userdata("nome")?>  <a href="<?= site_url('logout')?>" class="btn-logout"><?= $this->lang->line('sair');?></a>	
                <? } ?>
                </span>
                <span class="alterar-cidade">
                    <a href="<?= site_url("site/alterarcidade")?>"><?= $this->lang->line('alterar_cidade');?></a>
                </span>
                
            </div>
          <div class="busca">
                <span>
                    <form id="form_busca" method="post" name="form_busca"  action="<?=site_url()?>busca">
                            <input type="text" name="busca" id="busca" value="<?= $this->lang->line('pesquisar');?>" onblur="if(this.value==''){this.value='<?= $this->lang->line('pesquisar');?>'}" onfocus="if(this.value=='<?= $this->lang->line('pesquisar');?>'){this.value=''}" style="color:#787878; padding-right:22px; background:#fff;" />
                            <input type="submit" name="<?= $this->lang->line('enviar');?>" value="" class="bt-busca" />
                    </form>
                </span>
    		</div>
            
            
        
    
        <div class="menu-principal">
        		<ul class="menu" id="menu">
        			   	<li><a class="categoria"><?= $this->lang->line('a_uniodonto');?></a>
                        	
                            <ul>
                            	
                                <? foreach($menu_uniodonto as $uniodonto){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$uniodonto->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($uniodonto->texto_titulo))?>"><?= utf8_decode(ucfirst($uniodonto->texto_titulo))?></a></li>
                                <? } ?>
                                <li><a href="<?= site_url("clientes")?>"><?= $this->lang->line('clientes');?></a></li>
                            </ul>
                        </li>	  
                       	
                        <li><a class="categoria"><?= $this->lang->line('planos');?></a>
                            <ul>
                                <? foreach($menu_planos as $planos){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$planos->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($planos->texto_titulo))?>"><?=utf8_decode(ucfirst($planos->texto_titulo))?></a></li>
                                <? } ?>
                                
                            </ul>
                        </li>
                    	
                        <li><a class="categoria" href="<?= site_url("encontreseudentista")?>"><?= $this->lang->line('encontre_seu_dentista');?></a></li>
                        <li><a class="categoria"><?= $this->lang->line('dental_uni');?></a>
                            <ul>
                                <? foreach($menu_dental as $dental){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$dental->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($dental->texto_titulo))?>"><?=utf8_decode(ucfirst($dental->texto_titulo))?></a></li>
                                <? } ?>
                                <li><a href="http://www.dentaluni.com.br/" target="_blank"><?= $this->lang->line('loja_virtual');?></a></li>
                                
                            </ul>
                        </li>
                        <li><a class="categoria"><?= $this->lang->line('uniodonto_24h');?></a>
                            <ul>
                                <? foreach($menu_clinica as $clinica){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$clinica->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($clinica->texto_titulo))?>"><?=utf8_decode(ucfirst($clinica->texto_titulo))?></a></li>
                                <? } ?>
                                
                            </ul>
                        </li>
                        <li><a class="categoria" href="<?= site_url()?>historico"><?= $this->lang->line('noticias');?></a></li>
                        
                        <li><a class="categoria" href="<?= site_url()?>sustentabilidade"><?= $this->lang->line('sustentabilidade');?></a>
                        	<ul>
                            	<? foreach($menu_sustentabilidade as $sustentabilidade){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$sustentabilidade->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($sustentabilidade->texto_titulo))?>"><?=utf8_decode(ucfirst($sustentabilidade->texto_titulo))?></a></li>
                                <? } ?>
                            </ul>
                        
                        </li>
                        <li><a class="categoria"><?= $this->lang->line('contato');?></a>
                            <ul>
                                <li><a href="<?= site_url("localizacao")?>"><?= $this->lang->line('localizacao');?></a></li>
                                <li><a href="<?= site_url("contato")?>"><?= $this->lang->line('fale_conosco');?></a></li>
                                <li><a class="categoria"><?= $this->lang->line('trabalhe_conosco');?></a>
                                	<ul>
                                		<li><a href="<?= site_url("trabalheconosco/colaborador")?>" style="padding-left:10px;"><?= $this->lang->line('colaborador');?></a></li>
                                        <li><a href="<?= site_url("trabalheconosco/dentista")?>" style="padding-left:10px;"><?= $this->lang->line('dentista');?></a></li>
                                   	</ul>
                                </li>
                                <? foreach($menu_contato as $contato){ ?>
                                
                                <li><a href="<?= site_url()?>pagina/<?=$contato->texto_id?>/<?=urlencode($this->formata_nome_model->formataNome($contato->texto_titulo))?>"><?=utf8_decode(ucfirst($contato->texto_titulo))?></a></li>
                                <? } ?>
                                
                                
                            </ul>
                        </li>
                        
                     </ul>       
            
                </ul> 
                <div class="idioma-top">
                	<ul>
                    	<li>
                        <?= $this->lang->line('alterar_idioma');?>
                        </li>
                        <li class="idioma-top">
                        <a class="idioma" href="<?= site_url("site/trocaidioma/ptBR")?>"><img  src="<?= site_url()?>images/icons/brasil_16x16.png" border="0" /></a>
                        <a class="idioma" href="<?= site_url("site/trocaidioma/es")?>"><img  src="<?= site_url()?>images/icons/spain_16x16.png" border="0" /></a>
                        <a class="idioma" href="<?= site_url("site/trocaidioma/en")?>"><img  src="<?= site_url()?>images/icons/eua_16x16.png" border="0" /></a>
                        
                        
                        </li>
                    </ul>
                </div>
        </div>
		</div>
	<? if($this->login_model->logged_users() and $this->session->userdata("tipo")){ ?>
    <div class="menu-top-user">
		<? include("menu_user.php"); ?>
	</div>    
    <? } ?>       
    </div>    
	
    <div class="conteudo">
    
    <div class="banner" >
          <div class="slider-wrapper theme-light" >
            <div id="slider" class="nivoSlider">
                		<?
						  $i = 1;
							
						  foreach($banners as $banner){ 
						?>	
                           <a href="<?= $banner->banner_link?>" target="_blank"><img src="<?= site_url().$banner->banner_img?>" alt="image0<?=$i?>" /></a>
 
                        <? $i++; } ?>
            </div>
        </div>

    </div>

    <script type="text/javascript" src="<?=site_url()?>js/nivo-slider/jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
        	
        	directionNav: true, 
        	controlNav: false,
			pauseTime: 15300
        });
    });
    </script>