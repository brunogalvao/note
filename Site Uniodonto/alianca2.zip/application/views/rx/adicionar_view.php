<? include("header_view.php") ?>
<script>
	$(document).ready(function(){
		$('#croconsulta').keyup(function(e) {
			if(e.keyCode == 13) {
				consultaCro()
				}
		});
	})
	
	function consultaCro(){
		$(".error-2").html("");
		$("#formRx").hide();
		$("#form").reset();
		var cro = $('#croconsulta').val();
		var uf = $('#ufconsulta').val();		
		if(cro == ""){
				$(".msg").html("Digite o n&uacute;mero do CRO!");
			}else{
				$(".msg").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Buscando dados no sistema por favor aguarde!");
				
				$.ajax({
						type: "POST",
						url: "<?=site_url("rx/cro")?>",
						dataType : "json",
						data: { 'cro': cro, 'uf': uf },
						success: function( data ){
							
							$(".msg").html("");
							if(data.statusBusca == true){	
								$('#cro').val(data.cro);	
								$('#nome').val(data.nome);
								$('#cidade').val(data.cidade);	
								$('#uf').val(data.estado);							
								$("#formRx").fadeIn("slow");
								}else{							
									$(".msg").html("Nenhum dentista encontrado com este CRO!");
									
								}
						
						}
				});
			}
	}
	
	$(function(){

			jQuery("#form").validationEngine();
		});

</script>

   <div>
	<h1>Cadastrar RX</h1>
    
		<div>
            <ul class="formulario">
            	<li style="display: inline-block;">
                	<label class="titulo">Estado</label>   
                	<select name="ufconsulta" id="ufconsulta">
                        <option value="AC">AC</option>
                        <option value="AL">AL</option>
                        <option value="AM">AM</option>
                        <option value="AP">AP</option>
                        <option value="BA">BA</option>
                        <option value="CE">CE</option>
                        <option value="DF">DF</option>
                        <option value="ES">ES</option>
                        <option value="GO">GO</option>
                        <option value="MA">MA</option>
                        <option value="MG">MG</option>
                        <option value="MS">MS</option>
                        <option value="MT">MT</option>
                        <option value="PA">PA</option>
                        <option value="PB">PB</option>
                        <option value="PE">PE</option>
                        <option value="PI">PI</option>
                        <option value="PR" selected>PR</option>
                        <option value="RJ">RJ</option>
                        <option value="RN">RN</option>
                        <option value="RO">RO</option>
                        <option value="RR">RR</option>
                        <option value="RS">RS</option>
                        <option value="SC">SC</option>
                        <option value="SE">SE</option>
                        <option value="SP">SP</option>
                        <option value="TO">TO</option>    
                	</select>
                </li>
                <li style="display: inline-block;"> 
                	<label class="titulo">CRO</label>   
                    <input type="text" name="croconsulta" id="croconsulta" class="validate[required]" >
               	</li>
				<li style="display: inline-block;"> 
					<a href="javascript:consultaCro()" title="Consultar CRO" class="bt-busca" ><img src="<?= site_url("images/admin/bt-busca.jpg") ?>" border="0" /></a>
                </li>
                <li class="msg">
                	
                </li>
            </ul>
			<form action="<?= site_url('rx/rx/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
              
              				
             <ul class="formulario cadastro">
             	
                <li>
                    <ul id="formRx" style="display:none; overflow:hidden;">
                        <li style="display: inline-block;">
                            <label class="titulo">CRO</label>
                            <input type="text" name="cro" id="cro" readonly style="width: 50px;" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Nome</label>
                            <input type="text" name="nome" id="nome" readonly style="width: 630px;" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Cidade</label>
                            <input type="text" name="cidade" id="cidade" readonly >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">UF</label>
                            <input type="text" name="uf" id="uf" readonly style="width: 30px;">
                        </li>
                        <li>
                            <label class="titulo">Lote</label>
                            <input type="text" name="lote" id="lote" style="width: 100px;" class="validate[required]">
                        </li>
                        <li>
                             <textarea rows="20" cols="50" name="codrx" class="validate[required]"></textarea> 
        
                              
                        </li>
                        <li>
                            <input type="submit" name="Cadastrar" value="Cadastrar" />
                        </li>
                    </ul>
                </li>
                

		
            </ul>
        </form>
		</div>
		
	
    </div>
    <? if(isset($msg)) {
		 print '<div class="error-2">'. $msg.'</div>'; 
	}?>

  </div>
</div>

<? include("footer_view.php") ?>
