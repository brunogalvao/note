<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <title>Cadastro RX - Uniodonto Curitiba</title>
    <link type="image/x-icon" href="<?= site_url()?>images/admin/favicon.ico" rel="shortcut icon">
    <script src='<?= site_url()?>js/jquery.js' type="text/javascript"></script>
    <script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
    
    <script src='<?= site_url()?>js/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
    <script src='<?= site_url()?>js/jquery.blockUI.js' type="text/javascript" language="javascript"></script>
    <script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>
    <script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
    <script src="<?= site_url()?>js/js.js" type="text/javascript" charset="utf-8"></script>
    
    <script type="text/javascript" src="<?= site_url()?>/includes/minicolors/jquery.miniColors.js"></script>
	<link type="text/css" rel="stylesheet" href="<?= site_url()?>/includes/minicolors/jquery.miniColors.css" />
  
    
    <script type="text/javascript" src="<?=site_url()?>/includes/ckeditor/ckeditor.js"></script>
    <script src="<?= site_url()?>includes/ckeditor/_samples/sample.js" type="text/javascript"></script>
    <link href="<?= site_url()?>includes/ckeditor/_samples/sample.css" rel="stylesheet" type="text/css">
    <link href="<?= site_url()?>css/css_admin2.css" rel="stylesheet" type="text/css"/>
    <link href="<?= site_url()?>css/css_rx.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?= site_url()?>includes/validation/css/validationEngine.jquery2.css" type="text/css"/>
	<script src="<?= site_url()?>includes/validation/js/languages/jquery.validationEngine-<?= $this->session->userdata("idioma") ?>.js" type="text/javascript" charset="utf-8"></script>
    <script src="<?= site_url()?>includes/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
    
    <link href="<?= site_url()?>css/uniform.default_admin.css" rel="stylesheet" type="text/css"/>
    <!--[if IE]>
		<link href="<?= site_url()?>/css/css_admin_ie.css" rel="stylesheet" type="text/css"/>
	<![endif]-->
	<script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
    <script type="text/javascript" charset="utf-8">
		$(function(){
			$("input, textarea, select").uniform();
			
		});
		function submitform()
		{
			document.forms["form"].submit();
		}
		jQuery(function($){
		   $(".data").mask("99/99/9999");
		   $(".mes").mask("99/9999");
		   $(".tel").mask("(99) 9999-9999");
		   $(".numero").mask("99");
		   $(".cnpj").mask("99.999.999/9999-99");
		
		});
    </script>
	
    
    
    
</head>

<body>
<div class="site">
<div class="todo">
    <div class="topo">
        <span>
        	<h1>Cadastro RX</h1>
        </span>
                
    </div>     
    <div class="menu">
    	<? include('menu_view.php'); ?>
    </div>
    <div class="conteudo">
        
