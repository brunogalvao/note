<? include("header_view.php") ?>
        
    <div>
    
    <h1>Lotes cadastrados</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:100px;">Lote</div>
          <div style="width:200px;">Inicio / Fim</div>
          <div style="width:360px;">Qtd. Dispon&iacute;vel</div>
          <div style="width:100px; text-align:center;">Excluir</div>
        </li>
        <? $i= 1; ?>
        <? foreach($lotes as $lote){
			
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
				
		?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:100px;"><?= $lote->rx_qtd_lote ?></div>
          <div style="width:200px;"><?= $lote->rx_qtd_inicio ?>/<?= $lote->rx_qtd_fim ?></div>
          <div style="width:360px;"><?= $lote->rx_qtd ?></div>
          <div style="width:100px; text-align:center;">
                <a href="<?= site_url('rx/lote/excluir/'.$lote->rx_qtd_id) ?>" class="bt-excluir"></a>
          </div>
        </li>
		
		
		<? $i++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
