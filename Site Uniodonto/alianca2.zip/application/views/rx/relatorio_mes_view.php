<? include('header_view.php'); ?>
		
<script type="text/javascript" charset="utf-8">
$(function () {
        $('#grafico1').highcharts({
            chart: {
                type: 'column'
            },
            title: {
                text: 'Relatório'
            },
            subtitle: {
                text: 'Quantidade de RX em aberto, recebido e concluído durante o período de <?= $mes_inicio?>/<?= $ano?> a <?= $mes_fim?>/<?= $ano?>'
            },
            xAxis: {
                categories: [<?= $meses?>],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Quantidade',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },

            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -100,
                y: 100,
                floating: true,
                borderWidth: 1,
                backgroundColor: '#FFFFFF',
                shadow: true
            },
            credits: {
                enabled: false
            },
            series: [{
                name: 'Aberto',
                data: [<?= $aberto?>],
				color: '#f5821f'
            }, {
                name: 'Recebido',
                data: [<?= $producao?>],
				color: '#918d8d'
            }, {
                name: 'Concluído',
                data: [<?= $concluido?>],
				color: '#bdbcbc'
            }]
        });
    });
    
$(function () {
        $('#grafico2').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: 'Quantidade de RX em aberto, recebido e concluído durante o período de <?= $mes_inicio?>/<?= $ano?> a <?= $mes_fim?>/<?= $ano?>'
            },
            tooltip: {
        	    pointFormat: '{series.name}: <b>{point.percentage}%</b>',
            	percentageDecimals: 3
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#918d8d',
                        connectorColor: '#918d8d',
                        formatter: function() {
                            return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                        }
                    }
                }
            },
			colors: [
				   '#f5821f', 
				   '#918d8d',
				   '#bdbcbc'
				],
            series: [{
                type: 'pie',
                name: 'RX',
                data: [
                    ['Em aberto',   <?= $porcentagemaberto ?>],
					['Recebido',   <?= $porcentagemrecebido ?>],
					['Concluído',   <?= $porcentagemconcluido ?>]

                ]
            }]
        });
    });

</script>
<div style="min-width: 400px; height: 70px; margin: 0 auto; text-align:center;">
	<form method="post">
        <span>
             Mês e Ano<br />
             De <input type="text" name="data_menor" class="input-pesquisa mes" style="width:60px;" />
             Até  
             <input type="text" name="data_maior" class="input-pesquisa mes" style="width:60px;" />
             <input type="submit" value="Gerar" name="Gerar" />
        </span> 
    </form>
</div>
<hr />
<div id="grafico1" style="min-width: 400px; height: 400px; margin: 0 auto"></div>	



<div id="grafico2" style="min-width: 300px; height: 300px; margin: 120px auto"></div>

<script src="<?= site_url()?>includes/highcharts/js/highcharts.js"></script>
<script src="<?= site_url()?>includes/highcharts/js/modules/exporting.js"></script>


		
<? include('footer_view.php'); ?>