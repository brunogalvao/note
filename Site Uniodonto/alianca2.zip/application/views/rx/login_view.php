<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cadastro RX - Uniodonto Curitiba</title>
	<link type="image/x-icon" href="<?= site_url()?>images/admin/favicon.ico" rel="shortcut icon">
	<link href="<?= site_url()?>css/css_rx.css" rel="stylesheet" type="text/css"/>
	
	</head>

	<body>
        <div class="login">
        	<div class="topo">
				<h1>Cadastro RX</h1>
              
            </div> 
            <div class="form_login">
				<div class="error">
				<? echo validation_errors();
					  if(isset($error)){
						print $error;
					  }
				?>
                </div>
				<? print form_open(site_url("rx/login/dologin")); ?>
				<div>
				<label>Usu&aacute;rio: </label>
				<? print form_input('user_login','','class="input-login"'); ?>
                </div>
                <div>
				<label>Senha: </label>
				<? print form_password('user_senha','','class="input-login"'); ?>
				</div>
                <div class="button">
				<? print form_submit('submit','','class="bt-submit"'); ?>
				</div>
				<? form_close(); ?>
			</div>
		</div>

</body>
</html>
