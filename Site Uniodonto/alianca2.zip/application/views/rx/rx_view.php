<? include("header_view.php") ?>
        
    <div>
    <h1>RX(s)</h1>
    <? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
        <div class="pesquisa">
               
                <form action="<?= site_url("rx/rx/index") ?>" method="post" enctype="multipart/form-data" id="form">
                    <span>
                    Lote<br />
                    <input type="text" name="rx_lote" class="input-pesquisa" />
                    </span>
                    <span>
                    Código<br /> 
                    <input type="text" name="rx_cod" class="input-pesquisa" />
                    </span>
                    <br />
                    <span>
                    CRO <br />
                    <input type="text" name="rx_cro" class="input-pesquisa" />
                    </span>
                    <span>
                    Nome <br />
                    <input type="text" name="rx_nome" class="input-pesquisa" style="width:345px;" />
                    </span>
                    <span>
                    Guia <br />
                    <input type="text" name="rx_guia" class="input-pesquisa" />
                    </span>
                    
                    <span>
                    Data de sa&iacute;da<br />
                    <input type="text" name="data_saida_menor" class="input-pesquisa data" />
                     > 
                    <input type="text" name="data_saida_maior" class="input-pesquisa data" />
                    </span>
                    <span>
                    Entrega de Produ&ccedil;&atilde;o<br />
                    <input type="text" name="data_producao_menor" class="input-pesquisa data" />
                     > 
                    <input type="text" name="data_producao_maior" class="input-pesquisa data" />
                     </span>
                    <span>
                    Entrega<br />
                    <input type="text" name="data_entrega_menor" class="input-pesquisa data" />
                     > 
                    <input type="text" name="data_entrega_maior" class="input-pesquisa data" />
                     </span>
                    <span style="width: 70px;">
                    <input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar" />
                    
                    </span>
                </form>
            <a href="<?= site_url('rx/limparpesquisa') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a>
                       
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:100px;">N&ordm;/Lote</div>
          <div style="width:480px;">Dentista</div>
          <div style="width:80px;">Status</div>
          <div style="width:80px; text-align:center;">Editar</div>
        </li>
        <? $i= 1; ?>
        <? foreach($rxs as $rx){
			
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
				
		?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:100px;"><?= $rx->rx_cod?> / <?= $rx->rx_lote?></div>
          <div style="width:480px;">(<?= $rx->rx_cro?>) <?= $rx->rx_nome?></div>
          <div style="width:80px;">
          		
		  		<? if($rx->rx_status == 0) print "Aberto" ?>
                <? if($rx->rx_status == 1) print "Recebido" ?>
                <? if($rx->rx_status == 2) print "Conclu&iacute;do" ?>
          </div>
          <div style="width:80px; text-align:center;"><a href="<?= site_url('rx/rx/editar/'.$rx->rx_id) ?>" class="bt-editar"></a>
          </div>
        </li>
		
		
		<? $i++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
