<? include('header_view.php'); ?>
		
<div class="home">
	<a href="<?=site_url("rx/rx")?>" alt="Listar todos" title="Listar todos">
			<img src="<?= site_url('images/rx/bt-listar.png') ?>" border="0"></a>
    <a href="<?=site_url("rx/rx/adicionar")?>" alt="Adicionar" title="Adicionar">
			<img src="<?= site_url('images/rx/bt-adicionar.png') ?>" border="0"></a>
    <a href="<?=site_url("rx/rx/busca")?>" alt="Buscar" title="Buscar">
			<img src="<?= site_url('images/rx/bt-buscar.png') ?>" border="0"></a>
    <a href="<?=site_url("rx/relatorios")?>" alt="Relatórios" title="Relatórios">
			<img src="<?= site_url('images/rx/bt-relatorios.png') ?>" border="0"></a>								
</div>		
		
<? include('footer_view.php'); ?>