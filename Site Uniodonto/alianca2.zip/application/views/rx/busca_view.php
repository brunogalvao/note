<? include("header_view.php"); ?>
<script>

	
	function consultarx(){
		
		var lote = $('#lote').val();
		var cod = $('#cod').val();		
		if(cod == "" || lote == ""){
				$(".msg").html("Preencha os campos Lote e C&oacute;digo");
			}else{
				$(".msg").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Buscando dados no sistema por favor aguarde!");
				
				$.ajax({
						type: "POST",
						url: "<?=site_url("rx/rx/busca")?>",
						dataType : "json",
						data: { 'lote': lote, 'cod': cod },
						success: function( data ){
							if(data == false){
								$(".msg").html("Nenhum RX encontrado com este c&oacute;digo");
								}else{
									$(location).attr('href', '<?=site_url("rx/rx/editar")?>/'+data[0].rx_id);
										
									}
						
						}
				});
			}
	}
	$(function(){
		
		$('form').bind("keypress", function(e) {
			if (e.keyCode == 13) {               
				e.preventDefault();
				consultarx();
			}
		});
	});
	
	

</script>

   <div>
	<h1>Buscar RX</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
            
			<form method="post" enctype="multipart/form-data" id="form">
              
              				
             <ul class="formulario cadastro">
             	
                <li>
                    <ul id="formRx" >
                        <li style="display:block;" class="msg">
                            
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Lote</label>
                            <input type="text" name="lote" id="lote" style="width: 50px;" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">C&oacute;digo</label>
                            <input type="text" name="cod" id="cod" style="width: 250px;" >
                        </li>
                       
                        <li>
                            <input type="button" name="Abrir" value="Abrir" onclick="consultarx()" />
                        </li>
                    </ul>
                </li>
                

		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
