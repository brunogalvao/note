
<ul>
	<li><a href="<?= site_url('rx/home')?>" class="menu-principal">Home</a></li>
    <li><a href="<?= site_url('rx/rx/')?>" class="menu-principal">Listar RX</a></li> 
	<li><a href="<?= site_url('rx/rx/adicionar/')?>" class="menu-principal">Cadastrar RX</a></li> 
    <li><a href="<?= site_url('rx/rx/busca/')?>" class="menu-principal">Buscar RX</a></li>
    <li><a href="<?= site_url('rx/relatorios/')?>" class="menu-principal">Relat&oacute;rios</a></li> 
    <li><a href="<?= site_url('rx/lote/')?>" class="menu-principal">Lotes</a></li> 
    <li><a href="<?= site_url('rx/lote/adicionar')?>" class="menu-principal">Cadastrar lote</a></li> 
</ul>
