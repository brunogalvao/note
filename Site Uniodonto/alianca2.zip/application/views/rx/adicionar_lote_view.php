<? include("header_view.php") ?>
<div>
	<h1>Cadastrar Lote</h1>
    <? 
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	?>
		<div>
        	<form action="<?= site_url('rx/lote/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
            <ul class="formulario">
            	
                <li style="display: inline-block;"> 
                	<label class="titulo">Lote</label>   
                    <input type="text" name="lote" id="lote" class="validate[required]" >
               	</li>
                <li style="display: inline-block;"> 
                	<label class="titulo">N&ordm; in&iacute;cio</label>   
                    <input type="text" name="inicio" id="inicio" class="validate[required]" >
               	</li>
                <li style="display: inline-block;"> 
                	<label class="titulo">N&ordm; fim</label>   
                    <input type="text" name="fim" id="fim" class="validate[required]" >
               	</li>
                <li>
                    <input type="submit" name="Cadastrar" value="Cadastrar" />
                </li>

            </ul>

        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
