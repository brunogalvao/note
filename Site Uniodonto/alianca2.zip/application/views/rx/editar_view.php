<? include("header_view.php"); ?>
<script>

	
	function consultaCro(){
		var cro = $('#cro').val();
		var uf = $('#uf').val();		
		if(cro == ""){
				$(".msg").html("Digite o n&uacute;mero do CRO!");
			}else{
				$(".msg").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Buscando dados no sistema por favor aguarde!");
				
				$.ajax({
						type: "POST",
						url: "<?=site_url("rx/cro")?>",
						dataType : "json",
						data: { 'cro': cro, 'uf': uf },
						success: function( data ){
							
							$(".msg").html("");
							if(data.statusBusca == true){	
								$('#cro').val(data.cro);	
								$('#nome').val(data.nome);
								$('#cidade').val(data.cidade);	
								$('#uf').val(data.estado);							
								}else{							
									$(".msg").html("Nenhum dentista encontrado com este CRO!");
									$('#cro').val("");	
									$('#nome').val("");
									$('#cidade').val("");	
									
								}
						
						}
				});
			}
	}
	
	
	$(function(){

		$("#form").validationEngine();
			
		$('#cro').keyup(function(e) {
			if(e.keyCode == 13) {
				consultaCro()
				}
		});
		
		$('form').bind("keypress", function(e) {
			if (e.keyCode == 13) {               
				e.preventDefault();
				return false;
			}
		});
	});
	


</script>

   <div>
	<h1>Editar RX</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
            
			<form action="<?= site_url('rx/rx/editar/'.$rx->rx_id) ?>" method="post" enctype="multipart/form-data" id="form">
              
              				
             <ul class="formulario cadastro">
             	
                <li>
                    <ul id="formRx" >
                    	<li>
                            <h1>N&ordm;: <?= $rx->rx_cod ?> / Lote: <?= $rx->rx_lote ?> </h1>
                            <?
								$data = explode("-", $rx->rx_data_saida);
								$dataproducao =  explode("-", $rx->rx_data_producao);
								$dataentrega = explode("-", $rx->rx_data_entrega );
							?>
                            Data de cadastro: <?= $data[2] ?>/<?= $data[1] ?>/<?= $data[0] ?>
                        </li>
                        <li style="display:block;" class="msg">
                            
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">CRO</label>
                            <input type="text" name="cro" id="cro" value="<?= $rx->rx_cro ?>" style="width: 50px; background: #fff;"  class="validate[required]" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Nome</label>
                            <input type="text" name="nome" id="nome" readonly value="<?= $rx->rx_nome ?>" style="width: 630px;" class="validate[required]" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Cidade</label>
                            <input type="text" name="cidade" id="cidade" value="<?= $rx->rx_cidade ?>" readonly class="validate[required]" >
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">UF</label>
                            <input type="text" name="uf" id="uf" readonly value="<?= $rx->rx_uf ?>" style="width: 30px;" class="validate[required]">
                        </li>
                        <li>
                            <label class="titulo">N&ordm; da Guia</label>
                            <input type="text" name="guia" id="guia" style="width: 100px;" value="<?= $rx->rx_guia ?>">
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Entrega de produção</label>
                            <input type="text" name="data_producao" id="data_producao" style="width: 100px;" value="<?= $dataproducao[2] ?>/<?= $dataproducao[1] ?>/<?= $dataproducao[0] ?>" class="data">
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Data de devolução</label>
                            <input type="text" name="data_entrega" id="data_entrega" style="width: 100px;" value="<?= $dataentrega[2] ?>/<?= $dataentrega[1] ?>/<?= $dataentrega[0] ?>" class="data">
                        </li>
                        <li style="display: inline-block;">
                            <label class="titulo">Qtd. RX</label>
                            <input type="text" name="qtd" id="qtd" style="width: 20px;" value="<?= $rx->rx_qtd ?>">
                        </li>
                        
                        <li style="display: block;">
                            <label class="titulo">Observa&ccedil;&otilde;es</label>
                            <textarea cols="43" rows="10" name="obs" ><?= $rx->rx_obs ?></textarea>
                        </li>
                        <li style="display: block;">
                            <label class="titulo">Imagens</label>
                            <input type="file" class="multi" accept="jpg|jpeg" name="img[]" />
                        </li>
                        
                        <li>
                        	<div id="imgs">
                        	<?
							$rx_img = explode(";",$rx->rx_img);
								foreach($rx_img as $img){
									print "<div class='img'>";
									if($img != ""){
										$rx_img_thumb = explode(".",$img); 
							?>
                            	<a href="<?= site_url("upload/rx/".$rx_img_thumb[0].".".$rx_img_thumb[1]) ?>" target="_blank">
								<img src="<?= site_url("upload/rx/".$rx_img_thumb[0]."_small.".$rx_img_thumb[1]) ?>" >
                                </a>
								<a href="<?=site_url('rx/rx/exclui_img/'.$rx->rx_id.'/'.$img)?>" class="bt-excluir" alt="Excluir" title="Excluir"></a><br />
							<?		
                                    }	
									print "</div>";
								}
			
			
							?>
                            </div>
                        
                        </li>
                        
                        <li>
                            <input type="submit" name="Salvar" value="Salvar" />
                        </li>
                    </ul>
                </li>
                

		
            </ul>
        </form>
		</div>
        
		
	
    </div>
    <div class="alteracoes">
        <h1>Hist&oacute;rico</h1>	
        <? foreach($alteracoes as $alteracao){
			$datatime = explode(" ", $alteracao->rx_alteracoes_data);
			$data = explode("-", $datatime[0]);
			?>
			<div>
            <h3><?= ($alteracao->rx_alteracoes_tipo == 0) ? 'Cadastro' : 'Edi&ccedil;&atilde;o';?></h3>
            Usu&aacute;rio: (<?= $alteracao->rx_alteracoes_user_id ?>) <?= $alteracao->rx_alteracoes_user_nome ?> <?= $data[2] ?>/<?= $data[1] ?>/<?= $data[0] ?> <?=$datatime[1]?><br />
            
            <?= ($alteracao->rx_alteracoes_tipo == 0) ? '' : $alteracao->rx_alteracoes_dados ;?>

            
            </div>
			
			
		<? } ?>
        
        
    </div>

  </div>
</div>

<? include("footer_view.php") ?>
