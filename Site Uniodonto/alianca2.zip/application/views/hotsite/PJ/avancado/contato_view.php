﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Contato</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Central de Relacionamento com o Benefici&aacute;rio</h1>
          <img src="<?= site_url()?>hotsite/PJ/images/contato.png" alt="" style="display:block; float:right;  margin-top: -45px; margin-bottom: -50px; z-index:999; position:relative;" border="0" />
          <p> Tel.: (41) 3371.1900 <br />
            e-mail: beneficiario@uniodontocuritiba.com.br <br />
            Mais informa&ccedil;&otilde;es acesse: www.uniodontocuritiba.com.br </p>
          <h1>Curitiba</h1>
          <p> Unidade Sede - Tel.: (41) 3371.1900<br />
            Unidade Centro - Tel.: (41) 3234.2100<br />
            Uniodonto 24 horas - Tel.: (41) 3342.9060 | (41) 308.DENTE*<br />
            Unidade &Aacute;gua Verde - Tel.: (41) 3094.4004 </p>
        </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
