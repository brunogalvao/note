﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Encontre seu Dentista</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
	<div style="width: 550px;">
<h1>Veja como &eacute; f&aacute;cil encontrar o dentista de sua prefer&ecirc;ncia.</h1>
Basta escolher a especialidade do cirurgi&atilde;o-dentista cooperado, o bairro de sua prefer&ecirc;ncia ou a sua localidade. Caso voc&ecirc; viaje dentro do estado do Paran&aacute;, basta selecionar a cidade de destino e voc&ecirc; encontrar&aacute; um dentista para atend&ecirc;-lo.
	</div>
	<div class="encontreseudentista">
    <script type="text/javascript">
        $(document).ready(function(){
			
            $('#estadoDentista').change(function(){
                $('#cidadeDentista').load('<?=site_url()?>retorna_estados/'+$('#estadoDentista').val() );

            });
			 $('#especialidadeDentista').load('<?=site_url()?>retorna_especialidades').val();
			 $('#cidadeDentista').load('<?=site_url()?>retorna_estados/17').val();
			
		$("#btn_buscar").click(function(event) {
				
				if(($("#croDentista").val() != "")  || ($("#nomeDentista").val() != "") || ($("#cidadeDentista").val() != "0" || ($("#especialidadeDentista").val() != "0")) ){
						$("#dentistaForm").submit();
						$("#error").html("");
				}else{
					$("#error").html("Para efetuar a busca preencha pelo menos um dos campos!");
					
				}
		   
			});
        });

    </script>
	<form name="dentistaForm" id="dentistaForm" action="http://unioweb.uniodontocuritiba.com.br/Uniodonto/EncontreSeuDentista.do" method="POST" target="POPUPW">
	   	<div class="form" style="padding-bottom: 15px;">
            <label>CRO</label>           
            <input type="text" name="croDentista" id="croDentista"/>
            
        	<label>Nome</label>
            <input type="text" name="nomeDentista" id="nomeDentista" />
            
            	<span style="display: inline-block;">
                    <label>Estado</label>            
                    <select name="estadoDentista" id="estadoDentista">
                            <option value="1">AC</option>
                            <option value="2">AL</option>
                            <option value="4">AM</option>
                            <option value="3">AP</option>
                            <option value="5">BA</option>
                            <option value="6">CE</option>
                            <option value="7">DF</option>
                            <option value="8">ES</option>
                            <option value="10">GO</option>
                            <option value="11">MA</option>
                            <option value="14">MG</option>
                            <option value="13">MS</option>
                            <option value="12">MT</option>
                            <option value="15">PA</option>
                            <option value="16">PB</option>
                            <option value="18">PE</option>
                            <option value="19">PI</option>
                            <option value="17" selected>PR</option>
                            <option value="20">RJ</option>
                            <option value="21">RN</option>
                            <option value="23">RO</option>
                            <option value="9">RR</option>
                            <option value="22">RS</option>
                            <option value="25">SC</option>
                            <option value="27">SE</option>
                            <option value="26">SP</option>
                            <option value="24">TO</option>    
                    </select>
            	</span>
                <span style="display: inline-block;">
                	<label>Cidade</label>            
            		<select name="cidadeDentista" id="cidadeDentista"></select>
                </span>
            
            
        
            <label>Bairro</label>            
            <input type="text" name="bairroDentista" />

            <span style="display: inline-block;">
                <input type="radio" value="E" name="dentista.tipoEspecialidade">
                <font style="font-size: 9.3px">Especialidade</font>
                <input type="radio" value="A" name="dentista.tipoEspecialidade">
                <font style="font-size: 9.3px">&Aacute;rea de atua&ccedil;&atilde;o</font><br />       
                <select name="especialidadeDentista" id="especialidadeDentista"></select>
            </span>
            <span style="display: block; padding-bottom: 15px;">
                 
                <input type="checkbox" name="mostrarLiberacaoOnlineDentista" />Libera&ccedil;&atilde;o Online
            </span> 
            <div id="error" style="padding: 5px; color:#af2638;"></div>
            <input type="button" id="btn_buscar" value="" class="btn-buscar" />   
        </div>
    </form>
        
    </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
