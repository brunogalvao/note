﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Conhe&ccedil;a o plano</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Vantagens</h1>
          <ul>
            <li>Maior rede do Brasil com 22 mil cirurgi&otilde;es-dentistas cooperados;</li>
            <li>Mais de 1.400 dentistas cooperados no Paran&aacute;;</li>
            <li>Mais de 1.200 dentistas cooperados na &aacute;rea de atua&ccedil;&atilde;o da Uniodonto Curitiba;</li>
            <li>Libera&ccedil;&atilde;o Online diretamente do consult&oacute;rio do cirurgi&atilde;o-dentista, inclusive dos atos complementares, com pagamento  facilitado e possibilidade de parcelamento (e-commerce);</li>
            <li>Unidades M&oacute;veis: dispon&iacute;vel para preven&ccedil;&atilde;o e educa&ccedil;&atilde;o em SIPAT (Semana Interna de Preven&ccedil;&atilde;o de Acidentes de Trabalho), levantamento epidemiol&oacute;gico e a&ccedil;&atilde;o social;</li>
            <li>Livre escolha da rede cooperada em todas as especialidades;</li>
            <li>Dental Uni, uma loja com ampla linha de produtos de higiene oral com pre&ccedil;os especiais;</li>
            <li>Atendimento personalizado e com hora marcada;
            <li>100% de dedu&ccedil;&atilde;o no imposto de renda.</li>
          </ul>
          <h1>E ainda, alguns procedimentos com
            pre&ccedil;o de tabela Uniodonto.</h1>
          <ul class="lista-horizontal">
            <li style="float:left; width: 120px;">Pr&oacute;teses;</li>
            <li>Implantes;</li>
            <li style="float:left; width: 120px;">Claramento;</li>
            <li>Est&eacute;tica;</li>
            <li style="float:left; width: 120px;">Ortodontia;</li>
            <li>Cirurgias;</li>
          </ul>
          <h1>Facilidades</h1>
          <h2>Cirurgi&otilde;es-dentistas Cooperados</h2>
          <p>Voc&ecirc; encontra a listagem completa de dentistas cooperados em nosso site: www.uniodontocuritiba.com.br ou em nossas centrais de atendimento.</p>
          <h1>Libera&ccedil;&atilde;o Online</h1>
          <p>Al&eacute;m da libera&ccedil;&atilde;o imediata dos tratamentos, a Uniodonto tamb&eacute;m facilita o pagamento dos atos complementares. Trata-se de um diferencial da Uniodonto, pois o benefici&aacute;rio realiza a transa&ccedil;&atilde;o direto no consult&oacute;rio do cirurgi&atilde;o dentista cooperado, atrav&eacute;s do sistema de libera&ccedil;&atilde;o on-line da cooperativa, Unioweb, garantindo pre&ccedil;o &uacute;nico para o procedimento independente do profissional escolhido.</p>
          <h1>Perman&ecirc;ncia no plano</h1>
          <h2>Per&iacute;odo de 24 meses  (a partir da inscri&ccedil;&atilde;o do benefici&aacute;rio).</h2>
          <h2>Caso tenha utilizado</h2>
          <p>Cancelamento somente ap&oacute;s 12 meses da &uacute;ltima utiliza&ccedil;&atilde;o.</p>
          <h2>Caso n&atilde;o tenha utilizado</h2>
          <ul>
            <li>Cancelamento poder&aacute; ser efetuado a qualquer momento;</li>
            <li>Em caso de desligamento da empresa, cancela-se a qualquer momento.</li>
          </ul>
          <h1>Benef&iacute;cios</h1>
          <ul>
            <li>Urg&ecirc;ncias;</li>
            <li>Exames Cl&iacute;nicos;</li>
            <li>Alguns tipos de Radiografia;</li>
            <li>Profilaxia; </li>
            <li>Aplica&ccedil;&atilde;o de Fl&uacute;or; </li>
            <li>Aplica&ccedil;&atilde;o de Selante (at&eacute; 12 anos); </li>
            <li>Restaura&ccedil;&otilde;es em Am&aacute;lgama* e Resinas (exce&ccedil;&atilde;o de am&aacute;lgama completa e reconstru&ccedil;&atilde;o em resina);</li>
            <li>Tratamento de canais;</li>
            <li>Retratamento de canais;</li>
            <li>Periodontia (limpeza de T&aacute;rtaro simples);</li>
            <li>Remo&ccedil;&atilde;o dent&aacute;ria simples e cisos.</li>
          </ul>
          <h1>Dependentes</h1>
          <ul>
            <li>C&ocirc;njuge;</li>
            <li>Filhos solteiros que permanecem sob depend&ecirc;ncia financeira do titular respons&aacute;vel;</li>
            <li>O enteado, o menor sob guarda por for&ccedil;a de decis&atilde;o judicial e o menor tutelado, que
              ficam equiparados aos filhos; </li>
            <li>O convivente, havendo uni&atilde;o est&aacute;vel, na forma da lei, desde que n&atilde;o exista concorr&ecirc;ncia com o c&ocirc;njuge;</li>
            <li>Os pais do titular e do c&ocirc;njuge.</li>
          </ul>
        </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
