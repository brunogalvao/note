﻿<?php
include("topo_view.php");
?>
<div class="conteudo-superior">
	<h3>Cl&iacute;nica 24hs</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncias</h1>
          <img src="<?= site_url()?>hotsite/PJ/images/clinica.png" border="0" style="display:block; float:right;" /> <img src="images/fotos-clinica.png" border="0" style="display:block; float:right;" />
          <ul>
            <li>Moderna cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncia, <br />
              inclusive s&aacute;bados, domingos e feriados, dispon&iacute;vel para benefici&aacute;rio e cliente
              particular;</li>
            <li>Equipamentos de &uacute;ltima gera&ccedil;&atilde;o;</li>
            <li>Brinquedoteca;</li>
            <li>Espa&ccedil;o Sorriso (higieniza&ccedil;&atilde;o antes do atendimento);</li>
            <li>Profissionais qualificados;</li>
            <li>Atendimento personalizado: Agilidade e seguran&ccedil;a;</li>
          </ul>
          <h1>Ligue: (41) 3342-9060 | (41) 308-DENTE*</h1>
          <p style="margin-left: -5px;"> Rua Silveira Peixoto, 1040/ Sala 04 (sobreloja) <br />
            Batel (esquina com Av. Sete de Setembro)</p>
        </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
