﻿<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Odontom&oacute;vel</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
			<h1>Sa&uacute;de Preven&ccedil;&atilde;o e Educa&ccedil;&atilde;o circulando por todo lugar.</h1>
            <div class="odontomovel"> <span>A Uniodonto Curitiba est&aacute; sempre em movimento para oferecer o melhor para os seus benefici&aacute;rios. Prova disso s&atilde;o as nossas cinco Odontom&oacute;veis, unidades m&oacute;veis equipadas com um consult&oacute;rio odontol&oacute;gico para a realiza&ccedil;&atilde;o de avalia&ccedil;&otilde;es bucais. <br />
              <br />
              A Uniodonto oferece com a Odontom&oacute;vel palestras sobre a promo&ccedil;&atilde;o de sa&uacute;de bucal com v&aacute;rias op&ccedil;&otilde;es de temas, contribuindo e ajudando a melhorar a qualidade de vida das pessoas agindo tamb&eacute;m com o
              compromisso e responsabilidade social.</span></div>
            <h1><span>
              <img src="<?= site_url()?>hotsite/PJ/images/odontomovel.png" border="0"/>
              </span>
            </h1>
			

		</div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>     
<?php
include("rodape_view.php");
?>
