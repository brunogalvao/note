﻿<?php
include("topo_view.php");
?>
<div class="conteudo-superior">
	<h3>Cl&iacute;nica 24hs</h3>
  		
  </div>
<div class="conteudo-todo">   
  <div class="conteudo-top">
  	
  </div>
 
  <div class="conteudo">
  		<div>
  		  <h1>Cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncias</h1>
          <img src="<?= site_url()?>hotsite/PJ/images/clinica.png" border="0" style="display:block; float:right;" /> <img src="images/fotos-clinica.png" border="0" style="display:block; float:right;" />
          <ul>
            <li>Moderna cl&iacute;nica 24 horas para atendimento de urg&ecirc;ncia, <br />
              inclusive s&aacute;bados, domingos e feriados, dispon&iacute;vel para benefici&aacute;rio e cliente
              particular;</li>
            <li>Equipamentos de &uacute;ltima gera&ccedil;&atilde;o;</li>
            <li>Brinquedoteca;</li>
            <li>Espa&ccedil;o Sorriso (higieniza&ccedil;&atilde;o antes do atendimento);</li>
            <li>Profissionais qualificados;</li>
            <li>Atendimento personalizado: Agilidade e seguran&ccedil;a;</li>
          </ul>
          
       	  <p style="margin-left: -5px;">
          
          <h1>(41) 3342-9060 - (41) 308-DENTE*</h1>
            Rua Silveira Peixoto, 1040, Sala 04 (sobreloja) - Batel (esquina com Av. Sete de Setembro)</p>
        	<h1>Atendimentos de emerg&ecirc;ncia outras regi&otilde;es:</h1>
            <div class="clinica-outras">
              <div class="cidade">
              <h2>Jundia&iacute;</h2>
              <span>
              <h4>Pronto atendimento 24 Horas</h4>
              Rua Leonardo Cavalcante, 74 <br />Jundia&iacute; - S&atilde;o Paulo - SP
            </span></div>
            <div class="cidade">
              <h2>Vit&oacute;ria</h2>
              <span>
              <h4>Cl&iacute;nica NEO - N&uacute;cleo de Emerg&ecirc;ncia e Urg&ecirc;ncia</h4>
              <h3>(27) 3227-6307</h3>
              Rua Candido Portinari, 27 <br /> Santa Luzia - Vit&oacute;ria - ES (Atr&aacute;s do<br>
Detran da Reta da Penha)
            </span></div>
            <div class="cidade">
              <h2>Recife</h2>
              <span>
              <h4>Cl&iacute;nica Odontoprogress ( Hospital Alfa)</h4>
              <h4>Hugo Marcelo Domingos</h4>
              <h3>(81) 2129-1705 - (81) 2129-1706</h3>
              Av.:Visc. de Jequitinhonha,  1.144/705<br />
              Recife - PE
              </span>
              <h4><br>
                Dr. Marley Neves Heraclio</h4>
              <h3>(81) 2129-1705 - (81) 2129-1706</h3>
              Av.:Visc. de Jequitinhonha,  1.144/705<br />
              Recife - PE
              <span>
              </span></div>
            <div class="cidade">
              <h2>Cuiab&aacute; e V&aacute;rzea Grande</h2>
              <span>
              <h4>Plant&atilde;o Uniodonto de Atendimento de Emerg&ecirc;ncia 24 horas</h4>
              <h3>(65) 9224-9000<span>  </span></h3>
              </span></div>

        </div>
    </div>
  	
  	</div>
	<div class="conteudo-bottom"></div>
</div>    
<?php
include("rodape_view.php");
?>
