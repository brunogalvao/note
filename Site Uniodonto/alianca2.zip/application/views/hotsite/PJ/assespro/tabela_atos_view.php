<?php
include("topo_view.php");
?>

<div class="conteudo-superior">
	<h3>Tabela de atos</h3>
  		
  </div>
<div class="conteudo-todo">
  <div class="conteudo-top"></div>
  <div class="conteudo">
    <div class="tabela">
      <table>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td>PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">EMERG&Ecirc;NCIA</th>
        </tr>
        <tr>
          <td>82000468</td>
          <td>Controle de hemorragia com Aplica&ccedil;&atilde;o de Agente Hemost&aacute;tico em regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000484</td>
          <td>Controle de hemorragia sem Aplica&ccedil;&atilde;o de Agente Hemost&aacute;tico em regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200034</td>
          <td>Tratamento em odontalgia aguda </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300020</td>
          <td>Imobiliza&ccedil;&atilde;o dent&aacute;ria em dentes permanentes</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85000787</td>
          <td>Imobiliza&ccedil;&atilde;o dent&aacute;ria em dentes dec&iacute;duos</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400467</td>
          <td>Recimenta&ccedil;&atilde;o de trabalho prot&eacute;tico</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001650</td>
          <td>Tratamento de alveolite</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100048</td>
          <td>Colagem de fragmentos dent&aacute;rios</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001022</td>
          <td>Incis&atilde;o e drenagem Extra-Oral de abscesso, hematoma e/ou flegm&atilde;o da regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001030</td>
          <td>Incis&atilde;o e drenagem Intra-Oral de abscesso, hematoma e/ou flegm&atilde;o da regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300063</td>
          <td>Tratamento de Abscesso Periodontal agudo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001251</td>
          <td>Reimplante de dente com conten&ccedil;&atilde;o</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001499</td>
          <td>Sutura de ferida em regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001197</td>
          <td>Redu&ccedil;&atilde;o simples de Luxa&ccedil;&atilde;o de Articula&ccedil;&atilde;o T&ecirc;mporo-mandibular (ATM)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001642</td>
          <td>Tratamento conservador de luxa&ccedil;&atilde;o da articula&ccedil;&atilde;o t&ecirc;mporo-mandibular - ATM</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100056</td>
          <td>Curativo de demora em endodontia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300080</td>
          <td>Tratamento de pericoronarite</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">DIAGN&Oacute;STICODIAGN&Oacute;STICO</th>
        </tr>
        <tr>
          <td>81000030</td>
          <td>Consulta odontol&oacute;gica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000065</td>
          <td>Consulta odontologica inicial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000049</td>
          <td>Consulta odontologica de Urg&ecirc;ncia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000057</td>
          <td>Consulta odontologica de Urg&ecirc;ncia 24 hs</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000073</td>
          <td>Consulta para avalia&ccedil;&atilde;o t&eacute;cnica de auditoria</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000090</td>
          <td>Consulta para t&eacute;cnica de clareamento dent&aacute;rio caseiro</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000189</td>
          <td>Diagn&oacute;stico e planejamento para tratamento odontol&oacute;gico</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000197</td>
          <td>Diagn&oacute;stico e tratamento de estomatite herp&eacute;tica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000200</td>
          <td>Diagn&oacute;stico e tratamento de estomatite por candidose</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000219</td>
          <td>Diagn&oacute;stico e tratamento de halitose</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000235</td>
          <td>Diagn&oacute;stico e tratamento de xerostomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000260</td>
          <td>Diagn&oacute;stico por meio de procedimentos laboratoriais (Exame histopatol&oacute;gico)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">RADIOLOGIA</th>
        </tr>
        <tr>
          <td>81000421</td>
          <td>RX Periapical </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000375</td>
          <td>RX interproximal - bite-wing</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000383</td>
          <td>Radiografia oclusal</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000405</td>
          <td>Radiografia panor&acirc;mica de mand&iacute;bula / maxila (ortopantomografia)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000413</td>
          <td>Radiografia panor&acirc;mica de mand&iacute;bula / maxila (ortopantomografia) com tra&ccedil;ado cefalom&eacute;trico</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000367</td>
          <td>RX m&atilde;o e punho - carpal</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000308</td>
          <td>Modelos ortod&ocirc;nticos</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000305</td>
          <td>Fotos e slides (5 fotos e 7 slides) (somente em laborat&oacute;rios de radiologia)</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000456</td>
          <td>Slide</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000315</td>
          <td>Fotos e slides (por unidade)</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000278</td>
          <td>Fotografia</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000330</td>
          <td>Seio Frontal</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000340</td>
          <td>Seio Nasal </td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">EXAMES DE LABORAT&Oacute;RIO</th>
        </tr>
        <tr>
          <td>00000410</td>
          <td>Teste risco de c&aacute;rie</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000244</td>
          <td>Teste de fluxo salivar</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000228</td>
          <td>Teste de capacidade tamp&atilde;o da saliva</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000252</td>
          <td>Teste de PH salivar</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000111</td>
          <td>Diagn&oacute;stico anatomopatol&oacute;gico em citologia esfoliativa na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000138</td>
          <td>Diagn&oacute;stico anatomopatol&oacute;gico em material de bi&oacute;psia na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000154</td>
          <td>Diagn&oacute;stico anatomopatol&oacute;gico em pe&ccedil;a cir&uacute;rgica na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000170</td>
          <td>Diagn&oacute;stico anatomopatol&oacute;gico em pun&ccedil;&atilde;o na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">PREVEN&Ccedil;&Atilde;O</th>
        </tr>
        <tr>
          <td>84000198</td>
          <td>Profilaxia: Polimento Coron&aacute;rio - (com jato de bicarbonato e ultrasson - para maiores de 13 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300055</td>
          <td>Remo&ccedil;&atilde;o dos fatores de reten&ccedil;&atilde;o do biofilme dental (placa bacteriana)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000139</td>
          <td>Atividade educativa em sa&uacute;de bucal</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000024</td>
          <td>Atividade educativa para pais e/ou cuidadores</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000016</td>
          <td>Atividade educativa em odontologia para pais e/ou cuidadores de pacientes com necessidades especiais</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000090</td>
          <td>Aplica&ccedil;&atilde;o t&oacute;pica de fl&uacute;or ( incluso profilaxia com pasta profil&aacute;tica, ta&ccedil;as e escovas - p/ menores de 13 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000163</td>
          <td>Controle de biofilme (Placa Bacteriana)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000171</td>
          <td>Controle de c&aacute;rie incipiente</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">ODONTOPEDIATRIA</th>
        </tr>
        <tr>
          <td>84000074</td>
          <td>Aplica&ccedil;&atilde;o de selante de f&oacute;ssulas e fissuras - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000058</td>
          <td>Aplica&ccedil;&atilde;o de selante - t&eacute;cnica invasiva - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100080</td>
          <td>Restaura&ccedil;&atilde;o atraum&aacute;tica em dente permanente </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000031</td>
          <td>Aplica&ccedil;&atilde;o de cariost&aacute;tico - ( at&eacute; 07 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>84000201</td>
          <td>Remineraliza&ccedil;&atilde;o</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000660</td>
          <td>Adequa&ccedil;&atilde;o do meio bucal c/ ion&ocirc;mero de vidro (por elemento)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000670</td>
          <td>Adequa&ccedil;&atilde;o meio bucal&nbsp;c/ IRM (por elemento)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100137</td>
          <td>Restaura&ccedil;&atilde;o em ion&ocirc;mero de vidro - 1 face - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100145</td>
          <td>Restaura&ccedil;&atilde;o em ion&ocirc;mero de vidro - 2 faces - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100153</td>
          <td>Restaura&ccedil;&atilde;o em ion&ocirc;mero de vidro - 3 faces - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100161</td>
          <td>Restaura&ccedil;&atilde;o em ion&ocirc;mero de vidro - 4 faces - ( at&eacute; 12 anos)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000020</td>
          <td>Coroa de acetato em dente dec&iacute;duo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000040</td>
          <td>Coroa de acetato em dente permanente</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000046</td>
          <td>Coroa de a&ccedil;o em dente dec&iacute;duo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000059</td>
          <td>Coroa de a&ccedil;o em dente permanente</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000062</td>
          <td>Coroa de policarbonato em dente dec&iacute;duo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000067</td>
          <td>Coroa de policarbonato em dente permanente</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200042</td>
          <td>Pulpotomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000127</td>
          <td>Pulpotomia em dente dec&iacute;duo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000151</td>
          <td>Tratamento endod&ocirc;ntico em dec&iacute;duos</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>83000089</td>
          <td>Exodontia simples de dec&iacute;duos</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>81000014</td>
          <td>Condicionamento em Odontologia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>87000032</td>
          <td>Condicionamento em Odontologia para pacientes com necessidades especiais</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td  >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">DENT&Iacute;STICA</th>
        </tr>
        <tr>
          <td>85100099</td>
          <td>Restaura&ccedil;&atilde;o Am&aacute;lgama 1 face</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000911</td>
          <td>Restaura&ccedil;&atilde;o de superf&iacute;cie radicular&nbsp;</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100102</td>
          <td>Restaura&ccedil;&atilde;o Am&aacute;lgama 2 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100110</td>
          <td>Restaura&ccedil;&atilde;o Am&aacute;lgama 3 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100129</td>
          <td>Restaura&ccedil;&atilde;o Am&aacute;lgama 4 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00000950</td>
          <td>Restaura&ccedil;&atilde;o a Pino intra-dentin&aacute;rio</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100196</td>
          <td>Restaura&ccedil;&atilde;o resina fotopolimeriz&aacute;vel 1 face</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100200</td>
          <td>Restaura&ccedil;&atilde;o resina fotopolimeriz&aacute;vel 2 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100218</td>
          <td>Restaura&ccedil;&atilde;o resina fotopolimeriz&aacute;vel 3 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100226</td>
          <td>Restaura&ccedil;&atilde;o em resina fotopolimeriz&aacute;vel 4 faces</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200085</td>
          <td>Restaura&ccedil;&atilde;o tempor&aacute;ria / tratamento expectante</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100064</td>
          <td>Faceta direta em resina Fotopolimeriz&aacute;vel</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400017</td>
          <td>Ajuste Oclusal por acr&eacute;scimo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400025</td>
          <td>Ajuste Oclusal por Desgaste Seletivo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400262</td>
          <td>Pino pr&eacute; fabricado</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85100013</td>
          <td>Capeamento pulpar direto</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">ENDODONTIA</th>
        </tr>
        <tr>
          <td>85200166</td>
          <td>Tratamento endod&ocirc;ntico unirradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200140</td>
          <td>Tratamento endod&ocirc;ntico birradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200158</td>
          <td>Tratamento endod&ocirc;ntico multirradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200115</td>
          <td>Retratamento endod&ocirc;ntico unirradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200093</td>
          <td>Retratamento endod&ocirc;ntico birradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200107</td>
          <td>Retratamento endod&ocirc;ntico multirradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200123</td>
          <td>Tratamento de perfura&ccedil;&atilde;o endod&ocirc;ntica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200077</td>
          <td>Remo&ccedil;&atilde;o de N&uacute;cleo Intrarradicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200069</td>
          <td>Remo&ccedil;&atilde;o de material obturador intracanal para retratamento endod&ocirc;ntico</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200131</td>
          <td>Tratamento endod&ocirc;ntico de dente com rizogenese incompleta </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00002150</td>
          <td>Remo&ccedil;&atilde;o de obtura&ccedil;&atilde;o radicular (por conduto)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85200050</td>
          <td>Remo&ccedil;&atilde;o de corpo estranho intracanal (por conduto)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">PERIODONTIA</th>
        </tr>
        <tr>
          <td>85300047</td>
          <td>Raspagem supra-gengival</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300039</td>
          <td>Raspagem sub-gengival/alisamento radicular</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85300012</td>
          <td>Dessensibiliza&ccedil;&atilde;o dent&aacute;ria</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00003100</td>
          <td>Proserva&ccedil;&atilde;o pr&eacute; ou p&oacute;s cirurgica (por segmento)</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000506</td>
          <td>Controle p&oacute;s-operat&oacute;rio em odontologia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000921</td>
          <td>Gengivectomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000948</td>
          <td>Gengivoplastia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000212</td>
          <td>Aumento de coroa cl&iacute;nica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000336</td>
          <td>Cirurgia odontol&oacute;gica a retalho</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000417</td>
          <td>Cirurgia periodontal a retalho</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001464</td>
          <td>Sepultamento radicular </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000557</td>
          <td>Cunha Proximal</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00003175</td>
          <td>Tratamento de gengivite</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001073</td>
          <td>Odonto-Sec&ccedil;&atilde;o</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00003205</td>
          <td>Orienta&ccedil;&atilde;o e higiene bucal, t&eacute;c. escova&ccedil;&atilde;o, revela&ccedil;&atilde;o placas (somente para pacientes periodotais) (para contratos de pr&eacute; pgto dever&aacute; ser enviado levantamento periapical)</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000069</td>
          <td>Amputa&ccedil;&atilde;o radicular sem obtura&ccedil;&atilde;o retrogada</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000050</td>
          <td>Amputa&ccedil;&atilde;o radicular com obtura&ccedil;&atilde;o retrogada</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">PR&Oacute;TESE DENTAL</th>
        </tr>
        <tr>
          <td>81000243</td>
          <td>Diagn&oacute;stico por meio de enceramento</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400556</td>
          <td>Restaura&ccedil;&atilde;o met&aacute;lica fundida</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400505</td>
          <td>Remo&ccedil;&atilde;o de trabalho prot&eacute;tico</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00004070</td>
          <td>Recoloca&ccedil;&atilde;o de restaura&ccedil;&atilde;o met&aacute;lica fundida ou coroas</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400220</td>
          <td>N&uacute;cleo met&aacute;lico fundido</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00004081</td>
          <td>N&uacute;cleo met&aacute;lico bipartido</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400211</td>
          <td>N&uacute;cleo de preenchimento</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400076</td>
          <td>Coroa provis&oacute;ria&nbsp;com pino</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400084</td>
          <td>Coroa provis&oacute;ria&nbsp;sem pino</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400459</td>
          <td>Provis&oacute;rio para restaura&ccedil;&atilde;o met&aacute;lica fundida</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400475</td>
          <td>Reembasamento de coroa provis&oacute;ria</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400114</td>
          <td>Coroa total em cer&ocirc;mero</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>85400149</td>
          <td>Coroa total met&aacute;lica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr style="font-weight:bold; color:#af2638; background:#fff;">
          <td style="text-align:center;">TUSS</td>
          <td >PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
          <td style="text-align:center">PLANO SUPERIOR</td>
          <td  style="text-align:center">PLANO AVAN&Ccedil;ADO</td>
        </tr>
        <tr>
          <th colspan="4">CIRURGIA</th>
        </tr>
        <tr>
          <td>82000875</td>
          <td>Exodontia simples de permanente</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000832</td>
          <td>Exodontia de permanente por indica&ccedil;&atilde;o ortod&ocirc;ntica/prot&eacute;tica</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00005015</td>
          <td>Exodontia simples de Supra Numer&aacute;rio</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000816</td>
          <td>Exodontia a retalho&nbsp;</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000859</td>
          <td>Exodontia de raiz residual&nbsp;</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000034</td>
          <td>Alveoplastia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001715</td>
          <td>Ulotomia </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000255</td>
          <td>Bi&oacute;psia de l&aacute;bio</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000239</td>
          <td>Bi&oacute;psia de boca</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000263</td>
          <td>Bi&oacute;psia de l&iacute;ngua</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000247</td>
          <td>Bi&oacute;psia de gl&acirc;ndula salivar</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000271</td>
          <td>Bi&oacute;psia de mand&iacute;bula</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000280</td>
          <td>Bi&oacute;psia de maxila</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000441</td>
          <td>Coleta de Raspado em Les&otilde;es ou S&iacute;tios Espec&iacute;ficos da regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001103</td>
          <td>Pun&ccedil;&atilde;o aspirativa na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000190</td>
          <td>Aprofundamento / aumento de vestibulo</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001154</td>
          <td>Reconstru&ccedil;&atilde;o sulco gengivo labial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000395</td>
          <td>Cirurgia para Torus Palatino</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000352</td>
          <td>Cirurgia para exostose maxilar</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000387</td>
          <td>Cirurgia para Torus mandibular - unilateral</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000360</td>
          <td>Cirurgia para Torus mandibular - bilateral</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000182</td>
          <td>Apicetomia unirradiculares sem obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000174</td>
          <td>Apicetomia unirradiculares com obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000085</td>
          <td>Apicetomia birradiculares sem obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000077</td>
          <td>Apicetomia birradiculares com obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000166</td>
          <td>Apicetomia multirradiculares sem obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000158</td>
          <td>Apicetomia multirradiculares com obtura&ccedil;&atilde;o retr&oacute;grada</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000883</td>
          <td>Frenulectomia labial </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000905</td>
          <td>Frenulotomia labial </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000891</td>
          <td>Frenulectomia lingual</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000913</td>
          <td>Frenulotomia lingual</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000298</td>
          <td>Bridectomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000301</td>
          <td>Bridotomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001545</td>
          <td>Tratamento cir&uacute;rgico de bridas constritivas da regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001286</td>
          <td>Remo&ccedil;&atilde;o de dentes inclusos / impactados</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001294</td>
          <td>Remo&ccedil;&atilde;o de dentes semi inclusos / impactados </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001634</td>
          <td>Tratamento cir&uacute;rgico para tumores benignos odontog&ecirc;nicos - sem reconstru&ccedil;&atilde;o</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001588</td>
          <td>Tratamento Cirurgico de Hiperplasia de Tecidos &Oacute;sseos/Cartilaginosos na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001596</td>
          <td>Tratamento Cirurgico de Tumores Benigno de Tecidos &Oacute;sseos / Cartilaginosos na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001553</td>
          <td>Tratamento Cirurgico de Hiperplasia de Tecidos Moles da Regi&atilde;o Buco-Maxilo-Facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001618</td>
          <td>Tratamento Cirurgico de Tumores Benigno de Tecidos Moles da Regi&atilde;o Buco-Maxilo-Facial </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000743</td>
          <td>Ex&eacute;rese de lipoma na regi&atilde;o buco-maxilo-facial</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000786</td>
          <td>Ex&eacute;rese ou excis&atilde;o de Cistos odontol&oacute;gicos</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001510</td>
          <td>Tratamento cir&uacute;rgico de f&iacute;stula buco-nasais</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001529</td>
          <td>Tratamento cir&uacute;rgico de f&iacute;stula buco-sinusais</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000808</td>
          <td>Exerese ou Excis&atilde;o de R&acirc;nula</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000794</td>
          <td>Exerese ou Excis&atilde;o de Mucocele</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82000778</td>
          <td>Exerese ou Excis&atilde;o de calculo salivar</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001707</td>
          <td>Ulectomia</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001170</td>
          <td>Redu&ccedil;&atilde;o cruenta de fraturas alveolo dent&aacute;rias </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>82001189</td>
          <td>Redu&ccedil;&atilde;o incruenta de fraturas alveolo dent&aacute;rias </td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00005840</td>
          <td>Alveolotomia (por hemi arcada)</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00005850</td>
          <td>Cirurgia para corre&ccedil;&atilde;o de tuberosidade</td>
          <td style="text-align:center"></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
        <tr>
          <td>00005870</td>
          <td>Curetagem apical (cirurgia de granuloma e cisto)</td>
          <td style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
          <td  style="text-align:center"><img src="<?= site_url()?>hotsite/PJ/images/coberto.png" width="22" height="22" /></td>
        </tr>
      </table>
    </div>
  </div>
  <div class="conteudo-bottom"></div>
</div>    
  
<?php
include("rodape_view.php");
?>