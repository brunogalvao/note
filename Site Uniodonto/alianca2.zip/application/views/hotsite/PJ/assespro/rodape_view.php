﻿<div class="rodape">
  	<div>
		<span style="padding-top:8px;">
        	<img src="<?= site_url()?>hotsite/PJ/images/logo-rodape.png" border="0" /> <img src="<?= site_url()?>hotsite/PJ/images/<?=$pasta?>/logo-rodape-cliente.png">
        </span>
        <span>
        	R. Miguel Poholink, 130 – Hauer<br />
            Tel.: (41) 3371-1900 <br />
            beneficiario@uniodontocuritiba.com.br<br />
        </span>
        
        <span style="float:right; padding-top:8px;">
        	<a href="http://www.facebook.com/uniodontocuritiba" target="_blank"><img src="<?= site_url()?>hotsite/PJ/images/redes-sociais.png" border="0" /></a>
        </span>
        <span style="float:right; padding-top:20px;">
        	<a href="http://www.uniodontocuritiba.com.br" target="_blank">www.uniodontocuritiba.com.br</a>
        </span>
  	</div>
  </div>
  
</body>
</html>