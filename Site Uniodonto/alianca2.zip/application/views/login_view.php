<? include("header_view.php"); ?>
<div class="nav">
    <a href="<?=site_url()?>">Home</a> / <font style="color:#333;"><?= ucfirst($pagina)?></font> / Login
</div>
<div class="conteudo-left">
	
    <div class="login" style="background:url(<?=site_url()?>images/<?=$bg?>) bottom no-repeat;">
    	<iframe width="400" scrolling="no" height="180" frameborder="0" src="<?= $iframe?>" marginwidth="0" marginheight="0" allowtransparency="true"></iframe>
    </div>    
</div>
<div class="conteudo-right">
	
	<? include("lateral_view.php"); ?>
    
</div>
<? include("footer_view.php"); ?>