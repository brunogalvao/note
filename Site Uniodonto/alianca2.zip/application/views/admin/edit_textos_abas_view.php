<? include("header_view.php") ?>
   <div>
	<h1>Editar página: <?= ucfirst($texto_aba_aba) ?> - <?= $texto->texto_aba_titulo_ptBR ?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/textos_abas/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/textos_abas/editar/'.$texto->texto_aba_id) ?>" method="post" enctype="multipart/form-data" id="form">
				<input type="hidden" name="texto_aba_id" value="<?=$texto->texto_aba_id?>" />
                
               			
             <ul class="formulario">
             	<li> <span class="titulo">Menu</span>   
                <select name="texto_aba_menu" class="select">
                	
                      <?= $menus_texto ?> 
                 </select></li>
				<li> <span class="titulo">Título</span> <br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> 
                  <input type="text" name="texto_aba_titulo_ptBR" value="<?= $texto->texto_aba_titulo_ptBR ?>" class="input-grande" /></li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                  <input type="text" name="texto_aba_titulo_en" value="<?= $texto->texto_aba_titulo_en ?>" class="input-grande" /></li>
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                  <input type="text" name="texto_aba_titulo_es" value="<?= $texto->texto_aba_titulo_es ?>" class="input-grande" /></li>   				
				<li> <span class="titulo">Texto</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> 
                <textarea name="texto_aba_texto_ptBR" cols="5" rows="5" class="ckeditor"><?= $texto->texto_aba_texto_ptBR ?></textarea>
				
				</li>
               	<li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <textarea name="texto_aba_texto_en" cols="5" rows="5" class="ckeditor"><?= $texto->texto_aba_texto_en ?></textarea>
				
				</li>
				<li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <textarea name="texto_aba_texto_es" cols="5" rows="5" class="ckeditor"><?= $texto->texto_aba_texto_es ?></textarea>
				
				</li>
				<li> <span class="titulo">Imagens</span>   
				<input type="file" class="multi" accept="gif|jpg|png" name="teste[]" />
				
				
				<?
					$texto_aba_img = explode(";",$texto->texto_aba_img);
					foreach($texto_aba_img as $img){
						if($img != ""){
							print "<div class='img'>";
							$texto_aba_img_thumb = explode(".",$img);
							print "<img src='".site_url()."images/textos_abas/".$texto_aba_img_thumb[0]."_thumb.".$texto_aba_img_thumb[1]."' >";
							print '<a href="'.site_url('admin/textos_abas/exclui_img/'.$texto->texto_aba_id.'/'.$img).'" class="bt-excluir" alt="Excluir" title="Excluir"></a>';
							print "</div>";
						}	
					}


				?>
				</li>
				
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
