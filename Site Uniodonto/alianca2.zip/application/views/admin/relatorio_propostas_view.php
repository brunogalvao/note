<? include('header_view.php'); ?>
	<div>
    <h1>Notícias</h1> 
	<? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>	
		<div class="pesquisa">
        		<h2>Pesquisar</h2>
			<form method="post" id="form" name="form" action="<?=site_url("admin/propostas/relatorio/1")?>" />
                <span>
                    <label>N&ordm; Proposta</label>
                    <input type="text" name="proposta_n" id="proposta_n" >
                </span>
                <span>
                    <label>Cod. Representante</label>
                    <input type="text" name="cod_rep" id="cod_rep" >
                </span>
                <span>
                    <label>Nome Representante</label>
                    <input type="text" name="nome_rep" id="nome_rep" style="width:340px;" >
                </span>
                <span>
                    <label>Cod. Consultor</label>
                    <input type="text" name="cod_consultor" id="cod_rep" >
                </span>
                <span>
                    <label>Nome Consultor</label>
                    <input type="text" name="nome_consultor" id="nome_rep" style="width:340px;" >
                </span>
                <span>
                    <label>Data inclus&atilde;o de</label>
                    <input type="text" name="datade" class="data">
                </span>
                <span>
                	<label>at&eacute;</label>
                    <input type="text" name="dataate" class="data">
                </span>
                <span>
                    <label>Validade de</label>
                    <input type="text" name="validadede" class="data">
                </span>
                <span>
                	<label>at&eacute;</label>
                    <input type="text" name="validadeate" class="data">
                </span>
                <span>
                    <label>CNPJ</label>
                    <input type="text" name="cnpj" id="cnpj" class="cnpj">
                </span>
                <span>
                    <label>Nome da Empresa</label>
                    <input type="text" name="empresa" id="empresa" style="width:340px;">
                </span>
                <span>
                    <label>Email</label>
                    <input type="text" name="email" id="email" >
                </span>
                
                <span>
                        <label>Cidade</label>
                        <input type="text" name="cidade" id="cidade" >
                </span>
                <span>
                        <label>Estado</label>
                        <select name="uf">
                            <option value="AC">AC</option>
                            <option value="AL">AL</option>
                            <option value="AM">AM</option>
                            <option value="AP">AP</option>
                            <option value="BA">BA</option>
                            <option value="CE">CE</option>
                            <option value="DF">DF</option>
                            <option value="ES">ES</option>
                            <option value="GO">GO</option>
                            <option value="MA">MA</option>
                            <option value="MG">MG</option>
                            <option value="MS">MS</option>
                            <option value="MT">MT</option>
                            <option value="PA">PA</option>
                            <option value="PB">PB</option>
                            <option value="PE">PE</option>
                            <option value="PI">PI</option>
                            <option value="PR" selected>PR</option>
                            <option value="RJ">RJ</option>
                            <option value="RN">RN</option>
                            <option value="RO">RO</option>
                            <option value="RR">RR</option>
                            <option value="RS">RS</option>
                            <option value="SC">SC</option>
                            <option value="27">SE</option>
                            <option value="SE">SP</option>
                            <option value="TO">TO</option>
                        </select> 
                
                </span>
                    <input type="submit" value="Buscar"  name="Buscar" class="bt-pesquisar">
                
            </form>
        
	
            <a href="<?= site_url('admin/limparpesquisa/relatoriopropostas') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista relatorio-proposta" >
        <li class="cabecalho">
          <div style="width:90px;">N&ordm; Proposta</div>
          <div style="width:70px;">Data</div>
		  <div style="width:120px;">Representante</div>
          <div style="width:170px;">Empresa</div>
          <div style="width:170px;">Plano</div>
          <div style="width:90px;">Cidade</div>
          <div style="width:20px;">UF</div>
        </li>
        <? $i= 1; ?>
        <? foreach($propostas as $proposta){
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#ffffff";
				}
			$data_inclusao = explode("-", $proposta->proposta_data);
			$validade = explode("-", $proposta->proposta_validade);
			?>
			
		    
          <li class="itens" style="background:<?=$bg ?>;">
              <div style="width:90px;"><b><?= $proposta->proposta_n ?></b></div>
              <div style="width:70px;">
                  <strong>Inclus&atilde;o</strong><br /><?= $data_inclusao[2] ?>/<?= $data_inclusao[1] ?>/<?= $data_inclusao[0] ?><br />
                  <strong>Validade:</strong> <br /><?= $validade[2] ?>/<?= $validade[1] ?>/<?= $validade[0] ?>
              </div>
              <div style="width:120px;">
              Representante<br />(<?= $proposta->proposta_cod_rep ?>) <?= $proposta->proposta_nome_rep ?><br />
              Consultor<br />(<?= $proposta->proposta_cod_consultor ?>) <?= $proposta->proposta_nome_consultor ?>
              </div>
              <div style="width:170px;">
			  	  <?= $proposta->proposta_empresa ?><br />
              	  <strong>CNPJ:</strong> <?= $proposta->proposta_cnpj ?><br />
                  <strong>Contato:</strong> <?= $proposta->proposta_contato ?><br />
                  <strong>Tel.:</strong> <?= $proposta->proposta_tel ?><br />
                  <strong>Email:</strong> <?= $proposta->proposta_email ?>
              </div>
              <div style="width:170px;">
			  	  <?= $proposta->proposta_plano ?><br />
				  <strong>Qtd. Vidas:</strong> <?= $proposta->proposta_qtd_vidas ?><br />
                  <strong>Carência:</strong> <?= $proposta->proposta_carencia ?><br />
                  <strong>Taxa Adesão:</strong> <?= $proposta->proposta_adesao ?><br />
                  <strong>Valor por beneficiário:</strong> <?= $proposta->proposta_valor_beneficiario ?>
              </div>
              <div style="width:90px;"><?= $proposta->proposta_cidade ?></div>
              <div style="width:20px;"><?= $proposta->proposta_uf ?></div>
          </li>
        
        
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>  
      
	
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
    
	</div>
    
    








    	
<? include('footer_view.php'); ?>