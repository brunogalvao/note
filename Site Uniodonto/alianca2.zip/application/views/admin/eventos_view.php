<? include("header_view.php") ?>
        
    <div>
    <h1>Eventos</h1>
    <? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
        <div class="pesquisa">
               
                <form action="<?= site_url("admin/eventos/index") ?>" method="post" enctype="multipart/form-data" id="form">
                    <span>
                    Data de início
                    <input type="text" name="evento_inicio" class="input-pesquisa data" />
                    </span><span>
                    Data fim
                    <input type="text" name="evento_fim" class="input-pesquisa data" />
                     </span><span>
                     Título
                    <input type="text" name="evento_titulo" class="input-pesquisa" />
                   	</span><span style="width: 70px;">
                    <input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar" />
                    
                    </span>
                </form>
            <a href="<?= site_url('admin/limparpesquisa/eventos') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a>
                       
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:500px;">Titulo</div>
          <div style="width:80px;">Data inicio</div>
          <div style="width:80px;">Data fim</div>
          <div style="width:80px; text-align:center;">Editar/Excluir</div>
        </li>
        <? $i= 1; ?>
        <? foreach($eventos as $evento){
			
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
				
			$datainicio = explode(" ",$evento->evento_inicio);
			$diainicio = explode("-",$datainicio[0]);
			$datafim = explode(" ",$evento->evento_fim);
			$diafim = explode("-",$datafim[0]);	
			?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:500px;"><?= $evento->evento_titulo_ptBR?></div>
          <div style="width:80px;"><?= $diainicio[2] ?>/<?= $diainicio[1] ?>/<?= $diainicio[0] ?></div>
          <div style="width:80px;"><?= $diafim[2] ?>/<?= $diafim[1] ?>/<?= $diafim[0] ?></div>
          <div style="width:80px; text-align:center;"><a href="<?= site_url('admin/eventos/editar/'.$evento->evento_id) ?>" class="bt-editar"></a>
          <a href="<?= site_url('admin/eventos/excluir/'.$evento->evento_id) ?>" class="bt-excluir"></a>
          </div>
        </li>
		
		
		<? $i++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
