<? include("header_view.php") ?>
   <div>
	<h1>Adicionar endereço</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/localizacao/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/localizacao/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
             <ul class="formulario">
             	<li> <span class="titulo">Titulo</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />
                <input type="text" name="localizacao_titulo_ptBR" value="" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <input type="text" name="localizacao_titulo_en" value="" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <input type="text" name="localizacao_titulo_es" value="" class="input-grande" /></li>
                <li> <span class="titulo">Ordem</span>   
                <input type="text" name="localizacao_ordem" value="" style="width: 20px;" /></li>
                <li> <span class="titulo">Tel</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                <input type="text" name="localizacao_tel_ptBR" value="" class="input-grande" /></li>
                <li> 
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <input type="text" name="localizacao_tel_en" value="" class="input-grande" /></li>
                <li> 
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <input type="text" name="localizacao_tel_es" value="" class="input-grande" /></li>
				<li> <span class="titulo">Endereco</span><br /> 
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />   
                <input type="text" name="localizacao_endereco_ptBR" value="" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />
                <input type="text" name="localizacao_endereco_en" value="" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />
                <input type="text" name="localizacao_endereco_es" value="" class="input-grande" /></li>
				<li> <span class="titulo">Mapa</span>   
                <input type="text" name="localizacao_mapa" value="" style="width: 200px;" /><br />
                <i style="padding-left:40px;">Digite ("Latidude, Longitude"). <a href="http://support.google.com/maps/bin/answer.py?hl=pt-BR&answer=1334236" target="_blank">Veja como saber a latidude e longitude</a></i>
                </li>
            </ul>
        </form>
		</div>
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
