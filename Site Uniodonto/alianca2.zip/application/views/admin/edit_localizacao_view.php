<? include("header_view.php") ?>
   
	<h1>Editar endereço - <?=$local->localizacao_titulo_ptBR?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/localizacao/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/localizacao/editar/'.$local->localizacao_id) ?>" method="post" enctype="multipart/form-data" id="form">
             <input type="hidden" name="localizacao_id" value="<?=$local->localizacao_id?>" />
			 <ul class="formulario">
             	<li> <span class="titulo">Titulo</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> 
                <input type="text" name="localizacao_titulo_ptBR" value="<?=$local->localizacao_titulo_ptBR?>" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />
                 
                <input type="text" name="localizacao_titulo_en" value="<?=$local->localizacao_titulo_en?>" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />
                 
                <input type="text" name="localizacao_titulo_es" value="<?=$local->localizacao_titulo_es?>" class="input-grande" /></li>
                <li> <span class="titulo">Ordem</span>   
                <input type="text" name="localizacao_ordem" value="<?=$local->localizacao_ordem?>" style="width: 20px;" /></li>
                <li> <span class="titulo">Tel</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /></span>   
                <input type="text" name="localizacao_tel_ptBR" value="<?=$local->localizacao_tel_ptBR?>" class="input-grande"/></li>
                 <li>
                 <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />   
                <input type="text" name="localizacao_tel_en" value="<?=$local->localizacao_tel_en?>" class="input-grande"/></li>
                <li>
                 <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />   
                <input type="text" name="localizacao_tel_es" value="<?=$local->localizacao_tel_es?>" class="input-grande"/></li>
				<li> <span class="titulo">Endereco</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> 
                <input type="text" name="localizacao_endereco_ptBR" value="<?=$local->localizacao_endereco_ptBR?>" class="input-grande"/></li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />
                <input type="text" name="localizacao_endereco_en" value="<?=$local->localizacao_endereco_en?>" class="input-grande"/></li>
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />
                <input type="text" name="localizacao_endereco_es" value="<?=$local->localizacao_endereco_es?>" class="input-grande"/></li>
				<li> <span class="titulo">Mapa</span>   
                <input type="text" name="localizacao_mapa" value="<?=$local->localizacao_mapa?>" style="width: 200px;"/><br />
                <i style="padding-left:40px;">Digite ("Latidude, Longitude"). <a href="http://support.google.com/maps/bin/answer.py?hl=pt-BR&answer=1334236" target="_blank">Veja como saber a latidude e longitude</a></i>
                </li>   
            
            </ul>
        </form>
		</div>
        
<script type="text/javascript"src="https://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript">
  function initialize() {
    var latlng = new google.maps.LatLng(<?=$local->localizacao_mapa?>);
    var myOptions = {
      zoom: 18,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
    };
    var map = new google.maps.Map(document.getElementById("map_canvas"),
        myOptions);
		
	  var image = '<?=site_url()?>images/admin/logo-icon.png';
	  var myLatLng = new google.maps.LatLng(<?=$local->localizacao_mapa?>);
	  var beachMarker = new google.maps.Marker({
		  position: myLatLng,
		  map: map,
		  icon: image,
   	  	  title:"Uniodonto"
	  });
   
		
	
  }

</script>
        <div class="mapa">
        	<div id="map_canvas" style="width:780px; height:400px"></div>
        </div>    
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
