<? include("header_view.php") ?>
<div>
	<h1>Editar página institucional - <?= $texto->texto_titulo_ptBR ?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/textos/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/textos/editar/'.$texto->texto_id) ?>" method="post" enctype="multipart/form-data" id="form">
				<input type="hidden" name="texto_id" value="<?=$texto->texto_id?>" />
                
               			
             <ul class="formulario">
             	<li> <span class="titulo">Menu</span>   
                <select name="texto_menu" class="select">
                      <option value="1" <? if($texto->texto_menu == 1)print "selected" ?>>A Uniodonto</option>
                      <option value="2" <? if($texto->texto_menu == 2)print "selected" ?>>Planos</option>
                      <option value="3" <? if($texto->texto_menu == 3)print "selected" ?>>Dental Uni</option>
                      <option value="4" <? if($texto->texto_menu == 4)print "selected" ?>>Uniodonto 24h</option>
                      <option value="5" <? if($texto->texto_menu == 5)print "selected" ?>>Contato</option>
                      <option value="6" <? if($texto->texto_menu == 6)print "selected" ?>>Sustentabilidade</option>
                 </select><span class="titulo">Ordem</span>
                  <input type="text" name="texto_posicao" value="<?= $texto->texto_posicao ?>" style="width:20px;" /></li>
				<li> <span class="titulo">Título </span><br />   
                  <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  /> <input type="text" name="texto_titulo_ptBR" value="<?= $texto->texto_titulo_ptBR ?>" class="input-grande" /></li>	
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />   
                  <input type="text" name="texto_titulo_en" value="<?= $texto->texto_titulo_en ?>" class="input-grande" /></li>
                 <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />   
                  <input type="text" name="texto_titulo_es" value="<?= $texto->texto_titulo_es ?>" class="input-grande" /></li>  			
				<li> <span class="titulo">Texto</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />
                <textarea name="texto_texto_ptBR" cols="5" rows="5" class="ckeditor"><?= $texto->texto_texto_ptBR ?></textarea>
				
				</li>
                <li><img  src="<?= site_url()?>images/icons/eua_16x16.png"  />   
                <textarea name="texto_texto_en" cols="5" rows="5" class="ckeditor"><?= $texto->texto_texto_en ?></textarea>
				
				</li>
                <li><img  src="<?= site_url()?>images/icons/spain_16x16.png"  />   
                <textarea name="texto_texto_es" cols="5" rows="5" class="ckeditor"><?= $texto->texto_texto_es ?></textarea>
				
				</li>
				<script>
				$(function(){
						$('#T8B').MultiFile({
							STRING: {
								file: '<em title="Click to remove" onclick="$(this).parent().prev().click()">$file</em>',
								remove: '<img src="<?= site_url()?>images/admin/trash.png" height="16" width="16" alt="x"/>'
							}
						});
					});
				</script>
				<li> <span class="titulo">Imagens</span>   
				<input type="file" class="multi" id="T8B" accept="gif|jpg|png" name="teste[]" />
				
				
				<?
					$texto_img = explode(";",$texto->texto_img);
					foreach($texto_img as $img){
						if($img != ""){
							print "<div class='img'>";
							$texto_img_thumb = explode(".",$img);
							print "<img src='".site_url()."images/textos/".$texto_img_thumb[0]."_thumb.".$texto_img_thumb[1]."' >";
							print '<a href="'.site_url('admin/textos/exclui_img/'.$texto->texto_id.'/'.$img).'" class="bt-excluir" alt="Excluir" title="Excluir"></a>';
							print "</div>";
						}	
					}


				?>
				</li>
				
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>


<? include("footer_view.php") ?>
