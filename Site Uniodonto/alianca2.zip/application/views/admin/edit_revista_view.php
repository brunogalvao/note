<? include("header_view.php") ?>

   <div>
	<h1>Editar revista - <?= $revista->revista_titulo ?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
   	
		<div>
			<form action="<?= site_url('admin/revistas/editar/'.$revista->revista_id) ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/revistas/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
            <input type="hidden" name="revista_id" value="<?= $revista->revista_id ?>" />
             <ul class="formulario">
             	<li> <span class="titulo">Título</span>   <br />
                <input type="text" name="revista_titulo" value="<?= $revista->revista_titulo ?>" style="width:340px;"  /></li>
				
				
				
				<li> <span class="titulo">Capa</span>
									
				<input type="file" class="multi" accept="png|gif|jpg" maxlength="1" name="capa" /><br />
				<img src="<?= site_url().$revista->revista_capa ?>" />
				
				
				</li>
				<li> <span class="titulo">Revista PDF</span>
									
				<input type="file" class="multi" maxlength="1" name="pdf" />
				<? if($revista->revista_pdf != ""){ ?>
					<a href="<?= site_url().$revista->revista_pdf ?>" target="_blank" class="bt-voltar">Ver revista</a>
				<? } ?>
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
