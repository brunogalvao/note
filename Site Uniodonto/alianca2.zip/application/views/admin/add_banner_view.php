<? include("header_view.php") ?>


   <div>
	<h1>Adicionar banner</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
   	
		<div>
			<form action="<?= site_url('admin/banners/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/banners/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
             <ul class="formulario">
             	<li> <span class="titulo">Título</span>   
                <input type="text" name="banner_titulo" value="" class="input-grande" /></li>
				<li>  
                    <div style="display:inline-block;">
                    	<span class="titulo">Status</span>
                        <div class="styled-select2">   
                        <select name="banner_status" class="select">
                            <option value="0">N&atilde;o publicado</option>
                            <option value="1">Publicado</option>
                        </select>
                        </div>
                    </div>
                    <div style="display:inline-block;">
                        <span class="titulo">Idioma</span> 
                        <div class="styled-select2">  
                        <select name="banner_idioma" class="select">
                            <option value="ptBR" >Português</option>
                            <option value="en" >Inglês</option>
                            <option value="es" >Espanhol</option>
                        </select>
                        </div>
                    </div>    
				</li>
				<li> <span class="titulo">Seções</span><br />   
                <span class="titulo2">Home </span>
				<input type="radio" name="banner_home" value="1" checked /> Sim
				<input type="radio" name="banner_home" value="0" /> Não<br />
				<span class="titulo2">Beneficiário </span>
				<input type="radio" name="banner_beneficiario" value="1" /> Sim
				<input type="radio" name="banner_beneficiario" value="0" checked /> Não<br />
				<span class="titulo2">Empresa </span>
				<input type="radio" name="banner_empresa" value="1" /> Sim
				<input type="radio" name="banner_empresa" value="0" checked /> Não<br />
				<span class="titulo2">Dentista </span>
				<input type="radio" name="banner_dentista" value="1" /> Sim
				<input type="radio" name="banner_dentista" value="0" checked /> Não<br />
				<span class="titulo2">Uniodonto </span>
				<input type="radio" name="banner_uniodonto" value="1"  /> Sim
				<input type="radio" name="banner_uniodonto" value="0" checked /> Não<br />
				
				<span class="titulo2">Representante</span> 
				<input type="radio" name="banner_representante" value="1"  /> Sim
				<input type="radio" name="banner_representante" value="0" checked /> Não<br />
				</li>
				
				
				<li> <span class="titulo">Link ("http://www.linksite.com.br")</span> <br />  
				<input type="text" name="banner_link" value="" class="input-grande" /></li>
				<li> <span class="titulo">Imagens</span>
									
				<input type="file" class="multi" accept="png|gif|jpg" maxlength="1" name="img" />
				
				
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
