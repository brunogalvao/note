<? include("header_view.php") ?>
   <div>
	<h1>Editar usuário - <?= $usuario->user_nome ?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/usuarios/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/usuarios/editar/'.$usuario->user_id) ?>" method="post" enctype="multipart/form-data" id="form">
            <input type="hidden" name="user_id" value="<?= $usuario->user_id ?>" />
             <ul class="formulario">
             	<li> <span class="titulo">Nome</span>   
                <input type="text" name="user_nome" value="<?= $usuario->user_nome ?>" class="input-grande"  /></li>
                <li> <span class="titulo">E-mail</span>   
                <input type="text" name="user_email" value="<?= $usuario->user_email ?>" class="input-grande" /></li>
                <li> <span class="titulo">Senha</span>   
                <input type="text" name="user_senha" value="<?= $usuario->user_senha ?>" class="input-grande"  /></li> 
                
                <li class="permissoes">
                <span class="titulo">Permiss&otilde;es</span> <br />
                <? foreach($metodos as $metodo){ 
					$query = array("id_metodo" => $metodo->id, "id_usuario" => $usuario->user_id );
					$permissao = $this->sys_permissoes_model->get_permissao($query);
				?>
                
                	<span class="permissao-user"><input type="checkbox" class="checkbox" name="metodo[]" value="<?= $metodo->id ?>" <?  if($permissao["qt"] > 0) print "checked" ?> ><?= ucfirst($metodo->apelido) ?></span>
                <? } ?>
  				</li>    
            </ul>
        </form>
		</div>
		
	
    </div>
    
    <div class="push"></div>
  </div>
</div>

<? include("footer_view.php") ?>
