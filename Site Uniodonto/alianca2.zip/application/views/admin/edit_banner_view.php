<? include("header_view.php") ?>
   <div>
	<h1>Editar banners - <?= $banner->banner_titulo ?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        
       
			<form action="<?= site_url('admin/banners/editar/'.$banner->banner_id) ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
            	<a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/banners/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
				<input type="hidden" name="banner_id" value="<?= $banner->banner_id ?>" />
								
             <ul class="formulario">
             	<li> <span class="titulo">Título</span>   
                <input type="text" name="banner_titulo" value="<?= $banner->banner_titulo ?>" class="input-grande" /></li>
				<li> 
                	<div style="display:inline-block;">
                        <span class="titulo">Status</span> 
                        <div class="styled-select2">  
                        <select name="banner_status" class="select">
                            <option value="0" <? if($banner->banner_status == 0)print "selected" ?>>Não publicado</option>
                            <option value="1" <? if($banner->banner_status == 1)print "selected" ?>>Publicado</option>
                        </select>
                        </div>
                    </div>
                    <div style="display:inline-block;">
                        <span class="titulo">Idioma</span> 
                        <div class="styled-select2">  
                        <select name="banner_idioma" class="select">
                            <option value="ptBR" <? if($banner->banner_idioma == "ptBR")print "selected" ?>>Português</option>
                            <option value="en" <? if($banner->banner_idioma == "en")print "selected" ?>>Inglês</option>
                            <option value="es" <? if($banner->banner_idioma == "es")print "selected" ?>>Espanhol</option>
                        </select>
                        </div>
                    </div>
                    
				</li>
				<li> <span class="titulo">Seções</span> <br />  
				<span class="titulo2">Home </span>
				<input type="radio" name="banner_home" value="1" <? if($banner->banner_home == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_home" value="0" <? if($banner->banner_home == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Beneficiário </span>
				<input type="radio" name="banner_beneficiario" value="1" <? if($banner->banner_beneficiario == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_beneficiario" value="0" <? if($banner->banner_beneficiario == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Empresa</span>
				<input type="radio" name="banner_empresa" value="1" <? if($banner->banner_empresa == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_empresa" value="0" <? if($banner->banner_empresa == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Dentista </span>
				<input type="radio" name="banner_dentista" value="1" <? if($banner->banner_dentista == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_dentista" value="0" <? if($banner->banner_dentista == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Uniodonto </span>
				<input type="radio" name="banner_uniodonto" value="1" <? if($banner->banner_uniodonto == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_uniodonto" value="0" <? if($banner->banner_uniodonto == 0)print "checked" ?> /> Não<br />
				
				<span class="titulo2">Representante </span>
				<input type="radio" name="banner_representante" value="1" <? if($banner->banner_representante == 1)print "checked" ?> /> Sim
				<input type="radio" name="banner_representante" value="0" <? if($banner->banner_representante == 0)print "checked" ?> /> Não<br />
				</li>
				
				
				<li> <span class="titulo">Link ("http://www.linksite.com.br")</span> <br />  
				<input type="text" name="banner_link" value="<?= $banner->banner_link ?>" class="input-grande" /></li>
				
				<li> <span class="titulo">Imagen</span>   
				<input type="file" class="multi" accept="png|gif|jpg" maxlength="1" name="img" />
				
				<img src='<?=site_url().$banner->banner_img ?>' width="800">
				
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
