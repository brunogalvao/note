<? include('header_view.php'); ?>
	<div>
    <h1>Banners</h1>
	<? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>	
		<div class="pesquisa">
        		<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/banners/index/1") ?>" method="post">
            	
                <span>
                Status
                <select name="banner_status">
                	<option value="">Selecione</option>
                    <option value="1">Publicado</option>
                    <option value="0">Despublicado</option>
                </select>
               
                </span>
                <span>
                Página
                <select name="aba">
                	<option value="">Selecione</option>
                    <option value="banner_home">Home</option>
                    <option value="banner_beneficiario">Beneficiário</option>
                    <option value="banner_empresa">Empresa</option>
                    <option value="banner_dentista">Dentista</option>
                    <option value="banner_uniodonto">Uniodonto</option>
                    <option value="banner_colaborador">Colaborador</option>
                    <option value="banner_representante">Representante</option>
                </select>
                
                </span>
                <span>
                Título
                <input type="text" name="banner_titulo" class="input-pesquisa" />
                </span>
                <span style="width: 70px;">
				<input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar"/>
                </span>
                
            </form>
          	
            <a href="<?= site_url('admin/limparpesquisa/banners') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:600px;">Título</div>
          <div style="width:60px; text-align:center;">Status</div>
          <div style="text-align:center;">Editar/Apagar</div>
        </li>
        <? $i= 1; ?>
        <? foreach($banners as $banner){
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#ffffff";
				}
			?>
			
		    
          <li valign="middle" bgcolor="<?= $bg ?>" class="itens">
          	<div style="width:600px;">
                <span style="display:block;"><?= $banner->banner_titulo ?>
                <? if($banner->banner_idioma == "ptBR")print '<img  src="'.site_url().'images/icons/brasil_16x16.png"  />' ?>
                <? if($banner->banner_idioma == "en")print '<img  src="'.site_url().'images/icons/eua_16x16.png"  />' ?>
                <? if($banner->banner_idioma == "es")print '<img  src="'.site_url().'images/icons/spain_16x16.png"  />' ?>
                
                </span>
                <span style="display:block; font-weight:bold; font-size:12px;">
                    
                    <? if($banner->banner_home == 1)print " (Home) " ?>
                    <? if($banner->banner_beneficiario == 1)print " (Beneficiário) " ?>
                    <? if($banner->banner_empresa == 1)print " (Empresa) " ?>
                    <? if($banner->banner_dentista == 1)print " (Dentista) " ?>
                    <? if($banner->banner_uniodonto == 1)print " (Uniodonto) " ?>
                    <? if($banner->banner_colaborador == 1)print " (Colaborador) " ?>
                    <? if($banner->banner_representante == 1)print " (Representante) " ?>
                   
                   
                </span>
            </div>
          	<div style="width:60px; text-align:center;">
				<? if($banner->banner_status == 1){ 
                    print '<img src="'.site_url().'images/admin/ok-l.png" width="20" height="20" />';
				} ?>
            </div>
       
          	<div style="width:80px; text-align:center;">
                  <a href="<?= site_url('admin/banners/editar/'.$banner->banner_id) ?>" class="bt-editar" alt="Editar" title="Editar"></a> 
                  <a href="<?= site_url('admin/banners/excluir/'.$banner->banner_id) ?>" class="bt-excluir" alt="Excluir" title="Excluir"></a>
          	</div>
          </li>
        
        
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>  
      
	
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
    
	</div>
    
 	
<? include('footer_view.php'); ?>