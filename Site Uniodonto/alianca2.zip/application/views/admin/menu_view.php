
<ul>
	<li><a href="<?= site_url('admin/home')?>" class="menu-principal">Home</a></li>
	<li><a href="<?= site_url('admin/usuarios/')?>" class="menu-principal">Usu&aacute;rios</a>
    	<ul>
        	<li><a href="<?= site_url('admin/usuarios/adicionar')?>" class="menu-secundario">Adicionar Usu&aacute;rio</a></li> 
        </ul>
    </li> 
    <li><a href="<?= site_url('admin/propostas/')?>" class="menu-principal">Prospect</a>
    	<ul>
        	<li><a href="<?= site_url('admin/propostas/relatorio')?>" class="menu-secundario">Relat&oacute;rio</a></li>
        </ul>
    </li>   
	<li><a href="<?= site_url('admin/noticias')?>" class="menu-principal">Not&iacute;cias</a>
    	<ul>
        	<li><a href="<?= site_url('admin/noticias/adicionar')?>" class="menu-secundario">Adicionar Not&iacute;cia</a></li> 
        </ul>
    </li> 
	<li><a href="<?= site_url('admin/textos')?>" class="menu-principal">P&aacute;ginas institucionais</a>
    	<ul>
        	<li><a href="<?= site_url('admin/textos/adicionar')?>" class="menu-secundario">Adicionar p&aacute;gina</a></li> 
            </ul>
    </li> 
	<li><a href="<?= site_url('admin/textos_abas')?>" class="menu-principal">P&aacute;ginas restritas</a>
    	<ul>
            
            <li><a href="<?= site_url('admin/textos_abas/adicionar/beneficiario')?>" class="menu-secundario">Adicionar em benefici&aacute;rios</a></li>  
            <li><a href="<?= site_url('admin/textos_abas/adicionar/empresa')?>" class="menu-secundario">Adicionar em empresa</a></li> 
            <li><a href="<?= site_url('admin/textos_abas/adicionar/dentista')?>" class="menu-secundario">Adicionar em dentista</a></li> 
            <li><a href="<?= site_url('admin/textos_abas/adicionar/uniodonto')?>" class="menu-secundario">Adicionar em uniodonto</a></li> 
            <li><a href="<?= site_url('admin/textos_abas/adicionar/representante')?>" class="menu-secundario">Adicionar em representantes</a></li>
        </ul>
    </li> 
    <li><a href="<?= site_url('admin/links_abas')?>" class="menu-principal">Links restritos</a>
    	<ul>
            
            <li><a href="<?= site_url('admin/links_abas/adicionar/beneficiario')?>" class="menu-secundario">Adicionar em benefici&aacute;rios</a></li>  
            <li><a href="<?= site_url('admin/links_abas/adicionar/empresa')?>" class="menu-secundario">Adicionar em empresa</a></li> 
            <li><a href="<?= site_url('admin/links_abas/adicionar/dentista')?>" class="menu-secundario">Adicionar em dentista</a></li> 
            <li><a href="<?= site_url('admin/links_abas/adicionar/uniodonto')?>" class="menu-secundario">Adicionar em uniodonto</a></li> 

            <li><a href="<?= site_url('admin/links_abas/adicionar/representante')?>" class="menu-secundario">Adicionar em representantes</a></li>
        </ul>
    </li>  
	<li><a href="<?= site_url('admin/localizacao')?>" class="menu-principal">Localiza&ccedil;&atilde;o</a>
    	<ul>
        	<li><a href="<?= site_url('admin/localizacao/adicionar')?>" class="menu-secundario">Adicionar Endere&ccedil;o</a></li> 
        </ul>
    </li>    
    <li><a href="<?= site_url('admin/planos')?>" class="menu-principal">Planos</a></li>
    <li><a href="<?= site_url('admin/banners')?>" class="menu-principal">Banners</a>
    	<ul>
        	<li><a href="<?= site_url('admin/banners/adicionar')?>" class="menu-secundario">Adicionar banner</a></li> 
        </ul>
    </li>
    <li><a href="<?= site_url('admin/eventos')?>" class="menu-principal">Eventos</a>
    	<ul>
        	<li><a href="<?= site_url('admin/eventos/adicionar')?>" class="menu-secundario">Adicionar evento</a></li> 
        </ul>
    </li>
    <li><a href="<?= site_url('admin/upload/arquivosupload')?>" class="menu-principal">Enviar arquivos</a></li>
    <li><a href="<?= site_url('admin/upload/clientes')?>" class="menu-principal">Clientes</a></li>
    <li><a href="<?= site_url('admin/revistas')?>" class="menu-principal">Revistas</a>
    	<ul>
        	<li><a href="<?= site_url('admin/revistas/adicionar')?>" class="menu-secundario">Adicionar Revista</a></li> 
        </ul>
    </li>
	<li><a href="<?= site_url('admin/logout')?>" class="menu-principal">Sair</a></li>
</ul>
