<? include("header_view.php") ?>
   <div>
	<h1>Adicionar link restrito - <?= ucfirst($link_aba_aba)?></h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/links_abas/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/links_abas/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
			<input type="hidden" name="link_aba_aba" value="<?= $link_aba_aba?>"	 />                
              				
             <ul class="formulario">
             	<li> <span class="titulo">Menu</span>   
                <select name="link_aba_menu" class="select">
                     
                      <?= $menus_link ?>
                      
                 </select></li>
				<li> <span class="titulo">Título</span><br />
                	<img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                  	<input type="text" name="link_aba_titulo_ptBR" value="" class="input-grande" /></li>
                <li> 
                	<img  src="<?= site_url()?>images/icons/eua_16x16.png"  /> 
                  	<input type="text" name="link_aba_titulo_en" value="" class="input-grande" /></li> 
                <li> 
                	<img  src="<?= site_url()?>images/icons/spain_16x16.png"  /> 
                  	<input type="text" name="link_aba_titulo_es" value="" class="input-grande" /></li>  				
				<li> <span class="titulo">link</span>
                    <input type="text" name="link_aba_link" value="" class="input-grande" />
                    <i style="padding-left:10px;">Exemplo: http://www.url.com.br</i></li>
				</li>
		
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
