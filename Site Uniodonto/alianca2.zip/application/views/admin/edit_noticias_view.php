<? include("header_view.php") ?>
   <div>
	<h1>Editar notícia - <?= $noticia->noticia_titulo_ptBR ?></h1> 
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        
       
			<form action="<?= site_url('admin/noticias/editar/'.$noticia->noticia_id) ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
            	<a href="<?= site_url('admin/noticias/visualizar/'.$noticia->noticia_id) ?>" target="_blank" class="bt-voltar" alt="Visualizar" title="Visualizar">Visualizar</a>
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/noticias/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
				<input type="hidden" name="noticia_id" value="<?= $noticia->noticia_id ?>" />
				
             <ul class="formulario">
             	<li> <span class="titulo">Título</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />   
                <input type="text" name="noticia_titulo_ptBR" value="<?= $noticia->noticia_titulo_ptBR ?>" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <input type="text" name="noticia_titulo_en" value="<?= $noticia->noticia_titulo_en ?>" class="input-grande" /></li>
                <li>
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <input type="text" name="noticia_titulo_es" value="<?= $noticia->noticia_titulo_es ?>" class="input-grande" /></li>
				<li> 
                	<div style="display:inline-block;">
                        <span class="titulo">Status</span> 
                        <div class="styled-select2">  
                        <select name="noticia_status" class="select">
                            <option value="0" <? if($noticia->noticia_status == 0)print "selected" ?>>N&atilde;o Publicado</option>
                            <option value="1" <? if($noticia->noticia_status == 1)print "selected" ?>>Publicado</option>
                        </select>
                        </div>
                    </div>
                    <div style="display:inline-block; ">    
                        <span class="titulo">Destaque</span> 
                        <div class="styled-select2">  
                        <select name="noticia_destaque" class="select">
                            <option value="0" <? if($noticia->noticia_destaque == 0)print "selected" ?> >NÃO</option>
                            <option value="1" <? if($noticia->noticia_destaque == 1)print "selected" ?> >SIM</option>					
                        </select>
                        </div>
                    </div>
                    <?
					$data = explode(" ", $noticia->noticia_data);
					$data = explode("-", $data[0]);
					$data_final = $data[2]."/".$data[1]."/".$data[0];
					 ?>
                    <div style="display:inline-block;">    
                        <span class="titulo">Data</span> 
                        <div class="styled-select2"> 
                        <input type="text" name="noticia_data" value="<?=$data_final?>" class="data" />
                        </div>
                    </div> 
                    <div style="display:inline-block; ">    
                        <span class="titulo">Posi&ccedil;&atilde;o</span> 
                        <div class="styled-select2">  
                        <select name="noticia_posicao" class="select">
                            <option value="1" <? if($noticia->noticia_posicao == 1)print "selected" ?> >1</option>
                            <option value="2" <? if($noticia->noticia_posicao == 2)print "selected" ?> >2</option>
                            <option value="3" <? if($noticia->noticia_posicao == 3)print "selected" ?> >3</option>
                            <option value="4" <? if($noticia->noticia_posicao == 4)print "selected" ?> >4</option>					
                        </select>
                        </div>
                    </div>
				</li>
				<li> <span class="titulo">Seções</span> <br />  
				<span class="titulo2">Home </span>
				<input type="radio" name="noticia_home" value="1" <? if($noticia->noticia_home == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_home" value="0" <? if($noticia->noticia_home == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Beneficiário </span>
				<input type="radio" name="noticia_beneficiario" value="1" <? if($noticia->noticia_beneficiario == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_beneficiario" value="0" <? if($noticia->noticia_beneficiario == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Empresa</span>
				<input type="radio" name="noticia_empresa" value="1" <? if($noticia->noticia_empresa == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_empresa" value="0" <? if($noticia->noticia_empresa == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Dentista </span>
				<input type="radio" name="noticia_dentista" value="1" <? if($noticia->noticia_dentista == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_dentista" value="0" <? if($noticia->noticia_dentista == 0)print "checked" ?> /> Não<br />
				<span class="titulo2">Uniodonto </span>
				<input type="radio" name="noticia_uniodonto" value="1" <? if($noticia->noticia_uniodonto == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_uniodonto" value="0" <? if($noticia->noticia_uniodonto == 0)print "checked" ?> /> Não<br />
				
				<span class="titulo2">Representante </span>
				<input type="radio" name="noticia_representante" value="1" <? if($noticia->noticia_representante == 1)print "checked" ?> /> Sim
				<input type="radio" name="noticia_representante" value="0" <? if($noticia->noticia_representante == 0)print "checked" ?> /> Não<br />
				</li>
				
				
				<li> <span class="titulo">Texto</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />   
                <textarea name="noticia_texto_ptBR" cols="5" rows="5" class="ckeditor"><?= $noticia->noticia_texto_ptBR ?></textarea></li>
                <li><img  src="<?= site_url()?>images/icons/eua_16x16.png"  /> 
                <textarea name="noticia_texto_en" cols="5" rows="5" class="ckeditor"><?= $noticia->noticia_texto_en ?></textarea></li>
                <li><img  src="<?= site_url()?>images/icons/spain_16x16.png"  /> 
                <textarea name="noticia_texto_es" cols="5" rows="5" class="ckeditor"><?= $noticia->noticia_texto_es ?></textarea></li>
				
				<li> <span class="titulo">Imagens </span><br /> 
                <i>Somente imagens JPG</i><br />   
				<input type="file" class="multi" accept="jpg|jpeg" name="img[]" />
				
				
				<?
					$noticia_imgs = explode(";",$noticia->noticia_imgs);
					foreach($noticia_imgs as $img){
						print "<div class='img'>";
						if($img != ""){
							$noticia_img_thumb = explode(".",$img);
							print "<img src='".site_url()."images/noticias/".$noticia_img_thumb[0]."_medium.".$noticia_img_thumb[1]."' >";
							print '<a href="'.site_url('admin/noticias/exclui_img/'.$noticia->noticia_id.'/'.$img).'" class="bt-excluir" alt="Excluir" title="Excluir"></a>';
							print "<br />";
						}	
						print "</div>";
					}


				?>
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
