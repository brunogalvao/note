<? include("header_view.php") ?>
   <div>
	<h1>Adicionar página: <?= ucfirst($texto_aba_aba) ?></h1> 
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/textos_abas/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/textos_abas/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
			<input type="hidden" name="texto_aba_aba" value="<?= $texto_aba_aba?>"	 />                
              				
             <ul class="formulario">
             	<li> <span class="titulo">Menu</span>   
                <select name="texto_aba_menu" class="select">
                     
                     <?= $menus_texto ?>
                      
                 </select></li>
				<li> <span class="titulo">Título</span><br /> 
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                  <input type="text" name="texto_aba_titulo_ptBR" value="" class="input-grande" /></li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />   
                  <input type="text" name="texto_aba_titulo_en" value="" class="input-grande" /></li>
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />   
                  <input type="text" name="texto_aba_titulo_es" value="" class="input-grande" /></li>    				
				<li> <span class="titulo">Texto</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                <textarea name="texto_aba_texto_ptBR" cols="5" rows="5" class="ckeditor"></textarea>
				</li>
                <li><img  src="<?= site_url()?>images/icons/eua_16x16.png"  /> 
                <textarea name="texto_aba_texto_en" cols="5" rows="5" class="ckeditor"></textarea>
				</li>
               	<li><img  src="<?= site_url()?>images/icons/spain_16x16.png"  /> 
                <textarea name="texto_aba_texto_es" cols="5" rows="5" class="ckeditor"></textarea>
				</li>
				
				<li> <span class="titulo">Imagens</span>   
				<input type="file" class="multi" accept="gif|jpg|png" name="teste[]" />
				
				
				</li>
				
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
