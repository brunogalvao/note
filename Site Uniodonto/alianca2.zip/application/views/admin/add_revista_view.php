<? include("header_view.php") ?>


   <div>
	<h1>Adicionar revista</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
   	
		<div>
			<form action="<?= site_url('admin/revistas/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/revistas/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
             <ul class="formulario">
             	<li> <span class="titulo">Título</span> <br />  
                <input type="text" name="revista_titulo" value="" class="input-grande" style="width:340px;"/></li>
				
				
				
				<li> <span class="titulo">Capa</span>
									
				<input type="file" class="multi" accept="png|gif|jpg" maxlength="1" name="capa" />
				
				
				</li>
				<li> <span class="titulo">Revista PDF</span>
									
				<input type="file" class="multi" accept="pdf" maxlength="1" name="pdf" />
				
				
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
