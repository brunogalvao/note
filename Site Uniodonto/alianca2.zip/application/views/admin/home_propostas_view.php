<? include('header_view.php'); ?>
		
<div class="home">
	<img src="<?=site_url()?>images/logo-prospect.png" title="Prospect"> 
	<div class="propostas">
    	<span>
        	<h1>Hoje</h1>
        	<h2><?= $propostas_hoje ?></h2>
        </span>
        <span>
        	<h1>7 dias</h1>
        	<h2><?= $propostas_semana ?></h2>
        </span>
        <span>
        	<h1>30 dias</h1>
        	<h2><?= $propostas_mes ?></h2>
        </span>
        
    </div>
    <div class="ranking">
        <h1>Representante com mais contratos nos &uacute;ltimos 30 dias</h1>

			<?
			$i= 1; 
            foreach($ranking as $representante){ ?>
            	<div class="pos <?= $i?>">
                	<span class="pos"><?= $i?>º</span>
                    <span class="total">
                    <? print_r( $representante->total) ?> contratos - 
                    </span>
                    
                    <span class="nome">
                        (<?= $representante->proposta_cod_rep ?>)
                        <?= $representante->proposta_nome_rep ?>
                    </span>
                    
                </div>
            <? $i++; } ?>
    </div>
										

</div>		
		
<? include('footer_view.php'); ?>