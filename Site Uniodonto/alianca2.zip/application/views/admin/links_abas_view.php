<? include("header_view.php") ?>
        
    <div>
    <h1>Links restritos</h1>
    <? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
        <div class="pesquisa">
        	<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/links_abas/index/1") ?>" method="post">
            	<select name="aba">
                	<option value="">Selecione</option>
                    <option value="home">Home</option>
                    <option value="beneficiario">Beneficiário</option>
                    <option value="empresa">Empresa</option>
                    <option value="dentista">Dentista</option>
                    <option value="uniodonto">Uniodonto</option>
                    <option value="colaborador">Colaborador</option>
                    <option value="representante">Representante</option>
                </select>
            	<input type="text" name="link_aba_titulo" class="input-pesquisa" />
				<input type="submit" name="Buscar" value="Buscar" class="bt-pesquisar" />
            </form>
            <a href="<?= site_url('admin/limparpesquisa/links_abas') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:520px;">Titulo</div>
          <div style="width:150px;">Aba</div>
          <div style="width:80px; text-align:center;">Editar/Excluir</div>
        </li>
        <? $i= 1; ?>
        <? foreach($links_abas as $link){
			
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
			?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:520px;"><?= ucfirst($link->link_aba_titulo_ptBR) ?></div>
          <div style="width:150px;">
		  <?= ucfirst($link->link_aba_aba) ?></div>
          <div style="width:80px; text-align:center;"><a href="<?= site_url('admin/links_abas/editar/'.$link->link_aba_id) ?>" class="bt-editar"></a>
          <a href="<?= site_url('admin/links_abas/excluir/'.$link->link_aba_id) ?>" class="bt-excluir"></a>
          </div>
        </li>
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
