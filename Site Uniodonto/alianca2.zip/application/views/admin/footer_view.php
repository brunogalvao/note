	</div>
	</div>
    <div class="rodape">
        <img src="<?= site_url('images/admin/logo_trade.png') ?>" alt="TradeSystem" border="0">
    </div>
</div>
</body>
</html>