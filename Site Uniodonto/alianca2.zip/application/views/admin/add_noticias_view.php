<? include("header_view.php") ?>


   <div>
	<h1>Adicionar notícia</h1> 
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
   	
		<div>
			<form action="<?= site_url('admin/noticias/adicionar') ?>" method="post" enctype="multipart/form-data" id="form">
            <div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/noticias/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
             <ul class="formulario">
             	<li> <span class="titulo">Título</span><br /><img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />   
                <input type="text" name="noticia_titulo_ptBR" value="" class="input-grande" /> </li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <input type="text" name="noticia_titulo_en" value="" class="input-grande" /> </li>
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <input type="text" name="noticia_titulo_es" value="" class="input-grande" /> </li>
				<li>  
                    <div style="display:inline-block;">
                    	<span class="titulo">Status</span>
                        <div class="styled-select2">   
                        <select name="noticia_status" class="select">
                            <option value="0" selected="selected">N&atilde;o Publicado</option>
                            <option value="1">Publicado</option>
                        </select>
                        </div>
                    </div>
                    <div style="display:inline-block;">    
                        <span class="titulo">Destaque</span> 
                        <div class="styled-select2">   
                        <select name="destaque" class="select">
                            <option value="1">SIM</option>
                            <option value="0">NÃO</option>
                        </select>
                        </div>
                    </div> 
                    
                    <div style="display:inline-block;">    
                        <span class="titulo">Data</span> 
                        <div class="styled-select2"> 
                        <input type="text" name="noticia_data" value="<?= date("d/m/Y");?>" class="data" />
                        </div>
                    </div>
                    <div style="display:inline-block;">    
                        <span class="titulo">Posi&ccedil;&atilde;o</span> 
                        <div class="styled-select2">   
                        <select name="noticia_posicao" class="select">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                        </select>
                        </div>
                    </div>    
				</li>
				<li> <span class="titulo">Seções</span><br />   
                <span class="titulo2">Home </span>
				<input type="radio" name="noticia_home" value="1" checked /> Sim
				<input type="radio" name="noticia_home" value="0" /> Não<br />
				<span class="titulo2">Beneficiário </span>
				<input type="radio" name="noticia_beneficiario" value="1" /> Sim
				<input type="radio" name="noticia_beneficiario" value="0" checked /> Não<br />
				<span class="titulo2">Empresa </span>
				<input type="radio" name="noticia_empresa" value="1" /> Sim
				<input type="radio" name="noticia_empresa" value="0" checked /> Não<br />
				<span class="titulo2">Dentista </span>
				<input type="radio" name="noticia_dentista" value="1" /> Sim
				<input type="radio" name="noticia_dentista" value="0" checked /> Não<br />
				<span class="titulo2">Uniodonto </span>
				<input type="radio" name="noticia_uniodonto" value="1"  /> Sim
				<input type="radio" name="noticia_uniodonto" value="0" checked /> Não<br />
				<span class="titulo2">Representante</span> 
				<input type="radio" name="noticia_representante" value="1"  /> Sim
				<input type="radio" name="noticia_representante" value="0" checked /> Não<br />
				</li>
				
				
				<li> <span class="titulo">Texto</span> <br/>
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                <textarea name="noticia_texto_ptBR" cols="5" rows="5" class="ckeditor"></textarea></li>
                <li> <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <textarea name="noticia_texto_en" cols="5" rows="5" class="ckeditor"></textarea></li>
                <li> <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <textarea name="noticia_texto_es" cols="5" rows="5" class="ckeditor"></textarea></li>
				
				<li> <span class="titulo">Imagens</span>
                <br /> 
                <i>Somente imagens JPG</i><br />   
									
				<input type="file" class="multi" accept="jpg|jpeg" name="teste[]" />
				
				
				</li>
				
		
				

				
                     
            
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
