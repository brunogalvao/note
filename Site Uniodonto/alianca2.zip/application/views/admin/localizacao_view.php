<? include("header_view.php") ?>
        
    <div>
    <h1>Endereços</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div class="pesquisa">
        	<h2>Pesquisar</h2>
			<form action="<?= site_url("admin/localizacao/index/1") ?>" method="post">
            	<input type="text" name="pesquisa" class="input-pesquisa" />
				<input type="submit" name="Buscar" value="Busca" class="bt-pesquisar" />
            </form>
            <a href="<?= site_url('admin/limparpesquisa/localizacao') ?>" alt="Limpar" title="Limpar" class="link">Limpar pesquisa</a> 
		</div>
	  <div class="qt-resultado"><?= $qt ?> registro(s) encontrado(s)</div>	
      <ul class="lista">
        <li class="cabecalho">
          <div style="width:260px;">Nome</div>
          <div style="width:410px;">Endereco</div>
          <div style="width:80px;">Editar/Apagar</div>
        </li>
        <? 
		$i = 1;
		foreach($localizacao as $local){
			
			if($i % 2 == 0){
				$bg = "#dfdfdf";
				}else{
				$bg = "#fff";
				}
			?>
			
		<li class="itens" style="background:<?=$bg ?>;">
          <div style="width:260px;"><?= $local->localizacao_titulo_ptBR ?></div>
          <div style="width:410px;"><?= $local->localizacao_endereco_ptBR ?></div>
          <div style="width:80px; text-align:center;"><a href="<?= site_url('admin/localizacao/editar/'.$local->localizacao_id) ?>" class="bt-editar"></a> <a href="<?= site_url('admin/localizacao/excluir/'.$local->localizacao_id) ?>" class="bt-excluir"></a></div>
        </li>
		
		
		<? $i ++; } ?>
        
        
        
        
      </ul>
      
	
    
    
	</div>
    <div class="paginacao">
    <?php echo $paginacao; ?>
    </div>
<? include("footer_view.php") ?>
