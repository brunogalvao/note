<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administração - Uniodonto Curitiba</title>
	<link type="image/x-icon" href="<?= site_url()?>images/admin/favicon.ico" rel="shortcut icon">
	<link href="<?= site_url()?>css/css_admin2.css" rel="stylesheet" type="text/css"/>
    <link href="<?= site_url()?>css/uniform.default_admin.css" rel="stylesheet" type="text/css"/>
    <script src='<?= site_url()?>js/jquery.js' type="text/javascript"></script>
    <script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>
    <script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
    <script type="text/javascript" charset="utf-8">
		$(function(){
			$("input").uniform();
			$("select").uniform();
			
		});
	</script>
	
	</head>

	<body>
        <div class="login">
        	<div class="topo">
            	<span><img src="<?= site_url()?>images/admin/logo_sio.png" /></span>
                <span>
            	<h2>&Aacute;rea Administrativa</h2>
				<h1>Uniodonto Curitiba</h1>
                </span>
                
            </div> 
            <div class="tit-login">
            	<span><img src="<?= site_url()?>images/admin/lock.png" /> Email
                </span>
                <span>Senha</span>
                
                </div>   
			<div class="form_login">
				<div class="error">
				<?php echo validation_errors();
					  if(isset($error)){
						print $error;
					  }
				?>
                </div>
				<?php
				echo form_open(site_url("admin/login/dologin"));


				echo form_input('user_email','' ,'class="input-login"');

				echo form_password('user_senha','', 'class="input-login"');

				echo form_submit('submit', 'Entrar', 'class="bt-submit"');
				?>
				<?php form_close(); ?>
			</div>
            <div class="trade"><img src="<?= site_url()?>images/admin/logo_trade.png" /></div>
		</div>

</body>
</html>
