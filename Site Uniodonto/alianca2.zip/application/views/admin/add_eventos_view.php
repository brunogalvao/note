<? include("header_view.php") ?>
<script type="text/javascript">
			
			$(document).ready( function() {
				
				
				//
				// Enabling miniColors
				//
				
				$(".color-picker").miniColors({
					letterCase: 'uppercase',
					change: function(hex, rgb) {
						logData('change', hex, rgb);
					},
					open: function(hex, rgb) {
						logData('open', hex, rgb);
					},
					close: function(hex, rgb) {
						logData('close', hex, rgb);
					}
				});
				
				
				//
				// Only for the demo
				//
				
				function logData(type, hex, rgb) {
					$("#console").prepend(type + ': HEX = ' + hex + ', RGB = (' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ')<br />');
				}
				
				$("#disable").click( function() {
					$("#console").prepend('disable<br />');
					$(".color-picker").miniColors('disabled', true);
					$("#disable").prop('disabled', true);
					$("#enable").prop('disabled', false);
				});
				
				$("#enable").click( function() {
					$("#console").prepend('enable<br />');
					$(".color-picker").miniColors('disabled', false);
					$("#disable").prop('disabled', false);
					$("#enable").prop('disabled', true);
				});
				
				$("#makeReadonly").click( function() {
					$("#console").prepend('readonly = true<br />');
					$(".color-picker").miniColors('readonly', true);
					$("#unmakeReadonly").prop('disabled', false);
					$("#makeReadonly").prop('disabled', true);
				});
				
				$("#unmakeReadonly").click( function() {
					$("#console").prepend('readonly = false<br />');
					$(".color-picker").miniColors('readonly', false);
					$("#unmakeReadonly").prop('disabled', true);
					$("#makeReadonly").prop('disabled', false);
				});
				
				$("#destroy").click( function() {
					$("#console").prepend('destroy<br />');
					$(".color-picker").miniColors('destroy');
					$("INPUT[type=button]:not(#create)").prop('disabled', true);
					$("#destroy").prop('disabled', true);
					$("#create").prop('disabled', false);
				});
				
				$("#create").click( function() {
					$("#console").prepend('create<br />');
					$(".color-picker").miniColors({
						letterCase: 'uppercase',
						change: function(hex, rgb) {
							logData('change', hex, rgb);
						},
						open: function(hex, rgb) {
							logData('open', hex, rgb);
						},
						close: function(hex, rgb) {
							logData('close', hex, rgb);
						}
					});
					$("#makeReadonly, #disable, #destroy, #randomize").prop('disabled', false);
					$("#destroy").prop('disabled', false);
					$("#create").prop('disabled', true);
				});
				
				$("#randomize").click( function() {
					$(".color-picker").miniColors('value', '#' + Math.floor(Math.random() * 16777215).toString(16));
				});
				
				
			});
			
		</script>


   <div>
	<h1>Adicionar evento</h1>
    <? if($this->session->flashdata('msg')) {
		 print '<div class="error-2">'. $this->session->flashdata('msg').'</div>'; 
	}?>
		<div>
        	<div class="botoes">
                <a href="javascript: submitform()" class="bt-salvar" alt="Salvar" title="Salvar">Salvar</a>
                <a href="<?= site_url('admin/eventos/') ?>" class="bt-voltar" alt="Voltar" title="Voltar">Voltar</a>
            </div>
			<form action="<?= site_url('admin/eventos/adicionar/') ?>" method="post" enctype="multipart/form-data" id="form">
          
              				
             <ul class="formulario">
				<li> <span class="titulo">Título</span><br />
                <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                <input type="text" name="evento_titulo_ptBR" value="" class="input-grande" /></li>	
                <li> 
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  /> 
                <input type="text" name="evento_titulo_en" value="" class="input-grande" /></li>
                <li> 
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  /> 
                <input type="text" name="evento_titulo_es" value="" class="input-grande" /></li>
                 			
				<li> <span class="titulo">Data inicial</span>   
                  <input type="text" name="evento_inicio" value="" class="data" />  <span class="titulo">Data final</span>   
                  <input type="text" name="evento_fim" value="" class="data" /></li>
                
                <li> <span class="titulo">Cor das letras</span>   
                  <input type="text" name="evento_corfont" class="color-picker" size="7" value="#ffffff" />  <span class="titulo">Cor do fundo</span>   
                  <input type="text" name="evento_corbg" class="color-picker" size="7" value="#af2638" /></li>      
				<li> <span class="titulo">Texto</span><br /> <img  src="<?= site_url()?>images/icons/brasil_16x16.png"  />  
                <textarea name="evento_texto_ptBR" cols="5" rows="5" class="ckeditor"></textarea></li> 
                <li>
                <img  src="<?= site_url()?>images/icons/eua_16x16.png"  />  
                <textarea name="evento_texto_en" cols="5" rows="5" class="ckeditor"></textarea></li>
                <li>
                <img  src="<?= site_url()?>images/icons/spain_16x16.png"  />  
                <textarea name="evento_texto_es" cols="5" rows="5" class="ckeditor"></textarea></li>
		
            </ul>
        </form>
		</div>
		
	
    </div>
    

  </div>
</div>

<? include("footer_view.php") ?>
