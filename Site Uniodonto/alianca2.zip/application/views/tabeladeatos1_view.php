<? include("header_view.php"); ?>
    <div class="nav"> <a href="<?=site_url()?>">Home</a> / Tabela de Atos </div>
    <div class="conteudo-left">
          <div class="texto">
        <h1>Tabela de Atos - P&aacute;gina 1 de 5</h1>
        <table cellpadding="0" cellspacing="0" class="tabela-atos">
	<tbody>
		<tr>
			<th width="70">
				TUSS</th>
			<th>
				PROCEDIMENTOS ODONTOL&Oacute;GICOS</th>
			<th width="30">
				USO</th>
			<th width="40">
				0,15</th>
			<th width="40">
				0,18</th>
		</tr>
		<tr>
			<th class="titulo2" colspan="6">
				EMERG&Ecirc;NCIA</th>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				82000468</td>
			<td>
				Controle de hemorragia com Aplica&ccedil;&atilde;o de Agente Hemost&aacute;tico em regi&atilde;o buco-maxilo-facial</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				82000484</td>
			<td>
				Controle de hemorragia sem Aplica&ccedil;&atilde;o de Agente Hemost&aacute;tico em regi&atilde;o buco-maxilo-facial</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				85200034</td>
			<td>
				Tratamento em odontalgia aguda&nbsp;</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				85300020</td>
			<td>
				Imobiliza&ccedil;&atilde;o dent&aacute;ria em dentes permanentes</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				85000787</td>
			<td>
				Imobiliza&ccedil;&atilde;o dent&aacute;ria em dentes dec&iacute;duos</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				85400467</td>
			<td>
				Recimenta&ccedil;&atilde;o de trabalho prot&eacute;tico</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				82001650</td>
			<td>
				Tratamento de alveolite</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				85100048</td>
			<td>
				Colagem de fragmentos dent&aacute;rios</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				82001022</td>
			<td>
				Incis&atilde;o e drenagem Extra-Oral de abscesso, hematoma e/ou flegm&atilde;o da regi&atilde;o buco-maxilo-facial</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				82001030</td>
			<td>
				Incis&atilde;o e drenagem Intra-Oral de abscesso, hematoma e/ou flegm&atilde;o da regi&atilde;o buco-maxilo-facial</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				85300063</td>
			<td>
				Tratamento de Abscesso Periodontal agudo</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				82001251</td>
			<td>
				Reimplante de dente com conten&ccedil;&atilde;o</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				82001499</td>
			<td>
				Sutura de ferida em regi&atilde;o buco-maxilo-facial</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				82001197</td>
			<td>
				Redu&ccedil;&atilde;o simples de Luxa&ccedil;&atilde;o de Articula&ccedil;&atilde;o T&ecirc;mporo-mandibular (ATM)</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				82001642</td>
			<td>
				Tratamento conservador de luxa&ccedil;&atilde;o da articula&ccedil;&atilde;o t&ecirc;mporo-mandibular - ATM</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr>
			<td>
				85100056</td>
			<td>
				Curativo de demora em endodontia</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				85300080</td>
			<td>
				Tratamento de pericoronarite</td>
			<td>
				11</td>
			<td>
				1,65</td>
			<td>
				1,98</td>
		</tr>
	</tbody>
</table>
<p>
	&nbsp;</p>
<table cellpadding="0" cellspacing="0" class="tabela-atos">
	<tbody>
		<tr>
			<th width="70">
				TUSS</th>
			<th>
				PROCEDIMENTOS ODONTOL&Oacute;GICOS</th>
			<th width="30">
				USO</th>
			<th width="40">
				0,15</th>
			<th width="40">
				0,18</th>
		</tr>
		<tr bgcolor="#FFCCCC">
			<th class="titulo2" colspan="6">
				DIAGN&Oacute;STICO</th>
		</tr>
		<tr>
			<td>
				81000030</td>
			<td>
				Consulta odontol&oacute;gica</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000065</td>
			<td>
				Consulta odontologica inicial</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr>
			<td>
				81000049</td>
			<td>
				Consulta odontologica de Urg&ecirc;ncia</td>
			<td>
				118</td>
			<td>
				17,70</td>
			<td>
				21,24</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000057</td>
			<td>
				Consulta odontologica de Urg&ecirc;ncia 24 hs</td>
			<td>
				204</td>
			<td>
				30,60</td>
			<td>
				36,72</td>
		</tr>
		<tr>
			<td>
				81000073</td>
			<td>
				Consulta para avalia&ccedil;&atilde;o t&eacute;cnica de auditoria</td>
			<td>
				66</td>
			<td>
				9,90</td>
			<td>
				11,88</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000090</td>
			<td>
				Consulta para t&eacute;cnica de clareamento dent&aacute;rio caseiro</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr>
			<td>
				81000189</td>
			<td>
				Diagn&oacute;stico e planejamento para tratamento odontol&oacute;gico</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000197</td>
			<td>
				Diagn&oacute;stico e tratamento de estomatite herp&eacute;tica</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr>
			<td>
				81000200</td>
			<td>
				Diagn&oacute;stico e tratamento de estomatite por candidose</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000219</td>
			<td>
				Diagn&oacute;stico e tratamento de halitose</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr>
			<td>
				81000235</td>
			<td>
				Diagn&oacute;stico e tratamento de xerostomia</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000140</td>
			<td>
				Falta n&atilde;o justificada</td>
			<td>
				202</td>
			<td>
				30,30</td>
			<td>
				36,36</td>
		</tr>
	</tbody>
</table>
<p>
	&nbsp;</p>
<p>
	&nbsp;</p>
<table cellpadding="0" cellspacing="0" class="tabela-atos">
	<tbody>
		<tr>
			<th width="70">
				TUSS</th>
			<th>
				PROCEDIMENTOS ODONTOL&Oacute;GICOS</th>
			<th width="30">
				USO</th>
			<th width="40">
				0,15</th>
			<th width="40">
				0,18</th>
		</tr>
		<tr>
			<th class="titulo2" colspan="6">
				RADIOLOGIA</th>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000421</td>
			<td>
				RX Periapical&nbsp;</td>
			<td>
				39</td>
			<td>
				5,85</td>
			<td>
				7,02</td>
		</tr>
		<tr>
			<td>
				81000294</td>
			<td>
				Levantamento radiogr&aacute;fico (Exame Radiod&ocirc;ntico)</td>
			<td>
				457</td>
			<td>
				68,55</td>
			<td>
				82,26</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000375</td>
			<td>
				RX interproximal - bite-wing</td>
			<td>
				39</td>
			<td>
				5,85</td>
			<td>
				7,02</td>
		</tr>
		<tr>
			<td>
				81000383</td>
			<td>
				Radiografia oclusal</td>
			<td>
				104</td>
			<td>
				15,60</td>
			<td>
				18,72</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000430</td>
			<td>
				RX postero-anterior</td>
			<td>
				157</td>
			<td>
				23,55</td>
			<td>
				28,26</td>
		</tr>
		<tr>
			<td>
				81000324</td>
			<td>
				RX antero-posterior</td>
			<td>
				157</td>
			<td>
				23,55</td>
			<td>
				28,26</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000340</td>
			<td>
				RX da ATM&nbsp;</td>
			<td>
				354</td>
			<td>
				53,10</td>
			<td>
				63,72</td>
		</tr>
		<tr>
			<td>
				81000405</td>
			<td>
				Radiografia panor&acirc;mica de mand&iacute;bula / maxila (ortopantomografia)</td>
			<td>
				146</td>
			<td>
				21,90</td>
			<td>
				26,28</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000413</td>
			<td>
				Radiografia panor&acirc;mica de mand&iacute;bula / maxila (ortopantomografia) com tra&ccedil;ado cefalom&eacute;trico</td>
			<td>
				177</td>
			<td>
				26,55</td>
			<td>
				31,86</td>
		</tr>
		<tr>
			<td>
				81000480</td>
			<td>
				Telerradiografia com tra&ccedil;ado cefalom&eacute;trico</td>
			<td>
				206</td>
			<td>
				30,90</td>
			<td>
				37,08</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000472</td>
			<td>
				Telerradiografia</td>
			<td>
				157</td>
			<td>
				23,55</td>
			<td>
				28,26</td>
		</tr>
		<tr>
			<td>
				81000537</td>
			<td>
				Tra&ccedil;ado cefalom&eacute;trico</td>
			<td>
				61</td>
			<td>
				9,15</td>
			<td>
				10,98</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000367</td>
			<td>
				RX m&atilde;o e punho - carpal</td>
			<td>
				119</td>
			<td>
				17,85</td>
			<td>
				21,42</td>
		</tr>
		<tr>
			<td>
				81000308</td>
			<td>
				Modelos ortod&ocirc;nticos</td>
			<td>
				81</td>
			<td>
				12,15</td>
			<td>
				14,58</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000305</td>
			<td>
				Fotos e slides (5 fotos e 7 slides) (somente em laborat&oacute;rios de radiologia)</td>
			<td>
				358</td>
			<td>
				53,70</td>
			<td>
				64,44</td>
		</tr>
		<tr>
			<td>
				81000456</td>
			<td>
				Slide</td>
			<td>
				54</td>
			<td>
				8,10</td>
			<td>
				9,72</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000315</td>
			<td>
				Fotos e slides (por unidade)</td>
			<td>
				48</td>
			<td>
				7,20</td>
			<td>
				8,64</td>
		</tr>
		<tr>
			<td>
				81000278</td>
			<td>
				Fotografia</td>
			<td>
				41</td>
			<td>
				6,15</td>
			<td>
				7,38</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000330</td>
			<td>
				Seio Frontal - c&oacute;digo diferenciado para aumento de cobertura</td>
			<td>
				144</td>
			<td>
				21,60</td>
			<td>
				25,92</td>
		</tr>
		<tr>
			<td>
				00000340</td>
			<td>
				Seio Nasal - c&oacute;digo diferenciado para aumento de cobertura</td>
			<td>
				144</td>
			<td>
				21,60</td>
			<td>
				25,92</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000345</td>
			<td>
				Documenta&ccedil;&atilde;o Ortod&ocirc;ntica &quot;A&quot; (radiografia panor&acirc;mica, telerradiografia, 01 tra&ccedil;ado cefalom&eacute;trico, 05 fotos e 05 slides (frente, perfil e intrabucais), modelo de estudo superior e inferior)</td>
			<td>
				646</td>
			<td>
				96,90</td>
			<td>
				116,28</td>
		</tr>
		<tr>
			<td>
				00000346</td>
			<td>
				Documenta&ccedil;&atilde;o Ortod&ocirc;ntica &quot;B&quot; (radiografia panor&acirc;mica, telerradiografia, 01 tra&ccedil;ado cefalom&eacute;trico, 05 fotos (frente, perfil e intrabucais), modelo de estudo superior e inferior)</td>
			<td>
				586</td>
			<td>
				87,90</td>
			<td>
				105,48</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				00000348</td>
			<td>
				Documenta&ccedil;&atilde;o Ortod&ocirc;ntica &quot;E&quot; (radiografia panor&acirc;mica, telerradiografia, 01 tra&ccedil;ado cefalom&eacute;trico, 02 fotos (frente e perfil), modelo de estudo superior e inferior)</td>
			<td>
				454</td>
			<td>
				68,10</td>
			<td>
				81,72</td>
		</tr>
	</tbody>
</table>
<p>
	&nbsp;</p>
<p>
	&nbsp;</p>
<table cellpadding="0" cellspacing="0" class="tabela-atos">
	<tbody>
		<tr>
			<th width="70">
				TUSS</th>
			<th>
				PROCEDIMENTOS ODONTOL&Oacute;GICOS</th>
			<th width="30">
				USO</th>
			<th width="40">
				0,15</th>
			<th width="40">
				0,18</th>
		</tr>
		<tr>
			<th class="titulo2" colspan="6">
				EXAMES DE LABORAT&Oacute;RIO</th>
		</tr>
		<tr>
			<td>
				84000244</td>
			<td>
				Teste de fluxo salivar</td>
			<td>
				177</td>
			<td>
				26,55</td>
			<td>
				31,86</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				84000228</td>
			<td>
				Teste de capacidade tamp&atilde;o da saliva</td>
			<td>
				177</td>
			<td>
				26,55</td>
			<td>
				31,86</td>
		</tr>
		<tr>
			<td>
				84000252</td>
			<td>
				Teste de PH salivar</td>
			<td>
				177</td>
			<td>
				26,55</td>
			<td>
				31,86</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000111</td>
			<td>
				Diagn&oacute;stico anatomopatol&oacute;gico em citologia esfoliativa na regi&atilde;o buco-maxilo-facial</td>
			<td>
				422</td>
			<td>
				63,30</td>
			<td>
				75,96</td>
		</tr>
		<tr>
			<td>
				81000138</td>
			<td>
				Diagn&oacute;stico anatomopatol&oacute;gico em material de bi&oacute;psia na regi&atilde;o buco-maxilo-facial</td>
			<td>
				422</td>
			<td>
				63,30</td>
			<td>
				75,96</td>
		</tr>
		<tr bgcolor="#FFCCCC">
			<td>
				81000154</td>
			<td>
				Diagn&oacute;stico anatomopatol&oacute;gico em pe&ccedil;a cir&uacute;rgica na regi&atilde;o buco-maxilo-facial</td>
			<td>
				422</td>
			<td>
				63,30</td>
			<td>
				75,96</td>
		</tr>
		<tr>
			<td>
				81000170</td>
			<td>
				Diagn&oacute;stico anatomopatol&oacute;gico em pun&ccedil;&atilde;o na regi&atilde;o buco-maxilo-facial</td>
			<td>
				422</td>
			<td>
				63,30</td>
			<td>
				75,96</td>
		</tr>
	</tbody>
</table>
<p>
	&nbsp;</p>

       
      </div>
          <div class="paginacao"> <strong>1</strong> 
          <a href="<?= site_url("tabeladeatos/2")?>">2</a> 
          <a href="<?= site_url("tabeladeatos/3")?>">3</a> 
          <a href="<?= site_url("tabeladeatos/4")?>">4</a> 
          <a href="<?= site_url("tabeladeatos/5")?>">5</a> 
          </div>
     </div>
    <div class="conteudo-right">
          <? include("lateral_view.php"); ?>
  </div>
      <? include("footer_view.php"); ?>