<? include("header_view.php"); ?>
<link rel='stylesheet' type='text/css' href='<?= site_url()?>includes/fullcalendar/fullcalendar.css' />
<script type='text/javascript' src='<?= site_url()?>includes/fullcalendar/fullcalendar.min.js'></script>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('calendario') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1><?= $this->lang->line('calendario') ?></h1>
<script type='text/javascript'>
$(document).ready(function() {	
	$('#calendario').fullCalendar({
		events: function(start, end, callback) {
			$.ajax({
				 url: '<?=site_url("site/eventos")?>',
				 data: {
						start: Math.round(start.getTime() / 1000),
						end: Math.round(end.getTime() / 1000)
					},
				 dataType: "xml",	
				 contentType : 'application/xml',
				 success: function(doc) {
				  var events = [];
				  $(doc).find('event').each(function() {
					   events.push({

						title: $(this).find("titulo").text(),
						url: $(this).attr('url'),
						start: $(this).attr('start'),
						end: $(this).attr('end'),
						color: $(this).attr('color'),
						backgroundColor: $(this).attr('backgroundColor'),
						borderColor: "#fff",
						className: "evento-dia"
						});
				
					  });
					  	
					  callback(events);
					 }
					 

					});
				
					
					
		}
	});
});
</script>  

<div id="calendario"></div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>

<? include("footer_view.php"); ?>