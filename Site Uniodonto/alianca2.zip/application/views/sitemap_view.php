<?php 



echo'<?xml version="1.0" encoding="UTF-8" ?>' ?>
 
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo base_url();?></loc>
        <priority>1.0</priority>
    </url>
	<? foreach($menu_uniodonto as $uniodonto){ ?>
    <url>
        <loc><?= site_url()?>pagina/<?=$uniodonto->texto_id.'/'.urlencode($this->formata_nome_model->formataNome($uniodonto->texto_titulo))?></loc>
        <priority>0.3</priority>
    </url>                        
    <? } ?>
    <? foreach($menu_planos as $planos){ ?>
    <url>
        <loc><?= site_url()?>pagina/<?=$planos->texto_id.'/'.urlencode($this->formata_nome_model->formataNome($planos->texto_titulo))?></loc>
        <priority>0.3</priority>
    </url>                         
    <? } ?>
    <url>
        <loc><?php echo base_url('encontreseudentista');?></loc>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>http://www.dentaluni.com.br</loc>
        <priority>1.0</priority>
    </url>
    <? foreach($menu_dental as $dental){ ?>
    <url>
        <loc><?= site_url()?>pagina/<?=$dental->texto_id.'/'.urlencode($this->formata_nome_model->formataNome($dental->texto_titulo))?></loc>
        <priority>0.3</priority>
    </url>                         
    <? } ?>
    <? foreach($menu_clinica as $clinica){ ?>
    <url>
        <loc><?= site_url()?>pagina/<?=$clinica->texto_id.'/'.urlencode($this->formata_nome_model->formataNome($clinica->texto_titulo))?></loc>
        <priority>0.3</priority>
    </url>                         
    <? } ?>
    <url>
        <loc><?= site_url()?>historico</loc>
        <priority>0.5</priority>
    </url> 
    <url>
        <loc><?= site_url("localizacao")?></loc>
        <priority>0.5</priority>
    </url> 
    <url>
        <loc><?= site_url("contato")?></loc>
        <priority>0.4</priority>
    </url> 
    <url>
        <loc><?= site_url("trabalheconosco/colaborador")?></loc>
        <priority>0.2</priority>
    </url> 
    <url>
        <loc><?= site_url("trabalheconosco/dentista")?></loc>
        <priority>0.2</priority>
    </url>                       
	<? foreach($menu_contato as $contato){ ?>
    <url>
        <loc><?= site_url()?>pagina/<?=$contato->texto_id?></loc>
        <priority>0.2</priority>
    </url>                         
    <? } ?>
     
    <?php foreach($noticias as $noticia) {?>
    	
    <url>
        <loc><?php echo base_url()."noticia/".$noticia->noticia_id.'/'.urlencode($this->formata_nome_model->formataNome($noticia->noticia_titulo))?></loc>
        <priority>0.5</priority>
    </url>
    <?php } ?>
 
</urlset>