<script src='<?= site_url()?>js/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
<script type="text/javascript" charset="utf-8">
		$(function(){
			$("input:file").uniform();
		
		});
</script>

<div class="conteudo">
	<div class="bt-voltar"><a href="<?= site_url("alianca/site/cadastrado/".$cadastro->alianca_id) ?>">Voltar</a></div>
	<div class="enviadocs">
    
        <h1>Enviar documentos</h1>
        <div class="titular">
		<h2>Documentos do titular</h2>
        <form method="post" enctype="multipart/form-data">

            <label>Proposta <? if(isset($cadastro->alianca_copia_contrato) and $cadastro->alianca_copia_contrato != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" class="multi" accept="jpg|jpeg" name="proposta[]" />
			
            <label>RG <? if(isset($cadastro->alianca_copia_rg) and $cadastro->alianca_copia_rg != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" name="rg" />
            
            <label>CPF  <? if(isset($cadastro->alianca_copia_cpf) and $cadastro->alianca_copia_cpf != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" name="cpf" />
           
            <label>Comprovante de vinculo <? if(isset($cadastro->alianca_copia_vinculo) and $cadastro->alianca_copia_vinculo != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" name="vinculo" />
            
            <label>Residencia <? if(isset($cadastro->alianca_copia_residencia) and $cadastro->alianca_copia_residencia != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" name="residencia" />
            
            <label>Termo de posse <? if(isset($cadastro->alianca_copia_posse) and $cadastro->alianca_copia_posse != "") print "<b>(Arquivo enviado com sucesso!)</b>" ?></label>
            <input type="file" name="posse" />
            
            <div>
            <input type="submit" value="Salvar documentos" class="bt-continuar" />
            </div>
        </form>
    	</div>    
	</div>    


</div>

	
