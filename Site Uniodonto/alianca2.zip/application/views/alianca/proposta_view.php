<div id="page_1">
  <div id="id_1">
    <p>N° 110030</p>
    <p>PARABÉNS!</p>
    <p>Sua proposta de adesão, nº 110030 , foi preenchida com sucesso.</p>
    <p>Para concluir sua adesão, siga as instruções abaixo:</p>
    <p>1. Caso tenha impresso apenas uma via de sua proposta, acesse nosso site ( <a href="http://www.aliancaadm.com.br">www.aliancaadm.com.br </a>)   na página de serviços on­line, clique em &ldquo;Edição e Reimpressão de   Proposta de Adesão&rdquo; e com seu CPF e o número de proposta de adesão   indicado acima imprima as quantidade de vias necessárias, de acordo com a   classificação abaixo:</p>
    <p>a)Para filiados a entidades de classe e/ou associações ­ i m p r i m a m a i s u m a v i a , a p r i m e i r a s e r á s u a , a s e g u n d a d a A l i a n ç a</p>
    <p>Administradora.</p>
    <p>b)Para servidores de órgãos públicos e/ou entidades vinculadas ­   imprima mais duas vias, a primeira será sua, a segunda da Aliança   Administradora, e a terceira deverá ser entregue ao RH* de seu órgão ou   entidade vinculada.</p>
    <p>* Alguns órgãos/entidades não exigem a entrega de uma via da proposta de adesão. Veri** Alguns órgãos/entidades não exige</p>
    <p>Aos clientes vinculados à Câmara Dos Deputados ,   não é necessário entregar a via do RH. Neste caso, imprima duas vias a   primeira será sua e a segunda da Aliança Administradora.</p>
    <p>2.Confira todos os dados e assine todas as páginas.</p>
    <p>3.Reúna as cópias dos documentos obrigatórios listados na página a seguir e junte à via da proposta de adesão destinada à Aliança</p>
    <p>Administradora.</p>
    <p>4 . Encaminhe a via da proposta de adesão assinada e   as cópias dos documentos obrigatórios pelos Correios para a Aliança   Administradora, aos cuidados do Departamento de Cadastro, ou entregue   pessoalmente no endereço:</p>
    <p>Aliança Administradora</p>
    <p>A/C Departamento de Cadastro</p>
    <p>SCN Quadra 5 – Bloco A – Torre Norte – Sala 418</p>
    <p>Edifício Centro Empresarial Brasília Shopping</p>
    <p>Brasília – DF – CEP: 70.715­900</p>
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td><p>_________________________________</p></td>
          <td><p>_________________________________</p></td>
        </tr>
        <tr>
          <td><p>Local e data</p></td>
          <td><p>Assinatura</p></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="id_2">
    <div id="id_2_1">
      <p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente Modelo Orientações ­ v.03 Folha1 -de 1</p>
    </div>
    <div id="id_2_2">
      <p>Aliança Administradora</p>
    </div>
  </div>
</div>
<div id="page_2">
  <div id="id_1">
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td rowspan="2"><p>INFORMAÇÕES IMPORTANTES</p></td>
          <td><p> </p></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td><p>N° 110030</p></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td><p> </p></td>
          <td><p> </p></td>
          <td><p> </p></td>
        </tr>
      </tbody>
    </table>
    <p>1. ENTREGA DA PROPOSTA DE ADESÃO</p>
    <p>Para que a proposta de adesão seja implantada com   sucesso é necessário que uma via original e as cópias dos documentos   pertinentes sejam recebidos pela Aliança Administradora até o dia   estipulado na sua proposta de adesão.</p>
    <p>2. DOCUMENTOS OBRIGATÓRIOS</p>
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td></td>
          <td><p>Para o titular:</p></td>
          <td><p>Para o(s) dependente(s):</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>- RG;</p></td>
          <td><p>­ RG ou certidão de nascimento;</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>- CPF;</p></td>
          <td><p>- CPF para dependentes a partir de 18 anos;</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>­ Comprovante de vínculo com a entidade (comprovante de filiação) ou órgão público</p></td>
          <td><p>­ Certidão de casamento (em caso de cônjuge);</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>(contracheque atualizado);</p></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td></td>
          <td><p> </p></td>
          <td><p>­ D e c l a r a ç ã o p ú b l i c a d e u n i ã o e s t á v e l e x p e d i d a p o r c a r t ó r i o o u</p></td>
        </tr>
        <tr>
          <td></td>
          <td rowspan="2"><p>­ Comprovante de residência;</p></td>
          <td><p>contrato de união estável (em caso de companheiro);</p></td>
        </tr>
        <tr>
          <td></td>
          <td rowspan="2"><p>* C l i e n t e s S u l A m é r i c a ­ D e c l a r a ç ã o d e U n i ã o E s t á v e l S i m p l e s ,</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td></td>
          <td><p> </p></td>
          <td><p>conforme modelo da operadora.</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>­ Cópia do Termo de Posse ou da Publicação no diário oficial da União, para novos</p></td>
          <td><p>­ Comprovante atualizado de matrícula para os filhos entre 21 a 24</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p>servidores e novos pensionistas (exclusivo para servidores públicos).</p></td>
          <td><p>anos que sejam estudantes.</p></td>
        </tr>
        <tr>
          <td></td>
          <td><p> </p></td>
          <td><p> </p></td>
        </tr>
      </tbody>
    </table>
    <p>Atenção: Algumas entidades de classe ou órgãos públicos podem exigir documentos adicionais aos listados acima.</p>
    <p>3. PRAZO DE MOVIMENTAÇÃO CADASTRAL NA OPERADORA</p>
    <p>A proposta de adesão, acompanhada da documentação   completa, precisa ser recebida na Aliança até a data estabelecida na   proposta, para que o início da vigência do plano contratado ocorra a   partir do 1º dia do mês subsequente. Caso contrário, a data de início da   vigência poderá ser prorrogada.</p>
    <p>4. AUXÍLIO SAÚDE (somente para servidores públicos)</p>
    <p>Para solicitar o seu auxílio­saúde, apresente uma via   da sua proposta de adesão acompanhada do formulário de requerimento de   auxílio­ saúde ao RH da sua Instituição.</p>
    <p>A informação acerca do pagamento da mensalidade do   seu plano de saúde é enviada mensalmente pela Aliança Administradora ao   RH do seu órgão.</p>
    <p>Atenção: Servidores do Ministério do Trabalho e   Emprego ­ MTE deverão apresentar pessoalmente ao RH do órgão o   comprovante de pagamento/demonstrativo do débito da parcela emitido pelo   banco.</p>
    <p>5. CONFIRMAÇÃO DA DECLARAÇÃO PESSOAL DE SAÚDE</p>
    <p>A Área Médica da Aliança Administradora poderá entrar   em contato com o beneficiário para confirmar as informações da   Declaração Pessoal de Saúde.</p>
    <p>6. NÚMERO DA MATRÍCULA</p>
    <p>O número da matrícula do beneficiário e de seus dependentes será enviado por e­mail no início da vigência do plano escolhido.</p>
    <p>7. CARTÃO DE IDENTIFICAÇÃO DO USUÁRIOS</p>
    <p>O cartão de identificação do usuário e de seus   dependentes será enviado para o endereço informado na proposta de adesão   até 30 dias do início da vigência do plano escolhido. Atenção: A 2ª via   do cartão de identificação terá um custo adicional de R$ 10,00.</p>
    <p>8. CARÊNCIA</p>
    <p>O beneficiário deverá ficar atento para as regras e   prazos de carência existentes para o plano de saúde contratado,   constantes no formulário anexo à proposta de adesão.</p>
    <p>9. PAGAMENTO</p>
    <p>O pagamento da mensalidade deverá ser realizado de   acordo com a sua data de vencimento, para que não haja cancelamento do   plano. Atenção: O pagamento da mensalidade atual não quita os débitos anteriores.</p>
    <p>10. REAJUSTE</p>
    <p>A tabela de preços do plano do escolhido sofrerá   reajuste anualmente, no aniversário do contrato da Aliança com a   entidade ou órgão.</p>
    <p>11. VARIAÇÃO POR MODIFICAÇÃO DA FAIXA ETÁRIA</p>
    <p>O valor da mensalidade será modificado no mês   seguinte ao aniversário do beneficiário e de seus dependentes quando   houver mudança de faixa etária, independente da aplicação do reajuste.</p>
    <p>12. REDE CREDENCIADA</p>
    <p>Informamos ainda que está disponível, 24h por dia, a   relação da rede credenciada do seu plano de saúde. Acesse o site ou   ligue para a o p e r a d o r a e c o n f i r a a s m e l h o r e s o p ç   õ e s d e a t e n d i m e n t o . S e p r e f e r i r a c e s s e o P o   r t a l d o C l i e n t e n o s i t e d a A l i a n ç a –   http://www.aliancaadm.com.br/redereferenciada e clique na logomarca da   sua operadora.</p>
    <p>13. PORTAL DO CLIENTE</p>
    <p>Ao visitar o site da Aliança Administradora   (www.aliancaadm.com.br) você também tem acesso a diversos serviços   online que facilitam ainda mais a utilização do seu plano de saúde. No   espaço &ldquo;serviços on­line&rdquo; você pode solicitar a reprogramação do seu   débito automático, imprimir a 2ª via do seu boleto (quando esta for a   sua forma de pagamento), consultar seu número de matrícula, dentre   outros.</p>
    <p>14. CANCELAMENTO</p>
    <p>A solicitação de cancelamento do plano deverá ser   formalizada por documento assinado pelo beneficiário titular, entregue   em via original aos cuidados do Departamento de Cadastro da Aliança.</p>
    <p>Atenção: A solicitação de cancelamento não abona os débitos anteriores.</p>
    <p>15. COPARTICIPAÇÃO</p>
    <p>Caso seu plano seja com coparticipação, a cobrança   dessa poderá ser realizada no período de até 12 (doze) meses após a   prestação do atendimento. Caso ocorra o cancelamento do plano, a   cobrança das utilizações não efetuadas durante o período de vigência do   contrato poderá ser realizada mesmo após a data do cancelamento na   Aliança.</p>
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td><p>_________________________________</p></td>
          <td><p>_________________________________</p></td>
        </tr>
        <tr>
          <td><p>Local e data</p></td>
          <td><p>Assinatura</p></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="id_2">
    <div id="id_2_1">
      <p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente Modelo Informações ­ v.04 Folha1 -de 2</p>
    </div>
    <div id="id_2_2">
      <p>Aliança Administradora</p>
    </div>
  </div>
</div>
<div id="page_3">
  <div id="id_1">
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td rowspan="2"><p>INFORMAÇÕES IMPORTANTES</p></td>
          <td><p> </p></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td><p>N° 110030</p></td>
          <td><p> </p></td>
        </tr>
        <tr>
          <td><p> </p></td>
          <td><p> </p></td>
          <td><p> </p></td>
        </tr>
      </tbody>
    </table>
    <p>Para mais informações, acesse www.aliancaadm.com.br ou entre em contato conosco pelo telefone 0800 603 7007.</p>
    <table cellpadding="0" cellspacing="0">
      <tbody>
        <tr>
          <td><p>_________________________________</p></td>
          <td><p>_________________________________</p></td>
        </tr>
        <tr>
          <td><p>Local e data</p></td>
          <td><p>Assinatura</p></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="id_2">
    <div id="id_2_1">
      <p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente Modelo Informações ­ v.04 Folha2 -de 2</p>
    </div>
    <div id="id_2_2">
      <p>Aliança Administradora</p>
    </div>
  </div>
</div>
<div id="page_4">
  <p>PROPOSTA DE ADESÃO</p>
  <p>N° 110030</p>
  <p>Plano Coletivo Empresarial de Assistência á Saúde</p>
  <p>1. IDENTIFICAÇÃO DA PESSOA JURÍDICA SUBESTIPULANTE</p>
  <p>Razão Social­Pessoa Jurídica Subestipulante</p>
  <p>MINISTERIO DA EDUCACAO</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="15"><p>CNPJ ­ Pessoa Jurídica Subestipulante</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="8"><p>Data de Vigência</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>Lotação (se houver)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>00.394.445/0188-17</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>01/05/2012</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>MEC BRASILIA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>Entidade Vinculada (se houver)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>MEC</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="15"><p>2. DADOS CADASTRAIS DO PROPONENTE TITULAR</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Sexo</p></td>
        <td><p> </p></td>
        <td colspan="2"><p>EC</p></td>
      </tr>
      <tr>
        <td><p>SADASD</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>M</p></td>
        <td><p> </p></td>
        <td><p>S</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="11"><p>Data de Nascimento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="10"><p>Nº Declaração Nascido Vivo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="7"><p>Cartão Nacional de Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>362.749.238-29</p></td>
        <td><p> </p></td>
        <td colspan="6"><p>07/10/1986</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>22222222222</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>Nº do documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="9"><p>Tipo de documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>Orgão Emissor</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Data de Expedição</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>0000000</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="11"><p>CERTIDAO DE NASCIMENTO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>SESP-AL</p></td>
        <td><p> </p></td>
        <td colspan="5"><p> </p></td>
        <td><p> </p></td>
        <td><p>06/05/2013</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>Tipo de Beneficiário</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="7"><p>Matr. Servidor/SIAPE¹</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="7"><p>Matrícula Pensionista</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Ocupação Principal</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>Ativo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>2222222</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>ADESTRADOR</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>Nome da Mãe (completo)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="3"><p>MARIA JOS DE SOUZA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="15"><p>Endereço para Correspondencia (Rua, Avenida, Praça)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>Número</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="16"><p>Complemento de Endereço</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="5"><p>RUA MARCOS AURELIO TOZZO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>8454</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>Bairro</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="7"><p>Cidade</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>ITALIA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="9"><p>SAO JOSE DOS PINHAIS</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>U F</p></td>
        <td><p> </p></td>
        <td><p>CEP</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Tipo de Endereço</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>E-mail</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>PR</p></td>
        <td><p> </p></td>
        <td><p>83020510</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Residencial</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="11"><p>sdf@dfsd.com</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>DDD</p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Telefone Residencial</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>DDD</p></td>
        <td><p> </p></td>
        <td colspan="6"><p>Telefone Comercial</p></td>
        <td><p> </p></td>
        <td colspan="5"><p>Ramal</p></td>
        <td colspan="3"><p>DDD</p></td>
        <td><p> </p></td>
        <td colspan="9"><p>Telefone Celular</p></td>
        <td><p> </p></td>
        <td colspan="4"><p>PIS/PASEP</p></td>
      </tr>
      <tr>
        <td><p>41</p></td>
        <td><p> </p></td>
        <td><p>85645545</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>¹ Matrícula do servidor no orgão de recebimento dos proventos.</p>
  <p>3. RELAÇÃO DOS DEPENDENTES</p>
  <p>Legenda: PAR(parentesco): 11­cônjuge 13­filho(a)   15­menor sob guarda 16­pai/mãe EC(estado civil): S­Solteiro(a)   C­Casado(a) V­Viúvo D­Divorciado J­Separado Judicialmente</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Sexo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>EC</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Nº Declaração de Nascido Vivo</p></td>
        <td><p> </p></td>
        <td><p>Data de Nascimento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Cartão Nacional de Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>PAR.</p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Dep. 1</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Nº do Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td rowspan="2"><p>Tipo de Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Orgão Emissor</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Data de Expedição</p></td>
        <td><p> </p></td>
        <td><p>Nome da Mãe</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Sexo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>EC</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Nº Declaração de Nascido Vivo</p></td>
        <td><p> </p></td>
        <td><p>Data de Nascimento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Cartão Nacional de Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>PAR.</p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Dep. 2</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Nº do Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td rowspan="2"><p>Tipo de Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Orgão Emissor</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Data de Expedição</p></td>
        <td><p> </p></td>
        <td><p>Nome da Mãe</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Sexo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>EC</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Nº Declaração de Nascido Vivo</p></td>
        <td><p> </p></td>
        <td><p>Data de Nascimento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Cartão Nacional de Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>PAR.</p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Dep. 3</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Nº do Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td rowspan="2"><p>Tipo de Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Orgão Emissor</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Data de Expedição</p></td>
        <td><p> </p></td>
        <td><p>Nome da Mãe</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Sexo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>EC</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Nº Declaração de Nascido Vivo</p></td>
        <td><p> </p></td>
        <td><p>Data de Nascimento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Cartão Nacional de Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>PAR.</p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Dep. 4</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td rowspan="2"><p>Nº do Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td rowspan="2"><p>Tipo de Documento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Orgão Emissor</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Data de Expedição</p></td>
        <td><p> </p></td>
        <td><p>Nome da Mãe</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="5"><p>_________________________________</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="6"><p>_________________________________</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Local e data</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>Assinatura</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="5"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>Modelo CE-016-08 Folha -</p></td>
        <td colspan="3"><p>1 de 6</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_5">
  <p>PROPOSTA DE ADESÃO</p>
  <p>N° 110030</p>
  <p>Plano Coletivo Empresarial de Assistência á Saúde</p>
  <p>4. PLANO PRETENDIDO / OPCIONAL</p>
  <p>Tipo do Plano</p>
  <p>ASSISTÊNCIA ODONTOLÓGICA</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td><p>Operadora ­ Razão Social</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>Reg. Oper. - ANS</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>AMIL DENTAL</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome do Plano Escolhido</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>Registro do Plano - ANS</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>AMIL DENTAL</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome do Plano</p></td>
        <td><p> </p></td>
        <td><p>REGISTRO ANS.</p></td>
        <td><p>ABRANGÊNCIA</p></td>
        <td><p>SERVIÇOS</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>ACOMODAÇÃO</p></td>
        <td><p>TIPO DE CONTRATAÇÃO</p></td>
        <td><p>CARÊNCIA</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>AMIL DENTAL STANDART</p></td>
        <td colspan="2"><p>-</p></td>
        <td><p>NACIONAL</p></td>
        <td><p>ODONTOLOGICO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>PRODUTO ODONTOLOGICO</p></td>
        <td><p>Sem Coparticipação</p></td>
        <td><p>Integral</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Data do Inicio do Benefício</p></td>
        <td><p> </p></td>
        <td colspan="7" rowspan="2"><p>Os períodos de carência estipulados com a operadora passarão a contar a partir desta data.</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td rowspan="2"><p>01/07/2013</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>Obs.: Em caso de contratação   de plano de assistência odontológica, fica dispensado o preenchimento   dos itens 10 (dez) e 11 (onze) desta proposta de adesão.</p>
  <p>5. DEMONSTRATIVO DO VALOR INICIAL DA MENSALIDADE ­ De acordo com a faixa etária do titular e dependente(s)</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p>Tipo</p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Beneficiários</p></td>
        <td><p> </p></td>
        <td><p>Idade</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="5"><p>Plano Principal</p></td>
        <td><p> </p></td>
        <td><p>Total</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>T</p></td>
        <td><p> </p></td>
        <td colspan="3"><p>SADASD SADASD</p></td>
        <td colspan="2"><p>26</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>R$ 19,96</p></td>
        <td><p> </p></td>
        <td><p>R$ 19,96</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>Mensalidade Total R$</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>R$ 19,96</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>6. DADOS DE COBRANÇA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>Forma Pagamento</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Descriçãoda Unidade de Pagamento (UPAG)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>Código da UPAG</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>CONSIGNACAO EM FOLHA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>AGENCIA NACIONAL DO CINEMA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>20224</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>Titular da Conta Bancária</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p>Nome Completo ­ Titular da Conta Bancária</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>CPF ­ Titular da Conta Bancária</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>[X]Titular [' ']Outros</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>SADASD</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>362.749.238-29</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>N° Banco</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Nome do Banco</p></td>
        <td><p> </p></td>
        <td><p>Agência</p></td>
        <td><p> </p></td>
        <td><p>N° da Conta</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>TP CO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>341</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>BANCO ITAU</p></td>
        <td><p> </p></td>
        <td><p>0624 - 1</p></td>
        <td><p> </p></td>
        <td><p>02203 - 4</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>C</p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>(1)Bancos   Conveniados: 001 ­ Banco do Brasil | 033 ­ Santander | 070 ­ BRB | 104 ­   Caixa Econômica Federal | 237 ­ Bradesco | 341 ­ Banco Itaú | 756 ­   Bancoob</p>
  <p>(2)TP ­ Tipo de Conta: C corrente ou P poupança</p>
  <p>(3)CO ­ No caso de CEF especificar o código da operação</p>
  <p>Obs.: 1) Verifique se a opção consignação em folha está disponível para o seu contrato;</p>
  <p>2) Em caso de consignação em folha, é obrigatório o   preenchimento dos dados bancários e da Unidade de Pagamento (UPAG)   acima, do Tipo de Beneficiário, da Matrícula Servidor e Matrícula do   Pensionista, quando houver, localizados no item 2 (dois) dessa proposta   de adesão.</p>
  <p>A forma de pagamento referente ao plano de   assistência à saúde será consignação em folha de pagamento e/ou débito   em conta e será efetivado no mês da cobertura do benefício, no segundo   dia útil em caso de débito em conta.</p>
  <p>Eventuais diferenças no valor da mensalidade,   originadas de movimentações cadastrais, tais como: alteração de plano,   inclusão ou exclusão de beneficiário, realizadas após o envio das   informações para consignação em folha serão cobradas ou devolvidas no   mês subsequente.</p>
  <p>Autorizo a ALIANÇA ADMINISTRADORA a realizar a   consignação em folha e/ou o débito em conta do valor referente à   mensalidade e a coparticipação, quando houver, do plano de assistência à   saúde escolhido nesta proposta de adesão. Em caso de inexistência de   margem consignável, autorizo a Aliança Administradora a realizar o   débito em conta do valor devido, conforme dados bancários informados   neste item.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="3"><p>___________________________________</p></td>
        <td colspan="5"><p>____________________________________________</p></td>
      </tr>
      <tr>
        <td><p>Local e Data</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>Assinatura do Titular da Conta Bancária</p></td>
      </tr>
      <tr>
        <td><p>7. CORRETORA AUTORIZADA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>Nome da Corretora</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>CNPJ</p></td>
      </tr>
      <tr>
        <td colspan="3"><p>GAPE ADMINISTRADORA E CORRETORA DE SEGUROS LTDA</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>08.532.967/0001-26</p></td>
      </tr>
      <tr>
        <td><p>Nome do Agente de Vendas</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Cód. do Agente de Vendas</p></td>
      </tr>
      <tr>
        <td><p>WEB</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>000457</p></td>
      </tr>
      <tr>
        <td><p>CPF do Agente de Vendas</p></td>
        <td><p> </p></td>
        <td><p>Código do Angariador</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Cód. Equ.</p></td>
        <td><p> </p></td>
        <td><p>Equipe de Vendas</p></td>
      </tr>
      <tr>
        <td><p>000.000.000-00</p></td>
        <td><p> </p></td>
        <td><p>000756</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>8. AUTORIZAÇÕES</p>
  <p>Autorizo a ALIANÇA ADMINISTRADORA, como estipulante   do meu plano de assistência à saúde coletivo empresarial contratado, a   que proceda à cobrança da mensalidade do beneciário correspondente aos   serviços de assistência à saúde e gestão, na forma prevista no item 6   (seis) da presente proposta.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p>Modelo CE-016-08 Folha -</p></td>
        <td><p>2 de 6</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_6">
  <p>PROPOSTA DE ADESÃO</p>
  <p>N° 110030</p>
  <p>Plano Coletivo Empresarial de Assistência á Saúde</p>
  <p>Autorizo a ALIANÇA ADMINISTRADORA a enviar   comunicações e informações sobre o plano contratado, outros produtos de   assistência à saúde, bem como dados relativos ao pagamento da   mensalidade pelo e­mail indicado nesta proposta ou por SMS (Short   Message</p>
  <p>Service).</p>
  <p>9. CONDIÇÕES GERAIS DA CONTRATAÇÃO</p>
  <p>9.1. A presente proposta é para adesão a um &ldquo;contrato   coletivo empresarial&rdquo; estipulado pela ALIANÇA ADMI­NISTRADORA DE   BENEFÍCIOS DE SAÚDE LTDA., CNPJ 08.407.581/0001­92, doravante denominada   ALIANÇA ADMINISTRADORA, com a operadora ou seguradora, decorrente do   termo de acordo firmado com a pessoa jurídica identificada nesta   proposta de adesão. Tal contrato coletivo empresarial destina­se   exclusivamente às pessoas físicas que mantenham vínculo empregatício ou   estatutário com a PESSOA JURÍDICA SUBESTIPULANTE, identificada nesta   proposta de adesão como PESSOA JURÍDICA. Não se trata, portanto, de   adesão a um plano individual com a operadora ou seguradora definida   nesta proposta de adesão.</p>
  <p>9.2.A   ALIANÇA ADMINISTRADORA é investida de todos os poderes inerentes à   função de estipulante, dentre outros, para representar os beneficiários   que aderirem ao plano no cumprimento ou nas alterações das cláusulas   contratuais, bem como no reajuste ou modificação dos valores das   mensalidades.</p>
  <p>9.3.A adesão do proponente titular é voluntária e facultativa.</p>
  <p>9.4.A   aprovação do proponente titular e dos dependentes está condicionada à   análise da vinculação à PESSOA JURÍDICA e da condição de dependência. Se   forem constatadas irregularidades, eventual recusa deverá ser   apresentada ao proponente titular em até 15 (quinze) dias do recebimento   desta proposta na ALIANÇA ADMINISTRADORA.</p>
  <p>9.5. As condições do termo de acordo firmado entre a   PESSOA JURÍDICA e a ALIANÇA ADMINISTRADORA, bem como suas   particularidades de cobertura, despesas não cobertas e exclusão do   plano, na forma prevista no termo de referência anexo à Portaria   Normativa nº 5, de 11 de outubro de 2010, da Secretaria de Recursos   Humanos do Ministério do Planejamento, Orçamento e Gestão são de   conhecimento do proponente titular.</p>
  <p>9.5.1.Não   haverá carência para a inclusão do beneficiário que formalizar seu   ingresso no plano: a) no prazo de 60 (sessenta) dias contados da data do   termo de acordo firmado entre a PESSOA JURÍDICA e a ALIANÇA   ADMINISTRADORA; e b) no prazo de 30 (trinta) dias de sua vinculação à   PESSOA JURÍDICA.</p>
  <p>9.5.2.Os   prazos de carência bem como as demais situações não previstas na   Portaria Normativa nº. 5, de 11 de outubro de 2010, da Secretaria de   Recursos Humanos do Ministério de Orçamento e Gestão, deverão observar   as normas regulamentares da Agência Nacional de Saúde Suplementar ­ ANS,   conforme disposto no Art. 42 da mencionada portaria normativa.</p>
  <p>9.5.3.A   adesão dos pensionistas do beneficiário titular no plano de assistência à   saúde está condicionada ao registro de sua opção como beneficiário do   plano, junto ao setorial ou seccional do SIPEC.</p>
  <p>9.5.4.Não   estará obrigado ao cumprimento de nova carência, o pensionista que   aderir ao mesmo plano do beneficiário titular desde que sua adesão   ocorra dentro do prazo de 30 (trinta) dias contados do óbito.</p>
  <p>9.6.Após   a aprovação desta proposta, a cobertura assistencial contratada terá   início na data especificada no item 4 (quatro), localizado nesta   proposta de adesão.</p>
  <p>9.6.1.A   validade desta proposta de adesão está condicionada à entrega de toda a   documentação exigida por lei, pelas normativas da ANS e pelo   órgão/entidade ao qual está vinculado o proponente titular.</p>
  <p>9.6.2.Caso   o recebimento da documentação não ocorra no prazo de movimentação   cadastral de que trata o item 9.12.1 (nove ponto doze ponto um), o   início da cobertura assistencial contratada será postergado para o   primeiro dia do mês subsequente ao recebimento da documentação, limitado   a 30 (trinta) dias contados da data indicada no item 4 (quatro) desta   proposta. Após esse período será necessário o preenchimento de nova   proposta.</p>
  <p>9.7.A   data de vencimento da mensalidade e da coparticipação, quando houver,   bem como a forma de pagamento são as definidas no item 6 (seis)   localizado nesta proposta de adesão. Caso o pagamento da mensalidade e   da coparticipação não ocorram no vencimento estipulado, o beneficiário   titular deverá contatar a ALIANÇA ADMINISTRADORA nos locais e pelos   meios indicados no item 9.12 (nove ponto doze).</p>
  <p>9.8. O atraso no pagamento da mensalidade e da   coparticipação, esta quando houver, difere das regras previstas para os   planos individuais. Em caso de atraso no pagamento de mensalidade ou   coparticipação, além da exclusão prevista no item 9.9 (nove ponto nove)   desta proposta, o valor não pago será cobrado corrigido mo­netariamente   pelo IGPM­FGV ou outro índice que venha substituí­lo, acrescido de juros   de 1% a.m (um por cento ao mês), 2% (dois por cento) de multa sobre o   débito, despesas com cobrança por empresa especializada e honorários   advocatícios.</p>
  <p>9.9. A PESSOA JURÍDICA e a ALIANÇA ADMINISTRADORA   poderão proceder a exclusão do plano do beneficiário titular e dos   dependentes nos seguintes casos: (I) falta de quitação da mensalidade   e/ou da coparticipação, esta quando houver, no prazo de 60 (sessenta)   dias de seu vencimento; (II) pela ocorrência de ato que implique na   suspensão dos vencimentos, tais como, exoneração, redistribuição e   demissão, bem como deslocamento do beneficiário titular para outro órgão   ou entidade não coberto pelo plano, observado o art. 30 da Lei nº   9.656/98; (III) por solicitação do beneficiário titular; (IV) por óbito,   a partir da data de sua comunicação à ADMINISTRADORA; (V) por fraude;   (VI) pela rescisão do termo de acordo entre a PESSOA JURÍDICA e a   ALIANÇA ADMINISTRADORA e, a exclusão dos dependentes, pela perda da   condição de dependência, sem prejuízo de a PESSOA JURÍDICA e/ou a   ALIANÇA ADMINISTRADORA também procederem às exclusões passíveis de serem   aplicadas pela operadora/seguradora responsável pelo plano oferecido.</p>
  <p>9.9.1.No   caso de licença sem remuneração, afastamento legal ou suspensão   temporária de remuneração, será possível optar pela permanência no   plano, desde que o beneficiário titular assuma integralmente o seu   custeio durante o período da licença.</p>
  <p>9.9.2.No   caso de exoneração ou demissão sem justa causa, ou ainda de   aposentadoria, será assegurado ao beneficiário o direito de optar, no   prazo de 30 (trinta) dias a contar do aviso prévio ou do ato formal de   exoneração, demissão ou aposentadoria, pela manutenção</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p>Modelo CE-016-08 Folha -</p></td>
        <td><p>3 de 6</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_7">
  <p>PROPOSTA DE ADESÃO</p>
  <p>N° 110030</p>
  <p>Plano Coletivo Empresarial de Assistência á Saúde</p>
  <p>da condição de beneficiário, nas mesmas condições de   cobertura assistencial de que gozava, desde que assuma o seu pagamento   integral, nos termos da RN ANS, nº 279/2011.</p>
  <p>9.9.2.1. Quanto aos aposentados/inativos, deverão   ser observadas as peculiaridades previstas na Portaria Normativa nº 5,   de 11 de outubro de 2010, da Secretaria de Recursos Humanos do   Ministério do Planejamento, Orçamento e Gestão.</p>
  <p>9.10.No   caso de exclusão do beneficiário titular ou dos dependentes do plano, a   cobertura de serviços será totalmente encerrada no último dia da   vigência em que for efetivada a exclusão, sem prejuízo da cobrança de   débitos pendentes.</p>
  <p>9.11.Se   houver cancelamento por solicitação do beneficiário titular ou pelos   motivos constantes do item 9.9 (nove ponto nove) desta proposta, os   cartões de identificação do beneficiário titular e dos dependentes,   deverão ser devolvidos à ALIANÇA ADMINISTRADORA no prazo de 48 (quarenta   e oito horas), a partir do cance­lamento ou da exclusão. A   responsabilidade civil, criminal e financeira pela utilização indevida   do plano, incluindo a por terceiros com ou sem consentimento do   beneficiário titular, e o pagamento pelos procedimentos realizados após o   cancelamento ou exclusão do plano são de responsabilidade do   beneficiário titular.</p>
  <p>9.11.1.A   segunda via dos cartões de identificação será objeto de cobrança ao   beneficiário, cujo valor será informado no momento da solicitação.</p>
  <p>9.12.As   alterações cadastrais, principalmente de endereço, endereço eletrônico e   conta bancária para débito, quando for o caso, deverão s e r c o m u n i   c a d a s f o r m a l m e n t e à P E S S O A J U R Í D I C A e à A L I   A N Ç A A D M I N I S T R A D O R A , a s s u m i n d o o b e n e f i c   i á r i o t i t u l a r a responsabilidade pela incorreção das   informações ou sua não informação.</p>
  <p>9.12.1.A   solicitação de alteração cadastral, de inclusão e de exclusão em um dos   planos deverá ser efetivada no prazo descrito no item 6 (seis) do Anexo I   desta proposta de adesão.</p>
  <p>9.12.2.A   solicitação de inclusão deverá ser formalizada em formulário   específico, entregue em via original assinada, acompanhada de c ó p i a d   o s d o c u m e n t o s c o m p r o b a t ó r i o s d a s i n f o r m a   ç õ e s p r e s t a d a s , e d e v e r á s e r e n v i a d a p o r c o   r r e s p o n d ê n c i a à A L I A N Ç A ADMINISTRADORA, aos cuidados   do Departamento de Cadastro, situada no SCN Quadra 05, Bloco A, Torre   Norte, Sala 418, Edifício Brasília Shopping, Brasília­DF, CEP:   70.715­900; telefone: (61) 2103­7000. As demais solicitações poderão ser   encaminhadas por correios, no endereço aqui indicado; por fax: (61)   2103 ­ 7058; ou por e ­ mail: <a href="mailto:cadastro@aliancaadm.com.br">cadastro@aliancaadm.com.br </a>(com documentação digitalizada).</p>
  <p>9.12.3.A   solicitação de cancelamento do plano deverá ser formalizada por   documento escrito, entregue em via original assinada pelo beneficiário   titular, aos cuidados do Departamento de Cadastro da ALIANÇA   ADMINISTRADORA, situado no SCN Quadra 05, Bloco A, Torre Norte, Sala   418, Edifício Brasília Shopping, Brasília­DF, CEP: 70.715­900.</p>
  <p>9.13.A mensalidade do plano de assistência à saúde sofrerá alteração nos seguintes casos:</p>
  <p>9.13.1.Anualmente,   o reajuste da mensalidade do plano ocorrerá no aniversário do termo de   acordo firmado entre a PESSOA JURÍDICA e a A L I A N Ç A A D M I N I S T   R A D O R A , i n d e p e n d e n t e d a d a t a d e i n c l u s ã o d   o b e n e f i c i á r i o t i t u l a r e d o s d e p e n d e n t e s ,   e o b s e r v a r á , cumulativamente, no período dos 12 (doze) meses   anteriores, os critérios descritos no Anexo I da presente proposta.</p>
  <p>9.13.2.A   qualquer momento, o valor da mensalidade do plano de assistência médica   será modificado caso ocorra mudança de faixa etária do beneficiário   titular e dos dependentes, de acordo com os preços praticados na nova   faixa etária alcançada, no mês seguinte ao seu aniversário, de acordo   com tabela própria da operadora/seguradora que acompanha a presente   proposta (Anexo I), conforme previsto no art. 22 da RN ANS nº 195/2009.</p>
  <p>9.14. O plano coletivo empresarial de assistência à   saúde contratado na forma da presente proposta não está sujeito aos   índices de reajuste fixados pela ANS para planos individuais.</p>
  <p>10.CARTA DE ORIENTAÇÃO DE BENEFICIÁRIOS</p>
  <p>Prezado(a) Beneficiário(a),</p>
  <p>A Agência Nacional de Saúde Suplementar (ANS),   instituição que regula as atividades das operadoras de planos privados   de assistência à saúde, e tem como missão defender o interesse público   vem, por meio desta, prestar informações para o preenchimento da   DECLARAÇÃO DE SAÚDE.</p>
  <p>O QUE É A DECLARAÇÃO DE SAÚDE?</p>
  <p>É o formulário que acompanha o Contrato do Plano de   Saúde, onde o beneficiário ou seu representante legal deverá informar   as doenças ou lesões preexistentes que saiba ser portador ou sofredor no   momento da contratação do plano. Para o seu preenchimento, o   beneficiário tem o direito de ser orientado, gratuitamente, por um   médico credenciado/referenciado pela operadora. Se optar por um   profissional de sua livre escolha, assumirá o custo desta opção.</p>
  <p>Portanto, se o beneficiário (você) toma medicamentos   regularmente, consulta médicos por problema de saúde do qual conhece o   diagnóstico, fez qualquer exame que identificou alguma doença ou lesão,   esteve internado ou submeteu­se a alguma cirurgia, DEVE DECLARAR ESTA   DOENÇA OU LESÃO.</p>
  <p>AO DECLARAR AS DOENÇAS E/OU LESÕES QUE O BENEFICIÁRIO SAIBA SER PORTADOR NO MOMENTO DA CONTRATAÇÃO:</p>
  <p>•A operadora NÃO poderá impedi­lo de contratar o plano de saúde. Caso isto ocorra, encaminhe a denúncia à ANS.</p>
  <p>•A   operadora deverá oferecer: cobertura total ou COBERTURA PARCIAL   TEMPORÁRIA (CPT), podendo ainda oferecer o Agravo, que é um acréscimo no   valor da mensalidade, pago ao plano privado de assistência à saúde,   para que se possa utilizar toda a cobertura contratada, após os prazos   de carências contratuais.</p>
  <p>•No   caso de CPT, haverá restrição de cobertura para cirurgias, leitos de   alta tecnologia (UTI, unidade coronariana ou neonatal) e procedimentos   de alta complexidade ­ PAC (tomografia, ressonância, etc.*)   EXCLUSIVAMENTE relacionados à doença ou lesão declarada, até 24 meses,   contados desde a assinatura do contrato. Após o período máximo de 24   meses da assinatura contratual, a cobertura passará a ser integral de   acordo com o plano contratado.</p>
  <p>•NÃO   haverá restrição de cobertura para consultas médicas, internações não   cirúrgicas, exames e procedimentos que não sejam de alta complexidade,   mesmo que relacionados à doença ou lesão preexistente declarada, desde   que cumpridos os prazos de carências estabelecidas no contrato.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p>Modelo CE-016-08 Folha -</p></td>
        <td><p>4 de 6</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_8">
  <p>PROPOSTA DE ADESÃO</p>
  <p>N° 110030</p>
  <p>Plano Coletivo Empresarial de Assistência á Saúde</p>
  •   Não caberá alegação posterior de omissão de informação na Declaração de   Saúde por parte da operadora para esta doença ou lesão.</p>
  <p>AO NÃO DECLARAR AS DOENÇAS E/OU LESÕES QUE O BENEFICIÁRIO SAIBA SER PORTADOR NO MOMENTO DA CONTRATAÇÃO:</p>
  <p>•A   operadora poderá suspeitar de omissão de informação e, neste caso,   deverá comunicar imediatamente ao beneficiário, podendo oferecer CPT, ou   solicitar abertura de processo administrativo junto à ANS, denunciando a   omissão da informação.</p>
  <p>•Comprovada   a omissão de informação pelo beneficiário, a operadora poderá RESCINDIR   o contrato por FRAUDE e responsabilizá­lo pelos procedimentos   referentes a doença ou lesão não declarada.</p>
  <p>•Até o   julgamento final do processo pela ANS, NÃO poderá ocorrer suspensão do   atendimento nem rescisão do contrato. Caso isto ocorra, encaminhe a   denúncia à ANS.</p>
  <p>ATENÇÃO! Se a operadora   oferecer redução ou isenção de carência, isto não significa que dará   cobertura assistencial para as doenças ou lesões que o beneficiário   saiba ter no momento da assinatura contratual. Cobertura Parcial   Temporária ­ CPT ­ NÃO é carência! Portanto, o beneficiário não deve   deixar de informar se possui alguma doença ou lesão ao preencher a   Declaração de Saúde!</p>
  <p>* Para consultar a lista completa de procedimentos   de alta complexidade – PAC, acesse o Rol de Procedimentos e Eventos em   Saúde da ANS no endereço eletrônico: www.ans.gov.br ­ Perfil Beneficiário.</p>
  <p>Em caso de dúvidas, entre em contato com a ANS pelo telefone 0800-701-9656 ou consulte a página da ANS ­ www.ans.gov.br ­ Perfil Beneficiário.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p>Intermediário entre a operadora e o beneficiário</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>__________________________</p></td>
        <td><p>__________________________</p></td>
      </tr>
      <tr>
        <td><p>Nome completo</p></td>
        <td><p>CPF</p></td>
      </tr>
      <tr>
        <td><p>__________________________</p></td>
        <td><p>__________________________</p></td>
      </tr>
      <tr>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>Beneficiário</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>_________________________</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>Nome completo</p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>11. DECLARAÇÃO DE SAÚDE</p>
  <p>Com o propósito de atender à operadora escolhida, o   beneficiário titular deverá preencher e assinar a declaração de saúde   consoante modelo aprovado pelas operadoras contratadas pela ALIANÇA   ADMINISTRADORA, registrando todas as informações sobre doenças de que   seja portador e das quais tenha conhecimento, com relação a si e aos   dependentes que incluir no plano.</p>
  <p>INFORMAÇÕES IMPORTANTES</p>
  <p>11.1.Para   o preenchimento da Declaração de Saúde, o beneficiário titular deverá   observar as orientações da Carta de Orientação ao Beneficiário, entregue   neste ato, tendo a opção de ser orientado, sem ônus financeiro, por um   médico da operadora ou por um de sua confiança, caso em que as despesas   com honorários serão de sua responsabilidade.</p>
  <p>11.2.Havendo   declaração de doença ou lesão preexistente será aplicada pela operadora   a cobertura parcial temporária (CPT), na forma determinada pela Lei nº   9.656/98 e sua atualização.</p>
  <p>11.2.1.Doenças   ou lesões preexistentes (DLP) são aquelas que o beneficiário ou seu   representante legal saiba ser portador ou sofredor, no momento da   contratação ou adesão ao plano privado de assistência à saúde, de acordo   com o art. 11 da Lei nº 9.656, de 3 de junho de 1998 e o inciso IX do   artigo 4º da Lei nº 9.961, de 28 de janeiro de 2000;</p>
  <p>11.2.2. Cobertura parcial temporária (CPT) é aquela   que admite, por um período ininterrupto de até 24 meses, a partir da   data da contratação ou adesão ao plano privado de assistência à saúde, a   suspensão da cobertura de Procedimentos de Alta Complexidade (PAC),   leitos de alta tecnologia e procedimentos cirúrgicos, desde que   relacionados exclusivamente às doenças ou lesões preexistentes   declaradas pelo beneficiário ou seu representante legal;</p>
  <p>11.2.3.Agravo   é qualquer acréscimo no valor da contraprestação paga ao plano privado   de assistência à saúde, para que o beneficiário tenha direito integral à   cobertura contratada, para a doença ou lesão preexistente declarada,   após os prazos de carências contratuais, de acordo com as condições   negociadas entre a operadora e o beneficiário;</p>
  <p>PREENCHIMENTO</p>
  <p>Os campos de 1 a 28 deverão ser preenchidos com S   (SIM) ou N (NÃO). Caso um ou mais itens sejam afirmativos, esclareça­os   no quadro complementar no final deste questionário.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Declaração Pessoal de Saúde</p></td>
        <td><p> </p></td>
        <td><p>Titular</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td colspan="3"><p>Assinatura</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td colspan="3"><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Modelo CE-016-08 Folha -</p></td>
        <td><p>5 de 6</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_9">
  
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td rowspan="2"><p>PROPOSTA DE ADESÃO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2" rowspan="2"><p>N° 110030</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td rowspan="3"><p>Plano Coletivo Empresarial de Assistência á Saúde</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Peso</p></td>
        <td colspan="3"><p>96</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Altura</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>1,99</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Se voce escolheu um plano odontologico, nao e necessario o preenchimento da Declaracao de Saude. Sel</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2" rowspan="2"><p>N</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>12. ENTREVISTA QUALIFICADA</p>
  <p>( ) 1. Declaro que fui orientado por médico   referenciado da operadora no preenchimento da declaração de saúde, item   10 (dez) desta proposta.</p>
  <p>( ) 2. Declaro que fui orientado pelo meu médico   particular, não referenciado da operadora, no preenchimento da   declaração de saúde, item 10 (dez) desta proposta.</p>
  <p>( ) 3. Declaro que me foram oferecidas as opções 1 e   2 acima especificadas e, que tendo conhecimento de todos os itens da   declaração de saúde, deixei de fazer a entrevista médica qualificada,   assumindo total responsabilidade pelas informações por mim prestadas.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p>_____________________</p></td>
        <td><p>_______________________________________________</p></td>
        <td><p>_____________________</p></td>
      </tr>
      <tr>
        <td><p>Local e Data</p></td>
        <td><p>Assinatura do Médico Orientador, se for o caso</p></td>
        <td><p>CRM, se for o caso</p></td>
      </tr>
      <tr>
        <td><p>13. DECLARAÇÕES DO PROPONENTE</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>13.1. Na qualidade de proponente declaro que ao   preencher e assinar a declaração de saúde assumo a inteira   responsabilidade por qualquer omissão, falsidade, inexatidão ou erro nas   informações aqui prestadas, sujeitando­me ao disposto no Código Civil   Brasileiro: &ldquo;Art. 422. Os contratantes são obrigados a guardar, assim na   conclusão do contrato, como em sua execução, os princípios de probidade   e boa­fé&rdquo;.</p>
  <p>13.2. Declaro que eu e meus dependentes temos ciência   de como proceder à correta utilização do cartão de identificação e me   responsabilizo pela utilização indevida, entre outros, nos casos de   perda, extravio, utilização por terceiros, bem como, utilização   posterior à vigência do contrato ou exclusão, por mim e/ou meus   respectivos dependentes eventualmente inscritos.</p>
  <p>13.3.Declaro   ter recebido informações suficientes para a perfeita compreensão do   plano de assistência à saúde e/ou odontológica que estou firmando com a   operadora/seguradora, entre outras e especialmente sobre: a) coberturas,   exclusões e coberturas opcionais oferecidas; b) períodos de carência e   de cobertura parcial temporária; c) procedimentos a serem adotados para   obter eficiência nos atendimentos; d) abrangência da cobertura dos   produtos; e) critérios de reajustes e variações pecuniárias a serem   aplicados às mensalidades fixadas; f) coparticipação nas despesas,   quando houver; g) condições em que serão prestados os atendimentos; h)   redes assistenciais; e i) franquia nas despesas odontológicas, quando   houver. Declaro, também, que recebi e li o Manual de Orientação para   Contratação de Planos de Saúde – MPS, previamente à assinatura da   proposta de adesão, e que fui informado de que o Guia de Leitura   Contratual – GLC será enviado juntamente com o cartão de identificação   do plano. Declaro, ainda, que recebi e li, antes do preenchimento da   Declaração de Saúde, a Carta de Orientação ao Beneficiário, que integra a   presente proposta. O cartão de identificação e a lista de p r e s t a d   o r e s m é d i c o s e h o s p i t a l a r e s o u o d o n t o l ó g i   c o s , d i s p o n i b i z a d a e m m e i o m a g n é t i c o ( C D )   o u e m a c e s s o a o s i t e d a operadora/seguradora responsável   pelo plano, serão enviados após a aceitação de meu registro e de meus   dependentes pela operadora/seguradora.</p>
  <p>13.4.Declaro   que antes de optar pelo plano descrito nesta proposta de adesão me foi   oferecido e fui esclarecido sobre as condições do plano referência, que   foi instituído pela Lei 9.656/98 como padrão da assistência   médico­hospitalar e que abrange o atendimento em consultórios e   internação em padrão enfermaria, com direito a parto, a UTI e a todos os   exames e tratamentos necessários para diagnosticar ou tratar o problema   de saúde, mas que optei pela contratação do plano descrito nesta   proposta.</p>
  <p>13.5.Declaro   que as informações prestadas neste formulário são absolutamente   verdadeiras e completas, me responsabilizando, assim, civil e   criminalmente, por mim e meus dependentes. Se estiver omitindo   circunstâncias que possam influir na aceitação da proposta ou no valor   da mensalidade, perderei todo e qualquer direito inerente ao presente   contrato coletivo empresarial ao qual tenha aderido; e autorizo desde   já, a ALIANÇA ADMINISTRADORA e/ou a operadora/seguradora contratada a   solicitar, a qualquer tempo, documentos comprobatórios referentes a   todas as informações ora declaradas, bem como acessar as informações   sobre a utilização do meu plano de assistência à saúde, observadas as   normas regulatórias em vigor.</p>
  <p>13.6.Declaro,   ainda, que tomei ciência das condições necessárias a presente adesão,   bem como dos valores estipulados para o produto escolhido por mim e meus   dependentes.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p>Modelo CE-016-08 Folha -</p></td>
        <td><p>6 de 6</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_10">
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td colspan="5" rowspan="2"><p>PROPOSTA DE ADESÃO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td rowspan="2"><p>N° 110030</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4" rowspan="3"><p>Anexo I</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>1. IDENTIFICAÇÃO DA PESSOA JURÍDICA SUBESTIPULANTE</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Razão Social­Pessoa Jurídica Subestipulante</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>MINISTERIO DA EDUCACAO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>CNPJ ­ Pessoa Jurídica Subestipulante</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Data de Vigência</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>Lotação (se houver)</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>00.394.445/0188-17</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>01/05/2012</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>MEC BRASILIA</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Entidade Vinculada (se houver)</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>MEC</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>2. PROPONENTE TITULAR</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome Completo</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>CPF</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>SADASD</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>362.749.238-29</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>3. PLANO PRETENDIDO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="3"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Operadora ­ Razão Social</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>Reg. Oper. - ANS</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>AMIL DENTAL</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Nome do Plano Escolhido</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="4"><p>Registro do Plano - ANS</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>AMIL DENTAL STANDART NACIONAL SEM COPARTICIPACAO</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>4. REAJUSTE</p>
  <p>O reajuste a ser aplicado aos planos de assistência à saúde observará os seguintes critérios:</p>
  <p>4.1.Reajuste   Financeiro: de acordo com a variação dos custos médicos, hospitalares e   ambulatoriais ou odontológicos, bem como outras despesas operacionais   da operadora/seguradora;</p>
  <p>4.2.Reajuste   por Sinistralidade: com a revisão da taxa de sinistralidade, visando à   manutenção do equilíbrio econômico­financeiro do contrato firmado entre a   PESSOA JURÍDICA e a ALIANÇA ADMINISTRADORA, conforme índice calculado   com base na fórmula abaixo:</p>
  <p>IR = [(Ec/Mr/0,65)-1]x100</p>
  <p>IR = índice de reajuste das mensalidades</p>
  <p>Ec = somatório das despesas médicas, hospitalares e ambulatoriais ou odontológicas dos beneficiários</p>
  <p>Mr = somatório das mensalidades efetivamente recebidas pela operadora/seguradora do plano de assistência à saúde.</p>
  <p>5. VARIAÇÃO POR MODIFICAÇÃO DA FAIXA ETÁRIA</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td></td>
        <td rowspan="2"><p>Produto</p></td>
        <td rowspan="2"><p>Abrangência</p></td>
        <td rowspan="2"><p>Acomodação</p></td>
        <td rowspan="2"><p>Coparticipação</p></td>
        <td><p>0 anos ou</p></td>
      </tr>
      <tr>
        <td></td>
        <td rowspan="2"><p>mais</p></td>
      </tr>
      <tr>
        <td></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td></td>
        <td><p>AMIL DENTAL STANDART</p></td>
        <td><p>NACIONAL</p></td>
        <td><p>PRODUTO ODONTOLOGICO</p></td>
        <td><p>Sem Coparticipação</p></td>
        <td><p>-</p></td>
      </tr>
      <tr>
        <td></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>Declaro que tenho ciência e concordo com a   modificação do valor das mensalidades de meu plano de assistência à   saúde e de meu(s) dependente(s), conforme percentual de variação por   modificação por faixa etária, descrito acima.</p>
  <p>6. ALTERAÇÃO CADASTRAL</p>
  <p>A solicitação de alteração cadastral, de inclusão e   de exclusão no plano que for recebida entre o dia 16 (dezesseis) de um   determinado mês e o dia 15 (quinze) do mês subsequente, ocorrerá somente   a partir do dia 1º (primeiro) do mês que o suceder.</p>
  <p>Declaro que tenho ciência e concordo com o critério   de reajuste, com a modificação do valor por faixa etária das   mensalidades e com os prazos para as modificações cadastrais de meu   plano de assistência à saúde e de meu(s) dependente(s), conforme   descrito acima.</p>
  <p>7. PAGAMENTO DA PRIMEIRA MENSALIDADE (exclusivo para clientes do MEC - MEC e IBC, advindos da GEAP)</p>
  <p>Declaro que estou ciente que o pagamento da   mensalidade relativa ao plano de assistência à saúde escolhido ocorrerá   no mês da cobertura do benefício, na forma e no vencimento indicados no   item 6 (seis) da minha proposta de adesão.</p>
  <p>Declaro ainda que, na condição de beneciário do MEC ­   MEC e IBC e advindo da GEAP – Fundação de Seguridade Social, estou   ciente que o pagamento da primeira mensalidade do plano de assistência à   saúde será efetuado em 06 (seis) parcelas mensais, contados a partir do   primeiro mês de cobertura.</p>
  <p>OBS.: Essa condição está sujeita à validação na relação enviada pelo RH do órgão.</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td colspan="2"><p>_________________________________</p></td>
        <td><p>_________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local e data</p></td>
        <td><p>Assinatura</p></td>
      </tr>
      <tr>
        <td colspan="2"><p>1º Via ­ Aliança Administradora 2º Via ­ Operadora 3º Via ­ Cliente</p></td>
        <td><p>Aliança Administradora</p></td>
      </tr>
      <tr>
        <td><p>Modelo AI-026-02 Folha -</p></td>
        <td><p>1 de 1</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
</div>
<div id="page_11">
  <p>MINISTÉRIO DA EDUCAÇÃO</p>
  <p>Secretaria Executiva - SE</p>
  <p>Subsecretaria de Assuntos Administrativos - SAA</p>
  <p>Coordenação-Geral de Gestão de Pessoas - CGGP</p>
  <p>Coordenação de Assistência Médica e Social - CAMS</p>
  <p>REQUERIMENTO DE AUXÍLIO DE CARÁTER INDENIZATÓRIO -</p>
  <p>PORTARIA NORMATIVA Nº 05, DE 11/10/2010</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p>MAT. SIAPE:</p></td>
        <td colspan="2"><p>NOME DO SERVIDOR:</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>2222222</p></td>
        <td><p>SADASD</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p>IDENTIDADE:</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td colspan="2"><p>ÓRGÃO EXPEDIDOR:</p></td>
        <td><p> </p></td>
        <td><p>CPF:</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>362.749.238-29</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td colspan="2"><p>SITUAÇÃO FUNCIONAL:</p></td>
        <td rowspan="2"><p> Ativo</p></td>
        <td><p> </p></td>
        <td rowspan="2"><p> Inativo</p></td>
        <td colspan="2" rowspan="2"><p> Pensionista</p></td>
        <td><p>TELEFONE / RAMAL:</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <p>Venho requerer junto à Coordenação-Geral de Gestão de Pessoas-CGGP, por meio da Coordenação de Assistência Médica e Social-CAMS/MEC, nos termos da Portaria Normativa nº 05, de 11/10/2010, o   ressarcimento do auxílio indenizatório, por dependente legal, referente   ao mês de __________________________, com os seguintes dependentes:</p>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td><p>NOME COMPLETO</p></td>
        <td><p>DATA DE</p></td>
        <td colspan="2"><p>GRAU DE</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>NASCIMENTO</p></td>
        <td colspan="2"><p>PARENTESCO</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
    </tbody>
  </table>
  <table cellpadding="0" cellspacing="0">
    <tbody>
      <tr>
        <td><p> </p></td>
        <td><p>___________________________</p></td>
        <td colspan="2"><p>_______/_________/________</p></td>
        <td><p>____________________________________________</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local</p></td>
        <td><p> </p></td>
        <td><p>Data</p></td>
        <td><p>Assinatura do Titular</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Exclusivo da CAMS</p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Autorizamos a inscrição do servidor</p></td>
        <td><p>(</p></td>
        <td><p>)</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td colspan="2"><p>Autorizamos a inscrição do(s) dependente(s) (</p></td>
        <td><p>)</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>AUTORIZADOR</p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td colspan="3"><p>__________________________ ________/_________/________</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p>Local</p></td>
        <td><p> </p></td>
        <td><p>Data</p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
      </tr>
      <tr>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p> </p></td>
        <td><p>Assinatura e Carimbo</p></td>
      </tr>
    </tbody>
  </table>
  <p>ATENÇÃO:</p>
  <p>1. Documento a ser anexado ao Requerimento:</p>
  <p>. Comprovante de pagamento mensal do plano de saúde   e, valor discriminado por beneficiário, até o 05 (quinto) dia útil de   cada mês.</p>
  <p>formulário - REQUERIMENTO DE AUXÍLIO INDENIZATÓRIO</p>
</div>

