<div class="conteudo">
  		<div>
			<h1>Vantagens</h1>
            <ul>
              <li>Maior rede do Brasil com 22 mil cirurgioes-dentistas cooperados;</li>
              <li>Mais de 1.400 dentistas cooperados no Paran&aacute;;</li>
              <li>Mais de 1.200 dentistas cooperados na &aacute;rea de atua&ccedil;ao da Uniodonto Curitiba;</li>
              <li>Libera&ccedil;ao Online diretamente do consult&oacute;rio do cirurgiao-dentista, inclusive dos atos complementares, com pagamento  facilitado e possibilidade de parcelamento (e-commerce);</li>
              <li>Unidades M&oacute;veis: dispon&iacute;vel para preven&ccedil;ao e educa&ccedil;ao em SIPAT (Semana Interna de Preven&ccedil;ao de Acidentes de Trabalho), levantamento epidemiol&oacute;gico e a&ccedil;ao social;</li>
              <li>Livre escolha da rede cooperada em todas as especialidades;</li>
              <li>Dental Uni, uma loja com ampla linha de produtos de higiene oral com pre&ccedil;os especiais;</li>
              <li>Atendimento personalizado e com hora marcada;
              <li>100% de dedu&ccedil;ao no imposto de renda.</li>
            </ul>
            <h1>E ainda, alguns procedimentos com
              pre&ccedil;o de tabela Uniodonto.</h1>
            <ul class="lista-horizontal">
              <li style="float:left; width: 120px;">Pr&oacute;teses;</li>
              <li>Implantes;</li>
              <li style="float:left; width: 120px;">Claramento;</li>
              <li>Est&eacute;tica;</li>
              <li style="float:left; width: 120px;">Ortodontia;</li>
              <li>Cirurgias;</li>
            </ul>
            <h1>Facilidades</h1>
            <h2>Cirurgioes-dentistas Cooperados</h2>
            <p>Voce encontra a listagem completa de dentistas cooperados em nosso site: www.uniodontocuritiba.com.br ou em nossas centrais de atendimento.</p>
            <h1>Libera&ccedil;ao Online</h1>
            <p>Al&eacute;m da libera&ccedil;ao imediata dos tratamentos, a Uniodonto tamb&eacute;m facilita o pagamento dos atos complementares. Trata-se de um diferencial da Uniodonto, pois o benefici&aacute;rio realiza a transa&ccedil;ao direto no consult&oacute;rio do cirurgiao dentista cooperado, atrav&eacute;s do sistema de libera&ccedil;ao on-line da cooperativa, Unioweb, garantindo pre&ccedil;o &uacute;nico para o procedimento independente do profissional escolhido.</p>
            <h1>Permanencia no plano</h1>
            <h2>Per&iacute;odo de 24 meses  (a partir da inscri&ccedil;ao do benefici&aacute;rio).</h2>
            <h2>Caso tenha utilizado</h2>
            <p>Cancelamento somente ap&oacute;s 12 meses da &uacute;ltima utiliza&ccedil;ao.</p>
            <h2>Caso nao tenha utilizado</h2>
            <ul>
              <li>Cancelamento poder&aacute; ser efetuado a qualquer momento;</li>
              <li>Em caso de desligamento da empresa, cancela-se a qualquer momento.</li>
            </ul>
            <h1>Benef&iacute;cios</h1>
            <ul>
              <li>Urgencias;</li>
              <li>Exames Cl&iacute;nicos;</li>
              <li>Alguns tipos de Radiografia;</li>
              <li>Profilaxia; </li>
              <li>Aplica&ccedil;ao de Fl&uacute;or; </li>
              <li>Aplica&ccedil;ao de Selante (at&eacute; 12 anos); </li>
              <li>Restaura&ccedil;oes em Am&aacute;lgama* e Resinas (exce&ccedil;ao de am&aacute;lgama completa e reconstru&ccedil;ao em resina);</li>
              <li>Tratamento de canais;</li>
              <li>Retratamento de canais;</li>
              <li>Periodontia (limpeza de T&aacute;rtaro simples);</li>
              <li>Remo&ccedil;ao dent&aacute;ria simples e cisos.</li>
            </ul>
            <h1>Dependentes</h1>
            <ul>
              <li>C&ocirc;njuge;</li>
              <li>Filhos solteiros que permanecem sob dependencia financeira do titular respons&aacute;vel;</li>
              <li>O enteado, o menor sob guarda por for&ccedil;a de decisao judicial e o menor tutelado, que
                ficam equiparados aos filhos; </li>
              <li>O convivente, havendo uniao est&aacute;vel, na forma da lei, desde que nao exista concorrencia com o c&ocirc;njuge;</li>
              <li>Os pais do titular e do c&ocirc;njuge.</li>
            </ul>	
			

		</div>
  	
</div>