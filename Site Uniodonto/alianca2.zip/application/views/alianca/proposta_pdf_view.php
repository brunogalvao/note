<style>
	body{
		font-family: Arial, Helvetica, sans-serif;
		padding: 10px;
		font-size: 12px;
		width: 21cm;
		margin: auto;
		}

	.texto{
		width: 100%;
		overflow: hidden;
		float: left;
		text-align: justify;
		}
	h1{
		color: #af2638;	
		font-size: 18px;
		overflow: hidden;
	}
	h6{
		overflow: hidden;
	}
	.tit-pagina{
		width: 100%;
		font-size: 15px;
		font-weight: bold;
		color: #FFF;
		text-align: center;
		margin-bottom: 20px;
		}
		.tit-pagina p{
			padding: 0px;
			margin: 0px;
			font-size: 10px;
			}
	.titulo{
		width: 100%;
		font-size: 12px;
		font-weight: bold;
		border-bottom: 1px solid #333;
		margin-bottom: 5px;
		overflow: hidden;
		float: left;
		}
	.campos{
		overflow: hidden;
		}
	.campo{
		overflow: hidden;
		display: inline-block;
		float: left;
		}	
	.campo-titulo{
		font-size: 11px;
		margin: 2px 4px 0px 0px;
		}
	.campo-dados{
		border: 1px solid #333;
		border-top: none;
		font-size: 11px;
		text-transform: uppercase;
		height: 12px;
		margin: 2px 4px 0px 0px;
		}
	ul li{
		list-style: none;
		display: inline-block;
		}
		


</style>

<div class="texto" style="padding-top: 2cm">
  <p><strong>PARAB&Eacute;NS!</strong><br>
    Sua  proposta de ades&atilde;o foi preenchida com sucesso.<br>
    Para  concluir sua ades&atilde;o, siga as instru&ccedil;&otilde;es abaixo:<br>
    1. Caso tenha impresso  apenas uma via de sua proposta, acesse nosso site ( www.aliancaadm.com.br  ) na p&aacute;gina de servi&ccedil;os online, clique em  &ldquo;Edi&ccedil;&atilde;o e Reimpress&atilde;o de Proposta de Ades&atilde;o&rdquo; e com seu CPF e o n&uacute;mero de  proposta de ades&atilde;o indicado acima imprima    as  quantidade de vias necess&aacute;rias, de acordo com a classifica&ccedil;&atilde;o abaixo:<br>
    a) Para <strong>filiados a entidades de classe e/ou associa&ccedil;&otilde;es </strong>imprima    mais uma  via, a primeira ser&aacute; sua, a segunda da Alian&ccedil;a Administradora.<br>
    b) Para <strong>servidores de &oacute;rg&atilde;os p&uacute;blicos e/ou entidades vinculadas </strong>imprima    mais duas  vias, a primeira ser&aacute; sua, a segunda da Alian&ccedil;a    Administradora,  e a terceira dever&aacute; ser entregue ao RH* de seu &oacute;rg&atilde;o ou entidade vinculada.<br>
    * Alguns &oacute;rg&atilde;os/entidades  n&atilde;o exigem a entrega de uma via da proposta de ades&atilde;o. Veri** Alguns &oacute;rg&atilde;os/entidades n&atilde;o exige    Aos  clientes vinculados &agrave; <strong>C&acirc;mara Dos Deputados </strong>, n&atilde;o &eacute; necess&aacute;rio entregar a via do RH. Neste caso, imprima  duas vias a primeira
    ser&aacute; sua  e a segunda da Alian&ccedil;a Administradora.<br>
    2.  Confira todos os dados e assine todas as p&aacute;ginas.<br>
    3. Re&uacute;na  as c&oacute;pias dos documentos obrigat&oacute;rios listados na p&aacute;gina a seguir e junte &agrave; via  da proposta de ades&atilde;o destinada &agrave; Alian&ccedil;a 
    Administradora.<br>
    4. Encaminhe  a via da proposta de ades&atilde;o assinada e as c&oacute;pias dos documentos obrigat&oacute;rios  pelos Correios para a Alian&ccedil;a    Administradora,  aos cuidados do Departamento de Cadastro, ou entregue pessoalmente no endere&ccedil;o:<br>
    Alian&ccedil;a  Administradora<br>
    A/C Departamento de Cadastro<br>
    SCN  Quadra 5 &ndash; Bloco A &ndash; Torre Norte &ndash; Sala 418<br>
    Edif&iacute;cio  Centro Empresarial Bras&iacute;lia Shopping<br>
    Bras&iacute;lia &ndash; DF &ndash; CEP:  70.715900</p>
</div>

<pagebreak />
<div class="tit-pagina">INFORMA&Ccedil;&Otilde;ES IMPORTANTES</div>
<div class="texto">
		
  <p><strong>1. ENTREGA DA PROPOSTA DE ADES&Atilde;O</strong><br>
    Para que  a proposta de ades&atilde;o seja implantada com sucesso &eacute; necess&aacute;rio que uma via  original e as c&oacute;pias dos documentos 
    pertinentes  sejam recebidos pela Alian&ccedil;a Administradora at&eacute; o dia estipulado na sua  proposta de ades&atilde;o.<br>
  <strong>2. DOCUMENTOS OBRIGAT&Oacute;RIOS</strong>
  <table cellpadding="0" cellspacing="0" style="font-size:9px;" border="1" >
    <tr>
      <td>Para o titular:</td>
      <td>Para o(s) dependente(s):</td>
    </tr>
    <tr>
      <td>- RG;</td>
      <td>- RG ou certid&atilde;o de nascimento;</td>
    </tr>
    <tr>
      <td>- CPF;</td>
      <td>- CPF para dependentes a partir de 18 anos;</td>
    </tr>
    <tr>
      <td>- Comprovante
        de v&iacute;nculo com a entidade (comprovante de filia&ccedil;&atilde;o) ou &oacute;rg&atilde;o p&uacute;blico
        (contracheque atualizado);</td>
      <td>- Certid&atilde;o
        de casamento (em caso de c&ocirc;njuge);</td>
    </tr>
    <tr>
      <td>- Comprovante de resid&ecirc;ncia;</td>
      <td> Declara&ccedil;&atilde;o p&uacute;blica de uni&atilde;o est&aacute;vel expedida por cart&oacute;rio ou contrato de uni&atilde;o est&aacute;vel (em caso de companheiro); <br />
        * Clientes Sul Am&eacute;rica Declara&ccedil;&atilde;o de Uni&atilde;o Est&aacute;vel Simples, conforme modelo da operadora. </td>
    </tr>
    <tr>
      <td>- C&oacute;pia do Termo de Posse ou da Publica&ccedil;&atilde;o no di&aacute;rio oficial da Uni&atilde;o, para novos servidores e novos pensionistas (exclusivo para servidores p&uacute;blicos).</td>
      <td>- Comprovante atualizado de matr&iacute;cula para os filhos entre 21 a 24 anos que sejam estudantes.</td>
    </tr>
  </table>
  Aten&ccedil;&atilde;o:  Algumas entidades de classe ou &oacute;rg&atilde;os p&uacute;blicos podem exigir documentos  adicionais aos listados acima.<br>
    <strong>3. PRAZO DE MOVIMENTA&Ccedil;&Atilde;O CADASTRAL NA OPERADORA</strong><br>
  A  proposta de ades&atilde;o, acompanhada da documenta&ccedil;&atilde;o completa, precisa ser recebida  na Alian&ccedil;a at&eacute; a data estabelecida na proposta,  para que  o in&iacute;cio da vig&ecirc;ncia do plano contratado ocorra a partir do 1&ordm; dia do m&ecirc;s  subsequente. Caso contr&aacute;rio, a data de in&iacute;cio da  vig&ecirc;ncia  poder&aacute; ser prorrogada.<br>
  <strong>4. AUX&Iacute;LIO SA&Uacute;DE (somente para servidores p&uacute;blicos)</strong><br>
  Para  solicitar o seu aux&iacute;liosa&uacute;de,  apresente  uma via da sua proposta de ades&atilde;o acompanhada do formul&aacute;rio de requerimento de  aux&iacute;lio sa&uacute;de  ao RH da  sua Institui&ccedil;&atilde;o.<br>
  A informa&ccedil;&atilde;o  acerca do pagamento da mensalidade do seu plano de sa&uacute;de &eacute; enviada mensalmente  pela Alian&ccedil;a Administradora ao RH  do seu &oacute;rg&atilde;o.<br>
  Aten&ccedil;&atilde;o:  Servidores do Minist&eacute;rio do Trabalho e Emprego MTE  dever&atilde;o  apresentar pessoalmente ao RH do &oacute;rg&atilde;o o comprovante de  pagamento/demonstrativo  do d&eacute;bito da parcela emitido pelo banco.<br>
  <strong>5. CONFIRMA&Ccedil;&Atilde;O DA DECLARA&Ccedil;&Atilde;O PESSOAL DE SA&Uacute;DE</strong><br>
  A &Aacute;rea M&eacute;dica  da Alian&ccedil;a Administradora poder&aacute; entrar em contato com o benefici&aacute;rio para  confirmar as informa&ccedil;&otilde;es da Declara&ccedil;&atilde;o 
  Pessoal  de Sa&uacute;de.<br>
  <strong>6. N&Uacute;MERO DA MATR&Iacute;CULA</strong><br>
  O n&uacute;mero  da matr&iacute;cula do benefici&aacute;rio e de seus dependentes ser&aacute; enviado por email  no in&iacute;cio  da vig&ecirc;ncia do plano escolhido.<br>
  <strong>7. CART&Atilde;O DE IDENTIFICA&Ccedil;&Atilde;O DO USU&Aacute;RIOS</strong><br>
  O cart&atilde;o  de identifica&ccedil;&atilde;o do usu&aacute;rio e de seus dependentes ser&aacute; enviado para o endere&ccedil;o  informado na proposta de ades&atilde;o at&eacute; 30 dias  do in&iacute;cio  da vig&ecirc;ncia do plano escolhido. Aten&ccedil;&atilde;o: A 2&ordf; via do cart&atilde;o de identifica&ccedil;&atilde;o  ter&aacute; um custo adicional de R$ 10,00.<br>
  <strong>8. CAR&Ecirc;NCIA</strong><br>
  O  benefici&aacute;rio dever&aacute; ficar atento para as regras e prazos de car&ecirc;ncia existentes  para o plano de sa&uacute;de contratado, constantes no 
  formul&aacute;rio  anexo &agrave; proposta de ades&atilde;o.<br>
  <strong>9.  PAGAMENTO</strong><br>
  O  pagamento da mensalidade dever&aacute; ser realizado de acordo com a sua data de  vencimento, para que n&atilde;o haja cancelamento do plano.<br>
  <strong>Aten&ccedil;&atilde;o: </strong>O pagamento da mensalidade  atual n&atilde;o quita os d&eacute;bitos anteriores.<br>
  <strong>10.  REAJUSTE</strong><br>
  A tabela  de pre&ccedil;os do plano do escolhido sofrer&aacute; reajuste anualmente, no anivers&aacute;rio do  contrato da Alian&ccedil;a com a entidade ou &oacute;rg&atilde;o.<br>
  <strong>11. VARIA&Ccedil;&Atilde;O POR MODIFICA&Ccedil;&Atilde;O DA FAIXA ET&Aacute;RIA</strong><br>
  O valor  da mensalidade ser&aacute; modificado no m&ecirc;s seguinte ao anivers&aacute;rio do benefici&aacute;rio e  de seus dependentes quando houver mudan&ccedil;a  de faixa  et&aacute;ria, independente da aplica&ccedil;&atilde;o do reajuste.<br>
  <strong>12. REDE  CREDENCIADA</strong><br>
  Informamos  ainda que est&aacute; dispon&iacute;vel, 24h por dia, a rela&ccedil;&atilde;o da rede credenciada do seu  plano de sa&uacute;de. Acesse o site ou ligue para a operadora e confira as melhores op&ccedil;&otilde;es de atendimento. Se preferir acesse o Portal do Cliente no site  da Alian&ccedil;a&ndash;  http://www.aliancaadm.com.br/redereferenciada  e clique na logomarca da sua operadora.<br>
  <strong>13.  PORTAL DO CLIENTE</strong><br>
  Ao  visitar o site da Alian&ccedil;a Administradora (www.aliancaadm.com.br) voc&ecirc; tamb&eacute;m  tem acesso a diversos servi&ccedil;os online que facilitam 
  ainda  mais a utiliza&ccedil;&atilde;o do seu plano de sa&uacute;de. No espa&ccedil;o &ldquo;servi&ccedil;os online&rdquo;  voc&ecirc; pode  solicitar a reprograma&ccedil;&atilde;o do seu d&eacute;bito  autom&aacute;tico,  imprimir a 2&ordf; via do seu boleto (quando esta for a sua forma de pagamento),  consultar seu n&uacute;mero de matr&iacute;cula, dentre  outros.<br>
  <strong>14.  CANCELAMENTO</strong><br>
  A  solicita&ccedil;&atilde;o de cancelamento do plano dever&aacute; ser formalizada por documento  assinado pelo benefici&aacute;rio titular, entregue em via original  aos  cuidados do Departamento de Cadastro da Alian&ccedil;a.<br>
  Aten&ccedil;&atilde;o:  A solicita&ccedil;&atilde;o de cancelamento n&atilde;o abona os d&eacute;bitos anteriores.<br>
  <strong>15. COPARTICIPA&Ccedil;&Atilde;O</strong><br>
  Caso seu  plano seja com coparticipa&ccedil;&atilde;o, a cobran&ccedil;a dessa poder&aacute; ser realizada no per&iacute;odo  de at&eacute; 12 (doze) meses ap&oacute;s a presta&ccedil;&atilde;o do atendimento.  Caso ocorra o cancelamento do plano, a cobran&ccedil;a das utiliza&ccedil;&otilde;es n&atilde;o efetuadas  durante o per&iacute;odo de vig&ecirc;ncia do contrato poder&aacute; ser realizada mesmo  ap&oacute;s a data do cancelamento na Alian&ccedil;a.
  </p>
</div>  
<pagebreak /> 
<div class="tit-pagina">INFORMA&Ccedil;&Otilde;ES IMPORTANTES</div>
<div class="texto"> 
  <p>Para mais informa&ccedil;&otilde;es, acesse www.aliancaadm.com.br ou entre em contato conosco pelo telefone 0800 603 7007.</p>
</div>
<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O<p>Plano Coletivo Empresarial de Assist&ecirc;ncia &aacute; Sa&uacute;de</p></div>
<div class="titulo">
	1. IDENTIFICA&Ccedil;&Atilde;O DA PESSOA JUR&Iacute;DICA SUBESTIPULANTE
</div>
<div class="texto">
    <div class="campos">
        <div class="campo" style="width: 100%;">
            <div class="campo-titulo">Raz&atilde;o SocialPessoa Jur&iacute;dica Subestipulante</div>
            <div class="campo-dados"></div>
        </div>
        <div class="campo" style="width: 60%;">
            <div class="campo-titulo" >CNPJ - Pessoa Jur&iacute;dica Subestipulante</div>
            <div class="campo-dados"></div>
        </div>
        <div class="campo" style="width: 20%;">
            <div class="campo-titulo" >Data de Vig&ecirc;ncia</div>
            <div class="campo-dados"></div>
        </div>
        <div class="campo" style="width: 20%;">
            <div class="campo-titulo" >Lotaccedil;&atilde;o (se houver)</div>
            <div class="campo-dados"></div>
        </div>
        
        <div class="campo" style="width: 100%;">
            <div class="campo-titulo">Entidade Vinculada (se houver)</div>
            <div class="campo-dados"></div>
        </div>
    </div>
</div>
<div class="titulo">
	2. DADOS CADASTRAIS DO PROPONENTE TITULAR
</div>

<div class="campo" style="width: 90%;">
	<div class="campo-titulo">Nome Completo</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_nome ?></div>
</div>

<div class="campo" style="width: 5%;">
    <div class="campo-titulo">Sexo</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_sexo = 1 ? 'M' : 'F'; ?></div>
</div>

<div class="campo" style="width: 5%;">
    <div class="campo-titulo">EC</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_estado_civil ?></div>
</div>


<div class="campo" style="width: 20%;">
    <div class="campo-titulo">CPF</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_cpf ?></div>
</div>

<div class="campo" style="width: 20%;">
    <div class="campo-titulo">Data de Nascimento</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_nascimento ?></div>
</div>

<div class="campo" style="width: 30%;">
    <div class="campo-titulo">N&ordm; Declara&ccedil;&atilde;o Nascido Vivo</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_nascido_vivo ?></div>
</div>

<div class="campo" style="width: 30%;">
    <div class="campo-titulo">Cart&atilde;o Nacional de Sa&uacute;de</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_n_cartao_saude ?></div>
</div>

<div class="campo" style="width: 25%;">
    <div class="campo-titulo">N&ordm; do documento</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_n_documento ?></div>
</div>

<div class="campo" style="width: 35%;">
    <div class="campo-titulo">Tipo de documento</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_nome_tipo_documento ?></div>
</div>

<div class="campo" style="width: 20%;">
    <div class="campo-titulo">Org&atilde;o Emissor</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_orgao_emissor ?></div>
</div>

<div class="campo" style="width: 20%;">
    <div class="campo-titulo">Data de expedi&ccedil;&atilde;o</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_data_expedicao ?></div>
</div>

<div class="campo" style="width: 25%;">
    <div class="campo-titulo">Tipo de Benefici&aacute;rio</div>
    <div class="campo-dados">
    	<? if($dados_contrato->alianca_tipo_servidor == 1){ 
				print "Ativo" ;
			}else if($dados_contrato->alianca_tipo_servidor == 2){
				print "Inativo"; 
				}else if($dados_contrato->alianca_tipo_servidor == 2){
					print "Pensionista"; 
					}
		?>
    </div>
</div>

<div class="campo" style="width: 25%;">
    <div class="campo-titulo">Matr. Servidor/SIAPE</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_matricula ?></div>
</div>

<div class="campo" style="width: 25%;">
    <div class="campo-titulo">Matr&iacute;cula Pensionista</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_matr_pensionista ?></div>
</div>

<div class="campo" style="width: 25%;">
    <div class="campo-titulo">Ocupa&ccedil;&atilde;o Principal</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_principal_atividade_nome ?></div>
</div>

<div class="campo" style="width: 100%;">
    <div class="campo-titulo">Nome da M&atilde;e (completo)</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_nome_mae ?></div>
</div>

<div class="campo" style="width: 70%;">
    <div class="campo-titulo">Endere&ccedil;o para Correspondencia (Rua, Avenida, Pra&ccedil;a)</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_endereco ?></div>
</div>

<div class="campo" style="width: 10%;">
    <div class="campo-titulo">N&uacute;mero</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_numero ?></div>
</div>

<div class="campo" style="width: 20%;">
    <div class="campo-titulo">Complemento de Endere&ccedil;o</div>
    <div class="campo-dados"><?= $dados_contrato->alianca_complemento ?></div>
</div>

<div class="campo" style="width: 30%;">
            <div class="campo-titulo">Bairrro</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_bairro ?></div>
</div>

<div class="campo" style="width: 70%;">
            <div class="campo-titulo">Cidade</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_cidade ?></div>
</div>

<div class="campo" style="width: 10%;">
            <div class="campo-titulo">UF</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_uf ?></div>
</div>

<div class="campo" style="width: 20%;">
            <div class="campo-titulo">CEP</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_cep ?></div>
</div>

<div class="campo" style="width: 35%;">
            <div class="campo-titulo">Tipo de Endere&ccedil;o</div>
            <div class="campo-dados">
			<? if($dados_contrato->alianca_tipo_endereco == "R"){ 
				print "Residencial" ;
				}else if($dados_contrato->alianca_tipo_endereco == "C"){
					print "Comercial"; 
					}
				?>
            </div>
</div>

<div class="campo" style="width: 32%;">
            <div class="campo-titulo">E-mail</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_email ?></div>
</div>

<div class="campo" style="width: 5%;">
			<? $residencial = explode("-", $dados_contrato->alianca_tel_residencial) ?>
            <div class="campo-titulo">DDD</div>
            <div class="campo-dados"><?= $residencial[0] ?></div>
</div>

<div class="campo" style="width: 20%;">
            <div class="campo-titulo">Telefone Residencial</div>
            <div class="campo-dados"><?= $residencial[1] ?></div>
</div>

<div class="campo" style="width: 5%;">
			<? $comercial = explode("-", $dados_contrato->alianca_tel_comercial) ?>
            <div class="campo-titulo">DDD</div>
            <div class="campo-dados"><?= $comercial[1] ?></div>
</div>

<div class="campo" style="width: 20%;">
            <div class="campo-titulo">Telefone Comercial</div>
            <div class="campo-dados"><?= $comercial[1] ?></div>
</div>

<div class="campo" style="width: 5%;">
            <div class="campo-titulo">Ramal</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_tel_ramal ?></div>
</div>

<div class="campo" style="width: 5%;">
			<? $celular = explode("-", $dados_contrato->alianca_tel_celular) ?>
            <div class="campo-titulo">DDD</div>
            <div class="campo-dados"><?= $celular[1] ?></div>
</div>

<div class="campo" style="width: 20%;">
            <div class="campo-titulo">Telefone Celular</div>
            <div class="campo-dados"><?= $celular[1] ?></div>
</div>

<div class="campo" style="width: 20%;">
            <div class="campo-titulo">PIS/PASEP</div>
            <div class="campo-dados"><?= $dados_contrato->alianca_pis ?></div>
</div>

<div class="texto">
	<h6>&sup1; Matr&iacute;cula do servidor no org&atilde;o de recebimento dos proventos.</h6>

</div>
<div class="titulo">
	3. RELA&Ccedil;&Atilde;O DOS DEPENDENTES</div>
<div class="texto">
  <strong>Legenda: PAR(parentesco): 11-c&ocirc;njuge 13-filho(a) 15-menor sob  guarda 16-pai/m&atilde;e EC(estado civil): S-Solteiro(a) C-Casado(a) V-Vi&uacute;vo D-Divorciado  J-Separado Judicialmente</strong>
  <? $i = 1; foreach($dados_dependentes as $dependente){  ?>
  
  	<div style="width:100%;">
   	  <div style="width:10%; height: 70px; float:left; padding: 50px 0 0 0; text-align:center;">Dep. <?= $i ?></div>
      <div style="width:90%; float:left;">
            <div class="campo" style="width: 85%;">
                <div class="campo-titulo">Nome Completo</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_nome_completo ?></div>
            </div>
            
            <div class="campo" style="width: 5%;">
                <div class="campo-titulo">Sexo</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_sexo ?></div>
            </div>
            
            <div class="campo" style="width: 5%;">
                <div class="campo-titulo">EC</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_estado_civil ?></div>
            </div>
            <div class="campo" style="width: 20%;">
                <div class="campo-titulo">CPF</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_cpf ?></div>
            </div>
            <div class="campo" style="width: 25%;">
                <div class="campo-titulo">N&ordm; Declara&ccedil;&atilde;o Nascido Vivo</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_nascido_vivo ?></div>
            </div>
            <div class="campo" style="width: 20%;">
                <div class="campo-titulo">Data de Nascimento</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_data_nascimento ?></div>
            </div>
            <div class="campo" style="width: 20%;">
                <div class="campo-titulo">Cart&atilde;o Nacional de Sa&uacute;de</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_n_cartao_saude ?></div>
            </div>
            
            <div class="campo" style="width: 10%;">
                <div class="campo-titulo">PAR</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_parentesco ?></div>
            </div>
            
            <div class="campo" style="width: 50%;">
                <div class="campo-titulo">N&ordm; do documento</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_n_documento ?></div>
            </div>
            
            <div class="campo" style="width: 50%;">
                <div class="campo-titulo">Tipo de documento</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_tipo_documento ?></div>
            </div>
        	
            <div class="campo" style="width: 20%;">
                <div class="campo-titulo">Org&atilde;o Emissor</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_orgao_emissor ?></div>
            </div>
            
            <div class="campo" style="width: 20%;">
                <div class="campo-titulo">Data de expedi&ccedil;&atilde;o</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_data_expedicao ?></div>
            </div>
            <div class="campo" style="width: 60%;">
                <div class="campo-titulo">Nome da M&atilde;e (completo)</div>
                <div class="campo-dados"><?= $dependente->alianca_dependente_nome_mae ?></div>
            </div>
    </div>
    <? $i ++; } ?>
</div>    
<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O
<p>Plano Coletivo Empresarial de Assist&ecirc;ncia &aacute; Sa&uacute;de</p>
</div>
<div class="titulo">
	4. PLANO PRETENDIDO / OPCIONAL</div>
<div class="campo" style="width: 100%;">
	<div class="campo-titulo">Tipo do Plano</div>
  	<div class="campo-dados"></div>
</div>
<div class="campo" style="width: 50%;">
            <div class="campo-titulo">Operadora Raz&atilde;o Social</div>
            <div class="campo-dados"></div>
</div>
<div class="campo" style="width: 50%;">
            <div class="campo-titulo">Reg. Oper. - ANS</div>
            <div class="campo-dados"></div>
</div>
<div class="campo" style="width: 50%;">
            <div class="campo-titulo">Nome do Plano Escolhido</div>
            <div class="campo-dados"></div>
</div>
<div class="campo" style="width: 50%;">
            <div class="campo-titulo">Registro do Plano - ANS</div>
            <div class="campo-dados"></div>
</div>
<div class="texto">
  <table width="100%" cellspacing="0" cellpadding="0" style="font-size:10px;">
        <tr>
            <td>Nome do Plano</td>
       	  	<td>REGISTRO ANS.</td>
            <td>ABRANG&Ecirc;NCIA</td>
            <td>SERVI&Ccedil;OS</td>
            <td>ACOMODA&Ccedil;&Atilde;O</td>
            <td>TIPO DE CONTRATA&Ccedil;&Atilde;O</td>
            <td>CAR&Ecirc;NCIA</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
  </table>
  <div class="campo" style="width: 18%;">
    	<div class="campo-titulo">Data do Inicio do Benef&iacute;cio</div>
    	<div class="campo-dados"></div>
  </div>
    <p>Os per&iacute;odos  de car&ecirc;ncia estipulados com a operadora passar&atilde;o a contar a partir desta data.<br>
      <strong>Obs.: </strong>Em caso de contrata&ccedil;&atilde;o de plano de assist&ecirc;ncia odontol&oacute;gica,  fica dispensado o preenchimento os itens 10 (dez) e 11 (onze) desta proposta de  ades&atilde;o.
</p>
</div>
<div class="texto">
      <strong>5. DEMONSTRATIVO DO VALOR INICIAL DA MENSALIDADE De acordo com a  faixa et&aacute;ria do titular e dependente(s)</strong>
      <hr />
      <table width="100%" cellspacing="0" cellpadding="0" style="font-size:10px;">
        <tr>
            <td>Tipo</td>
       	  	<td>Benefici&aacute;rios</td>
            <td>Idade</td>
            <td>Plano Principal</td>
            <td>Total</td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
       </tr>
       <tr>
            <td colspan="4">Mensalidade Total R$</td>
            <td></td>
       </tr>
    </table>

</div> 

<div class="texto">
    <strong>6. DADOS DE COBRAN&Ccedil;A</strong> 
    <hr />
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Forma Pagamento</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 40%;">
        <div class="campo-titulo">Descri&ccedil;&atilde;oda Unidade de Pagamento (UPAG)</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">C&oacute;digo da UPAG</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Titular da Conta Banc&aacute;ria</div>
        <div class="campo-dados">[  ]Titular [ ]OUTROS</div>
	</div>
    <div class="campo" style="width: 40%;">
        <div class="campo-titulo">Nome Completo Titular        da Conta Banc&aacute;ria</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">CPF Titular        da Conta Banc&aacute;ria</div>
        <div class="campo-dados"></div>
	</div>
    
  </div>  
  <div class="campo" style="width: 30%;">
        <div class="campo-titulo">N&deg; Banco</div>
        <div class="campo-dados"></div>
  </div>
  <div class="campo" style="width: 20%;">
        <div class="campo-titulo">Nome do Banco</div>
        <div class="campo-dados"></div>
  </div>
  <div class="campo" style="width: 15%;">
        <div class="campo-titulo">Ag&ecirc;ncia</div>
        <div class="campo-dados"></div>
  </div>
  <div class="campo" style="width: 15%;">
        <div class="campo-titulo">N&deg; da Conta</div>
        <div class="campo-dados"></div>
  </div>
    <div class="campo" style="width: 5%;">
        <div class="campo-titulo">TP</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 15%;">
        <div class="campo-titulo">CO</div>
        <div class="campo-dados"></div>
	</div>
</div>
<div class="texto">
  <p>(1)  Bancos Conveniados: 001 Banco
    do Brasil  | 033 Santander
    | 070 BRB
    | 104  Caixa    Econ&ocirc;mica  Federal | 237 Bradesco    | 341  Banco    Ita&uacute; |  756 Bancoob<br>
    (2) TP  Tipo    de Conta:  C corrente ou P poupan&ccedil;a <br>
    (3) CO No
    caso de  CEF especificar o c&oacute;digo da opera&ccedil;&atilde;o<br>
  <strong>Obs.: 1) Verifique se a op&ccedil;&atilde;o consigna&ccedil;&atilde;o em folha est&aacute; dispon&iacute;vel  para o seu contrato;</strong> <br>
  <strong>2) Em caso de consigna&ccedil;&atilde;o em folha, &eacute; obrigat&oacute;rio o  preenchimento dos dados banc&aacute;rios e da Unidade de Pagamento (UPAG)</strong> <strong>acima, do Tipo de Benefici&aacute;rio, da Matr&iacute;cula Servidor e Matr&iacute;cula  do Pensionista, quando houver, localizados no item 2 (dois) dessa</strong><br>
  <strong>proposta de ades&atilde;o.</strong><br>
    A forma  de pagamento referente ao plano de assist&ecirc;ncia &agrave; sa&uacute;de ser&aacute; consigna&ccedil;&atilde;o em  folha de pagamento e/ou d&eacute;bito em conta e ser&aacute;    efetivado  no m&ecirc;s da cobertura do benef&iacute;cio, no segundo dia &uacute;til em caso de d&eacute;bito em  conta.<br>
    Eventuais  diferen&ccedil;as no valor da mensalidade, originadas de movimenta&ccedil;&otilde;es cadastrais,  tais como: altera&ccedil;&atilde;o de plano, inclus&atilde;o ou 
    exclus&atilde;o  de benefici&aacute;rio, realizadas ap&oacute;s o envio das informa&ccedil;&otilde;es para consigna&ccedil;&atilde;o em  folha ser&atilde;o cobradas ou devolvidas no m&ecirc;s    subsequente.<br>
  Autorizo  a ALIAN&Ccedil;A ADMINISTRADORA a realizar a consigna&ccedil;&atilde;o em folha e/ou o d&eacute;bito em  conta do valor referente &agrave; mensalidade e a    coparticipa&ccedil;&atilde;o,  quando houver, do plano de assist&ecirc;ncia &agrave; sa&uacute;de escolhido nesta proposta de ades&atilde;o.  Em caso de inexist&ecirc;ncia de    margem  consign&aacute;vel, autorizo a Alian&ccedil;a Administradora a realizar o d&eacute;bito em conta do  valor devido, conforme dados banc&aacute;rios  informados neste item.
            </p><div style="width:100%;">
              <div style="width:40%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Local e Data</div>
        <div style="width:40%; border-top: 1px solid #333; float:left; text-align:center; margin: 50px 25px 10px;">Assinatura do Titular da Conta Banc&aacute;ria</div>
  </div>
</div> 
<div class="titulo">7. CORRETORA AUTORIZADA</div>  
<div class="texto">
	<div class="campo" style="width: 70%;">
        <div class="campo-titulo">Nome da Corretora</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">CNPJ</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 70%;">
        <div class="campo-titulo">Nome do Agente de Vendas</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">C&oacute;d. do Agente de Vendas</div>
        <div class="campo-dados"></div>
	</div>
    
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">CPF do Agente de Vendas</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">C&oacute;digo do Angariador</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 10%;">
        <div class="campo-titulo">C&oacute;d. Equ.</div>
        <div class="campo-dados"></div>
	</div>
  <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Equipe de Vendas</div>
        <div class="campo-dados"></div>
  </div>

</div>
<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O
<p>Plano Coletivo Empresarial de Assist&ecirc;ncia &aacute; Sa&uacute;de</p></div>
<div class="titulo">8. AUTORIZA&Ccedil;&Otilde;ES</div>
<div class="texto">
  Autorizo  a ALIAN&Ccedil;A ADMINISTRADORA a enviar comunica&ccedil;&otilde;es e informa&ccedil;&otilde;es sobre o plano  contratado, outros produtos de assist&ecirc;ncia &agrave;    sa&uacute;de,  bem como dados relativos ao pagamento da mensalidade pelo email    indicado  nesta proposta ou por SMS (Short Message    Service).
</div>
<div class="titulo">9. CONDI&Ccedil;&Otilde;ES GERAIS DA CONTRATA&Ccedil;&Atilde;O</div>
<div class="texto">

    9.1. A  presente proposta &eacute; para ades&atilde;o a um &ldquo;contrato coletivo empresarial&rdquo; estipulado  pela ALIAN&Ccedil;A ADMINISTRADORA    DE    BENEF&Iacute;CIOS  DE SA&Uacute;DE LTDA., CNPJ 08.407.581/000192,    doravante  denominada ALIAN&Ccedil;A ADMINISTRADORA, com a operadora ou    seguradora,  decorrente do termo de acordo firmado com a pessoa jur&iacute;dica identificada nesta  proposta de ades&atilde;o. Tal contrato coletivo    empresarial  destinase
    exclusivamente  &agrave;s pessoas f&iacute;sicas que mantenham v&iacute;nculo empregat&iacute;cio ou estatut&aacute;rio com a  PESSOA    JUR&Iacute;DICA  SUBESTIPULANTE, identificada nesta proposta de ades&atilde;o como PESSOA JUR&Iacute;DICA. N&atilde;o  se trata, portanto, de ades&atilde;o a um    plano  individual com a operadora ou seguradora definida nesta proposta de ades&atilde;o.<br>
    9.2. A  ALIAN&Ccedil;A ADMINISTRADORA &eacute; investida de todos os poderes inerentes &agrave; fun&ccedil;&atilde;o de  estipulante, dentre outros, para representar os 
    benefici&aacute;rios  que aderirem ao plano no cumprimento ou nas altera&ccedil;&otilde;es das cl&aacute;usulas  contratuais, bem como no reajuste ou modifica&ccedil;&atilde;o    dos valores das  mensalidades.<br>
    9.3. A  ades&atilde;o do proponente titular &eacute; volunt&aacute;ria e facultativa.<br>
    9.4. A  aprova&ccedil;&atilde;o do proponente titular e dos dependentes est&aacute; condicionada &agrave; an&aacute;lise  da vincula&ccedil;&atilde;o &agrave; PESSOA JUR&Iacute;DICA e da condi&ccedil;&atilde;o    de depend&ecirc;ncia.  Se forem constatadas irregularidades, eventual recusa dever&aacute; ser apresentada ao  proponente titular em at&eacute; 15 (quinze)    dias do  recebimento desta proposta na ALIAN&Ccedil;A ADMINISTRADORA.<br>
    9.5. As  condi&ccedil;&otilde;es do termo de acordo firmado entre a PESSOA JUR&Iacute;DICA e a ALIAN&Ccedil;A  ADMINISTRADORA, bem como suas    particularidades  de cobertura, despesas n&atilde;o cobertas e exclus&atilde;o do plano, na forma prevista no  termo de refer&ecirc;ncia anexo &agrave; Portaria    Normativa  n&ordm; 5, de 11 de outubro de 2010, da Secretaria de Recursos Humanos do Minist&eacute;rio  do Planejamento, Or&ccedil;amento e Gest&atilde;o s&atilde;o    de conhecimento do  proponente titular. <br>
    9.5.1. N&atilde;o  haver&aacute; car&ecirc;ncia para a inclus&atilde;o do benefici&aacute;rio que formalizar seu ingresso no  plano: a) no prazo de 60 (sessenta) dias    contados  da data do termo de acordo firmado entre a PESSOA JUR&Iacute;DICA e a ALIAN&Ccedil;A  ADMINISTRADORA; e b) no prazo de 30 (trinta) dias    de sua  vincula&ccedil;&atilde;o &agrave; PESSOA JUR&Iacute;DICA.<br>
    9.5.2. Os  prazos de car&ecirc;ncia bem como as demais situa&ccedil;&otilde;es n&atilde;o previstas na Portaria  Normativa n&ordm;. 5, de 11 de outubro de 2010, da    Secretaria  de Recursos Humanos do Minist&eacute;rio de Or&ccedil;amento e Gest&atilde;o, dever&atilde;o observar as  normas regulamentares da Ag&ecirc;ncia    Nacional  de Sa&uacute;de Suplementar ANS,    conforme  disposto no Art. 42 da mencionada portaria normativa.<br>
    9.5.3. A  ades&atilde;o dos pensionistas do benefici&aacute;rio titular no plano de assist&ecirc;ncia &agrave; sa&uacute;de  est&aacute; condicionada ao registro de sua op&ccedil;&atilde;o    como  benefici&aacute;rio do plano, junto ao setorial ou seccional do SIPEC.<br>
    9.5.4. N&atilde;o  estar&aacute; obrigado ao cumprimento de nova car&ecirc;ncia, o pensionista que aderir ao  mesmo plano do benefici&aacute;rio titular desde que    sua ades&atilde;o  ocorra dentro do prazo de 30 (trinta) dias contados do &oacute;bito.<br>
    9.6. Ap&oacute;s  a aprova&ccedil;&atilde;o desta proposta, a cobertura assistencial contratada ter&aacute; in&iacute;cio na  data especificada no item 4 (quatro), localizado    nesta proposta  de ades&atilde;o.<br>
    9.6.1. A  validade desta proposta de ades&atilde;o est&aacute; condicionada &agrave; entrega de toda a  documenta&ccedil;&atilde;o exigida por lei, pelas normativas da    ANS e  pelo &oacute;rg&atilde;o/entidade ao qual est&aacute; vinculado o proponente titular.<br>
    9.6.2.  Caso o recebimento da documenta&ccedil;&atilde;o n&atilde;o ocorra no prazo de movimenta&ccedil;&atilde;o  cadastral de que trata o item 9.12.1 (nove ponto doze 
    ponto  um), o in&iacute;cio da cobertura assistencial contratada ser&aacute; postergado para o  primeiro dia do m&ecirc;s subsequente ao recebimento da    documenta&ccedil;&atilde;o,  limitado a 30 (trinta) dias contados da data indicada no item 4 (quatro) desta  proposta. Ap&oacute;s esse per&iacute;odo ser&aacute;    necess&aacute;rio  o preenchimento de nova proposta.<br>
    9.7. A  data de vencimento da mensalidade e da coparticipa&ccedil;&atilde;o, quando houver, bem como  a forma de pagamento s&atilde;o as definidas no    item 6  (seis) localizado nesta proposta de ades&atilde;o. Caso o pagamento da mensalidade e  da coparticipa&ccedil;&atilde;o n&atilde;o ocorram no vencimento    estipulado,  o benefici&aacute;rio titular dever&aacute; contatar a ALIAN&Ccedil;A ADMINISTRADORA nos locais e  pelos meios indicados no item 9.12 (nove    ponto doze).<br>
    9.8. O  atraso no pagamento da mensalidade e da coparticipa&ccedil;&atilde;o, esta quando houver,  difere das regras previstas para os planos 
    individuais.  Em caso de atraso no pagamento de mensalidade ou coparticipa&ccedil;&atilde;o, al&eacute;m da exclus&atilde;o  prevista no item 9.9 (nove ponto    nove)  desta proposta, o valor n&atilde;o pago ser&aacute; cobrado corrigido monetariamente    pelo  IGPMFGV    ou outro &iacute;ndice  que venha substitu&iacute;lo,    acrescido  de juros de 1% a.m (um por cento ao m&ecirc;s), 2% (dois por cento) de multa sobre o  d&eacute;bito, despesas com cobran&ccedil;a por empresa    especializada  e honor&aacute;rios advocat&iacute;cios.<br>
    9.9. A  PESSOA JUR&Iacute;DICA e a ALIAN&Ccedil;A ADMINISTRADORA poder&atilde;o proceder a exclus&atilde;o do plano  do benefici&aacute;rio titular e dos    dependentes  nos seguintes casos: (I) falta de quita&ccedil;&atilde;o da mensalidade e/ou da coparticipa&ccedil;&atilde;o,  esta quando houver, no prazo de 60    (sessenta)  dias de seu vencimento; (II) pela ocorr&ecirc;ncia de ato que implique na suspens&atilde;o  dos vencimentos, tais como, exonera&ccedil;&atilde;o,    redistribui&ccedil;&atilde;o  e demiss&atilde;o, bem como deslocamento do benefici&aacute;rio titular para outro &oacute;rg&atilde;o ou  entidade n&atilde;o coberto pelo plano,    observado  o art. 30 da Lei n&ordm; 9.656/98; (III) por solicita&ccedil;&atilde;o do benefici&aacute;rio titular;  (IV) por &oacute;bito, a partir da data de sua comunica&ccedil;&atilde;o&agrave;    ADMINISTRADORA;  (V) por fraude; (VI) pela rescis&atilde;o do termo de acordo entre a PESSOA JUR&Iacute;DICA e  a ALIAN&Ccedil;A ADMINISTRADORA e, a    exclus&atilde;o  dos dependentes, pela perda da condi&ccedil;&atilde;o de depend&ecirc;ncia, sem preju&iacute;zo de a  PESSOA JUR&Iacute;DICA e/ou a ALIAN&Ccedil;A    ADMINISTRADORA  tamb&eacute;m procederem &agrave;s exclus&otilde;es pass&iacute;veis de serem aplicadas pela  operadora/seguradora respons&aacute;vel pelo plano    oferecido.<br>
    9.9.1. No  caso de licen&ccedil;a sem remunera&ccedil;&atilde;o, afastamento legal ou suspens&atilde;o tempor&aacute;ria de  remunera&ccedil;&atilde;o, ser&aacute; poss&iacute;vel optar pela    perman&ecirc;ncia  no plano, desde que o benefici&aacute;rio titular assuma integralmente o seu custeio  durante o per&iacute;odo da licen&ccedil;a. <br>
  9.9.2. No  caso de exonera&ccedil;&atilde;o ou demiss&atilde;o sem justa causa, ou ainda de aposentadoria, ser&aacute;  assegurado ao benefici&aacute;rio o direito de  optar, no prazo de 30  (trinta) dias a contar do aviso pr&eacute;vio ou do ato formal de exonera&ccedil;&atilde;o, demiss&atilde;o  ou aposentadoria, pela manuten&ccedil;&atilde;o
</div>

<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O<p>Plano Coletivo Empresarial de Assist&ecirc;ncia &aacute; Sa&uacute;de</p></div>
<div class="texto">
  <p>da condi&ccedil;&atilde;o de benefici&aacute;rio, nas mesmas condi&ccedil;&otilde;es de cobertura assistencial de que gozava, desde que assuma o seu pagamento    integral, nos termos da RN ANS, n&ordm; 279/2011.<br>
    9.9.2.1. Quanto aos aposentados/inativos, dever&atilde;o ser observadas as peculiaridades previstas na Portaria Normativa n&ordm; 5, de 11 de    outubro de 2010, da Secretaria de Recursos Humanos do Minist&eacute;rio do Planejamento, Or&ccedil;amento e Gest&atilde;o.<br>
    9.10. No caso de exclus&atilde;o do benefici&aacute;rio titular ou dos dependentes do plano, a cobertura de servi&ccedil;os ser&aacute; totalmente encerrada no    &uacute;ltimo dia da vig&ecirc;ncia em que for efetivada a exclus&atilde;o, sem preju&iacute;zo da cobran&ccedil;a de d&eacute;bitos pendentes.<br>
    9.11. Se houver cancelamento por solicita&ccedil;&atilde;o do benefici&aacute;rio titular ou pelos motivos constantes do item 9.9 (nove ponto nove) desta    proposta, os cart&otilde;es de identifica&ccedil;&atilde;o do benefici&aacute;rio titular e dos dependentes, dever&atilde;o ser devolvidos &agrave; ALIAN&Ccedil;A ADMINISTRADORA no    prazo de 48 (quarenta e oito horas), a partir do cancelamento    ou da exclus&atilde;o. A responsabilidade civil, criminal e financeira pela    utiliza&ccedil;&atilde;o indevida do plano, incluindo a por terceiros com ou sem consentimento do benefici&aacute;rio titular, e o pagamento pelos<br>
    procedimentos realizados ap&oacute;s o cancelamento ou exclus&atilde;o do plano s&atilde;o de responsabilidade do benefici&aacute;rio titular.<br>
    9.11.1. A segunda via dos cart&otilde;es de identifica&ccedil;&atilde;o ser&aacute; objeto de cobran&ccedil;a ao benefici&aacute;rio, cujo valor ser&aacute; informado no momento da    solicita&ccedil;&atilde;o.<br>
    9.12. As altera&ccedil;&otilde;es cadastrais, principalmente de endere&ccedil;o, endere&ccedil;o eletr&ocirc;nico e conta banc&aacute;ria para d&eacute;bito, quando for o caso, dever&atilde;o    ser comunicadas formalmente &agrave; PESSOA JUR&Iacute;DICA e &agrave; ALIAN&Ccedil;A ADMINISTRADORA, assumindo o benefici&aacute;rio titular a    responsabilidade pela incorre&ccedil;&atilde;o das informa&ccedil;&otilde;es ou sua n&atilde;o informa&ccedil;&atilde;o.<br>
    9.12.1. A solicita&ccedil;&atilde;o de altera&ccedil;&atilde;o cadastral, de inclus&atilde;o e de exclus&atilde;o em um dos planos dever&aacute; ser efetivada no prazo descrito no item 6    (seis) do Anexo I desta proposta de ades&atilde;o.<br>
    9.12.2. A solicita&ccedil;&atilde;o de inclus&atilde;o dever&aacute; ser formalizada em formul&aacute;rio espec&iacute;fico, entregue em via original assinada, acompanhada de    c&oacute;pia dos documentos comprobat&oacute;rios das informa&ccedil;&otilde;es prestadas, e dever&aacute; ser enviada por correspond&ecirc;ncia &agrave; ALIAN&Ccedil;A    ADMINISTRADORA, aos cuidados do Departamento de Cadastro, situada no SCN Quadra 05, Bloco A, Torre Norte, Sala 418, Edif&iacute;cio    Bras&iacute;lia Shopping, Bras&iacute;liaDF,    CEP: 70.715900;    telefone: (61) 21037000.    As demais solicita&ccedil;&otilde;es poder&atilde;o ser encaminhadas por    correios, no endere&ccedil;o aqui indicado; por fax: (61) 21037058;    ou por email:    cadastro@aliancaadm.com.br (com documenta&ccedil;&atilde;o    digitalizada).<br>
    <strong>9.12.3. A solicita&ccedil;&atilde;o de cancelamento do plano dever&aacute; ser formalizada por documento escrito, entregue em via original assinada pelo    benefici&aacute;rio titular, aos cuidados do Departamento de Cadastro da ALIAN&Ccedil;A ADMINISTRADORA, situado no SCN Quadra 05, Bloco A,    Torre Norte, Sala 418, Edif&iacute;cio Bras&iacute;lia Shopping, Bras&iacute;liaDF,    CEP: 70.715900.</strong><br>
    9.13. A mensalidade do plano de assist&ecirc;ncia &agrave; sa&uacute;de sofrer&aacute; altera&ccedil;&atilde;o nos seguintes casos:<br>
    9.13.1. Anualmente, o reajuste da mensalidade do plano ocorrer&aacute; no anivers&aacute;rio do termo de acordo firmado entre a PESSOA JUR&Iacute;DICA e    a ALIAN&Ccedil;A ADMINISTRADORA, independente da data de inclus&atilde;o do benefici&aacute;rio titular e dos dependentes, e observar&aacute;,    cumulativamente, no per&iacute;odo dos 12 (doze) meses anteriores, os crit&eacute;rios descritos no Anexo I da presente proposta.<br>
    9.13.2. A qualquer momento, o valor da mensalidade do plano de assist&ecirc;ncia m&eacute;dica ser&aacute; modificado caso ocorra mudan&ccedil;a de faixa    et&aacute;ria do benefici&aacute;rio titular e dos dependentes, de acordo com os pre&ccedil;os praticados na nova faixa et&aacute;ria alcan&ccedil;ada, no m&ecirc;s seguinte ao    seu anivers&aacute;rio, de acordo com tabela pr&oacute;pria da operadora/seguradora que acompanha a presente proposta (Anexo I), conforme    previsto no art. 22 da RN ANS n&ordm; 195/2009.<br>
    9.14. O plano coletivo empresarial de assist&ecirc;ncia &agrave; sa&uacute;de contratado na forma da presente proposta n&atilde;o est&aacute; sujeito aos &iacute;ndices de    reajuste fixados pela ANS para planos individuais.<br>
    
  </p>
</div>
<div class="titulo">10. CARTA DE ORIENTA&Ccedil;&Atilde;O DE BENEFICI&Aacute;RIOS</div>
<div class="texto">  
  <p>Prezado(a) Benefici&aacute;rio(a),<br>
    A <strong>Ag&ecirc;ncia Nacional de Sa&uacute;de Suplementar  (ANS)</strong>, institui&ccedil;&atilde;o que regula  as atividades das operadoras de planos privados de assist&ecirc;ncia &agrave; sa&uacute;de, e tem  como    miss&atilde;o defender o interesse p&uacute;blico vem, por meio desta, prestar  informa&ccedil;&otilde;es para o preenchimento da DECLARA&Ccedil;&Atilde;O DE SA&Uacute;DE.<br>
  <p style="border:1px solid #333;">
  <strong>O QUE &Eacute; A DECLARA&Ccedil;&Atilde;O DE SA&Uacute;DE?</strong><br>
  &Eacute; o formul&aacute;rio que acompanha o Contrato do Plano de Sa&uacute;de, onde  o benefici&aacute;rio ou seu representante legal dever&aacute; informar as doen&ccedil;as ou les&otilde;es  preexistentes    que saiba ser portador ou sofredor no momento da contrata&ccedil;&atilde;o do  plano. Para o seu preenchimento, o benefici&aacute;rio tem o direito de ser orientado,    gratuitamente, por um m&eacute;dico credenciado/referenciado pela  operadora. Se optar por um profissional de sua livre escolha, assumir&aacute; o custo  desta op&ccedil;&atilde;o.    Portanto, se o benefici&aacute;rio (voc&ecirc;) toma medicamentos  regularmente, consulta m&eacute;dicos por problema de sa&uacute;de do qual conhece o diagn&oacute;stico,  fez qualquer    exame que identificou alguma doen&ccedil;a ou les&atilde;o, esteve internado  ou submeteuse    a alguma cirurgia, DEVE DECLARAR ESTA DOEN&Ccedil;A OU LES&Atilde;O.<br>
  </p> 
  <p style="border:1px solid #333;">
  <strong>AO DECLARAR AS DOEN&Ccedil;AS E/OU LES&Otilde;ES QUE O  BENEFICI&Aacute;RIO SAIBA SER PORTADOR NO MOMENTO DA CONTRATA&Ccedil;&Atilde;O:</strong><br>
  &bull; A operadora N&Atilde;O poder&aacute; impedilo    de contratar o plano de sa&uacute;de. Caso isto ocorra, encaminhe a den&uacute;ncia  &agrave; ANS.<br>
  &bull; A operadora dever&aacute; oferecer: cobertura total ou COBERTURA  PARCIAL TEMPOR&Aacute;RIA (CPT), podendo ainda oferecer o Agravo, que &eacute; um acr&eacute;scimo    no valor da mensalidade, pago ao plano privado de assist&ecirc;ncia &agrave;  sa&uacute;de, para que se possa utilizar toda a cobertura contratada, ap&oacute;s os prazos  de car&ecirc;ncias    contratuais.<br>
  &bull; No caso de CPT, haver&aacute; restri&ccedil;&atilde;o de cobertura para cirurgias,  leitos de alta tecnologia (UTI, unidade coronariana ou neonatal) e  procedimentos de alta    complexidade PAC<br>
    (tomografia, resson&acirc;ncia, etc.*) EXCLUSIVAMENTE relacionados &agrave;  doen&ccedil;a ou les&atilde;o declarada, at&eacute; 24 meses, contados desde a    assinatura do contrato. Ap&oacute;s o per&iacute;odo m&aacute;ximo de 24 meses da  assinatura contratual, a cobertura passar&aacute; a ser integral de acordo com o plano  contratado.<br>
  &bull; N&Atilde;O haver&aacute; restri&ccedil;&atilde;o de cobertura para consultas m&eacute;dicas,  interna&ccedil;&otilde;es n&atilde;o cir&uacute;rgicas, exames e procedimentos que n&atilde;o sejam de alta  complexidade, mesmo    que  relacionados &agrave; doen&ccedil;a ou les&atilde;o preexistente declarada, desde que cumpridos os  prazos de car&ecirc;ncias estabelecidas no contrato.    Nao caber� alega�ao posterior de omissao de informa�ao na Declara�ao de Sa�de por parte da operadora para esta doen�a ou lesao.
  </p>
    <p style="border:1px solid #333;"><strong>AO N&Atilde;O DECLARAR AS DOEN&Ccedil;AS E/OU LES&Otilde;ES  QUE O BENEFICI&Aacute;RIO SAIBA SER PORTADOR NO MOMENTO DA CONTRATA&Ccedil;&Atilde;O:</strong><br>
  &bull; A operadora poder&aacute; suspeitar de omiss&atilde;o de informa&ccedil;&atilde;o e, neste  caso, dever&aacute; comunicar imediatamente ao benefici&aacute;rio, podendo oferecer CPT, ou  solicitar      abertura de processo administrativo junto &agrave; ANS, denunciando a  omiss&atilde;o da informa&ccedil;&atilde;o.<br>
  &bull; Comprovada a omiss&atilde;o de informa&ccedil;&atilde;o pelo benefici&aacute;rio, a  operadora poder&aacute; RESCINDIR o contrato por FRAUDE e responsabiliz&aacute;lo      pelos procedimentos      referentes a doen&ccedil;a ou les&atilde;o n&atilde;o declarada.<br>
  &bull; At&eacute; o julgamento final do processo pela ANS, N&Atilde;O poder&aacute;  ocorrer suspens&atilde;o do atendimento nem rescis&atilde;o do contrato. Caso isto ocorra,  encaminhe a      den&uacute;ncia  &agrave; ANS.</p>

    <p style="border:1px solid #333;"><strong>ATEN&Ccedil;&Atilde;O! </strong>Se a operadora oferecer redu&ccedil;&atilde;o ou isen&ccedil;&atilde;o de car&ecirc;ncia, isto n&atilde;o  significa que dar&aacute; cobertura assistencial para as doen&ccedil;as ou les&otilde;es que o      benefici&aacute;rio saiba ter no momento da assinatura contratual.  Cobertura Parcial Tempor&aacute;ria CPT      N&Atilde;O  &eacute; car&ecirc;ncia! Portanto, o benefici&aacute;rio n&atilde;o deve deixar de      informar  se possui alguma doen&ccedil;a ou les&atilde;o ao preencher a Declara&ccedil;&atilde;o de Sa&uacute;de!</p>

    * Para consultar a lista completa de procedimentos de alta  complexidade &ndash; PAC, acesse o Rol de Procedimentos e Eventos em Sa&uacute;de da ANS no  endere&ccedil;o    eletr&ocirc;nico: <strong>www.ans.gov.br  - Perfil </strong><strong>Benefici&aacute;rio</strong>.<br>
Em caso de d&uacute;vidas, entre em contato com a ANS pelo telefone <strong>0800-701-9656 </strong>ou consulte a p&aacute;gina da  ANS <strong>www.</strong><strong>ans.gov.br -</strong><strong> Perfil</strong> <strong>Benefici&aacute;rio.</strong></div>

<div class="texto">
<hr />
Intermedi&aacute;rio entre a operadora e o benefici&aacute;rio

	<div style="width:100%;">
  		<div style="width:40%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Nome completo</div>
        <div style="width:40%; border-top: 1px solid #333; float:left; text-align:center; margin: 50px 25px 10px;">CPF</div>
  	</div>
    <div style="width:100%;">
  		<div style="width:40%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Local e data</div>
        <div style="width:40%; border-top: 1px solid #333; float:left; text-align:center; margin: 50px 25px 10px;">Assinatura</div>
  	</div>
    
</div>
<div class="texto">
	<hr />
	Benefici&aacute;rio
	<div style="width:100%;">
  		<div style="width:40%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Nome completo</div>
  	</div>    
</div>

<div class="titulo">11. DECLARA&Ccedil;&Atilde;O DE SA&Uacute;DE</div>
<div class="texto">Com o prop&oacute;sito de atender &agrave; operadora escolhida, o benefici&aacute;rio titular dever&aacute; preencher e assinar a declara&ccedil;&atilde;o de sa&uacute;de consoante  modelo aprovado pelas operadoras contratadas pela ALIAN&Ccedil;A ADMINISTRADORA, registrando todas as informa&ccedil;&otilde;es sobre doen&ccedil;as de 
  que seja portador e das quais tenha conhecimento, com rela&ccedil;&atilde;o a si e aos dependentes que incluir no plano. <br>
  INFORMA&Ccedil;&Otilde;ES IMPORTANTES<br>
  11.1. Para o preenchimento da Declara&ccedil;&atilde;o de Sa&uacute;de, o benefici&aacute;rio titular dever&aacute; observar as orienta&ccedil;&otilde;es da Carta de Orienta&ccedil;&atilde;o ao  Benefici&aacute;rio, entregue neste ato, tendo a op&ccedil;&atilde;o de ser orientado, sem &ocirc;nus financeiro, por um m&eacute;dico da operadora ou por um de sua  confian&ccedil;a, caso em que as despesas com honor&aacute;rios ser&atilde;o de sua responsabilidade. <br>
  11.2. Havendo declara&ccedil;&atilde;o de doen&ccedil;a ou les&atilde;o preexistente ser&aacute; aplicada pela operadora a cobertura parcial tempor&aacute;ria (CPT), na forma 
  determinada pela Lei n&ordm; 9.656/98 e sua atualiza&ccedil;&atilde;o.<br>
  11.2.1. Doen&ccedil;as ou les&otilde;es preexistentes (DLP) s&atilde;o aquelas que o benefici&aacute;rio ou seu representante legal saiba ser portador ou sofredor, 
  no momento da contrata&ccedil;&atilde;o ou ades&atilde;o ao plano privado de assist&ecirc;ncia &agrave; sa&uacute;de, de acordo com o art. 11 da Lei n&ordm; 9.656, de 3 de junho de  1998 e o inciso IX do artigo 4&ordm; da Lei n&ordm; 9.961, de 28 de janeiro de 2000;<br>
  11.2.2. Cobertura parcial tempor&aacute;ria (CPT) &eacute; aquela que admite, por um per&iacute;odo ininterrupto de at&eacute; 24 meses, a partir da data da  contrata&ccedil;&atilde;o ou ades&atilde;o ao plano privado de assist&ecirc;ncia &agrave; sa&uacute;de, a suspens&atilde;o da cobertura de Procedimentos de Alta Complexidade  (PAC), leitos de alta tecnologia e procedimentos cir&uacute;rgicos, desde que relacionados exclusivamente &agrave;s doen&ccedil;as ou les&otilde;es preexistentes  declaradas pelo benefici&aacute;rio ou seu representante legal; <br>
  11.2.3. Agravo &eacute; qualquer acr&eacute;scimo no valor da contrapresta&ccedil;&atilde;o paga ao plano privado de assist&ecirc;ncia &agrave; sa&uacute;de, para que o benefici&aacute;rio  tenha direito integral &agrave; cobertura contratada, para a doen&ccedil;a ou les&atilde;o preexistente declarada, ap&oacute;s os prazos de car&ecirc;ncias contratuais, de  acordo com as condi&ccedil;&otilde;es negociadas entre a operadora e o benefici&aacute;rio; <br>
  PREENCHIMENTO<br>
  Os campos de 1 a 28 dever&atilde;o ser preenchidos com S (SIM) ou N (N&Atilde;O). Caso um ou mais itens sejam afirmativos, esclare&ccedil;a-os no quadro complementar no final deste question&aacute;rio.
	
  <table cellpadding="0" cellspacing="0" style="width: 100%; font-size: 9px; border: 1px solid #666;">
    	<tr style="background:#999;">
        	<td style="padding: 5px; text-align:center; border: 1px solid #666;">Declara&ccedil;&atilde;o Pessoal de Sa&uacute;de</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">Titular</td>
        </tr>
        <tr>
        	<td style="border: 1px solid #666;">Peso</td>
            <td style="border: 1px solid #666;"></td>
        </tr>
        <tr >
        	<td style="border: 1px solid #666;">Altura</td>
            <td style="border: 1px solid #666;"></td>
        </tr>
        <tr>
        	<td style="border: 1px solid #666;">Se voce escolheu um plano odontologico, nao e necessario o preenchimento da Declaracao de Saude. Sel</td>
            <td style="border: 1px solid #666;">N</td>
        </tr>
  </table>

</div>
<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O<p>Plano Coletivo Empresarial de Assist&ecirc;ncia &aacute; Sa&uacute;de</p></div>
<div class="titulo">
	12. ENTREVISTA QUALIFICADA
</div>
<div class="texto">
  ( ) 1.  Declaro que fui orientado por m&eacute;dico referenciado da operadora no preenchimento  da declara&ccedil;&atilde;o de sa&uacute;de, item 10 (dez) desta proposta.<br>
    ( ) 2.  Declaro que fui orientado pelo meu m&eacute;dico particular, n&atilde;o referenciado da  operadora, no preenchimento da declara&ccedil;&atilde;o de sa&uacute;de, item 10  (dez) desta proposta.<br>
    ( ) 3.  Declaro que me foram oferecidas as op&ccedil;&otilde;es 1 e 2 acima especificadas e, que  tendo conhecimento e todos os itens da declara&ccedil;&atilde;o de sa&uacute;de, deixei de fazer a  entrevista m&eacute;dica qualificada, assumindo total responsabilidade pelas informa&ccedil;&otilde;es  por mim prestadas.
    <div style="width:100%;">
	  <div style="width:20%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Local e data</div>
        <div style="width:40%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">Assinatura do M&eacute;dico Orientador, se for o caso</div>
      <div style="width:20%; border-top: 1px solid #333; float:left; margin: 50px 25px 10px; text-align:center;">CRM, se for o caso</div>
  	</div> 
</div>

<div class="titulo">
	13. DECLARA&Ccedil;&Otilde;ES DO PROPONENTE</div>
<div class="texto">13.1. Na qualidade de proponente declaro que ao preencher e assinar a declara&ccedil;&atilde;o de sa&uacute;de assumo a inteira responsabilidade por  qualquer omiss&atilde;o, falsidade, inexatid&atilde;o ou erro nas informa&ccedil;&otilde;es aqui prestadas, sujeitandome  ao disposto no C&oacute;digo Civil Brasileiro:&ldquo;Art. 422. Os contratantes s&atilde;o obrigados a guardar, assim na conclus&atilde;o do contrato, como em sua execu&ccedil;&atilde;o, os princ&iacute;pios de probidade e  boaf&eacute;&rdquo;.<br>
  13.2. Declaro que eu e meus dependentes temos ci&ecirc;ncia de como proceder &agrave; correta utiliza&ccedil;&atilde;o do cart&atilde;o de identifica&ccedil;&atilde;o e me  responsabilizo pela utiliza&ccedil;&atilde;o indevida, entre outros, nos casos de perda, extravio, utiliza&ccedil;&atilde;o por terceiros, bem como, utiliza&ccedil;&atilde;o posterior&agrave;  vig&ecirc;ncia do contrato ou exclus&atilde;o, por mim e/ou meus respectivos dependentes eventualmente inscritos. <br>
  13.3. Declaro ter recebido informa&ccedil;&otilde;es suficientes para a perfeita compreens&atilde;o do plano de assist&ecirc;ncia &agrave; sa&uacute;de e/ou odontol&oacute;gica que  estou firmando com a operadora/seguradora, entre outras e especialmente sobre: a) coberturas, exclus&otilde;es e coberturas opcionais  oferecidas; b) per&iacute;odos de car&ecirc;ncia e de cobertura parcial tempor&aacute;ria; c) procedimentos a serem adotados para obter efici&ecirc;ncia nos  atendimentos; d) abrang&ecirc;ncia da cobertura dos produtos; e) crit&eacute;rios de reajustes e varia&ccedil;&otilde;es pecuni&aacute;rias a serem aplicados &agrave;s  mensalidades fixadas; f) coparticipa&ccedil;&atilde;o nas despesas, quando houver; g) condi&ccedil;&otilde;es em que ser&atilde;o prestados os atendimentos; h) redes  assistenciais; e i) franquia nas despesas odontol&oacute;gicas, quando houver. Declaro, tamb&eacute;m, que recebi e li o Manual de Orienta&ccedil;&atilde;o para  Contrata&ccedil;&atilde;o de Planos de Sa&uacute;de &ndash; MPS, previamente &agrave; assinatura da proposta de ades&atilde;o, e que fui informado de que o Guia de Leitura  Contratual &ndash; GLC ser&aacute; enviado juntamente com o cart&atilde;o de identifica&ccedil;&atilde;o do plano. Declaro, ainda, que recebi e li, antes do preenchimento  da Declara&ccedil;&atilde;o de Sa&uacute;de, a Carta de Orienta&ccedil;&atilde;o ao Benefici&aacute;rio, que integra a presente proposta. O cart&atilde;o de identifica&ccedil;&atilde;o e a lista de  prestadores m&eacute;dicos e hospitalares ou odontol&oacute;gicos, disponibizada em meio magn&eacute;tico (CD) ou em acesso ao site da  operadora/seguradora respons&aacute;vel pelo plano, ser&atilde;o enviados ap&oacute;s a aceita&ccedil;&atilde;o de meu registro e de meus dependentes pela  operadora/seguradora. <br>
  13.4. Declaro que antes de optar pelo plano descrito nesta proposta de ades&atilde;o me foi oferecido e fui esclarecido sobre as condi&ccedil;&otilde;es do  plano refer&ecirc;ncia, que foi institu&iacute;do pela Lei 9.656/98 como padr&atilde;o da assist&ecirc;ncia m&eacute;dicohospitalar  e que abrange o atendimento em  consult&oacute;rios e interna&ccedil;&atilde;o em padr&atilde;o enfermaria, com direito a parto, a UTI e a todos os exames e tratamentos necess&aacute;rios para  diagnosticar ou tratar o problema de sa&uacute;de, mas que optei pela contrata&ccedil;&atilde;o do plano descrito nesta proposta. <br>
  13.5. Declaro que as informa&ccedil;&otilde;es prestadas neste formul&aacute;rio s&atilde;o absolutamente verdadeiras e completas, me responsabilizando, assim,  civil e criminalmente, por mim e meus dependentes. Se estiver omitindo circunst&acirc;ncias que possam influir na aceita&ccedil;&atilde;o da proposta ou  no valor da mensalidade, perderei todo e qualquer direito inerente ao presente contrato coletivo empresarial ao qual tenha aderido; e  autorizo desde j&aacute;, a ALIAN&Ccedil;A ADMINISTRADORA e/ou a operadora/seguradora contratada a solicitar, a qualquer tempo, documentos  comprobat&oacute;rios referentes a todas as informa&ccedil;&otilde;es ora declaradas, bem como acessar as informa&ccedil;&otilde;es sobre a utiliza&ccedil;&atilde;o do meu plano  de assist&ecirc;ncia &agrave; sa&uacute;de, observadas as normas regulat&oacute;rias em vigor. <br>
  13.6. Declaro, ainda, que tomei ci&ecirc;ncia das condi&ccedil;&otilde;es necess&aacute;rias a presente ades&atilde;o, bem como dos valores estipulados para o produto 
escolhido por mim e meus dependentes.</div>

<pagebreak />
<div class="tit-pagina">PROPOSTA DE ADES&Atilde;O<p>Anexo I</p></div>
<div class="titulo">
1. IDENTIFICA&Ccedil;&Atilde;O DA PESSOA JUR&Iacute;DICA SUBESTIPULANTE</div>
<div class="texto">
  	<div class="campo" style="width: 100%;">
        <div class="campo-titulo">Raz&atilde;o Social - Pessoa Jur&iacute;dica Subestipulante</div>
        <div class="campo-dados"></div>
	</div>
    
    <div class="campo" style="width: 50%;">
        <div class="campo-titulo">CNPJ - Pessoa
        Jur&iacute;dica Subestipulante</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 20%;">
        <div class="campo-titulo">Data de Vig&ecirc;ncia</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Lota&ccedil;&atilde;o (se houver)</div>
        <div class="campo-dados"></div>
	</div>
    
    <div class="campo" style="width: 100%;">
        <div class="campo-titulo">Entidade Vinculada (se houver)</div>
        <div class="campo-dados"></div>
	</div>
	
</div>

<div class="titulo">
2. PROPONENTE TITULAR</div>

<div class="texto">
  	<div class="campo" style="width: 50%;">
        <div class="campo-titulo">Nome Completo</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 50%;">
        <div class="campo-titulo">CPF</div>
        <div class="campo-dados"></div>
	</div>
</div>

<div class="titulo">
3. PLANO PRETENDIDO</div>

<div class="texto">
  <div class="campo" style="width: 70%;">
        <div class="campo-titulo">Operadora Razao
Social</div>
        <div class="campo-dados"></div>
  </div>
  <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Reg. Oper. - ANS</div>
        <div class="campo-dados"></div>
  </div>
    <div class="campo" style="width: 70%;">
        <div class="campo-titulo">Nome do Plano Escolhido</div>
        <div class="campo-dados"></div>
	</div>
    <div class="campo" style="width: 30%;">
        <div class="campo-titulo">Registro do Plano - ANS</div>
        <div class="campo-dados"></div>
	</div>
</div>

<div class="titulo">
4. REAJUSTE</div>
<div class="texto">
  <p>O  reajuste a ser aplicado aos planos de assist&ecirc;ncia &agrave; sa&uacute;de observar&aacute; os  seguintes crit&eacute;rios:<br>
    4.1.  Reajuste Financeiro: de acordo com a varia&ccedil;&atilde;o dos custos m&eacute;dicos, hospitalares  e ambulatoriais ou odontol&oacute;gicos, bem como outras despesas operacionais da  operadora/seguradora;<br>
    4.2.  Reajuste por Sinistralidade: com a revis&atilde;o da taxa de sinistralidade, visando &agrave;  manuten&ccedil;&atilde;o do equil&iacute;brio econ&ocirc;micofinanceiro do contrato firmado entre a PESSOA JUR&Iacute;DICA e a ALIAN&Ccedil;A ADMINISTRADORA,  conforme &iacute;ndice calculado com base na f&oacute;rmula abaixo:<br>
    IR = [(Ec/Mr/0,65)-1]x100<br>
    IR = &iacute;ndice  de reajuste das mensalidades<br>
    Ec =  somat&oacute;rio das despesas m&eacute;dicas, hospitalares e ambulatoriais ou odontol&oacute;gicas  dos benefici&aacute;rios<br>
    Mr =  somat&oacute;rio das mensalidades efetivamente recebidas pela operadora/seguradora do  plano de assist&ecirc;ncia &agrave; sa&uacute;de.</p>
</div>

<div class="titulo">
5. VARIA&Ccedil;&Atilde;O POR MODIFICA&Ccedil;&Atilde;O DA FAIXA ET&Aacute;RIA</div>
<div class="texto">
  <table cellpadding="0" cellspacing="0" style="width: 100%; font-size: 9px; border: 1px solid #666;">
    	<tr style="background:#999;">
        	<td style="padding: 5px; text-align:center; border: 1px solid #666;">Produto</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">Abrang&ecirc;ncia</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">Acomoda&ccedil;&atilde;o</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">Coparticipa&ccedil;&atilde;o</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">0 anos ou<br>
            mais</td>
        </tr>
        <tr>
        	<td style="padding: 5px; text-align:center; border: 1px solid #666;">&nbsp;</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">&nbsp;</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">&nbsp;</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">&nbsp;</td>
            <td style="padding: 5px; text-align:center; border: 1px solid #666;">&nbsp;</td>
        </tr>
  </table>
	Declaro que tenho ci&ecirc;ncia e concordo com a modifica&ccedil;&atilde;o do valor das mensalidades de meu plano de assist&ecirc;ncia &agrave; sa&uacute;de e de meu(s) dependente(s), conforme percentual de varia&ccedil;&atilde;o por modifica&ccedil;&atilde;o por faixa et&aacute;ria, descrito acima.</div>

<div class="titulo">
6. ALTERA&Ccedil;&Atilde;O CADASTRAL</div>
<div class="texto">
  <p>A  solicita&ccedil;&atilde;o de altera&ccedil;&atilde;o cadastral, de inclus&atilde;o e de exclus&atilde;o no plano que for  recebida entre o dia 16 (dezesseis) de um determinado m&ecirc;s e o dia 15 (quinze)  do m&ecirc;s subsequente, ocorrer&aacute; somente a partir do dia 1&ordm; (primeiro) do m&ecirc;s que o  suceder.<br>
    Declaro  que tenho ci&ecirc;ncia e concordo com o crit&eacute;rio de reajuste, com a modifica&ccedil;&atilde;o do  valor por faixa &nbsp;et&aacute;ria das mensalidades  e com os prazos para as modifica&ccedil;&otilde;es cadastrais de meu plano de assist&ecirc;ncia &agrave;  sa&uacute;de e de meu(s) dependente(s), conforme descrito acima.</p>
</div>

<div class="titulo">
7. PAGAMENTO DA PRIMEIRA MENSALIDADE (exclusivo para clientes do MEC - MEC e IBC, advindos da GEAP)</div>
<div class="texto">
  <p>Declaro  que estou ciente que o pagamento da mensalidade relativa ao plano de assist&ecirc;ncia  &agrave; sa&uacute;de escolhido ocorrer&aacute; no m&ecirc;s da cobertura do benef&iacute;cio, na forma e no  vencimento indicados no item 6 (seis) da minha proposta de ades&atilde;o.<br>
    Declaro  ainda que, na condi&ccedil;&atilde;o de beneci&aacute;rio do MEC MEC e IBC e advindo da GEAP &ndash; Funda&ccedil;&atilde;o  de Seguridade Social, estou ciente que o pagamento da primeira mensalidade do  plano de assist&ecirc;ncia &agrave; sa&uacute;de ser&aacute; efetuado em 06 (seis) parcelas mensais,  contados a partir do primeiro m&ecirc;s de cobertura.<br>
    OBS.: Essa condi&ccedil;&atilde;o est&aacute;  sujeita &agrave; valida&ccedil;&atilde;o na rela&ccedil;&atilde;o enviada pelo RH do &oacute;rg&atilde;o.</p>
    
<pagebreak />

<STYLE type="text/css">

#page_1 {float: left; overflow: hidden;margin: 77px 0px 45px 61px;padding: 0px;border: none;width: 733px;}

.dclr {clear:both;float:none;height:1px;margin:0px;padding:0px;overflow:hidden;}

.ft0{font: bold 12px 'Tahoma';line-height: 14px;}
.ft1{font: bold 8px 'Tahoma';line-height: 10px;}
.ft2{font: 1px 'Tahoma';line-height: 1px;}
.ft3{font: bold 8px 'Tahoma';line-height: 9px;}
.ft4{font: bold 7px 'Tahoma';line-height: 8px;}
.ft5{font: bold 17px 'Tahoma';line-height: 21px;}
.ft6{font: bold 19px 'Tahoma';line-height: 23px;}
.ft7{font: bold 19px 'Tahoma';line-height: 22px;}
.ft8{font: bold 16px 'Tahoma';line-height: 19px;}
.ft9{font: 1px 'Tahoma';line-height: 3px;}
.ft10{font: bold 11px 'Tahoma';line-height: 12px;}
.ft11{font: 11px 'Times New Roman';color: #443e47;line-height: 14px;}
.ft12{font: 1px 'Tahoma';line-height: 5px;}
.ft13{font: bold 11px 'Tahoma';line-height: 11px;}
.ft14{font: 1px 'Tahoma';line-height: 11px;}
.ft15{font: bold 9px 'Tahoma';line-height: 11px;}
.ft16{font: 11px 'Times New Roman';color: #443e47;line-height: 12px;}
.ft17{font: 1px 'Tahoma';line-height: 2px;}
.ft18{font: 11px 'Tahoma';line-height: 13px;}
.ft19{font: bold 11px 'Tahoma';line-height: 13px;}
.ft20{font: 1px 'Tahoma';line-height: 9px;}
.ft21{font: 1px 'Tahoma';line-height: 4px;}
.ft22{font: bold 13px 'Tahoma';line-height: 22px;}
.ft23{font: 13px 'Tahoma';line-height: 22px;}
.ft24{font: 10px 'Tahoma';line-height: 12px;}
.ft25{font: bold 10px 'Tahoma';line-height: 12px;}
.ft26{font: bold 10px 'Tahoma';line-height: 11px;}
.ft27{font: 12px 'Tahoma';line-height: 14px;}
.ft28{font: 12px 'Tahoma';line-height: 15px;}
.ft29{font: 11px 'Times New Roman';line-height: 14px;}

.p0{text-align: left;padding-left: 90px;margin-top: 3px;margin-bottom: 0px;}
.p1{text-align: left;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p2{text-align: right;padding-right: 10px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p3{text-align: right;padding-right: 11px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p4{text-align: right;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p5{text-align: left;padding-left: 50px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p6{text-align: left;padding-left: 19px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p7{text-align: left;padding-left: 5px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p8{text-align: right;padding-right: 3px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p9{text-align: left;padding-left: 4px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p10{text-align: left;padding-left: 15px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p11{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p12{text-align: right;padding-right: 30px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p13{text-align: left;padding-left: 35px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p14{text-align: left;padding-left: 2px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p15{text-align: left;padding-left: 5px;padding-right: 78px;margin-top: 2px;margin-bottom: 0px;text-indent: 96px;}
.p16{text-align: left;padding-left: 152px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p17{text-align: left;padding-left: 26px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p18{text-align: left;padding-left: 46px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p19{text-align: left;padding-left: 11px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p20{text-align: left;padding-left: 33px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p21{text-align: right;padding-right: 13px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p22{text-align: right;padding-right: 15px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p23{text-align: right;padding-right: 33px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p24{text-align: left;padding-left: 69px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p25{text-align: right;padding-right: 86px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p26{text-align: center;padding-left: 16px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p27{text-align: left;padding-left: 7px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p28{text-align: right;padding-right: 100px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p29{text-align: right;padding-right: 99px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p30{text-align: left;padding-left: 131px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p31{text-align: right;padding-right: 20px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p32{text-align: left;padding-left: 72px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p33{text-align: right;padding-right: 79px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p34{text-align: left;padding-left: 115px;margin-top: 0px;margin-bottom: 0px;white-space: nowrap;}
.p35{text-align: left;padding-left: 3px;margin-top: 14px;margin-bottom: 0px;}
.p36{text-align: left;padding-left: 3px;margin-top: 0px;margin-bottom: 0px;}
.p37{text-align: left;padding-left: 37px;padding-right: 67px;margin-top: 1px;margin-bottom: 0px;text-indent: -7px;}
.p38{text-align: left;padding-left: 377px;margin-top: 8px;margin-bottom: 0px;}

.td0{padding: 0px;margin: 0px;width: 85px;vertical-align: bottom;}
.td1{padding: 0px;margin: 0px;width: 83px;vertical-align: bottom;}
.td2{padding: 0px;margin: 0px;width: 36px;vertical-align: bottom;}
.td3{padding: 0px;margin: 0px;width: 168px;vertical-align: bottom;}
.td4{border-left: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 190px;vertical-align: bottom;}
.td5{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 480px;vertical-align: bottom;}
.td6{border-left: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 114px;vertical-align: bottom;}
.td7{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 109px;vertical-align: bottom;}
.td8{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 122px;vertical-align: bottom;}
.td9{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 182px;vertical-align: bottom;}
.td10{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 143px;vertical-align: bottom;}
.td11{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 115px;vertical-align: bottom;}
.td12{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 14px;vertical-align: bottom;}
.td13{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 19px;vertical-align: bottom;}
.td14{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 89px;vertical-align: bottom;}
.td15{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 38px;vertical-align: bottom;}
.td16{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 33px;vertical-align: bottom;}
.td17{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 111px;vertical-align: bottom;}
.td18{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 144px;vertical-align: bottom;}
.td19{border-left: #000000 1px solid;border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td20{padding: 0px;margin: 0px;width: 109px;vertical-align: bottom;}
.td21{padding: 0px;margin: 0px;width: 14px;vertical-align: bottom;}
.td22{padding: 0px;margin: 0px;width: 19px;vertical-align: bottom;}
.td23{padding: 0px;margin: 0px;width: 89px;vertical-align: bottom;}
.td24{padding: 0px;margin: 0px;width: 38px;vertical-align: bottom;}
.td25{padding: 0px;margin: 0px;width: 33px;vertical-align: bottom;}
.td26{padding: 0px;margin: 0px;width: 111px;vertical-align: bottom;}
.td27{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 143px;vertical-align: bottom;}
.td28{padding: 0px;margin: 0px;width: 76px;vertical-align: bottom;}
.td29{border-left: #000000 1px solid;border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td30{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 76px;vertical-align: bottom;}
.td31{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 114px;vertical-align: bottom;}
.td32{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 13px;vertical-align: bottom;}
.td33{padding: 0px;margin: 0px;width: 108px;vertical-align: bottom;}
.td34{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 32px;vertical-align: bottom;}
.td35{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 13px;vertical-align: bottom;}
.td36{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 32px;vertical-align: bottom;}
.td37{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 18px;vertical-align: bottom;}
.td38{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;}
.td39{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 18px;vertical-align: bottom;}
.td40{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 37px;vertical-align: bottom;}
.td41{border-left: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td42{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 413px;vertical-align: bottom;}
.td43{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 106px;vertical-align: bottom;}
.td44{border-right: #000000 1px solid;border-top: #000000 1px solid;padding: 0px;margin: 0px;width: 147px;vertical-align: bottom;}
.td45{border-left: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td46{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 413px;vertical-align: bottom;}
.td47{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 106px;vertical-align: bottom;}
.td48{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 147px;vertical-align: bottom;}
.td49{border-left: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td50{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 413px;vertical-align: bottom;}
.td51{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 106px;vertical-align: bottom;}
.td52{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 145px;vertical-align: bottom;}
.td53{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 2px;vertical-align: bottom;}
.td54{padding: 0px;margin: 0px;width: 3px;vertical-align: bottom;}
.td55{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 414px;vertical-align: bottom;}
.td56{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 107px;vertical-align: bottom;}
.td57{padding: 0px;margin: 0px;width: 6px;vertical-align: bottom;}
.td58{padding: 0px;margin: 0px;width: 174px;vertical-align: bottom;}
.td59{padding: 0px;margin: 0px;width: 165px;vertical-align: bottom;}
.td60{padding: 0px;margin: 0px;width: 322px;vertical-align: bottom;}
.td61{padding: 0px;margin: 0px;width: 51px;vertical-align: bottom;}
.td62{padding: 0px;margin: 0px;width: 114px;vertical-align: bottom;}
.td63{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 174px;vertical-align: bottom;}
.td64{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 51px;vertical-align: bottom;}
.td65{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 114px;vertical-align: bottom;}
.td66{border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 322px;vertical-align: bottom;}
.td67{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 5px;vertical-align: bottom;}
.td68{padding: 0px;margin: 0px;width: 225px;vertical-align: bottom;}
.td69{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}
.td70{border-right: #000000 1px solid;padding: 0px;margin: 0px;width: 338px;vertical-align: bottom;}
.td71{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 5px;vertical-align: bottom;}
.td72{border-right: #000000 1px solid;border-bottom: #000000 1px solid;padding: 0px;margin: 0px;width: 113px;vertical-align: bottom;}

.tr0{height: 10px;}
.tr1{height: 9px;}
.tr2{height: 26px;}
.tr3{height: 22px;}
.tr4{height: 3px;}
.tr5{height: 12px;}
.tr6{height: 21px;}
.tr7{height: 5px;}
.tr8{height: 11px;}
.tr9{height: 2px;}
.tr10{height: 13px;}
.tr11{height: 4px;}
.tr12{height: 16px;}
.tr13{height: 15px;}
.tr14{height: 14px;}
.tr15{height: 30px;}
.tr16{height: 31px;}
.tr17{height: 29px;}
.tr18{height: 23px;}
.tr19{height: 25px;}
.tr20{height: 24px;}

.t0{width: 204px;margin-left: 90px;font: bold 8px 'Tahoma';}
.t1{width: 671px;margin-top: 2px;font: bold 11px 'Tahoma';}
.t2{width: 671px;margin-top: 7px;font: bold 12px 'Tahoma';}
.t3{width: 667px;margin-left: 2px;margin-top: 48px;font: 10px 'Tahoma';}

</STYLE>

<DIV id="page_1" style="background:url(<?= site_url() ?>images/alianca/logo-mec.jpg) no-repeat;">


<P class="p0 ft0">MINIST�RIO DA EDUCA�AO</P>
<TABLE cellpadding=0 cellspacing=0 class="t0">
<TR>
	<TD class="tr0 td0"><P class="p1 ft1">Secretaria Executiva</P></TD>
	<TD class="tr0 td1"><P class="p1 ft1">- SE</P></TD>
	<TD class="tr0 td2"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD colspan=2 class="tr1 td3"><P class="p1 ft3">Subsecretaria de Assuntos Administrativos</P></TD>
	<TD class="tr1 td2"><P class="p2 ft3">- SAA</P></TD>
</TR>
<TR>
	<TD colspan=2 class="tr0 td3"><P class="p1 ft1">Coordena�ao - Geral de Gestao de Pessoas</P></TD>
	<TD class="tr0 td2"><P class="p3 ft4">- CGGP</P></TD>
</TR>
<TR>
	<TD colspan=2 class="tr0 td3"><P class="p1 ft4">Coordena�ao de Assistencia M�dica e Social</P></TD>
	<TD class="tr0 td2"><P class="p4 ft1">- CAMS</P></TD>
</TR>
</TABLE>
<TABLE cellpadding=0 cellspacing=0 class="t1">
<TR>
	<TD colspan=2 class="tr2 td4"><P class="p5 ft5">REQUERIMENTO</P></TD>
	<TD colspan=8 class="tr2 td5"><P class="p6 ft6">DE AUX�LIO DE CAR�TER INDENIZ AT�RIO -</P></TD>
</TR>
<TR>
	<TD class="tr3 td6"><P class="p1 ft2">&nbsp;</P></TD>
	<TD colspan=2 class="tr3 td7"><P class="p7 ft7">PORTARIA</P></TD>
	<TD colspan=3 class="tr3 td8"><P class="p1 ft7">NORMATIVA</P></TD>
	<TD colspan=3 class="tr3 td9"><P class="p8 ft8">N<SPAN class="ft0">o </SPAN>05, DE 11/10/2010</P></TD>
	<TD class="tr3 td10"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td11"><P class="p1 ft9">&nbsp;</P></TD>
	<TD colspan=2 class="tr4 td7"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td12"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td13"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td14"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td15"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td17"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td18"><P class="p1 ft9">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr5 td19"><P class="p7 ft10">MAT. SIAPE:</P></TD>
	<TD colspan=2 class="tr5 td20"><P class="p9 ft1">NOME DO SERVIDOR:</P></TD>
	<TD class="tr5 td21"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td22"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td23"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td24"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td25"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td26"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td27"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr6 td19"><P class="p10 ft11">2222222</P></TD>
	<TD class="tr6 td28"><P class="p7 ft11">SADASD</P></TD>
	<TD class="tr6 td25"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td21"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td22"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td23"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td24"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td25"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td26"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr6 td27"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr7 td29"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td30"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td16"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td12"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td13"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td14"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td15"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td16"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td17"><P class="p1 ft12">&nbsp;</P></TD>
	<TD class="tr7 td10"><P class="p1 ft12">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td11"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td30"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td12"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td13"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td14"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td15"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td17"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td18"><P class="p1 ft9">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td31"><P class="p7 ft13">IDENTIDADE:</P></TD>
	<TD class="tr8 td28"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td25"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td32"><P class="p1 ft14">&nbsp;</P></TD>
	<TD colspan=2 class="tr8 td33"><P class="p11 ft15">�RGAO EXPEDIDOR:</P></TD>
	<TD class="tr8 td24"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td34"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td26"><P class="p9 ft13">CPF:</P></TD>
	<TD class="tr8 td27"><P class="p1 ft14">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr5 td31"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td28"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td25"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td32"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td22"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td23"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td24"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td34"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td26"><P class="p12 ft16"><NOBR>362.749.238-29</NOBR></P></TD>
	<TD class="tr5 td27"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr9 td6"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td30"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td16"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td35"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td13"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td14"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td15"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td36"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td17"><P class="p1 ft17">&nbsp;</P></TD>
	<TD class="tr9 td10"><P class="p1 ft17">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr4 td11"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td30"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td12"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td13"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td14"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td15"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td16"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td17"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td18"><P class="p1 ft9">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr10 td31"><P class="p7 ft1">SITUA�AO FUNCIONAL:</P></TD>
	<TD rowspan=2 class="tr3 td28"><P class="p1 ft2">&nbsp;</P></TD>
	<TD rowspan=2 class="tr3 td25"><P class="p1 ft18">Ativo</P></TD>
	<TD class="tr10 td21"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr10 td37"><P class="p1 ft2">&nbsp;</P></TD>
	<TD rowspan=2 class="tr3 td23"><P class="p13 ft18">Inativo</P></TD>
	<TD class="tr10 td38"><P class="p1 ft2">&nbsp;</P></TD>
	<TD rowspan=2 class="tr3 td25"><P class="p1 ft2">&nbsp;</P></TD>
	<TD rowspan=2 class="tr3 td26"><P class="p14 ft18">Pensionista</P></TD>
	<TD class="tr10 td27"><P class="p1 ft19">TELEFONE / RAMAL:</P></TD>
</TR>
<TR>
	<TD class="tr1 td31"><P class="p1 ft20">&nbsp;</P></TD>
	<TD class="tr1 td21"><P class="p1 ft20">&nbsp;</P></TD>
	<TD class="tr1 td37"><P class="p1 ft20">&nbsp;</P></TD>
	<TD class="tr1 td38"><P class="p1 ft20">&nbsp;</P></TD>
	<TD class="tr1 td27"><P class="p1 ft20">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr11 td6"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td30"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td16"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td12"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td39"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td14"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td40"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td16"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td17"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr11 td10"><P class="p1 ft21">&nbsp;</P></TD>
</TR>
</TABLE>
<P class="p15 ft23">Venho requerer junto a <NOBR>Coordena�ao-Geral</NOBR> de Gestao de <NOBR>Pessoas-CGGP,</NOBR> por meio da Coordena�ao de Assistencia M�dica e <NOBR>Social-CAMS/MEC,</NOBR> nos termos da <SPAN class="ft22">Portaria Normativa no 05, de 11/10/2010, </SPAN>o ressarcimento do aux�lio indenizat�rio, por dependente legal, referente ao mes de __________________________, com os seguintes dependentes:</P>
<TABLE cellpadding=0 cellspacing=0 class="t2">
<TR>
	<TD class="tr12 td41"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr12 td42"><P class="p16 ft0">NOME COMPLETO</P></TD>
	<TD class="tr12 td43"><P class="p17 ft0">DATA DE</P></TD>
	<TD colspan=2 class="tr12 td44"><P class="p18 ft0">GRAU DE</P></TD>
</TR>
<TR>
	<TD class="tr13 td45"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td46"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td47"><P class="p19 ft0">NASCIMENTO</P></TD>
	<TD colspan=2 class="tr13 td48"><P class="p20 ft0">PARENTESCO</P></TD>
</TR>
<TR>
	<TD class="tr14 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr16 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr17 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr16 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr16 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr17 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr15 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr15 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr17 td49"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td50"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td51"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td52"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr17 td53"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr11 td54"><P class="p1 ft21">&nbsp;</P></TD>
	<TD class="tr4 td55"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td56"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr4 td52"><P class="p1 ft9">&nbsp;</P></TD>
	<TD class="tr11 td54"><P class="p1 ft21">&nbsp;</P></TD>
</TR>
</TABLE>
<TABLE cellpadding=0 cellspacing=0 class="t3">
<TR>
	<TD class="tr13 td57"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td58"><P class="p21 ft24">___________________________</P></TD>
	<TD colspan=2 class="tr13 td59"><P class="p22 ft24">_______/_________/________</P></TD>
	<TD class="tr13 td60"><P class="p23 ft24">____________________________________________</P></TD>
</TR>
<TR>
	<TD class="tr5 td57"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td58"><P class="p24 ft24">Local</P></TD>
	<TD class="tr5 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td62"><P class="p25 ft24">Data</P></TD>
	<TD class="tr5 td60"><P class="p26 ft24">Assinatura do Titular</P></TD>
</TR>
<TR>
	<TD class="tr13 td57"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td63"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td64"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td65"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td66"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr18 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr18 td58"><P class="p27 ft25">Exclusivo da CAMS</P></TD>
	<TD class="tr18 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr18 td62"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr18 td60"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr5 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td58"><P class="p27 ft24">Autorizamos a inscri�ao do servidor</P></TD>
	<TD class="tr5 td61"><P class="p3 ft24">(</P></TD>
	<TD class="tr5 td62"><P class="p28 ft24">)</P></TD>
	<TD class="tr5 td60"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr10 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD colspan=2 class="tr10 td68"><P class="p27 ft24">Autorizamos a inscri�ao do(s) dependente(s) (</P></TD>
	<TD class="tr10 td62"><P class="p29 ft24">)</P></TD>
	<TD class="tr10 td60"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr10 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr10 td58"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr10 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr10 td62"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td66"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr19 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr19 td58"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr19 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr19 td69"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr20 td66"><P class="p30 ft25">AUTORIZADOR</P></TD>
</TR>
<TR>
	<TD class="tr3 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD colspan=3 class="tr3 td70"><P class="p31 ft24">__________________________ ________/_________/________</P></TD>
	<TD class="tr3 td60"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr5 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td58"><P class="p32 ft24">Local</P></TD>
	<TD class="tr5 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr5 td69"><P class="p33 ft24">Data</P></TD>
	<TD class="tr5 td60"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr13 td67"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td58"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td61"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr13 td69"><P class="p1 ft2">&nbsp;</P></TD>
	<TD class="tr14 td66"><P class="p1 ft2">&nbsp;</P></TD>
</TR>
<TR>
	<TD class="tr8 td71"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td63"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td64"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td72"><P class="p1 ft14">&nbsp;</P></TD>
	<TD class="tr8 td66"><P class="p34 ft26">Assinatura e Carimbo</P></TD>
</TR>
</TABLE>
<P class="p35 ft0">ATEN�AO:</P>
<P class="p36 ft27">1. Documento a ser anexado ao Requerimento:</P>
<P class="p37 ft28">. Comprovante de pagamento mensal do plano de sa�de e, valor discriminado por benefici�rio, at� o 05 (quinto) dia �til de cada mes.</P>
<P class="p38 ft29">formul�rio - REQUERIMENTO DE AUX�LIO INDENIZAT�RIO</P>
</DIV>


