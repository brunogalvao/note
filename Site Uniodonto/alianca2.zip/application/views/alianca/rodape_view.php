﻿<div class="rodape">
	<img src="<?= site_url()?>images/alianca/logo-uniodonto.png" border="0">
</div>

<div id="verificando-cpf" style="display: none; background:#af2638; color:#fff; text-align:center;">
    Verificando CPF, por favor aguarde... 
    <div><img src="<?= site_url()?>images/alianca/ajax-loader.gif" /></div>
</div>

<div id="busca-endereco" style="display: none; background:#af2638; color:#fff; text-align:center;">
    Buscando CEP, por favor aguarde... 
    <div><img src="<?= site_url()?>images/alianca/ajax-loader.gif" /></div>
</div>

<div id="gerando-proposta" style="display: none; background:#af2638; color:#fff; text-align:center;">
    Gerando a proposta, por favor aguarde... 
    <div><img src="<?= site_url()?>images/alianca/ajax-loader.gif" /></div>
</div>
 
<div id="erro-gera-proposta" style="display: none;">
    Houve um problema ao gerar a proposta, por favor, tente novamente.
</div>
  
</body>
</html>