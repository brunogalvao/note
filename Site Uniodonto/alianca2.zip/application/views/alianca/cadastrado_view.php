<div class="conteudo1">
    <div class="cadastrado">
        <h1>Ol&aacute; <?= $nome[0] ?>,</h1>
        <p>Voc&ecirc; j&aacute; preencheu o formul&aacute;rio! O que deseja fazer?</p>
       	
        <a onclick="baixarProposta('<?= site_url()?>alianca/site/imprimir_proposta/<?= $cadastro->alianca_id ?>')" ><img src="<?= site_url() ?>images/alianca/proposta.png" border="0"><br />Baixar Proposta</a>
        <a href="<?= site_url() ?>alianca/site/enviar_arquivos"><img src="<?= site_url() ?>images/alianca/enviar.png" border="0"><br />Enviar Documentos</a>
    </div>
</div>

	
