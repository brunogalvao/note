<div class="conteudo">
  <div class="tabela">
    <table>
      <tr style="font-weight:bold; color:#af2638; background:#fff;">
        <td style="text-align:center;">TUSS</td>
        <td  style="padding-left:265px;">PROCEDIMENTOS ODONTOL&Oacute;GICOS</td>
      </tr>
      <tr>
        <th colspan="2">EMERGENCIA</th>
      </tr>
      <tr>
        <td>82000468</td>
        <td>Controle de hemorragia com Aplica&ccedil;ao de Agente Hemost&aacute;tico em regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82000484</td>
        <td>Controle de hemorragia sem Aplica&ccedil;ao de Agente Hemost&aacute;tico em regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>85200034</td>
        <td>Tratamento em odontalgia aguda </td>
      </tr>
      <tr>
        <td>85300020</td>
        <td>Imobiliza&ccedil;ao dent&aacute;ria em dentes permanentes</td>
      </tr>
      <tr>
        <td>85000787</td>
        <td>Imobiliza&ccedil;ao dent&aacute;ria em dentes dec&iacute;duos</td>
      </tr>
      <tr>
        <td>85400467</td>
        <td>Recimenta&ccedil;ao de trabalho prot&eacute;tico</td>
      </tr>
      <tr>
        <td>82001650</td>
        <td>Tratamento de alveolite</td>
      </tr>
      <tr>
        <td>85100048</td>
        <td>Colagem de fragmentos dent&aacute;rios</td>
      </tr>
      <tr>
        <td>82001022</td>
        <td>Incisao e drenagem Extra-Oral de abscesso, hematoma e/ou flegmao da regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001030</td>
        <td>Incisao e drenagem Intra-Oral de abscesso, hematoma e/ou flegmao da regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>85300063</td>
        <td>Tratamento de Abscesso Periodontal agudo</td>
      </tr>
      <tr>
        <td>82001251</td>
        <td>Reimplante de dente com conten&ccedil;ao</td>
      </tr>
      <tr>
        <td>82001499</td>
        <td>Sutura de ferida em regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001197</td>
        <td>Redu&ccedil;ao simples de Luxa&ccedil;ao de Articula&ccedil;ao Temporo-mandibular (ATM)</td>
      </tr>
      <tr>
        <td>82001642</td>
        <td>Tratamento conservador de luxa&ccedil;ao da articula&ccedil;ao temporo-mandibular - ATM</td>
      </tr>
      <tr>
        <td>85100056</td>
        <td>Curativo de demora em endodontia</td>
      </tr>
      <tr>
        <td>85300080</td>
        <td>Tratamento de pericoronarite</td>
      </tr>
      <tr>
        <th colspan="2">DIAGN&Oacute;STICODIAGN&Oacute;STICO</th>
      </tr>
      <tr>
        <td>81000030</td>
        <td>Consulta odontol&oacute;gica</td>
      </tr>
      <tr>
        <td>81000065</td>
        <td>Consulta odontologica inicial</td>
      </tr>
      <tr>
        <td>81000049</td>
        <td>Consulta odontologica de Urgencia</td>
      </tr>
      <tr>
        <td>81000057</td>
        <td>Consulta odontologica de Urgencia 24 hs</td>
      </tr>
      <tr>
        <td>81000073</td>
        <td>Consulta para avalia&ccedil;ao t&eacute;cnica de auditoria</td>
      </tr>
      <tr>
        <td>81000090</td>
        <td>Consulta para t&eacute;cnica de clareamento dent&aacute;rio caseiro</td>
      </tr>
      <tr>
        <td>81000189</td>
        <td>Diagn&oacute;stico e planejamento para tratamento odontol&oacute;gico</td>
      </tr>
      <tr>
        <td>81000197</td>
        <td>Diagn&oacute;stico e tratamento de estomatite herp&eacute;tica</td>
      </tr>
      <tr>
        <td>81000200</td>
        <td>Diagn&oacute;stico e tratamento de estomatite por candidose</td>
      </tr>
      <tr>
        <td>81000219</td>
        <td>Diagn&oacute;stico e tratamento de halitose</td>
      </tr>
      <tr>
        <td>81000235</td>
        <td>Diagn&oacute;stico e tratamento de xerostomia</td>
      </tr>
      <tr>
        <td>81000260</td>
        <td>Diagn&oacute;stico por meio de procedimentos laboratoriais (Exame histopatol&oacute;gico)</td>
      </tr>
      <tr>
        <th colspan="2">RADIOLOGIA</th>
      </tr>
      <tr>
        <td>81000421</td>
        <td>RX Periapical </td>
      </tr>
      <tr>
        <td>81000375</td>
        <td>RX interproximal - bite-wing</td>
      </tr>
      <tr>
        <td>81000383</td>
        <td>Radiografia oclusal</td>
      </tr>
      <tr>
        <td>81000405</td>
        <td>Radiografia panor&acirc;mica de mand&iacute;bula / maxila (ortopantomografia)</td>
      </tr>
      <tr>
        <th colspan="2">EXAMES DE LABORAT&Oacute;RIO</th>
      </tr>
      <tr>
        <td>84000244</td>
        <td>Teste de fluxo salivar</td>
      </tr>
      <tr>
        <td>84000228</td>
        <td>Teste de capacidade tampao da saliva</td>
      </tr>
      <tr>
        <td>84000252</td>
        <td>Teste de PH salivar</td>
      </tr>
      <tr>
        <td>81000111</td>
        <td>Diagn&oacute;stico anatomopatol&oacute;gico em citologia esfoliativa na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>81000138</td>
        <td>Diagn&oacute;stico anatomopatol&oacute;gico em material de bi&oacute;psia na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>81000154</td>
        <td>Diagn&oacute;stico anatomopatol&oacute;gico em pe&ccedil;a cir&uacute;rgica na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>81000170</td>
        <td>Diagn&oacute;stico anatomopatol&oacute;gico em pun&ccedil;ao na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <th colspan="2">PREVEN&Ccedil;AO</th>
      </tr>
      <tr>
        <td>84000198</td>
        <td>Profilaxia: Polimento Coron&aacute;rio - (com jato de bicarbonato e ultrasson - para maiores de 13 anos)</td>
      </tr>
      <tr>
        <td>85300055</td>
        <td>Remo&ccedil;ao dos fatores de reten&ccedil;ao do biofilme dental (placa bacteriana)</td>
      </tr>
      <tr>
        <td>84000139</td>
        <td>Atividade educativa em sa&uacute;de bucal</td>
      </tr>
      <tr>
        <td>87000024</td>
        <td>Atividade educativa para pais e/ou cuidadores</td>
      </tr>
      <tr>
        <td>87000016</td>
        <td>Atividade educativa em odontologia para pais e/ou cuidadores de pacientes com necessidades especiais</td>
      </tr>
      <tr>
        <td>84000090</td>
        <td>Aplica&ccedil;ao t&oacute;pica de fl&uacute;or ( incluso profilaxia com pasta profil&aacute;tica, ta&ccedil;as e escovas - p/ menores de 13 anos)</td>
      </tr>
      <tr>
        <td>84000163</td>
        <td>Controle de biofilme (Placa Bacteriana)</td>
      </tr>
      <tr>
        <td>84000171</td>
        <td>Controle de c&aacute;rie incipiente</td>
      </tr>
      <tr>
        <th colspan="2">ODONTOPEDIATRIA</th>
      </tr>
      <tr>
        <td>84000074</td>
        <td>Aplica&ccedil;ao de selante de f&oacute;ssulas e fissuras - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>84000058</td>
        <td>Aplica&ccedil;ao de selante - t&eacute;cnica invasiva - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>85100080</td>
        <td>Restaura&ccedil;ao atraum&aacute;tica em dente permanente </td>
      </tr>
      <tr>
        <td>84000031</td>
        <td>Aplica&ccedil;ao de cariost&aacute;tico - ( at&eacute; 07 anos)</td>
      </tr>
      <tr>
        <td>84000201</td>
        <td>Remineraliza&ccedil;ao</td>
      </tr>
      <tr>
        <td>00000660</td>
        <td>Adequa&ccedil;ao do meio bucal c/ ion&ocirc;mero de vidro (por elemento)</td>
      </tr>
      <tr>
        <td>00000670</td>
        <td>Adequa&ccedil;ao meio bucal&nbsp;c/ IRM (por elemento)</td>
      </tr>
      <tr>
        <td>85100137</td>
        <td>Restaura&ccedil;ao em ion&ocirc;mero de vidro - 1 face - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>85100145</td>
        <td>Restaura&ccedil;ao em ion&ocirc;mero de vidro - 2 faces - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>85100153</td>
        <td>Restaura&ccedil;ao em ion&ocirc;mero de vidro - 3 faces - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>85100161</td>
        <td>Restaura&ccedil;ao em ion&ocirc;mero de vidro - 4 faces - ( at&eacute; 12 anos)</td>
      </tr>
      <tr>
        <td>83000020</td>
        <td>Coroa de acetato em dente dec&iacute;duo</td>
      </tr>
      <tr>
        <td>87000040</td>
        <td>Coroa de acetato em dente permanente</td>
      </tr>
      <tr>
        <td>83000046</td>
        <td>Coroa de a&ccedil;o em dente dec&iacute;duo</td>
      </tr>
      <tr>
        <td>87000059</td>
        <td>Coroa de a&ccedil;o em dente permanente</td>
      </tr>
      <tr>
        <td>83000062</td>
        <td>Coroa de policarbonato em dente dec&iacute;duo</td>
      </tr>
      <tr>
        <td>87000067</td>
        <td>Coroa de policarbonato em dente permanente</td>
      </tr>
      <tr>
        <td>85200042</td>
        <td>Pulpotomia</td>
      </tr>
      <tr>
        <td>83000127</td>
        <td>Pulpotomia em dente dec&iacute;duo</td>
      </tr>
      <tr>
        <td>83000151</td>
        <td>Tratamento endod&ocirc;ntico em dec&iacute;duos</td>
      </tr>
      <tr>
        <td>83000089</td>
        <td>Exodontia simples de dec&iacute;duos</td>
      </tr>
      <tr>
        <td>81000014</td>
        <td>Condicionamento em Odontologia</td>
      </tr>
      <tr>
        <td>87000032</td>
        <td>Condicionamento em Odontologia para pacientes com necessidades especiais</td>
      </tr>
      <tr>
        <th colspan="2">DENT&Iacute;STICA</th>
      </tr>
      <tr>
        <td>85100099</td>
        <td>Restaura&ccedil;ao Am&aacute;lgama 1 face</td>
      </tr>
      <tr>
        <td>00000911</td>
        <td>Restaura&ccedil;ao de superf&iacute;cie radicular&nbsp;</td>
      </tr>
      <tr>
        <td>85100102</td>
        <td>Restaura&ccedil;ao Am&aacute;lgama 2 faces</td>
      </tr>
      <tr>
        <td>85100110</td>
        <td>Restaura&ccedil;ao Am&aacute;lgama 3 faces</td>
      </tr>
      <tr>
        <td>85100129</td>
        <td>Restaura&ccedil;ao Am&aacute;lgama 4 faces</td>
      </tr>
      <tr>
        <td>00000950</td>
        <td>Restaura&ccedil;ao a Pino intra-dentin&aacute;rio</td>
      </tr>
      <tr>
        <td>85100196</td>
        <td>Restaura&ccedil;ao resina fotopolimeriz&aacute;vel 1 face</td>
      </tr>
      <tr>
        <td>85100200</td>
        <td>Restaura&ccedil;ao resina fotopolimeriz&aacute;vel 2 faces</td>
      </tr>
      <tr>
        <td>85100218</td>
        <td>Restaura&ccedil;ao resina fotopolimeriz&aacute;vel 3 faces</td>
      </tr>
      <tr>
        <td>85100226</td>
        <td>Restaura&ccedil;ao em resina fotopolimeriz&aacute;vel 4 faces</td>
      </tr>
      <tr>
        <td>85200085</td>
        <td>Restaura&ccedil;ao tempor&aacute;ria / tratamento expectante</td>
      </tr>
      <tr>
        <td>85100064</td>
        <td>Faceta direta em resina Fotopolimeriz&aacute;vel</td>
      </tr>
      <tr>
        <td>85400017</td>
        <td>Ajuste Oclusal por acr&eacute;scimo</td>
      </tr>
      <tr>
        <td>85400025</td>
        <td>Ajuste Oclusal por Desgaste Seletivo</td>
      </tr>
      <tr>
        <td>85400262</td>
        <td>Pino pr&eacute; fabricado</td>
      </tr>
      <tr>
        <td>85100013</td>
        <td>Capeamento pulpar direto</td>
      </tr>
      <tr>
        <th colspan="2">ENDODONTIA</th>
      </tr>
      <tr>
        <td>85200166</td>
        <td>Tratamento endod&ocirc;ntico unirradicular</td>
      </tr>
      <tr>
        <td>85200140</td>
        <td>Tratamento endod&ocirc;ntico birradicular</td>
      </tr>
      <tr>
        <td>85200158</td>
        <td>Tratamento endod&ocirc;ntico multirradicular</td>
      </tr>
      <tr>
        <td>85200115</td>
        <td>Retratamento endod&ocirc;ntico unirradicular</td>
      </tr>
      <tr>
        <td>85200093</td>
        <td>Retratamento endod&ocirc;ntico birradicular</td>
      </tr>
      <tr>
        <td>85200107</td>
        <td>Retratamento endod&ocirc;ntico multirradicular</td>
      </tr>
      <tr>
        <td>85200123</td>
        <td>Tratamento de perfura&ccedil;ao endod&ocirc;ntica</td>
      </tr>
      <tr>
        <td>85200077</td>
        <td>Remo&ccedil;ao de N&uacute;cleo Intrarradicular</td>
      </tr>
      <tr>
        <td>85200069</td>
        <td>Remo&ccedil;ao de material obturador intracanal para retratamento endod&ocirc;ntico</td>
      </tr>
      <tr>
        <td>85200131</td>
        <td>Tratamento endod&ocirc;ntico de dente com rizogenese incompleta </td>
      </tr>
      <tr>
        <td>00002150</td>
        <td>Remo&ccedil;ao de obtura&ccedil;ao radicular (por conduto)</td>
      </tr>
      <tr>
        <td>85200050</td>
        <td>Remo&ccedil;ao de corpo estranho intracanal (por conduto)</td>
      </tr>
      <tr>
        <th colspan="2">PERIODONTIA</th>
      </tr>
      <tr>
        <td>85300047</td>
        <td>Raspagem supra-gengival</td>
      </tr>
      <tr>
        <td>85300039</td>
        <td>Raspagem sub-gengival/alisamento radicular</td>
      </tr>
      <tr>
        <td>85300012</td>
        <td>Dessensibiliza&ccedil;ao dent&aacute;ria</td>
      </tr>
      <tr>
        <td>82000506</td>
        <td>Controle p&oacute;s-operat&oacute;rio em odontologia</td>
      </tr>
      <tr>
        <td>82000921</td>
        <td>Gengivectomia</td>
      </tr>
      <tr>
        <td>82000948</td>
        <td>Gengivoplastia</td>
      </tr>
      <tr>
        <td>82000212</td>
        <td>Aumento de coroa cl&iacute;nica</td>
      </tr>
      <tr>
        <td>82000336</td>
        <td>Cirurgia odontol&oacute;gica a retalho</td>
      </tr>
      <tr>
        <td>82000417</td>
        <td>Cirurgia periodontal a retalho</td>
      </tr>
      <tr>
        <td>82001464</td>
        <td>Sepultamento radicular </td>
      </tr>
      <tr>
        <td>82000557</td>
        <td>Cunha Proximal</td>
      </tr>
      <tr>
        <td>00003175</td>
        <td>Tratamento de gengivite</td>
      </tr>
      <tr>
        <td>82001073</td>
        <td>Odonto-Sec&ccedil;ao</td>
      </tr>
      <tr>
        <th colspan="2">PR&Oacute;TESE DENTAL</th>
      </tr>
      <tr>
        <td>85400556</td>
        <td>Restaura&ccedil;ao met&aacute;lica fundida</td>
      </tr>
      <tr>
        <td>85400505</td>
        <td>Remo&ccedil;ao de trabalho prot&eacute;tico</td>
      </tr>
      <tr>
        <td>85400220</td>
        <td>N&uacute;cleo met&aacute;lico fundido</td>
      </tr>
      <tr>
        <td>00004081</td>
        <td>N&uacute;cleo met&aacute;lico bipartido</td>
      </tr>
      <tr>
        <td>85400211</td>
        <td>N&uacute;cleo de preenchimento</td>
      </tr>
      <tr>
        <td>85400076</td>
        <td>Coroa provis&oacute;ria&nbsp;com pino</td>
      </tr>
      <tr>
        <td>85400084</td>
        <td>Coroa provis&oacute;ria&nbsp;sem pino</td>
      </tr>
      <tr>
        <td>85400459</td>
        <td>Provis&oacute;rio para restaura&ccedil;ao met&aacute;lica fundida</td>
      </tr>
      <tr>
        <td>85400114</td>
        <td>Coroa total em cer&ocirc;mero</td>
      </tr>
      <tr>
        <td>85400149</td>
        <td>Coroa total met&aacute;lica</td>
      </tr>
      <tr>
        <th colspan="2">CIRURGIA</th>
      </tr>
      <tr>
        <td>82000875</td>
        <td>Exodontia simples de permanente</td>
      </tr>
      <tr>
        <td>82000832</td>
        <td>Exodontia de permanente por indica&ccedil;ao ortod&ocirc;ntica/prot&eacute;tica</td>
      </tr>
      <tr>
        <td>00005015</td>
        <td>Exodontia simples de Supra Numer&aacute;rio</td>
      </tr>
      <tr>
        <td>82000816</td>
        <td>Exodontia a retalho&nbsp;</td>
      </tr>
      <tr>
        <td>82000859</td>
        <td>Exodontia de raiz residual&nbsp;</td>
      </tr>
      <tr>
        <td>82000034</td>
        <td>Alveoplastia</td>
      </tr>
      <tr>
        <td>82001715</td>
        <td>Ulotomia </td>
      </tr>
      <tr>
        <td>82000255</td>
        <td>Bi&oacute;psia de l&aacute;bio</td>
      </tr>
      <tr>
        <td>82000239</td>
        <td>Bi&oacute;psia de boca</td>
      </tr>
      <tr>
        <td>82000263</td>
        <td>Bi&oacute;psia de l&iacute;ngua</td>
      </tr>
      <tr>
        <td>82000247</td>
        <td>Bi&oacute;psia de gl&acirc;ndula salivar</td>
      </tr>
      <tr>
        <td>82000271</td>
        <td>Bi&oacute;psia de mand&iacute;bula</td>
      </tr>
      <tr>
        <td>82000280</td>
        <td>Bi&oacute;psia de maxila</td>
      </tr>
      <tr>
        <td>82000441</td>
        <td>Coleta de Raspado em Lesoes ou S&iacute;tios Espec&iacute;ficos da regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001103</td>
        <td>Pun&ccedil;ao aspirativa na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82000190</td>
        <td>Aprofundamento / aumento de vestibulo</td>
      </tr>
      <tr>
        <td>82001154</td>
        <td>Reconstru&ccedil;ao sulco gengivo labial</td>
      </tr>
      <tr>
        <td>82000395</td>
        <td>Cirurgia para Torus Palatino</td>
      </tr>
      <tr>
        <td>82000352</td>
        <td>Cirurgia para exostose maxilar</td>
      </tr>
      <tr>
        <td>82000387</td>
        <td>Cirurgia para Torus mandibular - unilateral</td>
      </tr>
      <tr>
        <td>82000360</td>
        <td>Cirurgia para Torus mandibular - bilateral</td>
      </tr>
      <tr>
        <td>82000182</td>
        <td>Apicetomia unirradiculares sem obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000174</td>
        <td>Apicetomia unirradiculares com obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000085</td>
        <td>Apicetomia birradiculares sem obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000077</td>
        <td>Apicetomia birradiculares com obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000166</td>
        <td>Apicetomia multirradiculares sem obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000158</td>
        <td>Apicetomia multirradiculares com obtura&ccedil;ao retr&oacute;grada</td>
      </tr>
      <tr>
        <td>82000883</td>
        <td>Frenulectomia labial </td>
      </tr>
      <tr>
        <td>82000905</td>
        <td>Frenulotomia labial </td>
      </tr>
      <tr>
        <td>82000891</td>
        <td>Frenulectomia lingual</td>
      </tr>
      <tr>
        <td>82000913</td>
        <td>Frenulotomia lingual</td>
      </tr>
      <tr>
        <td>82000298</td>
        <td>Bridectomia</td>
      </tr>
      <tr>
        <td>82000301</td>
        <td>Bridotomia</td>
      </tr>
      <tr>
        <td>82001545</td>
        <td>Tratamento cir&uacute;rgico de bridas constritivas da regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001286</td>
        <td>Remo&ccedil;ao de dentes inclusos / impactados</td>
      </tr>
      <tr>
        <td>82001294</td>
        <td>Remo&ccedil;ao de dentes semi inclusos / impactados </td>
      </tr>
      <tr>
        <td>82001634</td>
        <td>Tratamento cir&uacute;rgico para tumores benignos odontogenicos - sem reconstru&ccedil;ao</td>
      </tr>
      <tr>
        <td>82001588</td>
        <td>Tratamento Cirurgico de Hiperplasia de Tecidos &Oacute;sseos/Cartilaginosos na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001596</td>
        <td>Tratamento Cirurgico de Tumores Benigno de Tecidos &Oacute;sseos / Cartilaginosos na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82001553</td>
        <td>Tratamento Cirurgico de Hiperplasia de Tecidos Moles da Regiao Buco-Maxilo-Facial</td>
      </tr>
      <tr>
        <td>82001618</td>
        <td>Tratamento Cirurgico de Tumores Benigno de Tecidos Moles da Regiao Buco-Maxilo-Facial </td>
      </tr>
      <tr>
        <td>82000743</td>
        <td>Ex&eacute;rese de lipoma na regiao buco-maxilo-facial</td>
      </tr>
      <tr>
        <td>82000786</td>
        <td>Ex&eacute;rese ou excisao de Cistos odontol&oacute;gicos</td>
      </tr>
      <tr>
        <td>82001510</td>
        <td>Tratamento cir&uacute;rgico de f&iacute;stula buco-nasais</td>
      </tr>
      <tr>
        <td>82001529</td>
        <td>Tratamento cir&uacute;rgico de f&iacute;stula buco-sinusais</td>
      </tr>
      <tr>
        <td>82000808</td>
        <td>Exerese ou Excisao de R&acirc;nula</td>
      </tr>
      <tr>
        <td>82000794</td>
        <td>Exerese ou Excisao de Mucocele</td>
      </tr>
      <tr>
        <td>82000778</td>
        <td>Exerese ou Excisao de calculo salivar</td>
      </tr>
      <tr>
        <td>82001707</td>
        <td>Ulectomia</td>
      </tr>
      <tr>
        <td>82001170</td>
        <td>Redu&ccedil;ao cruenta de fraturas alveolo dent&aacute;rias </td>
      </tr>
      <tr>
        <td>82001189</td>
        <td>Redu&ccedil;ao incruenta de fraturas alveolo dent&aacute;rias </td>
      </tr>
      <tr>
        <td>00005870</td>
        <td>Curetagem apical (cirurgia de granuloma e cisto)</td>
      </tr>
    </table>
  </div>
</div>
