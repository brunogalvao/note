<div class="conteudo1">
    <div class="cpf">
        <h1>DIGITE SEU CPF</h1>
       	<? if(isset($msg)){ ?> <p class="msg-erro"> <?= $msg ?></p> <? } ?>
        <div style="overflow:hidden; text-align:center; margin:auto; width:370px;">
        <form method="post" >
            <input type="text" name="cpf" class="cpf" id="cpf" style="float:left;" >
            <input type="submit" value="" class="button-ok" style="float:left;" >
        </form>
        </div>
    </div>

</div>
