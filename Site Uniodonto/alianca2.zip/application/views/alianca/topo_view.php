<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />

<title>Alian&ccedil;a</title>

  	<link rel='stylesheet' type='text/css' href='<?= site_url()?>css/css_alianca.css' />
  	<script type='text/javascript' src="<?= site_url()?>js/jquery-latest.js"></script>
    <script src="<?= site_url()?>js/jquery-ui.js"></script>
	
    <script type="text/javascript" src="<?= site_url()?>js/jquery.mask.js" charset="utf-8"></script>
    <script type="text/javascript" src="<?= site_url()?>js/js_alianca.js" charset="utf-8"></script>
    
    <link rel="stylesheet" href="<?= site_url()?>includes/validation/css/validationEngine.jquery.css" type="text/css"/>
  	<script src="<?= site_url()?>includes/validation/js/languages/jquery.validationEngine-ptBR.js" type="text/javascript" charset="utf-8"></script>
 	<script src="<?= site_url()?>includes/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
    
    <script src='<?= site_url()?>js/jquery.form.js' type="text/javascript" language="javascript"></script>
  	<link href="<?= site_url()?>css/input.css" rel="stylesheet" type="text/css"/>
  	<script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>	
  	<script src="<?= site_url()?>js/jquery-ui.js"></script>
    <link type="text/css" rel="stylesheet" href="<?= site_url()?>js/jquery-ui/ui-lightness/jquery-ui.css">
    <script type="text/javascript" src="<?= site_url()?>js/jquery.fileDownload.js" charset="utf-8"></script> 


</head>

<body>
<div class="topo">
	<div class="logo"><a href="<?= site_url()?>alianca/site"><img src="<?= site_url()?>images/alianca/logo.png" border="0" ></a></div>
    <div class="menu">
    	</a>
        <a href="<?= site_url()?>alianca"><img src="<?= site_url()?>images/alianca/bt-home.png" border="0" >Home</a>
        <a href="<?= site_url()?>alianca/plano"><img src="<?= site_url()?>images/alianca/bt-conheca-o-plano.png" border="0" >Conhe&ccedil;a o plano</a>
        <a href="<?= site_url()?>alianca/urgencia"><img src="<?= site_url()?>images/alianca/bt-urgencia.png" border="0" >Urg&ecirc;ncias</a>
        <a href="<?= site_url()?>alianca/tabela"><img src="<?= site_url()?>images/alianca/bt-tabela.png" border="0" >Tabela de atos</a>
        <a href="<?= site_url()?>alianca/perguntas"><img src="<?= site_url()?>images/alianca/bt-perguntas.png" border="0" >Perguntas frequentes</a>
        <a href="<?= site_url()?>alianca/contato"><img src="<?= site_url()?>images/alianca/bt-contato.png" border="0" >Contato</a>
    </div>
</div>

