<div class="conteudo">
	<h1>Sua proposta foi preenchida com sucesso!</h1> 
    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit   amet vestibulum nulla. Vestibulum non sem lacus. Vivamus quis eleifend   ligula. Lorem ipsum dolor sit amet, consectetur adipiscing elit.   Pellentesque venenatis mattis erat in lacinia. Cras ullamcorper viverra   erat ac aliquet. Duis sollicitudin ante tellus, non aliquet libero   porttitor aliquam. Phasellus molestie ultrices mi, sed volutpat ante   mattis et. Ut vestibulum ut nibh vel ullamcorper. Praesent consequat   nunc nec enim ullamcorper porta. Aenean eu accumsan erat. </p>
  <p>&nbsp;</p>
    <p> Etiam et eros semper, luctus sapien id, cursus risus. Integer sem odio,   mollis blandit quam vel, lobortis iaculis metus. Mauris porttitor   lacinia risus, consequat tempor felis volutpat vitae. Vivamus rutrum   dolor quis dui convallis porttitor eget luctus quam. Praesent at diam   tristique, fermentum enim ut, laoreet mi. Sed a quam lobortis, egestas   libero id, interdum tellus. Etiam in placerat nisl. Suspendisse potenti.   Sed consequat purus diam, eu ullamcorper tortor ultrices pretium.   Vivamus massa sem, dictum in risus quis, elementum tempor sapien. Class   aptent taciti sociosqu ad litora torquent per conubia nostra, per   inceptos himenaeos.</p>
  <p>&nbsp; </p>
    <p>Para mais informa&ccedil;&otilde;es, acesse o &ldquo;Fale Conosco&rdquo; no site www.aliancaadm.com.br ou ligue 0800 ALIAN&Ccedil;A (0800 254 2622).</p>
    <p>&nbsp;</p>
    <p>Alian&ccedil;a Administradora de Benef&iacute;cios de Sa&uacute;de</p>
    <div class="gerar-proposta">
        <a onclick="baixarProposta('<?= site_url() ?>alianca/site/imprimir_proposta/<?= $id?>')" class="bt-continuar">Imprimir Proposta</a>
    </div>
    
</div>


