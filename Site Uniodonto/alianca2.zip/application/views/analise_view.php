<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('analise_critica') ?></a>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1><?= $this->lang->line('analise_critica') ?></h1>

	<? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
	<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
<script>
		jQuery(document).ready(function(){

			jQuery("#form").validationEngine();
		});

</script>    
<div class="formulario">
    	<form action="<?=site_url("analise")?>" method="post" id="form" />
        	
			<h2><?= $this->lang->line('dados_da_empresa') ?></h2>
				<label>
					<?= $this->lang->line('razao_social') ?><br>
				  <input style="width:630px;" class="validate[required]" name="razao" type="text">
				</label>
		    <span style="display: inline-block;">
                <label>
					<?= $this->lang->line('nome_fantasia') ?><br>
					<input style="width:410px;" class="validate[required]" name="fantasia" type="text">
				</label>
            </span>
			<span style="display: inline-block;">   
				<label>
					<?= $this->lang->line('cnpj') ?><br>
					<input maxlength="14" style="width:200px;" class="validate[required]" name="cnpj" type="text">
				</label>
			</span>
            <span style="display:inline-block;">
				<label>
				<?= $this->lang->line('endereco') ?><br>
					<input style="width:440px;" class="validate[required]" name="endereco" type="text">
				</label>
            </span>
            <span style="display:inline-block;">    
		           <label>
				  <?= $this->lang->line('numero') ?><br>
					<input style="width:50px;" maxlength="6" class="validate[required]" name="numero" type="text">
</label>
            </span>
            <span style="display: inline-block;">    
		           <label>
				  <?= $this->lang->line('complemento') ?><br>
				  <input style="width:100px;" name="complemento" type="text">
				</label>
            </span>
   			<span style="display: inline-block;"> 
	   		<label>
				  <?= $this->lang->line('bairro') ?><br>
					<input style="width:270px;" class="validate[required]" name="bairro" type="text">
			</label>
            </span>
   			<span style="display: inline-block;">     
	        <label>
				  <?= $this->lang->line('cidade') ?><br>
					<input style="width:300px;" class="validate[required]" name="cidade" type="text">
			</label>
            </span>
   			<span style="display: inline-block;">     
	        <label>
				  <?= $this->lang->line('estado') ?><br>
					<input style="width:20px;" maxlength="2" class="validate[required]" name="uf" type="text">
			</label>
            </span>
   			<span style="display: inline-block;">     
			<label>
					<?= $this->lang->line('ramo_de_atividade') ?><br>
				  <input style="width:200px;" class="validate[required]" name="ramo" type="text">
			</label>
            </span>
   			<span style="display: inline-block;">     
			<label>
					<?= $this->lang->line('telefone') ?><br>
				  <input style="width:100px;" class="validate[required]" name="fone" type="text">
			</label>
            </span>
   			<span style="display: inline-block;">     
	        <label>
					<?= $this->lang->line('fax') ?><br>
				  <input style="width:100px;" class="validate[required]" name="fax" type="text">
			</label>
		    </span>
   			<span style="display: inline-block;">     
            <label>
					<?= $this->lang->line('pessoa_de_contato') ?><br>
					<input style="width:168px;" class="validate[required]" name="pessoa" type="text">
			</label>
		    </span>
   			<span style="display: inline-block;">     
                <label>
				   <?= $this->lang->line('cargo') ?><br>
				   <input style="width:200px;" class="validate[required]" name="cargo" type="text">
				</label>
		    </span>
   			<span style="display: inline-block;">    
            <label>
					<?= $this->lang->line('email') ?><br>
				   <input style="width:410px;" id="email" class="validate[required]" name="email" type="text">
			</label>
		  	</span>


			<h2><?= $this->lang->line('pesquisa_para_elaboracao_da_proposta') ?></h2>
			<!-- Campos -->

			<div class="clear">
				
            	<span style="display: inline-block;">
                <label>
					<?= $this->lang->line('n_de_funcionarios_da_empresa') ?><br>
					<input style="width:180px;" class="validate[required]" name="numeroFuncionario" type="text">
				</label>
                </span>
            	<span style="display: inline-block;">
				<label>
					<?= $this->lang->line('quantos_participam_do_plano') ?><br>
					<input name="quantosParticipa" style="width:170px;" class="validate[required]" type="text">
				</label>
                </span>
			</div>

				<div class="clear">
				  
            	<span style="display: inline-block;">
				  <?= $this->lang->line('possui_convenio_medico') ?><br>
					<label><input id="possuiconvenio" value="sim" name="possuiconvenio" type="radio"><?= $this->lang->line('sim') ?></label>
                <label><input id="possuiconvenio" value="nao" name="possuiconvenio" type="radio">
                 <?= $this->lang->line('nao') ?></label>
                </span>
            	<span style="display: inline-block;">
	            <label>
					<?= $this->lang->line('com_qual_operadora_ou_seguradora') ?><br>
					<input style="width:200px;" name="operadoraMedico" type="text">
				</label>
                </span>
</div>

			<div class="clear">
	            </span>
            	<span style="display: inline-block;">
				  <?= $this->lang->line('possui_convenio_odontologico') ?><br>
					<label><input value="sim" id="possuiconvenioOdonto" name="possuiconvenioOdonto" type="radio"><?= $this->lang->line('sim') ?></label>

	                <label><input value="nao" id="possuiconvenioOdonto" name="possuiconvenioOdonto" type="radio">
	                <?= $this->lang->line('nao') ?></label>
			  </span>
            	<span style="display: inline-block;">
	            <label>
				  <?= $this->lang->line('com_qual_operadora_ou_seguradora') ?><br>
					<input style="width:200px;" name="operadoraOdonto" type="text">
				</label>
                </span>
            	<span style="display: inline-block;">
	            <label>
				  <?= $this->lang->line('motivo_mudanca') ?><br>
					<input style="width:215px;" name="motivo" type="text">
				</label>
                </span>
</div>

			<div class="clear">
	            </span>
            	<span style="display: inline-block;">
				  <?= $this->lang->line('tem_filiais') ?><br>
				<label>	<input value="sim" id="temFiliais" name="temFiliais" type="radio"><?= $this->lang->line('sim') ?></label>
	            <label> <input value="nao" id="temFiliais" name="temFiliais" type="radio">
               <?= $this->lang->line('nao') ?></label>
				</span>
            	<span style="display: inline-block;">
	            <label>
				  <?= $this->lang->line('em_quais_cidade') ?><br>
					<input style="width:295px;" name="cidadesFilial" type="text">
				</label>
                </span>
			</div>

			<div class="clear">
				</span>
            	<span style="display: inline-block;">
				 <?= $this->lang->line('o_plano_odontologico_sera_extensivo_para_estas_filiais
') ?><br>
					<label><input value="sim" id="SeraExtensivo" name="SeraExtensivo" type="radio"><?= $this->lang->line('sim') ?></label>
	                <label><input value="nao" id="SeraExtensivo" name="SeraExtensivo" type="radio"><?= $this->lang->line('nao') ?></label>
			  </span>
</div>

			<div class="clear">
	            </span>
            	<span style="display: inline-block;">
				 <?= $this->lang->line('O Plano Odontol&oacute;gico ser&aacute; extensivo aos dependentes dos funcion&aacute;rios?
') ?><br>
					<label><input value="sim" id="extensivoFuncionarios" name="extensivoFuncionarios" type="radio"><?= $this->lang->line('sim') ?></label>
	                <label><input value="nao" id="extensivoFuncionarios" name="extensivoFuncionarios" type="radio"><?= $this->lang->line('nao') ?></label>
			  </span>
</div>

			<div class="clear">
            
            	<span style="display: inline-block;">
	            <label style="clear:both;">
				  <?= $this->lang->line('caso_negativo_qual_sera_o_percentual_de_participacao_do_funcionario
') ?><br>
					<input size="5" name="percentual" type="text"> (%)
				</label>
                </span>
			</div>



   	  
		<h2><?= $this->lang->line('plano') ?></h2>

        <span style="display: inline-block;">
        	<?= $this->lang->line('plano') ?><br>
			<label><input value="Coletivo Empresarial" name="plano" type="radio">
				<?= $this->lang->line('coletivo_empresarial') ?></label>
          	<label><input value="Coletivo por Adesao" name="plano" type="radio">
            <?= $this->lang->line('coletivo_por_adesao') ?></label>
		</span>

		 <div class="clear">
         <span style="display: inline-block;">
		    <?= $this->lang->line('tipo_de_plano') ?><br>
			<label><input value="Basico" name="TipoPlano" type="radio">
		     <?= $this->lang->line('basico') ?></label>
            <label><input value="Superior" name="TipoPlano" type="radio"> <?= $this->lang->line('superior') ?></label>
            <label><input value="Avancado" name="TipoPlano" type="radio"> 
            <?= $this->lang->line('avancado') ?></label>
            <label><input value="Emergencial Misto" name="TipoPlano" type="radio">
            <?= $this->lang->line('emergencia_misto') ?></label>
            <label><input value="Custo Operacional" name="TipoPlano" type="radio"> <?= $this->lang->line('custo_operacional') ?></label>
          </span>
          
         </div>
		<span style="display: inline-block;">
        	<label style="clear:both;">
			  <?= $this->lang->line('valor') ?><br>
				<input style="width:95px;" name="valor" type="text">
			</label>
        </span>
        <span style="display: inline-block;">     
            <label>
			  <?= $this->lang->line('proposta_pra_quantas_vidas') ?><br>
				<input style="width:155px;" class="validate[required]" name="qtdpessoas" type="text">
			</label>
      </span>
      <span style="display: inline-block; height: 100px;">   
            <label>
             <?= $this->lang->line('observacoes') ?><br>
             <textarea name="obs" style="width:500px; height:50px;"></textarea>
            </label>
         </span>   
      <label>
            <input type="submit" value="<?= $this->lang->line('enviar') ?>"  name="Enviar" class="btn-submit" >
        </form>
        
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>