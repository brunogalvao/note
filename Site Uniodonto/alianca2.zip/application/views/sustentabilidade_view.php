<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('sustentabilidade') ?>
</div>
<div class="conteudo-left">
    <div class="texto">
    	<h1><?= $this->lang->line('sustentabilidade') ?></h1>
        <img src="<?= site_url()?>images/logo-sustentavel.JPG" style="float:left; padding-right:10px;" />
        <p>
       		<?= $this->lang->line('texto_sustentabilidade') ?>
        </p>
        
        <a href="<?= site_url()?>pagina/32/instituto+gui+darin"><img src="<?= site_url()?>images/logo-guidarin.jpg" style="padding:10px;" /></a>
        <a href="<?= site_url()?>pagina/33/projeto+avp"><img src="<?= site_url()?>images/avp.jpg" style="padding:10px;" border="0" /></a>
        <a href="<?= site_url()?>pagina/34/gaaco"><img src="<?= site_url()?>images/logo-gaaco.jpg" style="padding:10px;" border="0" /></a>
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>