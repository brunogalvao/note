<? if($this->session->userdata("logged") == true){?>
 
		<? if($this->session->userdata("pagina") == "beneficiario"){ ?>
       	<div class="bloco bloco-menu-user">
		  <h1><?= $this->lang->line('area_do_beneficiario') ?></h1>
          		<a href=<?=site_url("beneficiario/relatorios")?>><img src="<?=site_url()?>images/icons/relatorio.png" border="0"><?= $this->lang->line('relatorios') ?></a>
                <a href="<?=site_url("beneficiario/alterar-dados")?>"><img src="<?=site_url()?>images/icons/dados.png" border="0"><?= $this->lang->line('alterar_dados_cadastrais') ?></a>
                
                <a href="<?=site_url("beneficiario/boleto")?>"><img src="<?=site_url()?>images/icons/pagamento.png" border="0"><?= $this->lang->line('pagamento_online') ?></a>
        		
        </div>    
        
        <? } ?>
        <? if($this->session->userdata("pagina") == "empresa"){ ?>
        <div class="bloco bloco-menu-user">
		  <h1><?= $this->lang->line('area_da_empresa') ?></h1>
                <a href="<?=site_url("empresa/movimentacao-cadastral")?>"><img src="<?=site_url()?>images/icons/cadastro.png" border="0"><?= $this->lang->line('movimentacao_cadastral') ?></a>
                <a href="<?=site_url("empresa/liberacao-online")?>"><img src="<?=site_url()?>images/icons/sistema.png" border="0"><?= $this->lang->line('liberacao_online') ?></a>
                <a href="<?=site_url("empresa/boleto")?>"><img src="<?=site_url()?>images/icons/boleto.png" border="0"><?= $this->lang->line('boleto_bancario') ?></a>
                
        </div>
        <? } ?>
        <? if($this->session->userdata("pagina") == "dentista"){ ?>
        <div class="bloco bloco-menu-user">
		  <h1><?= $this->lang->line('area_do_dentista') ?></h1>
          <?
			$ip =$_SERVER['REMOTE_ADDR'];
			if($ip == '187.59.2.42'){
								
			?>
				<a href="http://192.168.1.168/zimbra/" target="_blank"><img src="<?=site_url()?>images/icons/agenda.png" border="0"><?= $this->lang->line('agenda') ?></a>
            <? }else{ ?>
            	<a href="http://agenda.uniodontocuritiba.com.br:81/" target="_blank"><img src="<?=site_url()?>images/icons/agenda.png" border="0"><?= $this->lang->line('agenda') ?></a>
			<?	} ?>
                
                <a href="http://webmail.uniodontocuritiba.com.br/" target="_blank"><img src="<?=site_url()?>images/icons/email.png" border="0"><?= $this->lang->line('email') ?></a>
                <a href="<?=site_url("dentista/liberacao-online")?>"><img src="<?=site_url()?>images/icons/sistema.png" border="0"><?= $this->lang->line('liberacao_online') ?></a>
                <a href="http://www.dentaluni.com.br"><img src="<?=site_url()?>images/icons/dentaluni.png" border="0"><?= $this->lang->line('dental_uni') ?></a>
                <a href="<?= site_url('relatorios/cooperado')?>"><img src="<?=site_url()?>images/icons/relatorio.png" border="0"><?= $this->lang->line('relatorios') ?></a>
                <a href="<?= site_url()?>"><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabela_de_atos') ?></a>
          		
        </div>   
        <? } ?>
        <? if($this->session->userdata("pagina") == "uniodonto"){ ?>
        <div class="bloco bloco-menu-user">
		  <h1><?= $this->lang->line('area_da_uniodonto') ?></h1>
                 <a href="<?=site_url("uniodonto/boleto")?>"><img src="<?=site_url()?>images/icons/boleto.png" border="0"> <?= $this->lang->line('boletos') ?></a>
                <a href="<?=site_url("uniodonto/liberacao-online")?>"><img src="<?=site_url()?>images/icons/sistema.png" border="0"> <?= $this->lang->line('liberacao_online') ?></a>

               
   
        </div>
        <? } ?>
        
        <? if($this->session->userdata("pagina") == "representante"){ ?>
        <div class="bloco bloco-menu-user">
		  <h1><?= $this->lang->line('area_do_representante') ?></h1>
                <a href="<?=site_url("analise")?>"><img src="<?=site_url()?>images/icons/analise.png" border="0"><?= $this->lang->line('analise_critica') ?></a>
                <a href="<?=site_url("representante/senha")?>"><img src="<?=site_url()?>images/icons/user.png" border="0"><?= $this->lang->line('alterar_senha') ?></a>
                
                
        
        </div>
        <? } ?>
<? } ?>

<? if(!$this->session->userdata("logged")){ ?>


<script type="text/javascript">
	$(document).ready(function(){
		$("#btn_calcular").click(function(event) {
			event.preventDefault();
			var str = $("#montePlanoForm").serialize();
			$('#resultado').html('');
			
			if(($("#plano_tipo").val() == "") || ($("#plano_pagamento").val() == "") || ($("#plano_modalidade").val() == "") || ($("#plano_qtd").val() == "")){
					$('#resultado').append("<?= $this->lang->line('selecione_todos_os_campos') ?>");
			}else{
				 
							
				$.ajax({
					
					url: "<?=site_url()?>site/calcula_planos?"+str,
					type: 'POST',
					context: jQuery('#resultado'),
					success: function(data){
						this.append(data);
					}
				});
			}
	   
		});
		$("#btn_contratar").click(function(event) {

			event.preventDefault();
	
			if(($("#plano_tipo").val() == "") || ($("#plano_pagamento").val() == "") || ($("#plano_modalidade").val() == "") || ($("#plano_qtd").val() == "")){
					$('#resultado').append("<?= $this->lang->line('selecione_todos_os_campos') ?>");
			}else{
				$("#montePlanoForm").attr("action","<?= site_url("contratar_plano")?>");
				$("#montePlanoForm").submit();
			}
	   
		});
	});
</script>
<div class="bloco box">
	<h1><?= $this->lang->line('monte_seu_plano_pf') ?></h1>
	<form name="montePlanoForm" id="montePlanoForm" action="" method="POST">
	   	<div class="form" style="padding-bottom: 15px;">
        	
            <label><?= $this->lang->line('plano') ?></label>
            
            <select name="plano_tipo" id="plano_tipo" >
                <option value=""><?= $this->lang->line('selecione') ?></option>
                <option value="1"><?= $this->lang->line('superior') ?></option>
                <option value="2"><?= $this->lang->line('avancado') ?></option>
            </select>
            
        
            <label><?= $this->lang->line('modalidade') ?></label>
            
            <select name="plano_modalidade" id="plano_pagamento">
            	<option value=""><?= $this->lang->line('selecione') ?></option>
            	<option value="1"><?= $this->lang->line('com_carencia') ?></option>
            	<option value="2"><?= $this->lang->line('sem_carencia') ?></option>
            	<option value="3"><?= $this->lang->line('co-participacao') ?></option>
          </select>
            
        
            <label><?= $this->lang->line('pagamento') ?></label>
            
            <select name="plano_pagamento" id="plano_modalidade">
            	<option value=""><?= $this->lang->line('selecione') ?></option>
                <option value="1"><?= $this->lang->line('boleto') ?></option>
                <option value="2"><?= $this->lang->line('debito') ?></option>
          </select>
            
        
            <label><?= $this->lang->line('beneficiarios') ?></label>        
            
            <select name="plano_qtd" id="plano_qtd">
            	<option value=""><?= $this->lang->line('selecione') ?></option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
          </select>
            
		</div>
        <div style="padding-bottom: 15px;" id="resultado">
            
    	</div>    
		<div style="padding-bottom: 25px;">
        	<a id="btn_contratar" href="#" class="btn-submit-pequeno"><?= $this->lang->line('contratar') ?></a>
        	<a id="btn_calcular" href="#" class="btn-submit-pequeno" style="margin-right:10px;"><?= $this->lang->line('calcular') ?></a>
            
 			
        </div>
    </form>
</div>

<div class="bloco-plan-empresa">

	<h1><?= $this->lang->line('planos_empresariais') ?></h1>
	<a href="<?= site_url()?>orcamento_empresa">    
   	<?= $this->lang->line('clique_aqui_e_solicite_um_orcamento') ?>
	</a>    
</div>

<? } ?>
<div class="bloco box">
	<h1><?= $this->lang->line('encontre_seu_dentista') ?></h1>
    <script type="text/javascript">
        $(document).ready(function(){
			
            $('#estados').change(function(){
                $('#cidades').load('<?=site_url()?>retorna_estados/'+$('#estados').val() );

            });
			 $('#especialidade').load('<?=site_url()?>retorna_especialidades').val();
			 $('#cidades').load('<?=site_url()?>retorna_estados/17').val();
 
		
		$("#btn_buscar").click(function(event) {
			
			if(($("#dentista_cro").val() != "")  || ($("#dentista_nome").val() != "") || ($("#cidades").val() != "0" || ($("#especialidade").val() != "0")) ){
					$("#dentistaForm").submit();
					$("#erro").html("");
			}else{
				$("#erro").html("<?= $this->lang->line('para_efetuar_a_busca_preencha_pelo_menos_um_dos_campos
') ?>");
				
			}
	   
		});
	});

    </script>
	<form name="dentistaForm" id="dentistaForm" action="<?= $link_sistema ?>EncontreSeuDentista.do" method="POST" target="POPUPW">
	   	<div class="form" style="padding-bottom: 15px;">
                      
            <label>CRO</label>           
            <input type="text" name="dentista.cro" id="dentista_cro" value="" />
            
        	<label><?= $this->lang->line('nome') ?></label>
            <input type="text" name="dentista.nome" id="dentista_nome" value="" />
            
            <label><?= $this->lang->line('estado') ?></label>            
            <select name="dentista.estado" id="estados">
              		<option value="1">AC</option>
					<option value="2">AL</option>
					<option value="4">AM</option>
					<option value="3">AP</option>
					<option value="5">BA</option>
					<option value="6">CE</option>
					<option value="7">DF</option>
					<option value="8">ES</option>
					<option value="10">GO</option>
					<option value="11">MA</option>
					<option value="14">MG</option>
					<option value="13">MS</option>
					<option value="12">MT</option>
					<option value="15">PA</option>
					<option value="16">PB</option>
					<option value="18">PE</option>
					<option value="19">PI</option>
					<option value="17" selected>PR</option>
					<option value="20">RJ</option>
					<option value="21">RN</option>
					<option value="23">RO</option>
					<option value="9">RR</option>
					<option value="22">RS</option>
					<option value="25">SC</option>
					<option value="27">SE</option>
					<option value="26">SP</option>
					<option value="24">TO</option>    
        	</select>
            
            <label><?= $this->lang->line('cidade') ?></label>            
            <select name="dentista.cidade" id="cidades"></select>
            
        
            <label><?= $this->lang->line('bairro') ?></label>            
            <input type="text" name="dentista.bairro" />
            <div style="height:20px;">
            <input type="radio" value="E" name="dentista.tipoEspecialidade">
            <font style="font-size: 9.3px"><?= $this->lang->line('especialidade') ?></font>
            <input type="radio" value="A" name="dentista.tipoEspecialidade">
            <font style="font-size: 9.3px"><?= $this->lang->line('area_de_atuacao') ?></font>    
            </div>
                
            <label><?= $this->lang->line('selecione') ?></label><select name="dentista.especialidade" id="especialidade" ></select>
            <div style="padding-top:10px;">
            <label style="width:100px;  margin-top:2px;"><?= $this->lang->line('liberacao_online') ?></label>  
            <input type="checkbox" name="dentista.mostrarLiberacaoOnline" />
            <div id="erro" style="padding-top: 5px; color:#af2638;"></div>
			<input type="button" id="btn_buscar" value="<?= $this->lang->line('buscar') ?>" class="btn-submit-pequeno" style="padding-bottom: 10px; margin-top: 3px;">
 			</div>
        </div>
    </form>
</div>

<script type="text/javascript">
$(document).ready(function() {
    $('.clientes').cycle({
		auto:  'true',
		fx: 'scrollLeft',
		timeout: 20
	});
});
</script>
<div class="bloco box">
	<h1><?= $this->lang->line('nossos_clientes') ?></h1>
        <div class="clientes">
        
        <?php
			//pega imagens no diret?rio e separa para arrays com 9 imagens
			$imgs = array_chunk(glob("upload/clientes".'/*.jpg'),9);
			//abre array e mostra as imagens
			foreach($imgs as $img){
				print '<div class="slide">';
				
				foreach($img as $image){
					print '<img src="'.site_url($image).'" width="71" height="46"/>';
				}
				print "</div>";
				
			}
			
			
		?>
		
	</div>
		
</div>
		
</div>



