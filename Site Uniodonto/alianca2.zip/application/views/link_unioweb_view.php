﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Unioweb</title>
	<script type="text/javascript" charset="utf-8">
      $(function(){
			$("input:text, input:checkbox, input:radio, input:file, textarea").uniform();
			$("select").uniform();
			
			if(typeof(Storage)!=="undefined") {
					sessionStorage.setItem('ss', '1');
					localStorage.setItem('ls', '1');
				}else{
					sessionStorage.setItem('ss', '1');
					store.set('ls', '1');
				}
						
		});
		
		
	  

    </script>

</head>

<body onLoad="document.forms.item(0).submit();">

<form name="actionForm" id="form" method="post" action="<?= $link ?>">
	<input type="text" name="actionDestino" value="<?= $action ?>">
</form>

</body>
</html>
