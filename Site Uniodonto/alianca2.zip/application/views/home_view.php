<? include("header_view.php"); ?>


<script type="text/javascript">
			
	$(document).ready(function(){
		var t=setTimeout("popup()",500);
		});
	
	function popup(){
	$("#popup").fancybox({
		'padding' : 0,
		'scrolling' : 'no',
		'showCloseButton'	: false,
		'transitionIn'	:	'elastic',
		'transitionOut'	:	'elastic',
		'speedIn'		:	600, 
		'speedOut'		:	200, 
		'overlayShow'	:	false,
		'modal'			: false
		});
	$('#popup').trigger('click');
		} 		
</script>
<? if($this->session->userdata("pagina") == "beneficiario" and $this->session->userdata("logged") == true){ ?>
<style>
.fancybox-close{
	margin-top: 20px;
	right: 1px;
	}
</style>
<a id="popup" href="#popup-conteudo" title="" style="display:none;"></a>
<div style="display: none; background: url(site.png) no-repeat; text-align:center;">
	
	<div id="popup-conteudo" style="text-align:center;overflow:none; border:none;">
    
	<a title="" style="z-index:9999;" target="_blank">
    <img src="<?= site_url("images/popup/beneficiario.png") ?>" alt="" border="0"/>
    </a>
	   
    </div>
</div>
<? } ?>
<? if($this->session->userdata("pagina") == "empresa" and $this->session->userdata("logged") == true){ ?>
<style>
.fancybox-close{
	margin-top: 20px;
	right: 1px;
	}
</style>
<a id="popup" href="#popup-conteudo" title="" style="display:none;"></a>
<div style="display: none; background: url(site.png) no-repeat; text-align:center;">
	
	<div id="popup-conteudo" style="text-align:center;overflow:none; border:none;">
    
	<a title="" style="z-index:9999;" target="_blank">
    <img src="<?= site_url("images/popup/empresa.png") ?>" alt="" border="0"/>
    </a>
	   
    </div>
</div>
<? } ?>
<? if($this->session->userdata("pagina") == "representante" and $this->session->userdata("logged") == true){ ?>
<style>
.fancybox-close{
	margin-top: 20px;
	right: 1px;
	}
</style>
<a id="popup" href="#popup-conteudo" title="" style="display:none;"></a>
<div style="display: none; background: url(site.png) no-repeat; text-align:center;">
	
	<div id="popup-conteudo" style="text-align:center;overflow:none; border:none;">
    
	<a title="" style="z-index:9999;" target="_blank">
    <img src="<?= site_url("images/popup/representante.png") ?>" alt="" border="0"/>
    </a>
	   
    </div>
</div>
<? } ?>
<? if($this->session->userdata("pagina") == "dentista" and $this->session->userdata("logged") == true){ ?>
<style>
.fancybox-close{
	margin-top: 20px;
	right: 1px;
	}
</style>
<a id="popup" href="#popup-conteudo" title="" style="display:none;"></a>
<div style="display: none; background: url(site.png) no-repeat; text-align:center;">
	
	<div id="popup-conteudo" style="text-align:center;overflow:none; border:none;">
    
	<a href="http://www.uniodontocuritiba.com.br/curitiba/upload/files/dentista/instrucoes-tecnicas-gerais-web.pdf" title="" style="z-index:9999;" target="_blank">
    <img src="<?= site_url("images/popup/tabela-dentista.png") ?>" alt="" border="0"/>
    </a>
	   
    </div>
</div>
<? } ?>

<div class="conteudo-left" style="padding-top:10px;">

	<? if($this->session->userdata("pagina") == "dentista" and $this->session->userdata("logged") == true){ ?>
	<script type='text/javascript'>
	

		
		
	

        $(document).ready(function() {	
                   
                
                   $.ajax({
                      url: '<?=site_url("site/eventos")?>',
                      data: { start: "", end: "" },
                      success: function(data) {
                         var events = [];
                          $(data).find('event').each(function() {
                               events.push({
								id: $(this).attr('id'),   
                                title: $(this).find("titulo").text(),
                                url: $(this).attr('url'),
                                start: $(this).attr('start').split("-"),
                                end: $(this).attr('end'),
                                color: $(this).attr('color'),
                                backgroundColor: $(this).attr('backgroundColor'),
                                borderColor: "#fff",
                                className: "evento-dia"
                                });
                        
                              });
						var meses = new Array('<?= $this->lang->line('Janeiro') ?>','<?= $this->lang->line('fevereiro') ?>','<?= $this->lang->line('marco') ?>','<?= $this->lang->line('abril') ?>','<?= $this->lang->line('maio') ?>','<?= $this->lang->line('junho') ?>','<?= $this->lang->line('julho') ?>','<?= $this->lang->line('agosto') ?>','<?= $this->lang->line('setembro') ?>','<?= $this->lang->line('outubro') ?>','<?= $this->lang->line('novembro') ?>','<?= $this->lang->line('dezembro') ?>');  
						
							  
                        
                        var eventsHtml;	        
                        for (var i=0; i<3; i++){
                            $("#eventos h1").after('<a href="'+events[i]['url']+'">'+
							'<div class="data">'+
							'<h5>'+
							events[i]['start'][2]+
							'</h5>'+
							meses[events[i]['start'][1] -1]+
							'</div><div class="titulo">'+
							events[i]['title']+
							'</div></a>');
                            }	
                        
                      }
                    });   
                            
              
        });
    </script>
    <div class="eventos-home" id="eventos">
    <h1><?= $this->lang->line('proximos_eventos');?></h1>
        
	 <a href="<?= site_url()?>calendario" id="bt-vejamais" class="bt-vejamais"><?= $this->lang->line('ver_calendario_completo');?></a>
    </div>
	<? } ?>
    <div class="noticias-home">
    	<h1><?= $this->lang->line('noticias');?></h1>
    	<span class="principal">
            <? $img = explode(";",$noticias_destaque[0]['noticia_imgs']); 
				$img_thumb = explode(".",$img[0]);
			?>  	
            <a href="<?= site_url()?>noticia/<?=$noticias_destaque[0]['noticia_id']?>/<?=str_replace('%','',urlencode($this->formata_nome_model->formataNome($noticias_destaque[0]['noticia_titulo_'.$this->session->userdata("idioma")])))?>"><img src="<?=site_url('images/noticias')."/".$img_thumb[0]?>_large.<?= $img_thumb[1]?>" alt="<?= utf8_decode($noticias_destaque[0]['noticia_titulo_'.$this->session->userdata("idioma")])?>" border="0">
            <h2><?=utf8_decode($noticias_destaque[0]['noticia_titulo_'.$this->session->userdata("idioma")])?></h2>
            </a>
        </span>
        <span class="recentes"> 
        <div style="overflow:hidden;">
        
        <?
		$i = 1; 
		foreach($noticias as $noticia){
            $data = explode(" ",$noticia[0]['noticia_data']);
            $data = explode("-",$data[0] );
			$img = explode(";",$noticia[0]['noticia_imgs']);
			$img_thumb = explode(".",$img[0]);
            ?>
            
        <a href="<?= site_url()?>noticia/<?=$noticia[0]['noticia_id']?>/<?=str_replace('%','',urlencode($this->formata_nome_model->formataNome($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])))?>">
        	<div>
                <span class="img"><img src="<?=site_url('images/noticias')."/".$img_thumb[0]?>_small.<?= $img_thumb[1]?>" alt="<?=utf8_decode($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?>" border="0"></span>
                <span class="titulo"><?=utf8_decode($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?></span>
        	</div>
        </a>
           
        <? if($i == 2){
			print "</div><div>";
			} 
		
		
		$i ++;} ?>
        <a href="<?= site_url()?>historico" id="bt-vejamais" class="bt-vejamais"><?= $this->lang->line('mais_noticias');?></a>
       </div>
		</span>
    </div>
    
    <div class="video-home" style="width:680px; height:175px; margin: 10px 25px;">
    <a href="<?=site_url("video")?>"><img src="<?=site_url("videos/video.jpg")?>" alt="<?= $this->lang->line('video_institucional');?>" border="0" ></a>
    <? if($this->session->userdata("idioma") == "ptBR"){ 
		print '<img src="'.site_url().'images/banner-pequeno-home.jpg" alt="Uniodonto 24 horas" border="0">'; }?>

    <? if($this->session->userdata("idioma") == "en"){ 
		print '<img src="'.site_url().'images/banner-pequeno-home_en.jpg" alt="Uniodonto 24 hours" border="0">'; }?>
	
    <? if($this->session->userdata("idioma") == "es"){ 
		print '<img src="'.site_url().'images/banner-pequeno-home_es.jpg" alt="24 hrs Uniodonto" border="0">'; }?>	

	
    </div>
    
    <div class="box" style="width:690px; height:77px; margin: 20px 0px 20px 0px; float:left;">
    	<a href="http://www.dentaluni.com.br" target="_blank">
        <? if($this->session->userdata("idioma") == "ptBR"){ 
		print '<img src="'.site_url().'images/banner-dental.jpg" alt="DentalUni" border="0">'; }?>

		<? if($this->session->userdata("idioma") == "en"){ 
		print '<img src="'.site_url().'images/banner-dental-en.jpg" alt="DentalUni" border="0">'; }?>
        
        <? if($this->session->userdata("idioma") == "es"){ 
		print '<img src="'.site_url().'images/banner-dental-es.jpg" alt="DentalUni" border="0">'; }?>
        
        </a>	
    </div>
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>

<? include("footer_view.php"); ?>