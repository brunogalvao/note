<? include("header_view.php");?>

<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= utf8_decode(ucfirst($texto[0]['texto_aba_titulo_'.$this->session->userdata("idioma")]))?>
</div>
<div class="conteudo-left">
    <div class="texto">
    	<h1><?= ucfirst($texto[0]['texto_aba_titulo_'.$this->session->userdata("idioma")])?></h1>
		<?= $texto[0]['texto_aba_texto_'.$this->session->userdata("idioma")]?>
        <? if(isset($texto[0]['texto_aba_img'])){ ?>
        <script type="text/javascript" src='<?= site_url()?>includes/galleria/galleria-1.2.8.min.js' ></script>
        <div id="galleria">
			<?
					$texto_aba_img = explode(";",$texto[0]['texto_aba_img']);
					foreach($texto_aba_img as $img){
						if($img != ""){
							$texto_aba_img_thumb = explode(".",$img);
							print '
							 <a href="'.site_url()."images/textos/".$img.'">
                <img src="'.site_url()."images/textos/".$texto_aba_img_thumb[0]."_thumb.".$texto_aba_img_thumb[1].'">
            				 </a>
							';
							
						}	
					} ?>
			<script>

			// Load the classic theme
			Galleria.loadTheme('<?=site_url()?>includes/galleria/themes/classic/galleria.classic.min.js');
		
			Galleria.configure({
				lightbox: true
			});
			// Initialize Galleria
			Galleria.run('#galleria', {
				transition: 'pulse',
				imageCrop: true,
				height: 400,
			
			});
		
			</script>

			
                
    	</div>
		<? } ?> 
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>