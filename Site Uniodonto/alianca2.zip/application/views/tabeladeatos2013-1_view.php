<? include("header_view.php"); ?>
<script>
$(document).ready(function(){
   $("tr:even").addClass("even");
   $("tr:odd").addClass("odd");
});
</script>
<style>
	.odd {
	   background-color: #fcb9c2; 
	   }
	.odd td {
	   border-bottom: 1px solid #fcb9c2; }
</style>
    <div class="nav"> <a href="<?=site_url()?>">Home</a> / Tabela de Atos </div>
    <div class="conteudo-left">
      <div class="texto">
        <h1>Tabela de Atos - P&aacute;gina 1 de 3</h1>
        <br /><br />
        <table cellpadding="0" cellspacing="0" class="tabela-atos">
          <tbody>
            <tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	URGÊNCIA	</td><td>	USO	</th></tr>
<tr><td>	82000468	</td><td>	Controle de hemorragia com aplicação de agente hemostático em região buco-maxilo-facial	</td><td>	12	</td></tr>
<tr><td>	82000484	</td><td>	Controle de hemorragia sem aplicação de agente hemostático em região buco-maxilo-facial	</td><td>	12	</td></tr>
<tr><td>	82001022	</td><td>	Incisão e Drenagem extra-oral de abscesso, hematoma e/ou flegmão da região buco-maxilo-facial	</td><td>	12	</td></tr>
<tr><td>	82001030	</td><td>	Incisão e Drenagem intra-oral de abscesso, hematoma e/ou flegmão da região buco-maxilo-facial	</td><td>	12	</td></tr>
<tr><td>	82001197	</td><td>	Redução simples de luxação de Articulação Têmporo-mandibular (ATM)	</td><td>	12	</td></tr>
<tr><td>	82001251	</td><td>	Reimplante dentário com contenção	</td><td>	12	</td></tr>
<tr><td>	82001642	</td><td>	Tratamento conservador de luxação da articulação têmporo-mandibular - ATM	</td><td>	12	</td></tr>
<tr><td>	82001650	</td><td>	Tratamento de alveolite	</td><td>	12	</td></tr>
<tr><td>	85000787	</td><td>	Imobilização dentária em dentes decíduos	</td><td>	12	</td></tr>
<tr><td>	85100048	</td><td>	Colagem de fragmentos dentários	</td><td>	12	</td></tr>
<tr><td>	85100056	</td><td>	Curativo de demora em endodontia	</td><td>	12	</td></tr>
<tr><td>	85200034	</td><td>	Tratamento em odontalgia aguda	</td><td>	12	</td></tr>
<tr><td>	85300020	</td><td>	Imobilização dentária em dentes permanentes	</td><td>	12	</td></tr>
<tr><td>	85300063	</td><td>	Tratamento de abscesso periodontal agudo	</td><td>	12	</td></tr>
<tr><td>	85300080	</td><td>	Tratamento de pericoronarite	</td><td>	12	</td></tr>
<tr><td>	85400467	</td><td>	Recimentação de trabalhos protéticos	</td><td>	12	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	DIAGNÓSTICO	</td><td>	USO	</th></tr>
<tr><td>	81000260	</td><td>	Diagnóstico por meio de procedimentos laboratoriais	</td><td>	455	</td></tr>
<tr><td>	81000243	</td><td>	Diagnóstico por meio de enceramento	</td><td>	151	</td></tr>
<tr><td>	81000235	</td><td>	Diagnóstico e tratamento de xerostomia	</td><td>	67	</td></tr>
<tr><td>	81000219	</td><td>	Diagnóstico e tratamento de halitose	</td><td>	67	</td></tr>
<tr><td>	81000200	</td><td>	Diagnóstico e tratamento de estomatite por candidose	</td><td>	67	</td></tr>
<tr><td>	81000197	</td><td>	Diagnóstico e tratamento de estomatite herpética	</td><td>	67	</td></tr>
<tr><td>	81000189	</td><td>	Diagnóstico e planejamento para tratamento odontológico	</td><td>	67	</td></tr>
<tr><td>	81000090	</td><td>	Consulta para Técnica de Clareamento Dentário Caseiro	</td><td>	67	</td></tr>
<tr><td>	81000073	</td><td>	Consulta odontológica para avaliação técnica de auditoria  	</td><td>	70	</td></tr>
<tr><td>	81000065	</td><td>	Consulta odontológica inicial	</td><td>	67	</td></tr>
<tr><td>	81000057	</td><td>	Consulta odontológica de Urgência 24 hs	</td><td>	217	</td></tr>
<tr><td>	81000049	</td><td>	Consulta odontológica de Urgência	</td><td>	125	</td></tr>
<tr><td>	81000030	</td><td>	Consulta odontológica	</td><td>	67	</td></tr>
<tr><td>	00000140	</td><td>	Falta nao justificada	</td><td>	202	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	EXAMES	</td><td>	USO	</th></tr>
<tr><td>	84000228	</td><td>	Teste de capacidade tampão da saliva	</td><td>	177	</td></tr>
<tr><td>	84000244	</td><td>	Teste de fluxo salivar	</td><td>	177	</td></tr>
<tr><td>	84000252	</td><td>	Teste de PH salivar	</td><td>	177	</td></tr>
<tr><td>	81000111	</td><td>	Diagnóstico anatomopatológico em citologia esfoliativa na região buco-maxilo-facial	</td><td>	422	</td></tr>
<tr><td>	81000138	</td><td>	Diagnóstico anatomopatológico em material de biópsia na região buco-maxilo-facial	</td><td>	422	</td></tr>
<tr><td>	81000154	</td><td>	Diagnóstico anatomopatológico em peça cirúrgica na região buco-maxilo-facial	</td><td>	422	</td></tr>
<tr><td>	81000170	</td><td>	Diagnóstico anatomopatológico em punção na região buco-maxilo-facial	</td><td>	422	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	RADIOLOGIA	</td><td>	USO	</th></tr>
<tr><td>	81000278	</td><td>	Fotografia	</td><td>	44	</td></tr>
<tr><td>	81000294	</td><td>	Levantamento Radiográfico (Exame Radiodôntico)	</td><td>	485	</td></tr>
<tr><td>	81000308	</td><td>	Modelos ortodônticos	</td><td>	86	</td></tr>
<tr><td>	81000324	</td><td>	Radiografia antero-posterior	</td><td>	157	</td></tr>
<tr><td>	81000340	</td><td>	Radiografia da ATM	</td><td>	376	</td></tr>
<tr><td>	81000367	</td><td>	Radiografia da mão e punho - carpal	</td><td>	126	</td></tr>
<tr><td>	81000375	</td><td>	Radiografia interproximal - bite-wing	</td><td>	42	</td></tr>
<tr><td>	81000383	</td><td>	Radiografia oclusal  	</td><td>	104	</td></tr>
<tr><td>	81000405	</td><td>	Radiografia panorâmica de mandíbula/maxila (ortopantomografia)  	</td><td>	155	</td></tr>
<tr><td>	81000413	</td><td>	Radiografia panorâmica de mandíbula/maxila (ortopantomografia) com traçado cefalométrico	</td><td>	188	</td></tr>
<tr><td>	81000421	</td><td>	Radiografia periapical	</td><td>	39	</td></tr>
<tr><td>	81000430	</td><td>	Radiografia póstero-anterior	</td><td>	157	</td></tr>
<tr><td>	81000456	</td><td>	Slide	</td><td>	54	</td></tr>
<tr><td>	81000472	</td><td>	Telerradiografia	</td><td>	167	</td></tr>
<tr><td>	81000480	</td><td>	Telerradiografia com traçado cefalométrico	</td><td>	219	</td></tr>
<tr><td>	81000510	</td><td>	Tomografia computadorizada por feixe cônico – cone beam - maxila *	</td><td>	900	</td></tr>
<tr><td>	81000511	</td><td>	Tomografia computadorizada por feixe cônico – cone beam - mandibula*	</td><td>	900	</td></tr>
<tr><td>	81000529	</td><td>	Tomografia convencional -multi direcional - maxila - especificar região	</td><td>	768	</td></tr>
<tr><td>	81000530	</td><td>	Tomografia convencional –  multi-direcional - mandibula - especificar região	</td><td>	768	</td></tr>
<tr><td>	81000537	</td><td>	Traçado Cefalométrico	</td><td>	61	</td></tr>
<tr><td>	00000330	</td><td>	Seio Frontal - código diferenciado para aumento de cobertura	</td><td>	144	</td></tr>
<tr><td>	00000340	</td><td>	Seio Nasal - código diferenciado para aumento de cobertura	</td><td>	144	</td></tr>
<tr><td>	00000345	</td><td>	Documentação Ortodôntica "A" (radiografia panorâmica, telerradiografia, 01 traçado cefalométrico, 05 fotos e 05 slides (frente, perfil e intrabucais), modelo de estudo superior e inferior)	</td><td>	685	</td></tr>
<tr><td>	00000346	</td><td>	Documentação Ortodôntica "B" (radiografia panorâmica, telerradiografia, 01 traçado cefalométrico, 05 fotos (frente, perfil e intrabucais), modelo de estudo superior e inferior)	</td><td>	622	</td></tr>
<tr><td>	00000348	</td><td>	Documentação Ortodôntica "E" (radiografia panorâmica, telerradiografia, 01 traçado cefalométrico, 02 fotos (frente e perfil), modelo de estudo superior e inferior)	</td><td>	482	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	PREVENÇÃO	</td><td>	USO	</th></tr>
<tr><td>	84000090	</td><td>	Aplicação tópica de flúor	</td><td>	192	</td></tr>
<tr><td>	84000139	</td><td>	Atividade educativa em saúde bucal	</td><td>	114	</td></tr>
<tr><td>	84000163	</td><td>	Controle de biofilme (placa bacteriana)	</td><td>	45	</td></tr>
<tr><td>	84000198	</td><td>	Profilaxia: polimento coronário	</td><td>	69	</td></tr>
<tr><td>	85300055	</td><td>	Remoção dos fatores de retenção do Biofilme Dental (Placa Bacteriana)	</td><td>	62	</td></tr>
<tr><td>	87000016	</td><td>	Atividade educativa em odontologia para pais e/ou cuidadores de pacientes com necessidades especiais	</td><td>	107	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ODONTOPEDIATRIA	</td><td>	USO	</th></tr>
<tr><td>	81000014	</td><td>	Condicionamento em Odontologia	</td><td>	138	</td></tr>
<tr><td>	82000700	</td><td>	Estabilização de paciente por meio de contenção física e/ou mecânica*	</td><td>	400	</td></tr>
<tr><td>	83000020	</td><td>	Coroa de acetato em dente decíduo	</td><td>	318	</td></tr>
<tr><td>	83000046	</td><td>	Coroa de aço em dente decíduo	</td><td>	318	</td></tr>
<tr><td>	83000062	</td><td>	Coroa de policarbonato em dente decíduo	</td><td>	318	</td></tr>
<tr><td>	83000089	</td><td>	Exodontia simples de decíduo	</td><td>	161	</td></tr>
<tr><td>	83000097	</td><td>	Mantenedor de espaço fixo	</td><td>	1406	</td></tr>
<tr><td>	83000100	</td><td>	Mantenedor de espaço removível	</td><td>	1406	</td></tr>
<tr><td>	83000127	</td><td>	Pulpotomia em dente decíduo	</td><td>	207	</td></tr>
<tr><td>	83000135	</td><td>	Restauração atraumática em dente decíduo	</td><td>	294	</td></tr>
<tr><td>	83000151	</td><td>	Tratamento endodôntico em dente decíduo	</td><td>	421	</td></tr>
<tr><td>	84000031	</td><td>	Aplicação de cariostático	</td><td>	123	</td></tr>
<tr><td>	84000058	</td><td>	Aplicação de selante - técnica invasiva	</td><td>	98	</td></tr>
<tr><td>	84000074	</td><td>	Aplicação de selante de fóssulas e fissuras	</td><td>	104	</td></tr>
<tr><td>	84000112	</td><td>	Aplicação tópica de verniz fluoretado	</td><td>	145	</td></tr>
<tr><td>	84000171	</td><td>	Controle de cárie incipiente	</td><td>	600	</td></tr>
<tr><td>	84000201	</td><td>	Remineralização	</td><td>	89	</td></tr>
<tr><td>	85100137	</td><td>	Restauração em ionômero de vidro - 1 face	</td><td>	121	</td></tr>
<tr><td>	85100145	</td><td>	Restauração em ionômero de vidro - 2 faces	</td><td>	179	</td></tr>
<tr><td>	85100153	</td><td>	Restauração em ionômero de vidro - 3 faces	</td><td>	243	</td></tr>
<tr><td>	85100161	</td><td>	Restauração em ionômero de vidro - 4 faces	</td><td>	243	</td></tr>
<tr><td>	85200042	</td><td>	Pulpotomia	</td><td>	207	</td></tr>
<tr><td>	87000032	</td><td>	Condicionamento em odontologia para pacientes com necessidades especiais	</td><td>	138	</td></tr>
<tr><td>	87000040	</td><td>	Coroa de acetato em dente permanente	</td><td>	318	</td></tr>
<tr><td>	87000059	</td><td>	Coroa de aço em dente permanente	</td><td>	318	</td></tr>
<tr><td>	87000148	</td><td>	Estabilização por meio de contenção física e/ou mecânica em pacientes com necessidades especias em odontologia	</td><td>	400	</td></tr>
<tr><td>	00000655	</td><td>	Escavação em massa c/ ionomêro de vidro restaurador (por elemento)	</td><td>	122	</td></tr>
<tr><td>	00000660	</td><td>	Adequação do meio bucal c/ ionômero de vidro (por elemento)	</td><td>	30	</td></tr>
<tr><td>	00000670	</td><td>	Adequação meio bucal c/ IRM (por elemento)	</td><td>	25	</td></tr>
<tr><td>	00000795	</td><td>	Supervisão de manutenção de saúde bucal na odontopediatria (até 12 anos)	</td><td>	344	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	DENTISTICA	</td><td>	USO	</th></tr>
<tr><td>	85100021	</td><td>	Clareamento dentário caseiro	</td><td>	1875	</td></tr>
<tr><td>	85100030	</td><td>	Clareamento dentário de consultório	</td><td>	763	</td></tr>
<tr><td>	85100031	</td><td>	Clareamento a laser ( S* )	</td><td>	5000	</td></tr>
<tr><td>	85100032	</td><td>	Complemento de Clareamento a laser  ( S* )	</td><td>	1670	</td></tr>
<tr><td>	85100064	</td><td>	Faceta direta em resina fotopolimerizável	</td><td>	342	</td></tr>
<tr><td>	85100072	</td><td>	Placa de Acetato para Clareamento Caseiro	</td><td>	131	</td></tr>
<tr><td>	85100080	</td><td>	Restauração atraumática em dente permanente	</td><td>	260	</td></tr>
<tr><td>	85100099	</td><td>	Restauração de amálgama  - 1 face	</td><td>	103	</td></tr>
<tr><td>	85100102	</td><td>	Restauração de amálgama - 2 faces	</td><td>	153	</td></tr>
<tr><td>	85100110	</td><td>	Restauração de amálgama - 3 faces	</td><td>	199	</td></tr>
<tr><td>	85100129	</td><td>	Restauração de amálgama - 4 faces	</td><td>	208	</td></tr>
<tr><td>	85100170	</td><td>	Restauração em resina (indireta) - Inlay	</td><td>	2200	</td></tr>
<tr><td>	85100188	</td><td>	Restauração em resina (indireta) - Onlay	</td><td>	2200	</td></tr>
<tr><td>	85100196	</td><td>	Restauração em resina fotopolimerizável  1 face	</td><td>	110	</td></tr>
<tr><td>	85100200	</td><td>	Restauração em resina fotopolimerizável  2 faces	</td><td>	163	</td></tr>
<tr><td>	85100218	</td><td>	Restauração em resina fotopolimerizável  3 faces	</td><td>	221	</td></tr>
<tr><td>	85400262	</td><td>	Pino pré fabricado	</td><td>	213	</td></tr>
<tr><td>	00000911	</td><td>	Restauraçao superficie radicular	</td><td>	110	</td></tr>
<tr><td>	00000995	</td><td>	Faceta em resina estética - cosmética	</td><td>	890	</td></tr>
<tr><td>	00000996	</td><td>	Reconstrução resina  direta estética - cosmética	</td><td>	1050	</td></tr>
<tr><td>	00001011	</td><td>	Restauração resina estética 1 face	</td><td>	292	</td></tr>
<tr><td>	00001012	</td><td>	Restauração resina estética 2 faces	</td><td>	341	</td></tr>
<tr><td>	00001013	</td><td>	Restauração resina estética 3 faces	</td><td>	444	</td></tr>
<tr><td>	00001040	</td><td>	Pino Fibra Estético	</td><td>	585	</td></tr>

    </tbody>
  
        </table>
        </div>
        <div class="paginacao"> <strong>1</strong> 
          <a href="<?= site_url("tabeladeatos2013/2")?>">2</a> 
          <a href="<?= site_url("tabeladeatos2013/3")?>">3</a> 
        </div>
     </div>
    <div class="conteudo-right">
          <? include("lateral_view.php"); ?>
  </div>
      <? include("footer_view.php"); ?>