<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('fale_conosco') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<h1><?= $this->lang->line('fale_conosco') ?></h1>

	<? if($this->session->flashdata('msg')){ ?>
    <?= '<div class="message">'. $this->session->flashdata('msg').'</div>' ?>
    <? } ?>	
	<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
	jQuery(function($){
		$(".data").mask("99/99/9999");
		$(".tel").mask("(99) 9999-9999");
		
		});
	
	$(document).ready(function(){
	$("#ncartao").val("");
	$("#numeroCartaoLabel").hide();
	$("#cliente").click(function(){
		if ($(this).is(":checked")){
			$("#numeroCartao").show();
			$("#ncartao").val("");
			} else {
				$("#numeroCartao").hide();
				$("#ncartao").val("");
				}
		});
	$("#naocliente").click(function(){
		if ($(this).is(":checked")){
			$("#ncartao").val("N&atilde;o h&aacute;.");
			$("#numeroCartao").hide();
			}
		});
	}); 
	
	function enviarContato(){
	$("#status").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Enviando por favor aguarde...");
	var dados = jQuery("#form").serialize();

			jQuery.ajax({
				type: "POST",
				url: "<?=site_url("contato")?>",
				data: dados,
				success: function( data )
				{
					var obj = eval ("(" + data + ")"); 
					$("#status").html(obj.msg);
					$("#captcha").attr("src",obj.captcha);
					
				}
		});
	}		
    </script>
<div class="contato">
    	<form method="post" id="form" name="form"/>
        	<label><?= $this->lang->line('nome') ?></label>
            <input type="text" title="Informe seu nome" name="nome" id="nome">
            <label><?= $this->lang->line('email') ?></label>
            <input type="text" title="Informe seu email" name="email" id="email">
            <label><?= $this->lang->line('telefone') ?></label>
            <input type="text" title="Informe seu telefone" name="telefone" id="telefone" class="tel">
            <label><?= $this->lang->line('cliente_uniodonto') ?></label>
            <label>
                <?= $this->lang->line('sim') ?>
                <input type="radio" name="cliente" value="Sim" id="cliente">
                <?= $this->lang->line('nao') ?>
                <input type="radio" name="cliente" value="Não" id="naocliente" checked>
            </label>
            <div style="display:none;" id="numeroCartao">
            	<label><?= $this->lang->line('numero_do_cartao_uniodonto') ?></label>
        		<input type="text" name="ncartao" id="ncartao" >
            </div>
            <label><?= $this->lang->line('mensagem') ?></label>
            <textarea name="msg"></textarea>
            <div class="bts-form">
            <label><?= $this->lang->line('digite_o_codigo_verificador') ?></label>
            <img id="captcha" src="<?= $captcha['src']?>" border="0" style="margin:5px 3px 0px 3px;" />
            <input type="text" name="captcha" style="width:170px;">
            </div>
            <div class="bts-form">
	            <span>
	            	<input type="button" value="<?= $this->lang->line('enviar') ?>"  name="Enviar" class="btn-submit" onclick="enviarContato()" >
	            </span>
	            <span id="status">

	            </span>
            </div>
        </form>
        
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>