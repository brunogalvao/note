<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('revistas') ?>
</div>

<div class="conteudo-left">
    <? foreach($revistas['rows'] as $revista){ ?>  
    	<div class="revista">
    		<a href="<?=site_url("site/ver_revista/".$revista->revista_id)?>" target="_blank">
    		<h2><?=$revista->revista_titulo?></h2>
    		<img src="<?=site_url().$revista->revista_capa?>" border="0" />
    		</a>
    	</div>
    <? } ?>	
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>

