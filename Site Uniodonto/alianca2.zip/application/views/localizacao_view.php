<? include("header_view.php"); ?>
<script type="text/javascript">
		$(document).ready(function() {
			$('.fancybox').fancybox({
				'type':'iframe',
				'scrolling' : 'false',
				'preload'  : true,
				'width':720

				
			});
			

		});
	</script>
    <style>
    .fancybox-outer{
		background: #fff;
		}
	.fancybox-close{
		margin: 25px 35px;
		}
    </style>

<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('localizacao') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
    <? foreach($localizacao as $local){?>
		<div class="local">
            <span>
                <h1><?= $local['localizacao_titulo_'.$this->session->userdata("idioma")] ?></h1>
                <p><?= $local['localizacao_tel_'.$this->session->userdata("idioma")] ?></p>
                <p><?= $local['localizacao_endereco_'.$this->session->userdata("idioma")] ?></p>
                <a class="fancybox fancybox.iframe" href="<?=site_url('site/mapa?mapa='.$local['localizacao_mapa'])?>"><?= $this->lang->line('como_chegar') ?></a>
            </span>

		</div>
	<? } ?>
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>