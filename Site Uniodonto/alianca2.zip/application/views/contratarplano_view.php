<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('proposta_de_adesao') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
<? if(isset($msg)){ ?>
     <div class="message"><?= $msg?></div> 
<? } ?>
<h1><?= $this->lang->line('proposta_adesao') ?></h1>
		
    <div class="texto">
    <?= $this->lang->line('adesao').$nome_plano?></strong>. </p>
      <p>&nbsp;</p>
    
      <? if($plano_tipo == 1){ ?>
      <p><?= $this->lang->line('adesao_superior') ?></p>
      <? } if($plano_tipo == 2){ ?>
      <p><?= $this->lang->line('adesao_avancado') ?></p>
      <? } ?>
      <p>&nbsp;</p>
      <?= $this->lang->line('adesao_valor1').$valor_por_pessoa?>
	  <?= $this->lang->line('adesao_valor2').$valor_total?>
	  <?= $this->lang->line('adesao_valor3')?>
    </div>

	
<script>
		$(document).ready(function(){

			$("#form").validationEngine();

		});
		
</script>    
<div class="formulario">
      	<form action="<?=site_url("contratar_plano")?>" method="post" id="form" enctype="multipart/form-data" class="jqtransform">
			<h2><?= $this->lang->line('dados_pessoais_do_titular_do_contrato') ?></h2>
		    <span style="display: inline-block;">
		     <label>
		       <?= $this->lang->line('nome') ?><br>
		       <input size="27" id="nome" class="validate[required]" name="nome" type="text">
		       </label>
			</span>
			<span style="display: inline-block;">
		     <label>
		       <?= $this->lang->line('sexo') ?><br>
		       <input style="border: medium none;" name="sexo" id="sexo" value="Masculino" checked="checked" type="radio">M
		       <input style="border: medium none;" name="sexo" id="sexo" value="Feminino" type="radio">F
	        </label>
			</span>
			<span style="display: inline-block;">
		     <label>
		       <?= $this->lang->line('data_de_Nascimento') ?><br>
		       <input size="27" id="dataNascimento" class="validate[required] data" name="dataNascimento" type="text">
	        </label>
			</span>
			<span style="display: inline-block;">
		     <label>
		       <?= $this->lang->line('estado_civil') ?><br>
		       <select id="estadoCivil" name="estadoCivil" class="validate[required]">
		         <option value="Solteiro(a)"><?= $this->lang->line('solteiro') ?></option>
		         <option value="Casado(a)"><?= $this->lang->line('casado') ?></option>
		         <option value="Separado(a)"><?= $this->lang->line('separado') ?></option>
		         <option value="Divorciado(a)"><?= $this->lang->line('divorciado') ?></option>
		         <option value="Vi&uacute;vo(a)"><?= $this->lang->line('viuvo') ?></option>
               </select>
	        </label>
			</span>

		    <h2><?= $this->lang->line('endereco') ?></h2>
		    <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('tipo_de_endereco') ?><br>
		        <select id="tipoEndereco" name="tipoEndereco" class="validate[required]">
		          <option value="Rua" selected="selected"><?= $this->lang->line('rua') ?></option>
		          <option value="Avenida"><?= $this->lang->line('avenida') ?></option>
		          <option value="Alameda"><?= $this->lang->line('alameda') ?></option>
		          <option value="Pra&ccedil;a"><?= $this->lang->line('praca') ?></option>
		          <option value="Rodovia"><?= $this->lang->line('rodovia') ?></option>
		          <option value="Travessa"><?= $this->lang->line('travessa') ?></option>
		          </select>
	        </label>
       		</span>
            <span style="display: inline-block;">         
	        <label>
		        <?= $this->lang->line('endereco') ?><br>
		        <input size="50" id="endereco" class="validate[required]" name="endereco" type="text">
		        </label>
        	</span>
            <span style="display: inline-block;">    
	        <label>
		        <?= $this->lang->line('bairro') ?><br>
		        <input size="27" id="bairro" class="validate[required]" name="bairro" type="text">
		        </label>
           	</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('cidade') ?><br>
		        <input size="27" id="cidade" class="validate[required]" name="cidade" type="text">
		        </label>
            </span>
            <span style="display: inline-block;">    
	        <label>
		        <?= $this->lang->line('estado') ?><br>
		        <select id="estado" name="estado" class="validate[required]">
		            <option value="AC">AC</option>
					<option value="AL">AL</option>
					<option value="AM">AM</option>
					<option value="AP">AP</option>
					<option value="BA">BA</option>
					<option value="CE">CE</option>
					<option value="DF">DF</option>
					<option value="ES">ES</option>
					<option value="GO">GO</option>
					<option value="MA">MA</option>
					<option value="MG">MG</option>
					<option value="MS">MS</option>
					<option value="MT">MT</option>
					<option value="PA">PA</option>
					<option value="PB">PB</option>
					<option value="PE">PE</option>
					<option value="PI">PI</option>
					<option value="PR" selected="selected">PR</option>
					<option value="RJ">RJ</option>
					<option value="RN">RN</option>
					<option value="RO">RO</option>
					<option value="RR">RR</option>
					<option value="RS">RS</option>
					<option value="SC">SC</option>
					<option value="SE">SE</option>
					<option value="SP">SP</option>
					<option value="TO">TO</option>
		          </select>
		        </label>
           	</span>
            <span style="display: inline-block;">   
	        <label>
		        <?= $this->lang->line('cep') ?><br>
		        <input size="27" id="cep" class="validate[required] cep" name="cep" type="text">
		        </label>
		    </span>


		    <h2><?= $this->lang->line('contato') ?></h2>

            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('telefone_residencial') ?><br>
		        <input size="27" id="telefoneResidencial" class="validate[required] tel" name="telefoneResidencial" type="text">
	          </label>
         	</span>
            <span style="display: inline-block;">
		       <label>
		       <?= $this->lang->line('celular') ?><br>
		       <input size="27" id="celular" class="validate[required] tel" name="celular" type="text">
		       </label>
           	</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('telefone_de_recado') ?><br>
		        <input size="27" id="telefoneRecado" class="validate[required] tel" name="telefoneRecado" type="text">
	          </label>
        	</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('falar_com') ?><br>
		        <input size="27" id="falarCom" class="validate[required]" name="falarCom" type="text">
	          </label>
       		</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('email') ?><br>
		        <input size="50" id="email" class="validate[required]" name="email" type="text">
	          </label>
	      	</span>

		    <h2><?= $this->lang->line('documentacao') ?></h2>
		    <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('rg') ?><br>
		        <input size="27" id="rg" class="validate[required]" name="rg" type="text">
	          </label>
          	</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('orgao_expedidor') ?><br>
		        <input size="27" id="orgao-rg" class="validate[required]" name="orgao-rg" type="text">
	          </label>
          	</span>
            <span style="display: inline-block;">
		     <label>
		       <?= $this->lang->line('data_expedicao_rg') ?><br>
		       <input size="27" id="data-rg" class="validate[required] data" name="data-rg" type="text">
	        </label>
			</span>
            <span style="display: inline-block;">    
		      <label>
		        <?= $this->lang->line('cpf') ?><br>
		        <input size="27" id="cpf" class="validate[required] cpf" name="cpf" type="text">
	          </label>
        	</span>


		    <h2><?= $this->lang->line('escolaridade') ?></h2>
		    <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('nivel') ?><br>
		        <select id="nivelEscolaridade" name="nivelEscolaridade" class="validate[required]">
		          <option value="Fundamental" selected="selected"><?= $this->lang->line('fundamental') ?></option>
		          <option value="M&eacute;dio"><?= $this->lang->line('medio') ?></option>
		          <option value="Superior"><?= $this->lang->line('superior') ?></option>
		          <option value="P&oacute;s Gradua&ccedil;&atilde;o"><?= $this->lang->line('pos_graduacao') ?></option>
		          <option value="Mestrado"><?= $this->lang->line('mestrado') ?></option>
		          <option value="Doutorado"><?= $this->lang->line('doutorado') ?></option>
		          <option value="P&oacute;s Doutorado"><?= $this->lang->line('pos_doutorado') ?></option>
                </select>
	          </label>
        	</span> 
            <h2><?= $this->lang->line('nome_completo_da_mae_do_titular_do_contrato') ?></h2>
		    <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('nome') ?><br>
		        <input size="100" id="nome-mae" class="validate[required]" name="nome-mae" type="text" style="width:610px;">
	          </label>
          	</span>
            <h2><?= $this->lang->line('dados_comerciais_do_titular_responsavel') ?></h2>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('empresa') ?><br>
		        <input size="100" id="rg" class="validate[required]" name="empresa-comercial" type="text" style="width:410px;">
	          </label>
          	</span>
            
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('autonomo') ?><br>
            	
                <?= $this->lang->line('nao') ?>
                <input type="radio" value="N&atilde;o" name="autonomo">
                <?= $this->lang->line('sim') ?>
                <input type="radio" value="Sim" name="autonomo">
                
              </label>
          	</span>   
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('tipo_de_endereco') ?><br>
		        <select id="tipoEndereco-comercial" name="tipoEndereco-comercial" class="validate[required]">
		          <option value="Rua" selected="selected"><?= $this->lang->line('rua') ?></option>
		          <option value="Avenida"><?= $this->lang->line('avenida') ?></option>
		          <option value="Alameda"><?= $this->lang->line('alameda') ?></option>
		          <option value="Pra&ccedil;a"><?= $this->lang->line('praca') ?></option>
		          <option value="Rodovia"><?= $this->lang->line('rodovia') ?></option>
		          <option value="Travessa"><?= $this->lang->line('travessa') ?></option>
		          </select>
	        </label>
       		</span>
            <span style="display: inline-block;">         
	        <label>
		        <?= $this->lang->line('endereco') ?><br>
		        <input size="50" id="endereco-comercial" class="validate[required]" name="endereco-comercial" type="text">
		        </label>
        	</span>
            <span style="display: inline-block;">    
	        <label>
		        <?= $this->lang->line('bairro') ?><br>
		        <input size="27" id="bairro-comercial" class="validate[required]" name="bairro-comercial" type="text">
		        </label>
           	</span>
            <span style="display: inline-block;">
		      <label>
		        <?= $this->lang->line('cidade') ?><br>
		        <input size="27" id="cidade-comercial" class="validate[required]" name="cidade-comercial" type="text">
		        </label>
            </span>
            <span style="display: inline-block;">    
	        <label>
		        <?= $this->lang->line('estado') ?><br>
		        <select id="estado-comercial" name="estado-comercial" class="validate[required]">
		            <option value="AC">AC</option>
					<option value="AL">AL</option>
					<option value="AM">AM</option>
					<option value="AP">AP</option>
					<option value="BA">BA</option>
					<option value="CE">CE</option>
					<option value="DF">DF</option>
					<option value="ES">ES</option>
					<option value="GO">GO</option>
					<option value="MA">MA</option>
					<option value="MG">MG</option>
					<option value="MS">MS</option>
					<option value="MT">MT</option>
					<option value="PA">PA</option>
					<option value="PB">PB</option>
					<option value="PE">PE</option>
					<option value="PI">PI</option>
					<option value="PR" selected="selected">PR</option>
					<option value="RJ">RJ</option>
					<option value="RN">RN</option>
					<option value="RO">RO</option>
					<option value="RR">RR</option>
					<option value="RS">RS</option>
					<option value="SC">SC</option>
					<option value="SE">SE</option>
					<option value="SP">SP</option>
					<option value="TO">TO</option>
		          </select>
		        </label>
           	</span>
            <span style="display: inline-block;">   
	        <label>
		        <?= $this->lang->line('cep') ?><br>
		        <input size="27" id="cep-comercial" class="validate[required] cep" name="cep-comercial" type="text">
		        </label>
		    </span>
            <span style="display: inline-block;">
		       <label>
		       <?= $this->lang->line('telefone') ?><br>
		       <input size="27" id="telefone-comercial" class="validate[required] tel" name="telefone-comercial" type="text">
		       </label>
           	</span>
            <span style="display: inline-block;">
		       <label>
		       <?= $this->lang->line('cargo') ?><br>
		       <input size="27" id="cargo-comercial" class="validate[required]" name="cargo-comercial" type="text">
		       </label>
           	</span>
            <span style="display: inline-block;">
		       <label>
		       <?= $this->lang->line('renda_familiar') ?><br>
		       <input size="27" id="renda-comercial" class="validate[required]" name="renda-comercial" type="text">
		       </label>
           	</span>
            <span style="display: inline-block;">    
	        <label>
		        <?= $this->lang->line('vinculo_empregaticio') ?><br>
		        	<select id="vinculo-comercial" name="vinculo-comercial" class="validate[required]">
		              <option value="Empregado"><?= $this->lang->line('empregado') ?></option>
                      <option value="Contratado"><?= $this->lang->line('contratado') ?></option>
                      <option value="Estagi&aacute;rio"><?= $this->lang->line('estagiario') ?></option>
                      <option value="Outros"><?= $this->lang->line('outros') ?></option>
					</select>
		        </label>
           	</span>
            <? for ($i = 2; $i <= $plano_qtd; $i++){?>
            <h2><?= $this->lang->line('informacoes_do_beneficiario_dependente') ?></h2>
            <span style="display: inline-block;">  
                <label>
                <?= $this->lang->line('nome') ?><br>
                <input name="dependente<?= $i?>_nome" class="validate[required]" style="width:450px;" type="text">
                </label>
            </span> 
            <span style="display: inline-block;">     
                <label>
                <?= $this->lang->line('data_de_Nascimento') ?><br>
                <input name="dependente<?= $i?>_data_nascimento" class="validate[required] data" style="width:130px;" type="text">
                </label>
            </span> 
            <span style="display: inline-block;">
                <label>
                <?= $this->lang->line('cpf') ?><br>
                <input name="dependente<?= $i?>_cpf" class="validate[required] cpf" style="width:120px;" type="text">
                </label>
            </span> 
            <span style="display: inline-block;">
                <label>
                <?= $this->lang->line('rg') ?><br>
                <input name="dependente<?= $i?>_rg" class="validate[required]" style="width:120px;" type="text">
                </label>
            </span> 
            <span style="display: inline-block;">
                 <label><?= $this->lang->line('orgao_expedidor') ?><br>
                    <input name="dependente<?= $i?>_orgao_expedidor" style="width:120px;" class="validate[required]" type="text">
                </label>
            </span> 
            <span style="display: inline-block;">
                <label><?= $this->lang->line('data_expedicao_rg') ?><br>
                    <input name="dependente<?= $i?>_data_expedicao" style="width:120px;" class="validate[required] data" type="text">
                </label>
           	</span> 
            <span style="display: inline-block;">
                <label><?= $this->lang->line('estado_civil') ?><br>
                <select name="dependente<?= $i?>_estado_civil" class="validate[required]">
                  <option value="Solteiro(a)"><?= $this->lang->line('solteiro') ?></option>
		         <option value="Casado(a)"><?= $this->lang->line('casado') ?></option>
		         <option value="Separado(a)"><?= $this->lang->line('separado') ?></option>
		         <option value="Divorciado(a)"><?= $this->lang->line('divorciado') ?></option>
		         <option value="Vi&uacute;vo(a)"><?= $this->lang->line('viuvo') ?></option>
                </select>
                </label>
            </span> 
            <span style="display: inline-block;">
                <label><?= $this->lang->line('grau_de_parentesco') ?><br>
                <select name="dependente<?= $i?>_parentesco" class="validate[required]">
                  <option value="C&ocirc;njuge"><?= $this->lang->line('conjugue') ?></option>
                  <option value="Filho"><?= $this->lang->line('filho') ?></option>
                  <option value="Filha"><?= $this->lang->line('filha') ?></option>
                  <option value="Pai"><?= $this->lang->line('pai') ?></option>
                  <option value="M&atilde;e"><?= $this->lang->line('mae') ?></option>
                  <option value="Agregado"><?= $this->lang->line('agregado') ?></option>
                  <option value="Outro"><?= $this->lang->line('outros') ?></option>
                </select>
                </label>
            </span> 
            <span style="display: inline-block;">
                <label><?= $this->lang->line('sexo') ?><br>
                <select name="dependente<?= $i?>_sexo" class="validate[required]">
                  <option value="Masculino"><?= $this->lang->line('masculino') ?></option>
                  <option value="Feminino"><?= $this->lang->line('feminino') ?></option>
                </select>
                </label>
            </span> 
            <span style="display: inline-block;">
                <label><?= $this->lang->line('nome_completo_da_mae') ?><br>
                    <input name="dependente<?= $i?>_mae" style="width:600px;" class="validate[required]" type="text">
                </label>
            </span> 
			<? } ?>	
			<input type="hidden" name="envia" value="ok">
            <input type="hidden" name="nome_plano" value="<?= $nome_plano?>">
            <input type="hidden" name="valor_por_pessoa" value="<?= $valor_por_pessoa?>">
            <input type="hidden" name="valor_total" value="<?= $valor_total?>">
            <input type="hidden" name="plano_qtd" value="<?= $plano_qtd?>">
            <input type="hidden" name="plano_tipo" value="<?= $plano_tipo?>">
            
            <div><?= $this->lang->line('e_necessario_ler_o_termo_de_adesao_e_assinalar_o_marcador_abaixo_para_completar_o_envio') ?></div>
            <br />
            <iframe width="620" style="border: 1px solid thin;" src="<?= site_url()?>upload/termos_<?= $this->session->userdata("idioma")?>.html"></iframe>
            <br />
            <div style="margin-top:5px;">
            	<span style="display: inline-block;"><input name="aceiteTermo" value="aceito" type="checkbox" class="validate[required]"></span>
                <span style="display: inline-block; margin-top:7px;"><?= $this->lang->line('eu_li_e_concordo_com_os_termos_descritos_no_termo_de_adesao_de_plano') ?></span>
                
            </div>
            <br />
            
		<div class="campos">
			<input type="submit" value="<?= $this->lang->line('enviar') ?>"  name="Enviar" class="btn-submit" >
	    </div>
		    
  	</form>
 
</div>   
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>