<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('noticias') ?>
</div>
<div class="conteudo-left">
    <div class="resultado-busca">
    <h1><?=$titulo?></h1>
    <div class="resultados">
    	<? foreach($noticias as $noticia){
            $data = explode(" ",$noticia['noticia_data']);
            $data = explode("-",$data[0] );
			if(empty($noticia['noticia_titulo_'.$this->session->userdata("idioma")])){
				$noticia_titulo = utf8_decode($noticia['noticia_titulo_ptBR']);
				}else{
					$noticia_titulo = utf8_decode($noticia['noticia_titulo_'.$this->session->userdata("idioma")]);
					}
            ?>
            
        <a href="<?= site_url()?>noticia/<?=$noticia['noticia_id']?>/<?=str_replace('%','',urlencode($this->formata_nome_model->formataNome($noticia_titulo)))?>" class="historico">
        <h3><?= $data[2]."/".$data[1]."/".$data[0]?></h3>
        <?= $noticia_titulo?>
        </a>
            
        <? } ?>
      </div>  
      <div class="paginacao">
		<?php echo $paginacao; ?>
      </div>  
    </div>  
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>