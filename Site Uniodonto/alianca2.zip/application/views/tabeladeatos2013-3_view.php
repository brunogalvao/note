<? include("header_view.php"); ?>
<script>
$(document).ready(function(){
   $("tr:even").addClass("even");
   $("tr:odd").addClass("odd");
});
</script>
<style>
	.odd {
	   background-color: #fcb9c2; 
	   }
	.odd td {
	   border-bottom: 1px solid #fcb9c2; }
</style>
    <div class="nav"> <a href="<?=site_url()?>">Home</a> / Tabela de Atos </div>
    <div class="conteudo-left">
      <div class="texto">
        <h1>Tabela de Atos - P&aacute;gina 3 de 3</h1>
        <br /><br />
        <table cellpadding="0" cellspacing="0" class="tabela-atos">
          	<tbody>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	CIRURGIA	</td><td>	USO	</th></tr>
<tr><td>	82000034	</td><td>	Alveoloplastia*	</td><td>	316	</td></tr>
<tr><td>	82000050	</td><td>	Amputação radicular com obturação retrograda*	</td><td>	661	</td></tr>
<tr><td>	82000069	</td><td>	Amputação radicular sem obturação retrograda*	</td><td>	635	</td></tr>
<tr><td>	82000077	</td><td>	Apicetomia birradiculares com obturação retrógrada  ( RL** )  (RI**) 	</td><td>	635	</td></tr>
<tr><td>	82000085	</td><td>	Apicetomia birradiculares sem obturação retrógrada ( RL** )  (RI**) 	</td><td>	568	</td></tr>
<tr><td>	82000158	</td><td>	Apicetomia multirradiculares com obturação retrógrada ( RL** )  (RI**)  	</td><td>	770	</td></tr>
<tr><td>	82000166	</td><td>	Apicetomia multirradiculares sem obturação retrógrada ( RL** )  (RI**)  	</td><td>	635	</td></tr>
<tr><td>	82000174	</td><td>	Apicetomia unirradiculares com obturação retrógrada ( RL** )  (RI**) 	</td><td>	568	</td></tr>
<tr><td>	82000182	</td><td>	Apicetomia unirradiculares sem obturação retrógrada ( RL** )  (RI**) 	</td><td>	581	</td></tr>
<tr><td>	82000190	</td><td>	Aprofundamento/aumento de vestíbulo*	</td><td>	375	</td></tr>
<tr><td>	82000239	</td><td>	Biópsia de boca*	</td><td>	305	</td></tr>
<tr><td>	82000247	</td><td>	Biópsia de glândula salivar*	</td><td>	305	</td></tr>
<tr><td>	82000255	</td><td>	Biópsia de lábio*	</td><td>	305	</td></tr>
<tr><td>	82000263	</td><td>	Biópsia de língua *	</td><td>	305	</td></tr>
<tr><td>	82000271	</td><td>	Biópsia de mandíbula*	</td><td>	305	</td></tr>
<tr><td>	82000280	</td><td>	Biópsia de maxila*	</td><td>	305	</td></tr>
<tr><td>	82000298	</td><td>	Bridectomia*	</td><td>	274	</td></tr>
<tr><td>	82000301	</td><td>	Bridotomia*	</td><td>	274	</td></tr>
<tr><td>	82000352	</td><td>	Cirurgia para exostose maxilar*	</td><td>	415	</td></tr>
<tr><td>	82000360	</td><td>	Cirurgia para torus mandibular – bilateral*	</td><td>	749	</td></tr>
<tr><td>	82000387	</td><td>	Cirurgia para torus mandibular – unilateral*	</td><td>	425	</td></tr>
<tr><td>	82000395	</td><td>	Cirurgia para torus palatino*	</td><td>	415	</td></tr>
<tr><td>	82000441	</td><td>	Coleta de raspado em lesões ou sítios específicos da região buco-maxilo-facial  *	</td><td>	305	</td></tr>
<tr><td>	82000506	</td><td>	Controle pós-operatório em odontologia*	</td><td>	306	</td></tr>
<tr><td>	82000581	</td><td>	Enxerto com osso autógeno da linha oblíqua*	</td><td>	5521	</td></tr>
<tr><td>	82000603	</td><td>	Enxerto com osso autógeno do mento*	</td><td>	5521	</td></tr>
<tr><td>	82000743	</td><td>	Exérese de lipoma na região buco-maxilo-facial*	</td><td>	305	</td></tr>
<tr><td>	82000778	</td><td>	Exérese ou excisão de cálculo salivar*	</td><td>	273	</td></tr>
<tr><td>	82000816	</td><td>	Exodontia a retalho*	</td><td>	161	</td></tr>
<tr><td>	82000832	</td><td>	Exodontia de permanente por indicação ortodôntica/protética*	</td><td>	161	</td></tr>
<tr><td>	82000859	</td><td>	Exodontia de raiz residual*	</td><td>	161	</td></tr>
<tr><td>	82000875	</td><td>	Exodontia simples de permanente*	</td><td>	161	</td></tr>
<tr><td>	82000883	</td><td>	Frenulectomia labial*	</td><td>	431	</td></tr>
<tr><td>	82000891	</td><td>	Frenulectomia lingual*	</td><td>	274	</td></tr>
<tr><td>	82000905	</td><td>	Frenulotomia labial*	</td><td>	406	</td></tr>
<tr><td>	82000913	</td><td>	Frenulotomia lingual*	</td><td>	274	</td></tr>
<tr><td>	82001073	</td><td>	Odonto-secção*	</td><td>	140	</td></tr>
<tr><td>	82001103	</td><td>	Punção aspirativa na região buco-maxilo-facial  *	</td><td>	305	</td></tr>
<tr><td>	82001120	</td><td>	Punção aspirativa orientada por imagem na região buco-maxilo-facial*	</td><td>	297	</td></tr>
<tr><td>	82001154	</td><td>	Reconstrução de sulco gengivo-labial*	</td><td>	375	</td></tr>
<tr><td>	82001170	</td><td>	Redução cruenta de fraturas alveolo dentárias*	</td><td>	773	</td></tr>
<tr><td>	82001189	</td><td>	Redução incruenta de fratura alvéolo dentária*	</td><td>	403	</td></tr>
<tr><td>	82001219	</td><td>	Reeducação e/ou reabilitação de distúrbio buco-maxilo-facial*	</td><td>	500	</td></tr>
<tr><td>	82001286	</td><td>	Remoção de dentes inclusos / impactados  (RL* )  ( RI**) 	</td><td>	682	</td></tr>
<tr><td>	82001294	</td><td>	Remoção de dentes semi-inclusos / impactados ( RL* )  ( RI** )	</td><td>	337	</td></tr>
<tr><td>	82001367	</td><td>	Remoção de odontoma*	</td><td>	385	</td></tr>
<tr><td>	82001430	</td><td>	Retirada dos meios de fixação da região buco-maxilo-facial*	</td><td>	2654	</td></tr>
<tr><td>	82001448	</td><td>	Sedação consciente com óxido nitroso e oxigênio em odontologia*	</td><td>	1274	</td></tr>
<tr><td>	82001502	</td><td>	Tracionamento cirúrgico com finalidade ortodôntica*	</td><td>	2229	</td></tr>
<tr><td>	82001510	</td><td>	Tratamento cirúrgico das fístulas buco nasal*	</td><td>	1045	</td></tr>
<tr><td>	82001529	</td><td>	Tratamento cirúrgico das fístulas buco sinusal*	</td><td>	1045	</td></tr>
<tr><td>	82001545	</td><td>	Tratamento cirúrgico de bridas constritivas da região buco-maxilo-facial*	</td><td>	290	</td></tr>
<tr><td>	82001553	</td><td>	Tratamento cirúrgico de hiperplasias de tecidos moles na região buco-maxilo-facial*	</td><td>	323	</td></tr>
<tr><td>	82001588	</td><td>	Tratamento cirúrgico de hiperplasias de tecidos ósseos/cartilaginosos na região buco-maxilo-facial *	</td><td>	632	</td></tr>
<tr><td>	82001596	</td><td>	Tratamento cirúrgico de tumores benignos de tecidos ósseos/cartilaginosos na região buco-maxilo-facial*	</td><td>	632	</td></tr>
<tr><td>	82001618	</td><td>	Tratamento cirúrgico dos tumores benignos de tecidos moles na região buco-maxilo-facial *	</td><td>	323	</td></tr>
<tr><td>	82001634	</td><td>	Tratamento Cirúrgico para tumores odontogênicos benignos – sem reconstrução *	</td><td>	657	</td></tr>
<tr><td>	82001707	</td><td>	Ulectomia*	</td><td>	188	</td></tr>
<tr><td>	82001715	</td><td>	Ulotomia*	</td><td>	138	</td></tr>
<tr><td>	87000164	</td><td>	Sedação consciente com óxido nitroso e oxigênio em pacientes com necessidades especiais em odontologia*	</td><td>	1274	</td></tr>
<tr><td>	00005450	</td><td>	Osteotomia e Osteoplastia de Mandíbula p/ Prognatismo*	</td><td>	25832	</td></tr>
<tr><td>	00005455	</td><td>	Artroplastia de ATM*	</td><td>	25832	</td></tr>
<tr><td>	00005460	</td><td>	Osteotomia e Osteoplastia de Mandíbula p/ Micrognatismo*	</td><td>	25832	</td></tr>
<tr><td>	00005470	</td><td>	Osteotomia e Osteoplastia de Mandíbula p/ Laterognatismo*	</td><td>	25832	</td></tr>
<tr><td>	00005475	</td><td>	Mentoplastia*	</td><td>	25832	</td></tr>
<tr><td>	00005480	</td><td>	Osteotomia/Osteoplastia maxila tipo LE fort I*	</td><td>	25832	</td></tr>
<tr><td>	00005490	</td><td>	Osteotomia/Osteoplastia maxila tipo LE fort II*	</td><td>	31000	</td></tr>
<tr><td>	00005500	</td><td>	Osteotomia/Osteoplastia maxila tipo LE fort III*	</td><td>	40185	</td></tr>
<tr><td>	00005530	</td><td>	Sulcoplastia p/arcada c/remoção de hiperplasia / Reconstrução sulco gengivo labial*	</td><td>	736	</td></tr>
<tr><td>	00005830	</td><td>	Correção de brida muscular*	</td><td>	274	</td></tr>
<tr><td>	00005840	</td><td>	Alveolotomia (por hemi arcada)*	</td><td>	283	</td></tr>
<tr><td>	00005850	</td><td>	Cirurgia para correção de tuberosidade*	</td><td>	455	</td></tr>
<tr><td>	00005870	</td><td>	Curetagem apical (cirurgia de granuloma e cisto)*	</td><td>	306	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ORTOUNIPLAN A	</td><td>	USO	</th></tr>
<tr><td>	00006220	</td><td>	Contenção móvel (superior ou inferior), ou aparelhos móveis simples 	</td><td>	1757	</td></tr>
<tr><td>	00006225	</td><td>	Tratamento ortodôntico parcial	</td><td>	2866	</td></tr>
<tr><td>	00006226	</td><td>	Manutenção tratamento ortodôntico parcial	</td><td>	374	</td></tr>
<tr><td>	00006229	</td><td>	Manutenção ortodôntica	</td><td>	665	</td></tr>
<tr><td>	00006231	</td><td>	Tratamento ortodôntico corretivo I	</td><td>	4801	</td></tr>
<tr><td>	00006236	</td><td>	Tratamento ortodôntico corretivo II	</td><td>	6515	</td></tr>

<tr><td>	00006239	</td><td>	Dispositivos auxiliares	</td><td>	2726	</td></tr>
<tr><td>	00006240	</td><td>	Supervisão pós tratamento ortodôntico fixo	</td><td>	250	</td></tr>
<tr><td>	00006245	</td><td>	Conserto de aparelho móvel	</td><td>	1319	</td></tr>
<tr><td>	00006257	</td><td>	Reposição braquetes ou bandas	</td><td>	80	</td></tr>
<tr><td>	00006258	</td><td>	Esplintagem com brakets ortodônticos	</td><td>	1746	</td></tr>
<tr><td>	00006260	</td><td>	Estudo/ acompanhamento ortodontico 	</td><td>	265	</td></tr>
<tr><td>	00006288	</td><td>	Contenção antero-inferior 3X3 	</td><td>	690	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ORTOUNIPLAN B	</td><td>	USO	</th></tr>
<tr><td>	00008310	</td><td>	12 meses	</td><td>	1721	</td></tr>
<tr><td>		</td><td>	18 meses	</td><td>	1148	</td></tr>
<tr><td>		</td><td>	24 meses	</td><td>	861	</td></tr>
<tr><td>		</td><td>	36 meses	</td><td>	573	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ORTOUNIPLAN E	</td><td>	USO	</th></tr>
<tr><td>	00006150	</td><td>	Ortouniplan E 	</td><td>	482	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ORTOUNIPLAN 	</td><td>	USO	</th></tr>
<tr><td>	00007300	</td><td>	Documentação ortodontica - ortouniplan	</td><td>	458	</td></tr>
<tr><td>	00007310	</td><td>	Manutenção ortodontica - ortouniplan	</td><td>	458	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	TRATAMENTO ORTOPÉDICO FUNCIONAL DOS MAXILARES	</td><td>	USO	</th></tr>
<tr><td>	86000551	</td><td>	Plano inclinado	</td><td>	942	</td></tr>
<tr><td>	00008510	</td><td>	Manutenção Aparelho Ortopédico Funcional	</td><td>	636	</td></tr>
<tr><td>	00008520	</td><td>	Tratamento Ortopédico Funcional (36 meses)	</td><td>	609	</td></tr>
<tr><td>	00008530	</td><td>	Monitoramento Ortopédico Funcional	</td><td>	388	</td></tr>
<tr><td>	00008540	</td><td>	Pista Direta Planas	</td><td>	1689	</td></tr>
<tr><td>	00008550	</td><td>	Conserto Aparelho Ortopédico Funcional	</td><td>	721	</td></tr>
<tr><td>	00008560	</td><td>	Montagem em Gnatostato (modelo de estudo - par montado em gnatostato)	</td><td>	572	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	DISFUNÇAO TEMPORO-MANDIBULAR (DTM)	</td><td>	USO	</th></tr>
<tr><td>	85400246	</td><td>	Órtese miorrelaxante	</td><td>	1242	</td></tr>
<tr><td>	85400254	</td><td>	Órtese reposicionadora 	</td><td>	1242	</td></tr>
<tr><td>	86000595	</td><td>	Artroscopia de atm	</td><td>	3000	</td></tr>
<tr><td>	86000596	</td><td>	Dispositivo reposicionador	</td><td>	2000	</td></tr>
<tr><td>	86000597	</td><td>	Dispositivo descompressor	</td><td>	2000	</td></tr>
<tr><td>	86000598	</td><td>	Infiltração anestesica	</td><td>	2000	</td></tr>
<tr><td>	86000599	</td><td>	Infiltração medicamentosa	</td><td>	2000	</td></tr>
<tr><td>	86000600	</td><td>	Eletromiografia	</td><td>	2000	</td></tr>
<tr><td>	86000601	</td><td>	Manutencão de dispositivo inter oclusal	</td><td>	400	</td></tr>
<tr><td>	86000602	</td><td>	Tratamento de DTM - acupuntura - sessão	</td><td>	400	</td></tr>
<td>	85100196	</td><td>	Restauração em resina fotopolimerizável  1 face	</td><td>	110	</td></tr>
<tr><td>	85100200	</td><td>	Restauração em resina fotopolimerizável  2 faces	</td><td>	163	</td></tr>
<tr><td>	85100218	</td><td>	Restauração em resina fotopolimerizável  3 faces	</td><td>	221	</td></tr>
<tr><td>	85400262	</td><td>	Pino pré fabricado	</td><td>	213	</td></tr>
<tr><td>	00000911	</td><td>	Restauraçao superficie radicular	</td><td>	110	</td></tr>
<tr><td>	00000995	</td><td>	Faceta em resina estética - cosmética	</td><td>	890	</td></tr>
<tr><td>	00000996	</td><td>	Reconstrução resina  direta estética - cosmética	</td><td>	1050	</td></tr>
<tr><td>	00001011	</td><td>	Restauração resina estética 1 face	</td><td>	292	</td></tr>
<tr><td>	00001012	</td><td>	Restauração resina estética 2 faces	</td><td>	341	</td></tr>
<tr><td>	00001013	</td><td>	Restauração resina estética 3 faces	</td><td>	444	</td></tr>
<tr><td>	00001040	</td><td>	Pino Fibra Estético	</td><td>	585	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ENDODONTIA	</td><td>	USO	</th></tr>
<tr><td>	85200050	</td><td>	Remoção de corpo estranho intracanal	</td><td>	450	</td></tr>
<tr><td>	85200069	</td><td>	Remoção de material obturador intracanal para retratamento endodôntico	</td><td>	243	</td></tr>
<tr><td>	85200077	</td><td>	Remoção de núcleo intrarradicular	</td><td>	243	</td></tr>
<tr><td>	85200093	</td><td>	Retratamento endodôntico birradicular ( RL** ) ( RI** ) 	</td><td>	1128	</td></tr>
<tr><td>	85200107	</td><td>	Retratamento endodôntico multirradicular  ( RL** ) ( RI** )  	</td><td>	1700	</td></tr>
<tr><td>	85200110	</td><td>	Instrumentação mecanizada*	</td><td>	220	</td></tr>
<tr><td>	85200115	</td><td>	Retratamento endodôntico unirradicular  ( RL** ) ( RI** )  	</td><td>	761	</td></tr>
<tr><td>	85200123	</td><td>	Tratamento de perfuração endodôntica 	</td><td>	373	</td></tr>
<tr><td>	85200131	</td><td>	Tratamento endodôntico de dente com rizogênese incompleta	</td><td>	132	</td></tr>
<tr><td>	85200140	</td><td>	Tratamento endodôntico birradicular  ( RL** ) ( RI** )	</td><td>	690	</td></tr>
<tr><td>	85200158	</td><td>	Tratamento endodôntico multirradicular  ( RL** ) ( RI** )	</td><td>	1098	</td></tr>
<tr><td>	85200166	</td><td>	Tratamento endodôntico unirradicular  ( RL** ) ( RI** )	</td><td>	511

            
    		</tbody>
  
        </table>
        </div>
        <div class="paginacao"> 
          <a href="<?= site_url("tabeladeatos2013/1")?>">1</a> 
          <a href="<?= site_url("tabeladeatos2013/2")?>">2</a> 
          <strong>3</strong> 
        </div>
     </div>
    <div class="conteudo-right">
          <? include("lateral_view.php"); ?>
  </div>
      <? include("footer_view.php"); ?>