<? include("header_view.php"); ?>
<script>
$(document).ready(function(){
   $("tr:even").addClass("even");
   $("tr:odd").addClass("odd");
});
</script>
<style>
	.odd {
	   background-color: #fcb9c2; 
	   }
	.odd td {
	   border-bottom: 1px solid #fcb9c2; }
</style>
    <div class="nav"> <a href="<?=site_url()?>">Home</a> / Tabela de Atos </div>
    <div class="conteudo-left">
      <div class="texto">
        <h1>Tabela de Atos - P&aacute;gina 2 de 3</h1>
        <br /><br />
        <table cellpadding="0" cellspacing="0" class="tabela-atos">
          	<tbody>
            <tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	ENDODONTIA	</td><td>	USO	</th></tr>
<tr><td>	85200050	</td><td>	Remoção de corpo estranho intracanal	</td><td>	450	</td></tr>
<tr><td>	85200069	</td><td>	Remoção de material obturador intracanal para retratamento endodôntico	</td><td>	243	</td></tr>
<tr><td>	85200077	</td><td>	Remoção de núcleo intrarradicular	</td><td>	243	</td></tr>
<tr><td>	85200093	</td><td>	Retratamento endodôntico birradicular ( RL** ) ( RI** ) 	</td><td>	1128	</td></tr>
<tr><td>	85200107	</td><td>	Retratamento endodôntico multirradicular  ( RL** ) ( RI** )  	</td><td>	1700	</td></tr>
<tr><td>	85200110	</td><td>	Instrumentação mecanizada*	</td><td>	220	</td></tr>
<tr><td>	85200115	</td><td>	Retratamento endodôntico unirradicular  ( RL** ) ( RI** )  	</td><td>	761	</td></tr>
<tr><td>	85200123	</td><td>	Tratamento de perfuração endodôntica 	</td><td>	373	</td></tr>
<tr><td>	85200131	</td><td>	Tratamento endodôntico de dente com rizogênese incompleta	</td><td>	132	</td></tr>
<tr><td>	85200140	</td><td>	Tratamento endodôntico birradicular  ( RL** ) ( RI** )	</td><td>	690	</td></tr>
<tr><td>	85200158	</td><td>	Tratamento endodôntico multirradicular  ( RL** ) ( RI** )	</td><td>	1098	</td></tr>
<tr><td>	85200166	</td><td>	Tratamento endodôntico unirradicular  ( RL** ) ( RI** )	</td><td>	511	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	PERIODONTIA	</td><td>	USO	</th></tr>
<tr><td>	82000212	</td><td>	Aumento de coroa clínica *	</td><td>	402	</td></tr>
<tr><td>	82000336	</td><td>	Cirurgia odontológica a retalho *	</td><td>	409	</td></tr>
<tr><td>	82000344	</td><td>	Cirurgia odontológica com aplicação de aloenxertos *	</td><td>	2655	</td></tr>
<tr><td>	82000417	</td><td>	Cirurgia periodontal a retalho*	</td><td>	413	</td></tr>
<tr><td>	82000557	</td><td>	Cunha proximal*	</td><td>	345	</td></tr>
<tr><td>	82000620	</td><td>	Enxerto com osso liofilizado *	</td><td>	1380	</td></tr>
<tr><td>	82000646	</td><td>	Enxerto conjuntivo subepitelial*	</td><td>	1586	</td></tr>
<tr><td>	82000662	</td><td>	Enxerto gengival livre*	</td><td>	1586	</td></tr>
<tr><td>	82000689	</td><td>	Enxerto pediculado*	</td><td>	1586	</td></tr>
<tr><td>	82000690	</td><td>	Cirurgia de enxerto com osso homologo (banco de ossos) - ato cirurgico *	</td><td>	5521	</td></tr>
<tr><td>	82000921	</td><td>	Gengivectomia*	</td><td>	283	</td></tr>
<tr><td>	82000948	</td><td>	Gengivoplastia*	</td><td>	283	</td></tr>
<tr><td>	82001049	</td><td>	Levantamento do seio maxilar com osso autógeno*	</td><td>	5521	</td></tr>
<tr><td>	82001057	</td><td>	Levantamento do seio maxilar com osso homólogo *	</td><td>	5521	</td></tr>
<tr><td>	82001065	</td><td>	Levantamento do seio maxilar com osso liofilizado  *	</td><td>	5521	</td></tr>
<tr><td>	82001464	</td><td>	Sepultamento radicular*	</td><td>	431	</td></tr>
<tr><td>	82001669	</td><td>	Tratamento odontológico regenerativo com enxerto de osso autógeno*	</td><td>	4247	</td></tr>
<tr><td>	82001685	</td><td>	Tunelização*	</td><td>	2123	</td></tr>
<tr><td>	85300012	</td><td>	Dessensibilização dentária*	</td><td>	18	</td></tr>
<tr><td>	85300039	</td><td>	Raspagem sub-gengival/alisamento radicular *	</td><td>	80	</td></tr>
<tr><td>	85300047	</td><td>	Raspagem supra-gengival *	</td><td>	69	</td></tr>
<tr><td>	85300071	</td><td>	Tratamento de gengivite necrosante aguda - GNA*	</td><td>	1060	</td></tr>
<tr><td>	85400270	</td><td>	Placa oclusal resiliente*	</td><td>	1319	</td></tr>
<tr><td>	00003015	</td><td>	Cirurgia plastica periodontal *	</td><td>	529	</td></tr>
<tr><td>	00003060	</td><td>	Contenção(Imobilizaçao) dentaria com resina fotopolimerizavel*	</td><td>	90	</td></tr>
<tr><td>	00003070	</td><td>	Contenção(Esplintagem) com fio ortodôntico até 6 elementos (especificar o segmento)*	</td><td>	818	</td></tr>
<tr><td>	00003071	</td><td>	Manutenção para pacientes periodontais *	</td><td>	1060	</td></tr>
<tr><td>	00003100	</td><td>	Proservação pre/pos cirurgica segmento e/ou  Controle periodontal*	</td><td>	336	</td></tr>
<tr><td>	00003141	</td><td>	Osteotomia / osteoplastia por elemento*	</td><td>	344	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	IMPLANTE/PROTESE SOBRE IMPLANTE*	</td><td>	USO	</th></tr>
<tr><td>	82000964	</td><td>	Implante ortodôntico (mini implante ortodontico para ancoragem)*	</td><td>	1102	</td></tr>
<tr><td>	82000980	</td><td>	Implante ósseo integrado - ato cirurgico  *	</td><td>	4038	</td></tr>
<tr><td>	82001138	</td><td>	Reabertura - colocação de cicatrizador ( ato cirúrgico ) *	</td><td>	513	</td></tr>
<tr><td>	85400122	</td><td>	Coroa total livre de metal (metalfree) sobre implante - cerâmica  *	</td><td>	7036	</td></tr>
<tr><td>	85500020	</td><td>	Coroa provisória sobre implante com carga imediata *	</td><td>	1680	</td></tr>
<tr><td>	85500038	</td><td>	Coroa total metalo-cerâmica sobre implante*	</td><td>	4326	</td></tr>
<tr><td>	85500062	</td><td>	Guia cirúrgico para implante*	</td><td>	2159	</td></tr>
<tr><td>	85500089	</td><td>	Manutenção de prótese sobre implantes*	</td><td>	1013	</td></tr>
<tr><td>	85500097	</td><td>	Overdenture barra clipe ou o'ring sobre dois implantes *	</td><td>	17077	</td></tr>
<tr><td>	85500143	</td><td>	Protocolo Branemark em carga imediata para 4 implantes - parte protética *	</td><td>	28005	</td></tr>
<tr><td>	85500151	</td><td>	Protocolo Branemark em carga imediata para 5 implantes - parte protética  *	</td><td>	32102	</td></tr>
<tr><td>	85500186	</td><td>	Protocolo Branemark provisório para 4 implantes  *	</td><td>	14015	</td></tr>
<tr><td>	85500194	</td><td>	Protocolo Branemark provisório para 5 implantes  *	</td><td>	16040	</td></tr>
<tr><td>	00003145	</td><td>	Supervisao cirurgica de implante*	</td><td>	306	</td></tr>
<tr><td>	00003300	</td><td>	Reabilitação unitaria com implante*	</td><td>	12080	</td></tr>
<tr><td>	00004189	</td><td>	Cicatrizador ( Paralelo ou divergente ) *	</td><td>	417	</td></tr>
<tr><td>	00004190	</td><td>	Intermediário protético cônico (para implantes) *	</td><td>	1470	</td></tr>
<tr><td>	00004191	</td><td>	Intermediário protético cônico angulado *	</td><td>	1633	</td></tr>
<tr><td>	00004192	</td><td>	Intermediário (Munhão) standart sobre implante  *	</td><td>	1307	</td></tr>
<tr><td>	00004193	</td><td>	Análogo ou réplica do implante nacional *	</td><td>	323	</td></tr>
<tr><td>	00004194	</td><td>	Transfer moldeira fechada ou aberta *	</td><td>	664	</td></tr>
<tr><td>	00004195	</td><td>	Parafuso de cobertura *	</td><td>	127	</td></tr>
<tr><td>	00004196	</td><td>	Parafuso de trabalho Assentamento passivo *	</td><td>	207	</td></tr>
<tr><td>	00004197	</td><td>	Parafuso para enxerto *	</td><td>	420	</td></tr>
<tr><td>	00004198	</td><td>	Parafuso sextavado  *	</td><td>	202	</td></tr>
<tr><td>	00004199	</td><td>	Parafuso sextavado  ( II Plus/ ou similar ) *	</td><td>	209	</td></tr>
<tr><td>	00005001	</td><td>	Parafuso sextavado ( II Plus/ neotorque ou similar ) *	</td><td>	336	</td></tr>
<tr><td>	00005002	</td><td>	Paralelizador *	</td><td>	372	</td></tr>
<tr><td>	00005003	</td><td>	Ucla Calcinável *	</td><td>	207	</td></tr>
<tr><td>	00005004	</td><td>	Ucla em cromo e cobalto *	</td><td>	721	</td></tr>
<tr><td>	00005005	</td><td>	Ucla em titânio  *	</td><td>	526	</td></tr>
<tr style="font-weight:bold; color:#fff; background:#af2638;"><th style="text-align:center;">	TUSS	</td><td>	PROTESE DENTÁRIA	</td><td>	USO	</th></tr>
<tr><td>	85400017	</td><td>	Ajuste Oclusal por acréscimo*	</td><td>	159	</td></tr>
<tr><td>	85400025	</td><td>	Ajuste Oclusal por desgaste seletivo*	</td><td>	106	</td></tr>
<tr><td>	85400033	</td><td>	Conserto em prótese parcial removível (em consultório e em laboratório)*	</td><td>	418	</td></tr>
<tr><td>	85400041	</td><td>	Conserto em prótese parcial removível (exclusivamente em consultório)*	</td><td>	418	</td></tr>
<tr><td>	85400050	</td><td>	Conserto em prótese total (em consultório e em laboratório)*	</td><td>	418	</td></tr>
<tr><td>	85400068	</td><td>	Conserto em prótese total (exclusivamente em consultório) *	</td><td>	418	</td></tr>
<tr><td>	85400076	</td><td>	Coroa provisória com pino *	</td><td>	309	</td></tr>
<tr><td>	85400084	</td><td>	Coroa provisória sem pino *	</td><td>	309	</td></tr>
<tr><td>	85400092	</td><td>	Coroa total acrílica prensada*	</td><td>	1146	</td></tr>
<tr><td>	85400106	</td><td>	Coroa total em cerâmica pura *	</td><td>	4234	</td></tr>
<tr><td>	85400114	</td><td>	Coroa total em cerômero  ( RL*) (RI**) 	</td><td>	951	</td></tr>
<tr><td>	85400149	</td><td>	Coroa total metálica (RL* ) RI** ) 	</td><td>	951	</td></tr>
<tr><td>	85400157	</td><td>	Coroa total metalo cerâmica *	</td><td>	2631	</td></tr>
<tr><td>	85400165	</td><td>	Coroa total metalo plástica – cerômero *	</td><td>	1710	</td></tr>
<tr><td>	85400173	</td><td>	Coroa total metalo plástica – resina acrílica*	</td><td>	1710	</td></tr>
<tr><td>	85400181	</td><td>	Faceta em cerâmica pura*	</td><td>	4234	</td></tr>
<tr><td>	85400190	</td><td>	Faceta em cerômero*	</td><td>	1527	</td></tr>
<tr><td>	85400203	</td><td>	Guia cirúrgico para prótese total imediata*	</td><td>	6186	</td></tr>
<tr><td>	85400211	</td><td>	Núcleo de preenchimento*	</td><td>	264	</td></tr>
<tr><td>	85400220	</td><td>	Núcleo metálico fundido ( RL**)  ( RI**)	</td><td>	602	</td></tr>
<tr><td>	85400238	</td><td>	Onlay de Resina Indireta*	</td><td>	1815	</td></tr>
<tr><td>	85400289	</td><td>	Prótese fixa adesiva direta (provisória)*	</td><td>	1734	</td></tr>
<tr><td>	85400300	</td><td>	Prótese fixa adesiva indireta em metalo cerâmica*	</td><td>	5826	</td></tr>
<tr><td>	85400319	</td><td>	Prótese fixa adesiva indireta em metalo plástica*	</td><td>	2882	</td></tr>
<tr><td>	85400335	</td><td>	Prótese parcial fixa em metalo cerâmica*	</td><td>	3290	</td></tr>
<tr><td>	85400343	</td><td>	Prótese parcial fixa em metalo plástica*	</td><td>	1710	</td></tr>
<tr><td>	85400351	</td><td>	Prótese parcial fixa In Ceran livre de metal (metal free)*	</td><td>	7433	</td></tr>
<tr><td>	85400360	</td><td>	Prótese parcial fixa provisória*	</td><td>	3186	</td></tr>
<tr><td>	85400378	</td><td>	Prótese parcial removível com encaixes de precisão ou de semi precisão*	</td><td>	4902	</td></tr>
<tr><td>	85400386	</td><td>	Prótese parcial removível com grampos bilateral*	</td><td>	3335	</td></tr>
<tr><td>	85400394	</td><td>	Prótese parcial removível provisória em acrílico com ou sem grampos*	</td><td>	1086	</td></tr>
<tr><td>	85400408	</td><td>	Prótese total *	</td><td>	3110	</td></tr>
<tr><td>	85400416	</td><td>	Prótese total imediata*	</td><td>	2512	</td></tr>
<tr><td>	85400424	</td><td>	Prótese total incolor *	</td><td>	3110	</td></tr>
<tr><td>	85400432	</td><td>	Provisório para Faceta*	</td><td>	301	</td></tr>
<tr><td>	85400440	</td><td>	Provisório para Inlay/Onlay*	</td><td>	301	</td></tr>
<tr><td>	85400459	</td><td>	Provisório para Restauração metálica fundida*	</td><td>	309	</td></tr>
<tr><td>	85400475	</td><td>	Reembasamento de coroa provisória*	</td><td>	199	</td></tr>
<tr><td>	85400483	</td><td>	Reembasamento de prótese total ou parcial - imediato (em consultório)*	</td><td>	713	</td></tr>
<tr><td>	85400491	</td><td>	Reembasamento de prótese total ou parcial - mediato (em laboratório) *	</td><td>	1274	</td></tr>
<tr><td>	85400505	</td><td>	Remoção de trabalho protético *	</td><td>	151	</td></tr>
<tr><td>	85400513	</td><td>	Restauração em cerâmica pura - inlay *	</td><td>	3053	</td></tr>
<tr><td>	85400521	</td><td>	Restauração em cerâmica pura - onlay *	</td><td>	3053	</td></tr>
<tr><td>	85400530	</td><td>	Restauração em cerômero - onlay*	</td><td>	1491	</td></tr>
<tr><td>	85400548	</td><td>	Restauração em cerômero - inlay*	</td><td>	1491	</td></tr>
<tr><td>	85400556	</td><td>	Restauração metálica fundida ( RL*) (RI**)	</td><td>	951	</td></tr>
<tr><td>	00004010	</td><td>	Planejamento em protese*	</td><td>	491	</td></tr>
<tr><td>	00004030	</td><td>	Ajuste funcional com finalidade protetica*	</td><td>	229	</td></tr>
<tr><td>	00004120	</td><td>	Coroa de jaqueta acrilica*	</td><td>	939	</td></tr>
<tr><td>	00004141	</td><td>	Coroa elemento metaloceramica*	</td><td>	5416	</td></tr>
<tr><td>	00004170	</td><td>	Coroa 3/4 ou 4/5*	</td><td>	998	</td></tr>
<tr><td>	00004270	</td><td>	Encaixe macho/femea *	</td><td>	522	</td></tr>
<tr><td>	00004301	</td><td>	Protese Total personalizada *	</td><td>	5973	</td></tr>
<tr><td>	00004320	</td><td>	Casquete moldagem *	</td><td>	295	</td></tr>
<tr><td>	00004330	</td><td>	Ponto de solda *	</td><td>	672	</td></tr>
<tr><td>	00004360	</td><td>	JIG ou front plateau*	</td><td>	211	</td></tr>
<tr><td>	00004385	</td><td>	Recimentação (peça protetica)*	</td><td>	96	</td></tr>
<tr><td>	00004390	</td><td>	Supervisao protetica em consultorio*	</td><td>	325	</td></tr>

            
    		</tbody>
  
        </table>
        </div>
        <div class="paginacao"> 
          <a href="<?= site_url("tabeladeatos2013/1")?>">1</a> 
          <strong>2</strong> 
          <a href="<?= site_url("tabeladeatos2013/3")?>">3</a> 
        </div>
     </div>
    <div class="conteudo-right">
          <? include("lateral_view.php"); ?>
  </div>
      <? include("footer_view.php"); ?>