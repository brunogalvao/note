<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rio de faturamento
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rio de faturamento</h1>
		          
<script>

	function float2moeda(num) {
		x = 0;
		if (num < 0) {
			num = Math.abs(num);
			x = 1;
		}

		if (isNaN(num))
			num = "0";

		cents = Math.floor((num * 100 + 0.5) % 100);
		num = Math.floor((num * 100 + 0.5) / 100).toString();

		if (cents < 10)
			cents = "0" + cents;

		for ( var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
			num = num.substring(0, num.length - (4 * i + 3)) + '.' + num.substring(num.length - (4 * i + 3));

		ret = num + ',' + cents;

		if (x == 1)
			ret = ' - ' + ret;

		return ret;
	}

	function loadCharts(){
		jQuery('#graficoFaturamentoEmpresa').html("Carregando...");
		jQuery("#graficoFaturamentoEmpresaDivTable").hide();
		jQuery("#mesFiltroFaturamentoEmpresa").attr('disabled', 'disabled');
		xmlHttpBar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'barFaturamentoEmpresa','empresa','<?=site_url("site/serverRequest")?>', xmlHttpBar, 	jQuery("#mesFiltroFaturamentoEmpresa").val() );
	}

	function loadChartsFaturamentoEmpresa(){
		jQuery('#graficoFaturamentoEmpresa').html("Carregando...");
		jQuery("#graficoFaturamentoEmpresaDivTable").hide();
		jQuery("#mesFiltroFaturamentoEmpresa").attr('disabled', 'disabled');

		xmlHttpBar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'barFaturamentoEmpresa','empresa','<?=site_url("site/serverRequest")?>', xmlHttpBar, 	document.getElementById('mesFiltroFaturamentoEmpresa').value );
	}

	function generateTableFaturamento(paramXML){
		var xmlData;

		if(jQuery.browser.msie){
			xmlData = new ActiveXObject("Microsoft.XMLDOM");
			xmlData.loadXML("<a>"+paramXML+"</a>");
		}else{
			xmlData = jQuery("<a>"+paramXML+"</a>");
		}

		var html = jQuery("#graficoFaturamentoEmpresaTableTable")[0];
		var trDefault = jQuery(html).find("tbody tr")[0];
		jQuery(html).find("tbody").html(trDefault);

		var sumQtde = 0;
		var sumValor= 0;

		jQuery(xmlData).find("item").each(function(i, j){

			var trExample = jQuery(html).find("tbody tr")[0];
			var tr = jQuery(trExample).clone();

			sumQtde = sumQtde + (jQuery(this).find("quantidade").attr("value")*1);
			sumValor = sumValor + (jQuery(this).find("valor").attr("value") *1);

			jQuery(tr).find("#mes").html(jQuery(this).find("mes").attr("value"));
			jQuery(tr).find("#valor").html('R$ '+ float2moeda( jQuery(this).find("valor").attr("value") ));
			jQuery(tr).find("#qtde").html(jQuery(this).find("quantidade").attr("value"));
			jQuery(tr).show();
			jQuery(tr).appendTo(jQuery(html).find("tbody"));
		});

		var trFoot = jQuery(html).find("tfoot tr")[0];

		jQuery(trFoot).find("#totalFat").html('R$ '+ float2moeda( sumValor) );
		jQuery(trFoot).find("#totalQtde").html(sumQtde);


		jQuery("#graficoFaturamentoEmpresaDivTable").show();

	}




</script>
</head>
<body onLoad="loadCharts()">
	<div class="desc-relatorio">
	Este relat&oacute;rio consiste em apresentar o valor faturado nas notas fiscais de um per&iacute;odo, pela quantidade de benefici&aacute;rios atendidos por estas notas.<br/>
	Dados relativos ao &uacute;ltimo fechamento.
	</div>
	<label>&Uacute;ltimos
		<select id="mesFiltroFaturamentoEmpresa" name="mesFiltroFaturamentoEmpresa" onChange="loadChartsFaturamentoEmpresa();">
        	<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
		meses</label>

				<div id="graficoFaturamentoEmpresa" align="center" class="chartClass" style="z-index: 10000"></div>
				<br/>

				<div id="graficoFaturamentoEmpresaDivTable" style="display: none; ">

					<table id="graficoFaturamentoEmpresaTableTable" width="100%" style="border: 1px solid #CCC; background-color: white; color: #333;" cellpadding="0" cellspacing="0" align="center">
						<thead>
							<tr >
								<th width="30%" style="border-right: 1px solid #CCC; text-align: center;" >M&ecirc;s</th>
								<th width="35%" style="border-right: 1px solid #CCC; text-align: center;">Faturamento</th>
								<th width="35%" style="text-align: center;" >Quantidade</th>
							</tr>

						</thead>
						<tbody>
							<tr style="display:none;">
								<td id="mes" width="30%" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: center" ></td>
								<td id="valor" width="35%" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: right;"></td>
								<td id="qtde" width="35%" style="border-top: 1px solid #CCC; text-align: center;"></td>
							</tr>
						</tbody>
						<tfoot>

							<tr>
								<td style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: center">
									<b>TOTAL</b>
								</td>
								<td id="totalFat" style="border-right: 1px solid #CCC; border-top: 1px solid #CCC; text-align: right;">
									R$ 0,00
								</td>
								<td id="totalQtde" style="border-top: 1px solid #CCC; text-align: center;">
									0
								</td>

							</tr>

						</tfoot>
					</table>
</div>

            <script type="text/javascript">

                   function semDados(chartName, msg){
                	   jQuery("#graficoFaturamentoEmpresaDivTable").hide();
                   		document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>"+msg+"</b><br>( Nenhum dado foi encontrado. )</p>"
                   }


				function buildChart( id, xml ) {

			   	   if( id=="barFaturamentoEmpresa" ) {
			  			jQuery('#graficoFaturamentoEmpresa').html("Carregando...");
			  			jQuery("#graficoFaturamentoEmpresaDivTable").hide();

			  			var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId", "710", "510");
			  			chartZoom.addParam("wMode","transparent");
			  			chartZoom.setDataXML(xml);
			  			chartZoom.render("graficoFaturamentoEmpresa");



			  			jQuery("#graficoFaturamentoEmpresa").fancybox({
			  				'autoDimensions':	false,
			  				'autoScale'		: 	false,
			  				'scrolling'		: 'auto',
			  				'href'			: "<?=site_url()?>js/empresa/chart/details/chartDetails.html",
			  				'width'			:750,
			  				'height'		:600,
			  				'onComplete'	:	function() {
								  					jQuery("#ChartId").hide();

								  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId", "700", "350");
								  					chartZoom.setDataXML(xml);
								  					chartZoom.render("content");

								  					jQuery("#tabelaChartDetails").html(jQuery("#graficoFaturamentoEmpresaTableTable").clone().attr("width","98%").attr("align","center"));
								  				},
			  				'onCleanup' : function(){
			  					jQuery("#ChartId").show();
			  				}
			  			});

     					generateTableFaturamento(xml);
     					jQuery("#graficoFaturamentoEmpresaDivTable").show();
     					jQuery("#mesFiltroFaturamentoEmpresa").attr('disabled', '');

			  	   	}
			  	}

</script>


         
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>