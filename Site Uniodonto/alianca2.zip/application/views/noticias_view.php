<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / <a href="<?=site_url()?>historico"><?= $this->lang->line('noticias') ?></a> / <?= ucfirst($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?>
</div>
<div class="conteudo-left">
    <div class="texto">
    	<h1><?= ucfirst($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?></h1>
        
        <? $data = explode(" ",$noticia[0]['noticia_data'] );
           $data = explode("-",$data[0] ); ?>
        <i style="color:#999;"><?=($this->session->userdata("idioma") == "en") ? 'published in' : 'Publicado em ';?> <?= $data[2]."/".$data[1]."/".$data[0]?></i>
    	<div class="redes-sociais">
			<div class="addthis_toolbox addthis_default_style "
		        addthis:url="<?=site_url("noticia/".$noticia[0]['noticia_id'])?>/<?=str_replace('%','',urlencode($this->formata_nome_model->formataNome($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])))?>"
		        addthis:title="<?=ucfirst($noticia[0]['noticia_titulo_'.$this->session->userdata("idioma")])?>"
		        addthis:description="<?=$breve_desc ?>">
			<a class="addthis_button_facebook"></a>
			<a class="addthis_button_twitter"></a>
			</div>
			<script type="text/javascript">
				var addthis_config = {"data_track_addressbar":false};
            </script>
			<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5087c8db50a1cb75"></script>

    	</div>
    	
    	
		<?= $noticia[0]['noticia_texto_'.$this->session->userdata("idioma")]?>
        
        <? $noticia_img = explode(";",$noticia[0]['noticia_imgs']);
		
        if(count($noticia_img) > 2){ ?>
        <script type="text/javascript" src='<?= site_url()?>includes/galleria/galleria-1.2.8.min.js' ></script>
        <div id="galleria">
        
			<?
					
					foreach($noticia_img as $img){
						if($img != ""){
							$noticia_img_thumb = explode(".",$img);
							print '
							 <a href="'.site_url()."images/noticias/".$img.'">
                <img src="'.site_url()."images/noticias/".$noticia_img_thumb[0]."_medium.".$noticia_img_thumb[1].'">
            				 </a>
							';
							
						}	
					} ?>
			<script>

			// Load the classic theme
			Galleria.loadTheme('<?=site_url()?>includes/galleria/themes/classic/galleria.classic.min.js');
		
			Galleria.configure({
				lightbox: true
			});
			// Initialize Galleria
			Galleria.run('#galleria', {
				transition: 'pulse',
				imageCrop: false,
				height: 500,
			
			});
		
			</script>

			
                
    	</div>
		<? } ?> 
    
    </div> 
    
    <div class="resultados">
    <h1><?= $this->lang->line('mais_noticias') ?></h1>
    
    	<? foreach($noticias as $noticia){
            $data = explode(" ",$noticia['noticia_data'] );
            $data = explode("-",$data[0] );
            ?>
            
        <a href="<?= site_url()?>noticia/<?=$noticia['noticia_id']?>/<?=str_replace('%','',urlencode($this->formata_nome_model->formataNome($noticia['noticia_titulo_'.$this->session->userdata("idioma")])))?>" class="historico">
        <h3><?= $data[2]."/".$data[1]."/".$data[0]?></h3>
        <?=$noticia['noticia_titulo_'.$this->session->userdata("idioma")]?>
        </a>
            
        <? } ?>
        <a href="<?= site_url()?>historico" id="bt-vejamais" class="bt-vejamais"><?= $this->lang->line('mais_noticias') ?></a>
        
    </div>  
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>