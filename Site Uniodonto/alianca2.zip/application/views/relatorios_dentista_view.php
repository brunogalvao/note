<? include("header_view.php"); ?>
<div class="nav">
<a href="<?=site_url()?>">Home</a> / Relat&oacute;rios
</div>


<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/FusionCharts.js"></script>

<script type="text/javascript" src="<?=site_url()?>js/fusionchart/js/GetRemoteXML.js"></script>
<script type="text/javascript" src="<?=site_url()?>js/jquery.fusioncharts.js" ></script>
<div class="conteudo-left">
    <div class="texto">
    	<h1>Relat&oacute;rios</h1>
		          
<script>
	var chart5 = null;

	function loadCharts(){

		xmlHttpLine=GetXmlHttpObject();
		xmlHttpBarAtoCobertoXComplementar=GetXmlHttpObject();
		xmlHttpBar=GetXmlHttpObject();
		xmlHttpBarProducao=GetXmlHttpObject();
		xmlHttpPie=GetXmlHttpObject();

		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'line','cooperado','<?=site_url("site/serverRequest")?>', xmlHttpLine, document.getElementById('mesFiltroAtendimento').value );
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar-atos-x-complementar','cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBarAtoCobertoXComplementar, document.getElementById('mesFiltroAtoCobertoXComplementar').value );
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBar, document.getElementById('mesFiltroStatus').value  );
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar-producao-cooperado' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBarProducao, document.getElementById('mesFiltroProducao').value  );
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'pie' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpPie, document.getElementById('mesFiltroEspec').value  );

	}

	function loadChartsAtendimento(){
		//xmlHttpLine=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'line','cooperado','<?=site_url("site/serverRequest")?>', xmlHttpLine, 	document.getElementById('mesFiltroAtendimento').value );
	}

	function loadChartsAtoCobertoXAtoNaoCoberto(){
		//xmlHttpBarAtoCobertoXComplementar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar-atos-x-complementar','cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBarAtoCobertoXComplementar, 	document.getElementById('mesFiltroAtoCobertoXComplementar').value );
	}

	function loadChartsStatus(){
		//xmlHttpBar=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBar,	document.getElementById('mesFiltroStatus').value );
	}

	function loadChartsProducao(){
		//xmlHttpBarProducao=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'bar-producao-cooperado' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpBarProducao,	document.getElementById('mesFiltroProducao').value );
	}

	function loadChartsEspec(){
		//xmlHttpPie=GetXmlHttpObject();
		showCustomerWithFilter(<?=$this->session->userdata("codigo")?>,'pie' ,'cooperado','<?=site_url("site/serverRequest")?>', xmlHttpPie, 	document.getElementById('mesFiltroEspec').value );
	}




</script>
<title>Insert title here</title>
</head>
<body onLoad="loadCharts()">

	<h1>Atendimentos Realizados</h1>
	<div class="desc-relatorio">
    Este relat&oacute;rio consiste em apresentar a quantidade de atendimentos feitos no per&iacute;odo selecionado.<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>
	<label>&Uacute;ltimos
		<select id="mesFiltroAtendimento" name="mesFiltroAtendimento" class="style2" onChange="loadChartsAtendimento();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>

		<div id="chartLine" align="center" style="cursor: pointer !important;"></div>


	<h1>Produ&ccedil;&atilde;o de Cooperado (Ato Coberto X Ato Complementar)</h1>
	<div class="desc-relatorio">
	Este relat&oacute;rio consiste em apresentar o comparativo entre valor e percentual. Considera os totais de ato coberto e ato n&atilde;o coberto da produ&ccedil;&atilde;o do cooperado.<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>
    <label>&Uacute;ltimos
		<select id="mesFiltroAtoCobertoXComplementar" name="mesFiltroAtoCobertoXComplementar" class="style2" onChange="loadChartsAtoCobertoXAtoNaoCoberto();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>
		
		<div id="chartLineAtoCobertoXComplementar" align="center" style="cursor: pointer !important;"></div>


	<h1>Status dos Guias</h1>
	<div class="desc-relatorio">
    Este relat&oacute;rio consiste em apresentar o status e valores das guias realizados no per&iacute;odo selecionado.<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>
    <label>&Uacute;ltimos
		<select id="mesFiltroStatus" name="mesFiltroStatus" class="style2" onChange="loadChartsStatus();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>

		<div id="chartColumn3D" align="center" style="cursor: pointer !important;"></div>

	<h1>Produ&ccedil;&atilde;o de Cooperado</h1>
	<div class="desc-relatorio">
    <label>
	Este relat&oacute;rio consiste em apresentar os valores da produ&ccedil;&atilde;o do cooperado, considerando o valor l&iacute;quido da produ&ccedil;&atilde;o.<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</label>
	</div>
    <label>&Uacute;ltimos
		<select id="mesFiltroProducao" name="mesFiltroProducao" class="style2" onChange="loadChartsProducao();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>
		<div id="chartColumn3DProducao" align="center" style="cursor: pointer !important;"></div>

	<h1>Atendimentos por faixa et&aacute;ria</h1>
	<div class="desc-relatorio">
    Este relat&oacute;rio consiste em apresentar a quantidade de atendimentos por faixa et&aacute;ria no per&iacute;odo selecionado.<br/>
	Dados considerados at&eacute; &uacute;ltimo fechamento.
	</div>
    <label>&Uacute;ltimos
		<select id="mesFiltroEspec" name="mesFiltroEspec" class="style2" onChange="loadChartsEspec();">
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
			<option value="6" selected="selected">6</option>
		</select>
	meses</label>

		<div id="chartPie3D" align="center" style="cursor: pointer !important;"></div>
		<div id="tableArea" align="center">
			<table id="tabelaChart" width="402px" cellpadding="0" cellspacing="0" border="0" style="border: 1px solid black; background-color: white;">
				<thead>
					<tr>
						<th width="5%" align="center" style="border-right: 1px solid black;">&nbsp;</th>
						<th width="33%" align="center" style="border-right: 1px solid black;">Faixa Et&aacute;ria</th>

						<th width="30%" align="center" style="border-right: 1px solid black;">Quantidade</th>
						<th width="32%" align="center">Porcentagem</th>
					</tr>
				</thead>
				<tbody>
					<tr style="display: none;">
						<td id="cor"  align="center" style="border-top: 1px solid black; border-right: 1px solid black;">&nbsp;</td>
						<td class="faixa-etaria"  align="center" style="border-top: 1px solid black; border-right: 1px solid black; text-transform: uppercase;"></td>

						<td class="quantidade"  align="center" style="border-top: 1px solid black; border-right: 1px solid black; text-transform: uppercase;"></td>
						<td class="porcentagem"  align="center" style="border-top: 1px solid black; text-transform: uppercase;"></td>
					</tr>
				</tbody>
				<tfoot>
                      <tr>
                          <td style="border-right: 1px solid black; border-top: 1px solid black; text-align: center;" colspan="2" >
                              <b>TOTAL</b>

                          </td>
                          <td id="totalQtde" style="border-right: 1px solid black; border-top: 1px solid black; text-align: center;">&nbsp;
                              
                          </td>
                          <td style="border-top: 1px solid black; text-align: center;">
                              100%
                          </td>
                      </tr>
                  </tfoot>

			</table>
		</div>


<script type="text/javascript">

	function semDados(chartName, msg) {
		document.getElementById(chartName).innerHTML = "<p align='center'><Font face='verdana' size='1'><b>" + msg + "</b><br>( Nenhum dado foi encontrado. )</p>"
	}

	function hideCharts(){
		jQuery("#ChartId1").hide();
		jQuery("#ChartId3").hide();
		jQuery("#ChartId4").hide();
		jQuery("#ChartId5").hide();
		jQuery("#ChartId6").hide();

	}

	function showCharts(){
		jQuery("#ChartId1").show();
		jQuery("#ChartId3").show();
		jQuery("#ChartId4").show();
		jQuery("#ChartId5").show();
		jQuery("#ChartId6").show();
	}

	function buildChart(id, xml) {
		if (id == "line") {
			var chart1 = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Line.swf", "ChartId1", "400", "210");
			chart1.addParam("wMode","transparent");
			chart1.setDataXML(xml);
			chart1.render("chartLine");

			jQuery("#chartLine").fancybox({
  				'autoDimensions':	false,
  				'autoScale'		: 	false,
  				'scrolling'		: 'no',
  				'href'			: "http://www.uniodontocuritiba.com.br/unio/unio/dentista/chart/details/chartDetails.html",
  				'width'			:750,
  				'height'		:520,
  				'onComplete'	:	function() {
  										hideCharts();

					  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Line.swf", "ChartId2", "684", "398");
										chartZoom.setDataXML(xml);
										chartZoom.render("content");

					  				},
  				'onCleanup' : function(){
  					showCharts();
  				}
  			});


		} else if (id == "bar-atos-x-complementar") {
			$("#ChartId3").remove();
			var chart5 = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/FCF_MSColumn2D.swf", "ChartId3", "580", "210", "0", "0");
			chart5.addParam("wMode","transparent");
			chart5.setDataXML(xml);
			chart5.render("chartLineAtoCobertoXComplementar");

			jQuery("#chartLineAtoCobertoXComplementar").fancybox({
  				'autoDimensions':	false,
  				'autoScale'		: 	false,
  				'scrolling'		: 'no',
  				'href'			: "http://www.uniodontocuritiba.com.br/unio/unio/dentista/chart/details/chartDetails.html",
  				'width'			:750,
  				'height'		:520,
  				'onComplete'	:	function() {
  										hideCharts();

					  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/FCF_MSColumn2D.swf", "ChartId31", "684", "398");
										chartZoom.setDataXML(xml);
										chartZoom.render("content");

					  				},
  				'onCleanup' : function(){
  					showCharts();
  				}
  			});





		} else if (id == "bar") {
			var chart2 = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId4", "400", "210", "0", "0");
			chart2.addParam("wMode","transparent");
			chart2.setDataXML(xml);
			chart2.render("chartColumn3D");

			jQuery("#chartColumn3D").fancybox({
  				'autoDimensions':	false,
  				'autoScale'		: 	false,
  				'scrolling'		: 'no',
  				'href'			: "http://www.uniodontocuritiba.com.br/unio/unio/dentista/chart/details/chartDetails.html",
  				'width'			:750,
  				'height'		:520,
  				'onComplete'	:	function() {
  										hideCharts();

					  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId41", "684", "398");
										chartZoom.setDataXML(xml);
										chartZoom.render("content");

					  				},
  				'onCleanup' : function(){
  					showCharts();
  				}
  			});



		} else if (id == "bar-producao-cooperado") {
			var chart4 = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId5", "580", "210", "0", "0");
			chart4.addParam("wMode","transparent");
			chart4.setDataXML(xml);
			chart4.render("chartColumn3DProducao");

			jQuery("#chartColumn3DProducao").fancybox({
  				'autoDimensions':	false,
  				'autoScale'		: 	false,
  				'scrolling'		: 'no',
  				'href'			: "http://www.uniodontocuritiba.com.br/unio/unio/dentista/chart/details/chartDetails.html",
  				'width'			:750,
  				'height'		:520,
  				'onComplete'	:	function() {
					  					hideCharts();

					  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Column3D.swf", "ChartId51", "684", "398");
										chartZoom.setDataXML(xml);
										chartZoom.render("content");

					  				},
  				'onCleanup' : function(){
  					showCharts();
  				}
  			});


		} else if (id == "pie") {
			if ((xml == -1)) {
				semDados("chartPie3D", "Faixa etaria dos atendidos em 6 meses.");
				$("#tabelaChart").hide();
			} else {
				var chart3 = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Pie3D.swf", "ChartId6","400", "210", "0", "0");
				chart3.addParam("wMode","transparent");
				chart3.setDataXML(xml);
				chart3.render("chartPie3D");
				$("#tabelaChart").show();
				jQuery("#chartPie3D").fancybox({
	  				'autoDimensions':	false,
	  				'autoScale'		: 	false,
	  				'scrolling'		: 'auto',
	  				'href'			: "http://www.uniodontocuritiba.com.br/unio/unio/dentista/chart/details/chartDetails.html",
	  				'width'			:750,
	  				'height'		:620,
	  				'onComplete'	:	function() {
	  										hideCharts();

						  					var chartZoom = new FusionCharts("<?=site_url()?>js/fusionchart/grafico/Pie3D.swf", "ChartId61", "684", "398");
											xml = xml.replace("100","200");
											chartZoom.setDataXML(xml);
											chartZoom.render("content");
											$("#tabelaChartDetails").html($("#tabelaChart").clone().attr("width","100%"));

						  				},
	  				'onCleanup' : function(){
	  					showCharts();
	  				}
	  			});



				extractSets(xml);
			}
		}
	}

	function ItemChart(name, value, color) {
		this.name = name;
		this.value = value;
		this.color = color;
	}

	function extractSets(xml) {
		var xmlData;

		if(jQuery.browser.msie){
			xmlData = new ActiveXObject("Microsoft.XMLDOM");
			xmlData.loadXML("<a>"+xml+"</a>");
		}else{
			xmlData = $("<a>"+xml+"</a>");
		}
		xml = xmlData;

		var itensChartArray = [];
		var total = 0;
		$(xml).find("set").each(function(i, item) {
			var itemChart = new ItemChart($(item).attr("name"), eval($(item).attr("value")), $(item).attr("color") );
			total = total + itemChart.value;
			itensChartArray.push(itemChart);
		});
		addItensToTable(itensChartArray, total);
	}

	function addItensToTable(itensChartArray, total) {
		var tbody = $("#tabelaChart>tbody")[0];
		$(itensChartArray).each(function(i, item) {
			var tr = $(tbody).find("tr")[0];
			var newTR = $(tr).clone();
			$(newTR).find("#cor").css('backgroundColor', '#'+item.color);
			$(newTR).find(".faixa-etaria").text(item.name);
			$(newTR).find(".quantidade").text(item.value);
			$(newTR).find(".porcentagem").text(Math.round((item.value/total) * 100) + "%");
			if (i == 0)
				$(tbody).html(newTR);
			else
				$(newTR).appendTo(tbody);
			$(newTR).show();
		});
		var trFoot = $("#tabelaChart>tfoot>tr")[0];
	    $(trFoot).find("#totalQtde").html(total);
	}

</script>


         
    
    </div>   
</div>
<div class="conteudo-right">
	<? include("lateral_view.php"); ?>
</div>
<? include("footer_view.php"); ?>