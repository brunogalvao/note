<? include("header_view.php"); ?>
    <div class="nav"> <a href="<?=site_url()?>">Home</a> / <a href="<?=site_url("pagina-restrita/17")?>"><?= $this->lang->line('beneficios') ?></a> / Nissei </div>
    <div class="conteudo-left">
      <div class="texto">
        <?= $this->lang->line('nissei') ?>    
      </div>
    </div> 
    <div class="conteudo-right">
          <? include("lateral_view.php"); ?>
  </div>
      <? include("footer_view.php"); ?>