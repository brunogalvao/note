<? include("header_view.php"); ?>
<div style="padding-top:10px; width: 1000px; height: 500px; margin:auto; text-align: center;">
    <h1 style="font-size: 40px; color:#d1cfcf;">Ops</h1>
    <p style="font-size: 20px; padding: 10px; color: #808080;"><?= $this->lang->line('pagina_nao_encontrada') ?></p>
    <p style="font-size: 12px;"><?= $this->lang->line('desculpe_a_pagina_que_voce_procura_nao_foi_encontrada_em_nosso_site') ?></p>
    </div>
<? include("footer_view.php"); ?>