<? print $this->load->view("header_view",$this->data); ?>

<div class="nav">
<a href="<?=site_url()?>">Home</a> / <a href="<?=site_url("gerarproposta")?>"><?= $this->lang->line('prospect') ?></a> / <?= $this->lang->line('nova_proposta') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
	<img src="<?=site_url()?>images/logo-prospect.png" title="Prospect"> 
		<div class="menu-proposta">
        	<a href="<?=site_url("emailproposta")?>" ><img src="<?=site_url()?>images/icons/email.png" border="0"><?= $this->lang->line('enviar_email') ?></a>
            <a href="<?=site_url("novaproposta")?>" ><img src="<?=site_url()?>images/icons/novo.png" border="0"><?= $this->lang->line('nova_proposta') ?></a>
            <a href="<?=site_url("verpropostas/1")?>" ><img src="<?=site_url()?>images/icons/propostas.png" border="0"><?= $this->lang->line('ver_propostas') ?></a>
            <a href="<?=site_url("upload/files/representante/tabela.pdf")?>" ><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabela') ?></a>
            <a href="<?=site_url("contratospropostas")?>" ><img src="<?=site_url()?>images/icons/contrato.png" border="0"><?= $this->lang->line('contrato') ?></a>
            <a href="<?=site_url("materialgraficopropostas")?>" ><img src="<?=site_url()?>images/icons/arquivos.png" border="0"><?= $this->lang->line('material_grafico') ?></a>
        </div>

	<? if(isset($msg)){ ?>
    <?= '<div class="message">'.$msg.'</div>' ?>
    <? } ?>	
<script>
		$(document).ready(function(){

			$("#form").validationEngine();

		});
		

	function consultaCnpj(){
		var cnpj = $('#cnpjconsulta').val();
		if(cnpj == ""){
				$(".msg").html("<?= $this->lang->line('digite_o_numero_do_cnpj') ?>");
			}else{
				$(".msg").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> <?= $this->lang->line('consultando_cnpj_por_favor_aguarde') ?>");
				
				jQuery.ajax({
						type: "POST",
						url: "<?=site_url("site/consultacnpj")?>",
						data: { 'cnpj': cnpj },
						success: function( data )
						{
							$(".msg").html("");
							if(data == "0"){	
								$('#cnpj').val(cnpj);						
								$("#form-proposta").fadeIn("slow");
								}else{							
									$(".msg").html(data);
								}
						
						}
				});
			}
	}
</script>	

<div class="proposta">
			<div class="consultacnpj">
                <label><?= $this->lang->line('cnpj') ?></label>
                <input type="text" name="cnpjconsulta" id="cnpjconsulta" class="validate[required] cnpj">
                <a href="javascript:consultaCnpj()" title="Consultar CNPJ" >Consultar</a>
                <div class="msg">
                	
                </div>
            </div>
    	
        	
        <div style="display:none; margin-top:15px;" id="form-proposta">
            <form method="post" id="form" name="form" action="<?=site_url()?>novaproposta" />
            
            	
            <div>
            	<label><?= $this->lang->line('cnpj') ?></label>
            	<input type="text" name="cnpj" id="cnpj" class="validate[required]" value="" readonly >
            </div>
            <? if($this->session->userdata("representante") == 1){ ?>
            	<input type="hidden" name="codvendedor" id="codvendedor" value="<?=$this->session->userdata("codigo")?>">
            <? }else{ ?>
                <div>
                    <label><?= $this->lang->line('codigo_consultor') ?></label>
                    <input type="text" name="codvendedor" id="codvendedor" class="validate[required]" value="">
                </div>
            <? } ?>
        	<div>
                <label><?= $this->lang->line('tipo_de_plano') ?></label>
                <select name="plano">
                    <option value="1"><?= $this->lang->line('superior') ?></option>
                    <option value="2"><?= $this->lang->line('avancado') ?></option>
                </select>
            </div>
            
            <div>
                <label><?= $this->lang->line('nome_da_empresa') ?></label>
                <input type="text" name="nome" id="nome" class="validate[required]">
            </div>
            <div>
                <label><?= $this->lang->line('pessoa_de_contato') ?></label>
                <input type="text" name="contato" id="contato" class="validate[required]">
            </div>
            <div>
                <label><?= $this->lang->line('telefone') ?></label>
                <input type="text" name="tel" id="tel" class="validate[required] tel">
            </div>
            <div>
                <label><?= $this->lang->line('email') ?></label>
                <input type="text" name="email" id="email" class="validate[required email]">
            </div>
            <div>
            	<span>
                    <label><?= $this->lang->line('qtd_de_vidas') ?></label>
                    <input type="text" name="qtd" id="qtd" class="validate[required]">
                </span>
                <span>
                    <label><?= $this->lang->line('taxa_de_adesao') ?></label>
                    <input type="text" name="adesao" id="adesao" class="validate[required]">
                </span>
                <span>
                    <label><?= $this->lang->line('carencia') ?></label>
                    <input type="text" name="carencia" id="carencia" >
                </span>
            </div>
            <div>
            	<span>
                    <label><?= $this->lang->line('cidade') ?></label>
                    <input type="text" name="cidade" id="cidade" class="validate[required]">
            	</span>
                <span>
                    <label><?= $this->lang->line('estado') ?></label>
                    <select name="uf">
                        <option value="AC">AC</option>
                        <option value="AL">AL</option>
                        <option value="AM">AM</option>
                        <option value="AP">AP</option>
                        <option value="BA">BA</option>
                        <option value="CE">CE</option>
                        <option value="DF">DF</option>
                        <option value="ES">ES</option>
                        <option value="GO">GO</option>
                        <option value="MA">MA</option>
                        <option value="MG">MG</option>
                        <option value="MS">MS</option>
                        <option value="MT">MT</option>
                        <option value="PA">PA</option>
                        <option value="PB">PB</option>
                        <option value="PE">PE</option>
                        <option value="PI">PI</option>
                        <option value="PR" selected>PR</option>
                        <option value="RJ">RJ</option>
                        <option value="RN">RN</option>
                        <option value="RO">RO</option>
                        <option value="RR">RR</option>
                        <option value="RS">RS</option>
                        <option value="SC">SC</option>
                        <option value="27">SE</option>
                        <option value="SE">SP</option>
                        <option value="TO">TO</option>
                 	</select> 
           		</span>
            </div>
            <div>
            <input type="submit" value="<?= $this->lang->line('gerar') ?>"  name="<?= $this->lang->line('gerar') ?>" class="btn-submit" >
			</div>
           
        </form>
        </div>
    </div> 
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? print $this->load->view("lateral_view",$this->data); ?>
</div>
<? print $this->load->view("footer_view",$this->data); ?>