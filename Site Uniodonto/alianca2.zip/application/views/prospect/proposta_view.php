<style>
	body{
		font-family: Arial, Helvetica, sans-serif;
		padding: 10px;
		}
	.texto{
		margin: 0px 70px 0px 70px;
		}
	p{
		padding: 5px;
		}
	p strong{
		color: #af2638;
		}
	h1{
		color: #af2638;	
		font-size: 18px;
	}


</style>

<? $data = explode("-",$proposta_data)?>
<? $data_validade = explode("-",$proposta_validade_contrato)?>
<div class="texto">
    <p><?=$proposta_cidade?>, <?=$data[2]?> de <?= $this->lang->line('mes'.$data[1])?> de <?=$data[0]?>.</p>
    <p><strong><?=$proposta_empresa;?></strong><br>
      Prezados Senhores,</p>
    <p>A <strong>UNIODONTO </strong>&eacute; uma sociedade cooperativa, organizada e administrada  por cirurgi&otilde;es-dentistas com a finalidade de presta&ccedil;&atilde;o de assist&ecirc;ncia  odontol&oacute;gica para empresas e fam&iacute;lias.<br>
      Nossos servi&ccedil;os abrangem todas as especialidades odontol&oacute;gicas e  s&atilde;o oferecidos atrav&eacute;s de diferentes planos, que nos permitem criar solu&ccedil;&otilde;es  adequadas &agrave;s necessidades de sua empresa.<br>
      A assist&ecirc;ncia odontol&oacute;gica oferecida pela <strong>UNIODONTO</strong> permitir&aacute; &agrave; sua empresa, desde que agregado o  benef&iacute;cio: melhores condi&ccedil;&otilde;es de negocia&ccedil;&otilde;es salariais, maior efici&ecirc;ncia e  produtividade, al&eacute;m da redu&ccedil;&atilde;o do absente&iacute;smo. <br>
      Confira a seguir a solu&ccedil;&atilde;o ideal que criamos para voc&ecirc; e sua  empresa.</p>
    <p><h1>NOSSA REDE</h1></p>
    <p style="padding-left:100px;">Mais de 130 singulares  em todo o Brasil;</p>
    <p style="padding-left:100px;">Mais de 22 mil  cirurgi&otilde;es-dentistas cooperados em todo Brasil;</p>
    <p style="padding-left:100px;">Mais de 2.5000.000  benefici&aacute;rios satisfeitos em todo Brasil.</p>
      <img style="padding-left:100px;" src="<?=site_url()?>images/pdf/nossa-rede.jpg" alt="" width="567" height="87">
    <p>&nbsp;</p>
    
    <p><h1>NOSSA ESTRUTURA</h1></p>
    <p style="padding-left:100px;"><strong>Atendimento  ao Benefici&aacute;rio</strong></p>
    <p style="padding-left:100px;">O Atendimento ser&aacute;  realizado no consult&oacute;rio particular do cirurgi&atilde;o-dentista cooperado.</p>
    
    <strong><br clear="all">
    </strong>
    <p><img src="<?=site_url()?>images/pdf/logo-clinica.jpg" alt="" width="260" height="247" align="left" style="float: left;"><strong>Atendimento de Urg&ecirc;ncia</strong><br />A Uniodonto 24 horas, &eacute;  um benef&iacute;cio direcionado aos benefici&aacute;rios que buscam atendimento de urg&ecirc;ncia a  qualquer hora do dia ou da noite, inclusive s&aacute;bados, domingo e feriados. Para  consultar a rede credenciada e clinicas, consulte o telefone listado abaixo.<br /><br />
    <img src="<?=site_url()?>images/pdf/odontomovel.jpg" alt="" width="276" height="198" align="right" style="float: right;">
    <strong>Atendimento M&oacute;vel</strong><br />Odontom&oacute;vel s&atilde;o unidades m&oacute;veis equipadas com um consult&oacute;rio  odontol&oacute;gico para a realiza&ccedil;&atilde;o de avalia&ccedil;&otilde;es bucais, al&eacute;m de a&ccedil;&otilde;es de preven&ccedil;&atilde;o  ou SIPAT.
    </p>
    
    <p><h1>SISTEMA E TECNOLOGIA</h1></p>
    <p><img src="<?=site_url()?>images/pdf/menina.jpg" alt="" width="199" height="363" style="float: left;">
    <strong>Relat&oacute;rios de Acompanhamento</strong><br />
    An&aacute;lise de atendimentos  por perfil de cooperado, tipos de atendimento, tipos de procedimento, clientes  que mais utilizam, utiliza&ccedil;&atilde;o por regi&atilde;o, an&aacute;lise financeira de receitas e  despesas, eventos abertos e realizados, entre outros, e tudo isso de forma  clara, f&aacute;cil e r&aacute;pida atrav&eacute;s do nosso site.
    <br /><br />
    <strong>Libera&ccedil;&atilde;o  Online</strong><br />
    A libera&ccedil;&atilde;o do  tratamento odontol&oacute;gico &eacute; realizada diretamente do consult&oacute;rio do  cirurgi&atilde;o-dentista, inclusive dos atos complementares, com pagamento facilitado  e possibilidade de parcelamento em at&eacute; 12x sem juros nos cart&otilde;es de cr&eacute;dito  Visa e Mastercard.
    <br /><br />
    <strong>Pesquisa  de Satisfa&ccedil;&atilde;o</strong><br />
    A Uniodonto Curitiba  disp&otilde;e de uma ferramenta m&oacute;vel e de servi&ccedil;os para atender projetos de Pesquisa  de Satisfa&ccedil;&atilde;o de Clientes para organiza&ccedil;&otilde;es &ndash; empresas e &aacute;reas &ndash; de qualquer  porte, setor e localidade, de maneira pr&aacute;tica, segura e &aacute;gil.
    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>
      <h1>INVESTIMENTO</h1>
    </p>
    <p style="padding-left:100px;">O investimento, a ser  definido na aquisi&ccedil;&atilde;o do plano escolhido, varia em raz&atilde;o da massa de  benefici&aacute;rios, domic&iacute;lio dos mesmos quando for abrang&ecirc;ncia nacional e demais  informa&ccedil;&otilde;es coletadas na empresa. </p>
    <br /><br />
    <p><strong>PR&Eacute;-PAGAMENTO &ndash; Coletivo Empresarial*</strong></p>
    <div align="center">
      <table border="0" cellspacing="5" cellpadding="0"  align="center">
        <tr bgcolor="#AF2638" valign="top">
          <td style="color:#fff; padding:10px; text-align:center;"><p align="center"><strong>Massa</strong><br>
            <strong>de Benefici&aacute;rios</strong></p></td>
          <td style="color:#fff; padding:10px; text-align:center;"><p align="center"><strong>PLANO </strong><strong><?=$proposta_plano?></strong><strong> </strong><br>
            <strong>(por    benefici&aacute;rio)</strong></p></td>
          <td style="color:#fff; padding:10px; text-align:center;"><p align="center"><strong>VALOR    DE ADES&Atilde;O</strong><br>
            <strong>(pagamento &uacute;nico)</strong></p></td>
        </tr>
        <tr>
          <td style="color:#af2638; padding:10px; text-align:center;"><p><strong>&nbsp;</strong></p>
            <p align="center"><strong><?=$proposta_qtd_vidas?></strong></p></td>
          <td style="color:#af2638; padding:10px; text-align:center;"><p><strong>&nbsp;</strong></p>
            <p align="center"><strong>R$ <?=str_replace(".",",",$proposta_valor_beneficiario)?>**</strong></p></td>
          <td style="color:#af2638; padding:10px; text-align:center;"><p><strong>&nbsp;</strong></p>
            <p align="center"><strong>R$ </strong><strong><?=$proposta_adesao?></strong></p></td>
        </tr>
      </table>
    </div>
    <div style="font-size:10px;">
    <p><strong>&nbsp; </strong><strong>*Coletivo Empresarial</strong>: inclus&atilde;o da maioria absoluta da massa populacional da  empresa.<br>
      ** Promo&ccedil;&atilde;o v&aacute;lida no per&iacute;odo de <?=$data[2]?>/<?=$data[1]?>/<?=$data[0]?> &agrave; <?=$data_validade[2]?>/<?=$data_validade[1]?>/<?=$data_validade[0]?>.<strong></strong></p>
    <p style="padding-left:100px;"><strong>Recolhimento  INSS:</strong> Em  conformidade com a Lei 9876 e Instru&ccedil;&atilde;o Normativa IN MPS/SRF n&ordm; 03 art. 291,  publicada no D.O.U. publicado em 15/07/05, dever&aacute; ser recolhido 9% de INSS  sobre o valor da fatura mensal Pr&eacute;-Pagamento.</p>
    <p style="padding-left:100px;"><strong>Recolhimento  IR:</strong> Embasamento  Legal: RIR/99, art. 652 ou art. 64 da Lei 8981/95, a reten&ccedil;&atilde;o dever&aacute; ser  realizada at&eacute; o dia 10&ordm; do m&ecirc;s subsequente. A base de c&aacute;lculo &eacute; demonstrada na  Nota Fiscal (c&aacute;lculo de 1,5% sobre a base).</p>
    </div>
    <? if($proposta_carencia != ""){?>
    <p><strong>Car&ecirc;ncia: </strong><strong><?=$proposta_carencia?></strong><br>
    <div style="font-size:10px; padding-left:100px;">
      Conforme disposto na Resolu&ccedil;&atilde;o RN n&ordm;. 195,  alterada pela RN 200, para planos de contrata&ccedil;&atilde;o coletiva empresarial, com  n&uacute;mero de participantes maior ou igual que 30 (trinta), n&atilde;o ser&aacute; permitida a  exig&ecirc;ncia de cumprimento de prazos de car&ecirc;ncia desde que o benefici&aacute;rio  formalize o pedido de ingresso ao plano contratado em at&eacute; trinta dias da  celebra&ccedil;&atilde;o do contrato coletivo, ou de sua vincula&ccedil;&atilde;o a pessoa jur&iacute;dica  contratante. J&aacute; para planos de contrata&ccedil;&atilde;o coletiva empresarial, com n&uacute;mero de  participantes menor que 30 (trinta), a cobran&ccedil;a de car&ecirc;ncias &eacute; permitida.</p>
     </div>
    
    <? }else{ ?>
    <p><strong>Car&ecirc;ncia: </strong><strong>ISENTO</strong><br>
    <? } ?>
</div>	