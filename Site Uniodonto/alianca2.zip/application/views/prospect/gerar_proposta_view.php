<? print $this->load->view("header_view",$this->data); ?>

<div class="nav">
<a href="<?=site_url()?>">Home</a> / <?= $this->lang->line('prospect') ?>
</div>
<div class="conteudo-left" style="padding-top:10px;">
    <img src="<?=site_url()?>images/logo-prospect.png" title="Prospect"> 
        <div class="menu-proposta">
        	<a href="<?=site_url("emailproposta")?>" ><img src="<?=site_url()?>images/icons/email.png" border="0"><?= $this->lang->line('enviar_email') ?></a>
            <a href="<?=site_url("novaproposta")?>" ><img src="<?=site_url()?>images/icons/novo.png" border="0"><?= $this->lang->line('nova_proposta') ?></a>
            <a href="<?=site_url("verpropostas/1")?>" ><img src="<?=site_url()?>images/icons/propostas.png" border="0"><?= $this->lang->line('ver_propostas') ?></a>
            <a href="<?=site_url("upload/files/representante/tabela.pdf")?>" ><img src="<?=site_url()?>images/icons/tabela.png" border="0"><?= $this->lang->line('tabela') ?></a>
            <a href="<?=site_url("contratospropostas")?>" ><img src="<?=site_url()?>images/icons/contrato.png" border="0"><?= $this->lang->line('contrato') ?></a>
            <a href="<?=site_url("materialgraficopropostas")?>" ><img src="<?=site_url()?>images/icons/arquivos.png" border="0"><?= $this->lang->line('material_grafico') ?></a>
        </div>
</div>
<div class="conteudo-right" style="padding-top:10px;">
	<? print $this->load->view("lateral_view",$this->data); ?>
</div>
<? print $this->load->view("footer_view",$this->data); ?>