<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Uniodonto Curitiba - Quem tem valoriza</title>
<link media="screen" href="<?= site_url()?>css/css.css" type="text/css" rel="stylesheet">

<link href="<?= site_url()?>css/input.css" rel="stylesheet" type="text/css"/>



<script type='text/javascript' src="<?= site_url()?>js/jquery-latest.js"></script>

<script type='text/javascript' src='<?= site_url()?>js/js.js'></script>


<script src="<?= site_url()?>js/jquery.mask.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>js/libs.js" type="text/javascript" charset="utf-8"></script>

<script type="text/javascript" src="<?= site_url()?>includes/slideshow/js/jquery.eislideshow.js"></script>
<script type="text/javascript" src="<?= site_url()?>includes/slideshow/js/jquery.easing.1.3.js"></script>

<script src="<?= site_url()?>js/jquery.qtip.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>js/jquery.uniform.js" type="text/javascript" charset="utf-8"></script>

    <script type="text/javascript" charset="utf-8">
      $(function(){
			$("input:text, input:checkbox, input:radio, input:file, textarea").uniform();
			$("select").uniform();
			
		});
	  

    </script>

	
<link rel="stylesheet" href="<?= site_url()?>includes/validation/css/validationEngine.jquery.css" type="text/css"/>
<script src="<?= site_url()?>includes/validation/js/languages/jquery.validationEngine-<?= $this->session->userdata("idioma") ?>.js" type="text/javascript" charset="utf-8"></script>
<script src="<?= site_url()?>includes/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
<script>
	$(document).ready(function(){

		$("#form").validationEngine();

	});
		


	
	function enviarEmail(){
	$("#status").html("<img src='<?= site_url()?>images/loading.gif' alt='Enviando' /> Enviando por favor aguarde...");
	var dados = jQuery("#form").serialize();

			jQuery.ajax({
				type: "POST",
				url: "<?=site_url("site/dadosemailproposta/".$emailto)?>",
				data: dados,
				success: function( data )
				{
					var obj = eval ("(" + data + ")"); 
					$("#status").html(obj.msg);
					
				}
		});
	}		
    </script>
</head>

<body>

<div class="proposta proposta-form-cliente"> 	
        	
        <div class="formulario">
        	<h1>Solicite uma proposta</h1>
            <form method="post" id="form" name="form" />
            <input type="hidden" name="emailto"  value="<?= $emailto ?>" >
            <div>
            	<label><?= $this->lang->line('cnpj') ?></label>
            	<input type="text" name="cnpj"  class="validate[required] cnpj" >
            </div>
          
            <div>
                <label><?= $this->lang->line('nome_da_empresa') ?></label>
                <input type="text" name="nome" id="nome" class="validate[required]">
            </div>
            <div>
                <label><?= $this->lang->line('pessoa_de_contato') ?></label>
                <input type="text" name="contato" id="contato" class="validate[required]">
            </div>
            <div>
                <label><?= $this->lang->line('telefone') ?></label>
                <input type="text" name="tel" id="tel" class="validate[required] tel">
            </div>
            <div>
                <label><?= $this->lang->line('email') ?></label>
                <input type="text" name="email" id="email" class="validate[required email]">
            </div>
            <div>
            	<span>
                    <label><?= $this->lang->line('qtd_de_vidas') ?></label>
                    <input type="text" name="qtd" id="qtd" class="validate[required]">
                </span>
            </div>
            <div>
            	<span>
                    <label><?= $this->lang->line('cidade') ?></label>
                    <input type="text" name="cidade" id="cidade" class="validate[required]">
            	</span>
                <span>
                    <label><?= $this->lang->line('estado') ?></label>
                    <select name="uf">
                        <option value="AC">AC</option>
                        <option value="AL">AL</option>
                        <option value="AM">AM</option>
                        <option value="AP">AP</option>
                        <option value="BA">BA</option>
                        <option value="CE">CE</option>
                        <option value="DF">DF</option>
                        <option value="ES">ES</option>
                        <option value="GO">GO</option>
                        <option value="MA">MA</option>
                        <option value="MG">MG</option>
                        <option value="MS">MS</option>
                        <option value="MT">MT</option>
                        <option value="PA">PA</option>
                        <option value="PB">PB</option>
                        <option value="PE">PE</option>
                        <option value="PI">PI</option>
                        <option value="PR" selected>PR</option>
                        <option value="RJ">RJ</option>
                        <option value="RN">RN</option>
                        <option value="RO">RO</option>
                        <option value="RR">RR</option>
                        <option value="RS">RS</option>
                        <option value="SC">SC</option>
                        <option value="27">SE</option>
                        <option value="SE">SP</option>
                        <option value="TO">TO</option>
                 	</select> 
           		</span>
            </div>
            <div class="bts-form">
	            <span>
	            	<input type="button" value="<?= $this->lang->line('enviar') ?>"  name="Enviar" class="btn-submit" onclick="enviarEmail()" >
	            </span>
	            <span id="status">

	            </span>
            </div>
           
        </form>
        </div>
    </div> 
</div>

</body>
</html>