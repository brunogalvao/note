<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "site";
$route['pagina/(:num)/(:any)'] = 'site/pagina/$1/$2';
$route['pagina-restrita/(:num)'] = 'site/paginaaba/$1';
$route['beneficios/(:num)'] = 'site/beneficios/$1';
$route['noticia/(:num)/(:any)'] = 'site/noticia/$1/$2';
$route['evento/(:num)'] = 'site/evento/$1';
$route['emailproposta'] = 'site/emailproposta';
$route['prospect'] = 'site/gerarproposta';
$route['materialgraficopropostas'] = 'site/materialgraficopropostas';
$route['contratospropostas'] = 'site/contratospropostas';
$route['novaproposta'] = 'site/novaproposta';
$route['verpropostas'] = 'site/verpropostas/1';
$route['verpropostas/(:num)'] = 'site/verpropostas/$1';
$route['orcamento_empresa'] = 'site/orcamento_empresa';
$route['contratar_plano'] = 'site/contratar_plano';
$route['acesso/(:any)'] = 'site/acesso/$1';
$route['clientes'] = 'site/clientes';
$route['sustentabilidade'] = 'site/sustentabilidade';
$route['relatorios/cooperado'] = 'site/relatorios_cooperado';
$route['relatorios/empresa/atendimentomes'] = 'site/relatorios_empresa_atendimentomes';
$route['relatorios/empresa/guias'] = 'site/relatorios_empresa_statusguias';
$route['relatorios/empresa/atendimentoespecialidade'] = 'site/relatorios_empresa_atendimentoespecialidade';
$route['relatorios/empresa/faturamento'] = 'site/relatorios_empresa_faturamento';
$route['relatorios/uniodonto/faturamento'] = 'site/relatorios_uniodonto_faturamento';
$route['relatorios/uniodonto/faturamentointercambio'] = 'site/relatorios_uniodonto_faturamentointercambio';
$route['relatorios/uniodonto/qtbeneficiarios'] = 'site/relatorios_uniodonto_qtbeneficiarios';
$route['beneficiario/(:any)'] = 'site/links_beneficiario/$1';
$route['empresa/(:any)'] = 'site/links_empresa/$1';
$route['dentista/(:any)'] = 'site/links_dentista/$1';
$route['uniodonto/(:any)'] = 'site/links_uniodonto/$1';
$route['colaborador/(:any)'] = 'site/links_colaborador/$1';
$route['representante/(:any)'] = 'site/links_representante/$1';
$route['calendario'] = 'site/calendario';
$route['tabeladeatos/(:num)'] = 'site/tabeladeatos/$1';
$route['tabeladeatos2013/(:num)'] = 'site/tabeladeatos2013/$1';
$route['video'] = 'site/video';
$route['arquivos'] = 'site/arquivos';
$route['login'] = 'site/login';
$route['logout'] = 'site/logout';
$route['contato'] = 'site/contato';
$route['revisaovalores'] = 'site/revisaovalores';
$route['revista'] = 'site/revista';
$route['encontreseudentista'] = 'site/encontreseudentista';
$route['analise'] = 'site/analise';
$route['historico'] = 'site/historico';
$route['busca/(:num)'] = 'site/busca/$1';
$route['busca'] = 'site/busca';
$route['historico/(:num)'] = 'site/historico/$1';
$route['trabalheconosco/colaborador'] = 'site/trabalheconoscocolaborador';
$route['trabalheconosco/dentista'] = 'site/trabalheconoscodentista';
$route['retorna_estados/(:num)'] = 'site/retorna_estados/$1';
$route['retorna_especialidades'] = 'site/retorna_especialidades';
$route['localizacao'] = 'site/localizacao';
$route['admin'] = 'admin/login';
$route['admin/logout'] = 'admin/logout';
$route['admin/home'] = 'admin/home';
$route['admin/usuarios'] = 'admin/usuarios/index/1';
$route['admin/menus'] = 'admin/menus/index/1';
$route['admin/noticias'] = 'admin/noticias/index/1';
$route['admin/textos'] = 'admin/textos/index/1';
$route['admin/textos_abas'] = 'admin/textos_abas/index/1';
$route['admin/textos_abas/adicionar/(:any)'] = 'admin/textos_abas/adicionar/$1';
$route['admin/links_abas'] = 'admin/links_abas/index/1';
$route['admin/links_abas/adicionar/(:any)'] = 'admin/links_abas/adicionar/$1';
$route['admin/planos'] = 'admin/planos/index/1';
$route['admin/limparpesquisa/(:any)'] = 'admin/limparpesquisa/index/$1';
$route['admin/banners'] = 'admin/banners/index/1';
$route['admin/relatoriopropostas'] = 'admin/propostas/relatorio/index/1';
$route['admin/localizacao'] = 'admin/localizacao';

$route['rx'] = 'rx/login';

$route['alianca'] = 'alianca/site';
$route['alianca/plano'] = 'alianca/site/plano';
$route['alianca/urgencia'] = 'alianca/site/urgencia';
$route['alianca/tabela'] = 'alianca/site/tabela';
$route['alianca/perguntas'] = 'alianca/site/perguntas';
$route['alianca/contato'] = 'alianca/site/contato';
$route['alianca/contratar'] = 'alianca/site/contratar';
$route['alianca/formulario'] = 'alianca/site/formulario';
$route['alianca/encontreseudentista'] = 'alianca/site/encontreseudentista';


$route['404_override'] = 'site/naoencontrada';
$route['sitemap\.xml'] = "site/sitemap";



/* End of file routes.php */
/* Location: ./application/config/routes.php */