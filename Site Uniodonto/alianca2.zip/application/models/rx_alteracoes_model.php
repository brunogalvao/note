<?php
class rx_alteracoes_model extends CI_Model {

	function get_rx_alteracoes(){
		$this->db->order_by("rx_alteracoes_id", "desc"); 
		$query = $this->db->get('rx_alteracoes');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}

	function add_record($options = array()){
		$this->db->insert('rx_alteracoes', $options);
  		return  $this->db->insert_id()  ;
	}
  
	function update_record($options = array()){
		$this->db->where('rx_alteracoes_id', $options['rx_alteracoes_id']);
		$this->db->update('rx_alteracoes', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('rx_alteracoes_id', $id);
		$this->db->delete('rx_alteracoes');
		return $this->db->affected_rows();
	}
  
	
	function get_by_id($id){
		$this->db->where("rx_alteracoes_rx_id",$id);
		$query = $this->db->get("rx_alteracoes");
		return $query->row(0);
		}
	
	function get_by_rx($id){
		$this->db->order_by("rx_alteracoes_id", "desc"); 
		$this->db->where("rx_alteracoes_rx_id",$id);
		$query = $this->db->get("rx_alteracoes");
		return $query->result();
		}
		
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("rx_alteracoes_id", "desc");
		if(isset($pesquisa['rx_alteracoes_id']) != ""){
			$this->db->where('rx_alteracoes_id',$pesquisa['rx_alteracoes_id']);
			}
		
		$this->db->limit($limit, $start);
		$query = $this->db->get('rx_alteracoes');
		
		return $query->result();

		
		}
	function count_rx_alteracoes($pesquisa){
		if(isset($pesquisa['rx_alteracoes_id']) != ""){
			$this->db->where('rx_alteracoes_id',$pesquisa['rx_alteracoes_id']);
			}
			
		$query = $this->db->get('rx_alteracoes');
        return $query->num_rows();
	} 	

		

}