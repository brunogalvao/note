<?php
class sys_permissoes_model extends CI_Model {

	function get_permissao($options){

		if(isset($options['id_metodo'])){
			$this->db->where('id_metodo',$options['id_metodo']);
			}
		if(isset($options['id_usuario'])){
			$this->db->where('id_usuario',$options['id_usuario']);
			}	
	
		$query = $this->db->get('sys_permissoes');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('sys_permissoes', $options);
		return $this->db->affected_rows();
	}
  
	function delete_record($id){
		$this->db->where('permissao_id', $id);
		$this->db->delete('sys_permissoes');
		return $this->db->affected_rows();
	}
	
	function delete_permissao($id){
		$this->db->where('id_usuario', $id);
		$this->db->delete('sys_permissoes');
		return $this->db->affected_rows();
	}
	
	
		

}