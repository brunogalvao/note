<?php
class formata_nome_model extends CI_Model {

	function formataNome($var){
	$acentos = array(
			'a' => '/À|Á|Â|Ã|Ä|Å/',
			'a' => '/à|á|â|ã|ä|å/',
			'c' => '/Ç/',
			'c' => '/ç/',
			'e' => '/È|É|Ê|Ë/',
			'e' => '/è|é|ê|ë/',
			'i' => '/Ì|Í|Î|Ï/',
			'i' => '/ì|í|î|ï/',
			'n' => '/Ñ/',
			'n' => '/ñ/',
			'o' => '/Ò|Ó|Ô|Õ|Ö/',
			'o' => '/ò|ó|ô|õ|ö/',
			'u' => '/Ù|Ú|Û|Ü/',
			'u' => '/ù|ú|û|ü/',
			'y' => '/Ý/',
			'y' => '/ý|ÿ/',
			'a.' => '/ª/',
			'o.' => '/º/'
	);
	$var = preg_replace($acentos, array_keys($acentos), $var);
	$var = strtolower($var);
	return $var;
}
}