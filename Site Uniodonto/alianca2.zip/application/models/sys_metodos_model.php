<?php
class sys_metodos_model extends CI_Model {

	function get_metodos(){
		$this->db->order_by("apelido", "asc"); 
		$query = $this->db->get('sys_metodos');
		
		return $query->result();
	}
	
	
		

}