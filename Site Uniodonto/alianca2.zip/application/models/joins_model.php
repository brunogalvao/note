<?php
class joins_model extends CI_Model {

	function get_links_abas_and_textos_abas($pesquisa){
		$this->db->select('texto_aba_id, texto_aba_titulo_'.$this->session->userdata("idioma").', texto_aba_menu');
		$this->db->order_by("texto_aba_titulo_".$this->session->userdata("idioma"), "asc"); 
		$this->db->where('texto_aba_aba',$pesquisa);
		$query = $this->db->get('textos_abas');
		$result["texto"] = $query->result_array();
		
		$this->db->select('link_aba_titulo_'.$this->session->userdata("idioma").', link_aba_menu, link_aba_link');
		$this->db->order_by("link_aba_aba", "asc"); 
		$this->db->where('link_aba_aba',$pesquisa);
		$query = $this->db->get('links_abas');
		$result["links"]= $query->result_array();
		
		return $result;

	}
	
	function pesquisa($pesquisa,$limit, $start){
		$this->db->select('noticia_id as id, noticia_titulo_'.$this->session->userdata("idioma").' as titulo, noticia_texto_'.$this->session->userdata("idioma").' as texto, noticia_tipo as tipo');
		$this->db->like('noticia_titulo_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->or_like('noticia_texto_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->limit($limit, $start);
		$query = $this->db->get('noticias');
		$result[] = $query->result_array();
		
		$this->db->select('texto_id as id, texto_titulo_'.$this->session->userdata("idioma").' as titulo, texto_texto_'.$this->session->userdata("idioma").' as texto, texto_tipo as tipo');
		$this->db->like('texto_titulo_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->or_like('texto_texto_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->limit($limit, $start);
		$query = $this->db->get('textos');
		$result[] = $query->result_array();
		
		$resultado = array_merge($result[0],$result[1]);
		
		return $resultado;
		

	}

	function count_pesquisa($pesquisa){
		$this->db->select('noticia_id as id, noticia_titulo_'.$this->session->userdata("idioma").' as titulo, noticia_texto_'.$this->session->userdata("idioma").' as texto, noticia_tipo as tipo');
		$this->db->like('noticia_titulo_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->or_like('noticia_texto_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$query = $this->db->get('noticias');
		$result[] = $query->result_array();
		
		$this->db->select('texto_id as id, texto_titulo_'.$this->session->userdata("idioma").' as titulo, texto_texto_'.$this->session->userdata("idioma").' as texto, texto_tipo as tipo');
		$this->db->like('texto_titulo_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$this->db->or_like('texto_texto_'.$this->session->userdata("idioma"),$pesquisa['busca']);
		$query = $this->db->get('textos');
		$result[] = $query->result_array();
		
		$resultado = array_merge($result[0],$result[1]);
		return count($resultado);
	}
	 
}