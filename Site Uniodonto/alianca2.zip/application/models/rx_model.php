<?php
class rx_model extends CI_Model {

	function get_rx(){
		$this->db->order_by("rx_id", "desc"); 
		$query = $this->db->get('rx');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}

	function add_record($options = array()){
		$this->db->insert('rx', $options);
  		return  $this->db->insert_id()  ;
	}
  
	function update_record($options = array()){
		$this->db->where('rx_id', $options['rx_id']);
		$this->db->update('rx', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('rx_id', $id);
		$this->db->delete('rx');
		return $this->db->affected_rows();
	}
  
	
	function get_by_id($id){
		$this->db->where("rx_id",$id);
		$query = $this->db->get("rx");
		return $query->row(0);
		}
	
	
	function get_by_cod_lote($cod, $lote){

		$this->db->where("rx_cod",$cod);
		$this->db->where("rx_lote",$lote);
		$query = $this->db->get("rx");
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
		}
		
	function get_all($pesquisa, $limit, $start) {
		
		$this->db->order_by("rx_id", "desc");
		if(isset($pesquisa['rx_id']) != ""){
			$this->db->where('rx_id',$pesquisa['rx_id']);
			}
		if(isset($pesquisa['rx_cod']) != ""){
			$this->db->where('rx_cod',$pesquisa['rx_cod']);
			}
		if(isset($pesquisa['rx_lote']) != ""){
			$this->db->where('rx_lote',$pesquisa['rx_lote']);
			}	
		if(isset($pesquisa['rx_cro']) != ""){
			$this->db->where('rx_cro',$pesquisa['rx_cro']);
			}
		if(isset($pesquisa['rx_nome']) != ""){
			$this->db->like('rx_nome',$pesquisa['rx_nome']);
			}
		if(isset($pesquisa['rx_guia']) != ""){
			$this->db->where('rx_guia',$pesquisa['rx_guia']);
			}
		
		if(isset($pesquisa['data_saida_menor']) != ""){
			$this->db->where('data_saida_menor >=',$pesquisa['rx_data_saida']);
			}
		if(isset($pesquisa['data_saida_maior']) != ""){
			$this->db->where('data_saida_maior <=',$pesquisa['rx_data_saida']);
			}
		
		if(isset($pesquisa['data_producao_menor']) != ""){
			$this->db->where('data_producao_menor >=',$pesquisa['rx_data_producao']);
			}
		if(isset($pesquisa['data_producao_maior']) != ""){
			$this->db->where('data_producao_maior <=',$pesquisa['rx_data_producao']);
			}
			
		if(isset($pesquisa['data_entrega_menor']) != ""){
			$this->db->where('data_entrega_menor >=',$pesquisa['rx_data_entrega']);
			}
		if(isset($pesquisa['data_entrega_maior']) != ""){
			$this->db->where('data_entrega_maior <=',$pesquisa['rx_data_entrega']);
			}
			
		$this->db->limit($limit, $start);
		$query = $this->db->get('rx');
		
		return $query->result();

		
		}
	function count_rx($pesquisa){
		if(isset($pesquisa['rx_id']) != ""){
			$this->db->where('rx_id',$pesquisa['rx_id']);
			}
		if(isset($pesquisa['rx_cod']) != ""){
			$this->db->where('rx_cod',$pesquisa['rx_cod']);
			}
		if(isset($pesquisa['rx_lote']) != ""){
			$this->db->where('rx_lote',$pesquisa['rx_lote']);
			}	
		if(isset($pesquisa['rx_cro']) != ""){
			$this->db->where('rx_cro',$pesquisa['rx_cro']);
			}
		if(isset($pesquisa['rx_nome']) != ""){
			$this->db->like('rx_nome',$pesquisa['rx_nome']);
			}
		if(isset($pesquisa['rx_guia']) != ""){
			$this->db->where('rx_guia',$pesquisa['rx_guia']);
			}
		
		if(isset($pesquisa['data_saida_menor']) != ""){
			$this->db->where('data_saida_menor >=',$pesquisa['rx_data_saida']);
			}
		if(isset($pesquisa['data_saida_maior']) != ""){
			$this->db->where('data_saida_maior <=',$pesquisa['rx_data_saida']);
			}
		
		if(isset($pesquisa['data_producao_menor']) != ""){
			$this->db->where('data_producao_menor >=',$pesquisa['rx_data_producao']);
			}
		if(isset($pesquisa['data_producao_maior']) != ""){
			$this->db->where('data_producao_maior <=',$pesquisa['rx_data_producao']);
			}
			
		if(isset($pesquisa['data_entrega_menor']) != ""){
			$this->db->where('data_entrega_menor >=',$pesquisa['rx_data_entrega']);
			}
		if(isset($pesquisa['data_entrega_maior']) != ""){
			$this->db->where('data_entrega_maior <=',$pesquisa['rx_data_entrega']);
			}
			
		$query = $this->db->get('rx');
        return $query->num_rows();
	} 	
	
	function relatorio_rx_mes_aberto($mes,$ano){
		$this->db->select("count(rx_data_saida) as qt");
		$this->db->group_by("EXTRACT(MONTH FROM rx_data_saida), EXTRACT(YEAR FROM rx_data_saida)");
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) =',$mes);
		$this->db->where('EXTRACT(YEAR FROM rx_data_saida) =',$ano);
		
		
		$query = $this->db->get("rx");
		$result['qt'] = $query->num_rows();
		$result['row'] = $query->row(0);
		return $result;
		}
	function relatorio_rx_mes_producao($mes,$ano){
		$this->db->select("count(rx_data_producao) as qt");
		$this->db->group_by("EXTRACT(MONTH FROM rx_data_producao), EXTRACT(YEAR FROM rx_data_producao)");
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_producao) =',$mes);
		$this->db->where('EXTRACT(YEAR FROM rx_data_producao) =',$ano);
		
		
		$query = $this->db->get("rx");
		$result['qt'] = $query->num_rows();
		$result['row'] = $query->row(0);
		return $result;
		}
	function relatorio_rx_mes_concluido($mes,$ano){
		$this->db->select("count(rx_data_entrega) as qt");
		$this->db->group_by("EXTRACT(MONTH FROM rx_data_entrega), EXTRACT(YEAR FROM rx_data_entrega)");
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_entrega) =',$mes);
		$this->db->where('EXTRACT(YEAR FROM rx_data_entrega) =',$ano);
		
		
		$query = $this->db->get("rx");
		$result['qt'] = $query->num_rows();
		$result['row'] = $query->row(0);
		return $result;
		}
	
	function relatorio_rx_mes_total_aberto($mes_inicio,$mes_fim,$ano){
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) >=',$mes_inicio);
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) <=',$mes_fim);
		$this->db->where('EXTRACT(YEAR FROM rx_data_saida) =',$ano);
		
		$query = $this->db->get("rx");
		return $query->num_rows();
		}
	function relatorio_rx_mes_total_producao($mes_inicio,$mes_fim,$ano){
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) >=',$mes_inicio);
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) <=',$mes_fim);
		$this->db->where('EXTRACT(YEAR FROM rx_data_saida) =',$ano);
		$this->db->where('rx_data_producao <>','0000-00-00');
		
		$query = $this->db->get("rx");
		return $query->num_rows();
		}
	function relatorio_rx_mes_total_concluido($mes_inicio,$mes_fim,$ano){
				
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) >=',$mes_inicio);
		$this->db->where('EXTRACT(MONTH FROM rx_data_saida) <=',$mes_fim);
		$this->db->where('EXTRACT(YEAR FROM rx_data_saida) =',$ano);
		$this->db->where('rx_data_producao <>','0000-00-00');
		$this->db->where('rx_data_entrega <>','0000-00-00');
		
		$query = $this->db->get("rx");
		return $query->num_rows();
		}

		

}