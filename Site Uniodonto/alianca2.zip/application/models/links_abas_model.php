<?php
class links_abas_model extends CI_Model {

	function get_links_abas(){
		$this->db->order_by("link_aba_id", "asc"); 
		$query = $this->db->get('links_abas');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function pesquisa_links_abas($pesquisa){
		
		if(isset($pesquisa['link_aba_titulo_ptBR'])){
			$this->db->order_by("link_aba_titulo_ptBR", "asc"); 
			$this->db->like('link_aba_titulo_ptBR',$pesquisa['link_aba_titulo_ptBR']);
			}
		if(isset($pesquisa['link_aba_titulo_en'])){
			$this->db->order_by("link_aba_titulo_en", "asc"); 
			$this->db->like('link_aba_titulo_en',$pesquisa['link_aba_titulo_en']);
			}
		if(isset($pesquisa['link_aba_titulo_es'])){
			$this->db->order_by("link_aba_titulo_es", "asc"); 
			$this->db->like('link_aba_titulo_es',$pesquisa['link_aba_titulo_es']);
			}
		if(isset($pesquisa['link_aba_menu'])){
			$this->db->where('link_aba_menu',$pesquisa['link_aba_menu']);
			}	
		if(isset($pesquisa['link_aba_aba'])){
			$this->db->where('link_aba_aba',$pesquisa['link_aba_aba']);
			}	
		if(isset($pesquisa['link_aba_link'])){
			$this->db->where('link_aba_link',$pesquisa['link_aba_link']);
			}
		$query = $this->db->get('links_abas');
		return $query->result();
	}
	function add_record($options = array()){
		$this->db->insert('links_abas', $options);
		return $this->db->affected_rows();
	}
 	function delete_record($id){
		$this->db->where('link_aba_id', $id);
		$this->db->delete('links_abas');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['link_aba_titulo_ptBR'])){
			$this->db->set('link_aba_titulo_ptBR',$options['link_aba_titulo_ptBR']);
			}
		if(isset($options['link_aba_titulo_en'])){
			$this->db->set('link_aba_titulo_en',$options['link_aba_titulo_en']);
			}
		if(isset($options['link_aba_titulo_es'])){
			$this->db->set('link_aba_titulo_es',$options['link_aba_titulo_es']);
			}
		if(isset($options['link_aba_menu'])){
			$this->db->set('link_aba_menu',$options['link_aba_menu']);
			}	
		if(isset($options['link_aba_aba'])){
			$this->db->set('link_aba_aba',$options['link_aba_texto']);
			}	
		if(isset($options['link_aba_link'])){
			$this->db->set('link_aba_link',$options['link_aba_link']);
			}
					
		$this->db->where('link_aba_id',$options['link_aba_id']);
		$this->db->update('links_abas');		
		
		return $this->db->affected_rows();
		
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("link_aba_id",$id);
		$query = $this->db->get("links_abas");
		return $query->row(0);
		}

		
	function get_all($pesquisa, $limit, $start) {
		
		if(isset($pesquisa['link_aba_titulo'])){
			$this->db->like('link_aba_titulo_ptBR',$pesquisa['link_aba_titulo']);
			}

		if(isset($pesquisa['link_aba_menu'])){
			$this->db->where('link_aba_menu',$pesquisa['link_aba_menu']);
			}	
		if(isset($pesquisa['link_aba_aba'])){
			$this->db->where('link_aba_aba',$pesquisa['link_aba_aba']);
			}	
		if(isset($pesquisa['link_aba_link'])){
			$this->db->where('link_aba_link',$pesquisa['link_aba_link']);
			}	
		$this->db->limit($limit, $start);
		$query = $this->db->get('links_abas');
		return $query->result();
		}
	function count_links_abas($pesquisa){
		if(isset($pesquisa['link_aba_titulo'])){
			$this->db->like('link_aba_titulo_ptBR',$pesquisa['link_aba_titulo']);
			}
		if(isset($pesquisa['link_aba_menu'])){
			$this->db->where('link_aba_menu',$pesquisa['link_aba_menu']);
			}
		if(isset($pesquisa['link_aba_aba'])){
			$this->db->where('link_aba_aba',$pesquisa['link_aba_aba']);
			}	
		if(isset($pesquisa['link_aba_link'])){
			$this->db->where('link_aba_link',$pesquisa['link_aba_link']);
			}	
		$query = $this->db->get('links_abas');
        return $query->num_rows();
} 
}