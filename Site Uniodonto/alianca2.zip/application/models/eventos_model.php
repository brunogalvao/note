<?php
class eventos_model extends CI_Model {

	function get_eventos(){
		$this->db->order_by("evento_inicio", "desc"); 
		$query = $this->db->get('eventos');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function pesquisa_eventos($options){
		$this->db->order_by("evento_inicio", "asc");  
		if(isset($options['evento_titulo_ptBR'])){
			$this->db->like('evento_titulo_ptBR',$options['evento_titulo_ptBR']);
			}
		if(isset($options['evento_aba'])){
			$this->db->where('evento_aba',$options['evento_aba']);
			}
		if(isset($options['evento_aba2'])){
			$this->db->or_where('evento_aba',$options['evento_aba2']);
			}		
		if(isset($options['evento_inicio'])){
			$this->db->where('evento_inicio',$options['evento_inicio']);
			}	
		if(isset($options['evento_fim'])){
			$this->db->where('evento_fim',$options['evento_fim']);
			}
		if(isset($options['evento_inicio_maior'])){
			$this->db->where('evento_inicio >',$options['evento_inicio_maior']);
			}	
		if(isset($options['evento_fim_menor'])){
			$this->db->where('evento_fim <',$options['evento_fim_menor']);
			}
		$query = $this->db->get('eventoss');	
		if($options['tipo'] == "array"){
			return $query->result_array();
			}else{
				return $query->result();
				}	
		
		
	}
	function add_record($options = array()){
		$this->db->insert('eventos', $options);
		return $this->db->affected_rows();
	}
 	function delete_record($id){
		$this->db->where('evento_id', $id);
		$this->db->delete('eventos');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['evento_titulo_ptBR'])){
			$this->db->set('evento_titulo_ptBR',$options['evento_titulo_ptBR']);
			}
		if(isset($options['evento_titulo_en'])){
			$this->db->set('evento_titulo_en',$options['evento_titulo_en']);
			}	
		if(isset($options['evento_titulo_es'])){
			$this->db->set('evento_titulo_es',$options['evento_titulo_es']);
			}
		if(isset($options['evento_aba'])){
			$this->db->set('evento_aba',$options['evento_aba']);
			}	
		if(isset($options['evento_inicio'])){
			$this->db->set('evento_inicio',$options['evento_inicio']);
			}	
		if(isset($options['evento_fim'])){
			$this->db->set('evento_fim',$options['evento_fim']);
			}	
		if(isset($options['evento_link'])){
			$this->db->set('evento_link',$options['evento_link']);
			}
		if(isset($options['evento_corbg'])){
			$this->db->set('evento_corbg',$options['evento_corbg']);
			}	
		if(isset($options['evento_corfont'])){
			$this->db->set('evento_corfont',$options['evento_corfont']);
			}	
		if(isset($options['evento_desc'])){
			$this->db->set('evento_desc',$options['evento_desc']);
			}
		if(isset($options['evento_texto_ptBR'])){
			$this->db->set('evento_texto_ptBR',$options['evento_texto_ptBR']);
			}
		if(isset($options['evento_texto_en'])){
			$this->db->set('evento_texto_en',$options['evento_texto_en']);
			}
		if(isset($options['evento_texto_es'])){
			$this->db->set('evento_texto_es',$options['evento_texto_es']);
			}	
					
		$this->db->where('evento_id',$options['evento_id']);
		$this->db->update('eventos');		
		
		return $this->db->affected_rows();
		
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("evento_id",$id);
		$query = $this->db->get("eventos");
		return $query->row(0);
		}
	
	function get_by_id_array($id){
		$this->db->where("evento_id",$id);
		$query = $this->db->get("eventos");
		return $query->result_array(0);
		}	

		
	function get_all($options, $limit, $start) {
		$this->db->order_by("evento_inicio", "desc"); 
		if(isset($options['evento_titulo'])){
			$this->db->like('evento_titulo_ptBR',$options['evento_titulo']);
			}
		if(isset($options['evento_titulo'])){
			$this->db->or_like('evento_titulo_en',$options['evento_titulo']);
			}
		if(isset($options['evento_titulo'])){
			$this->db->or_like('evento_titulo_es',$options['evento_titulo']);
			}
		if(isset($options['evento_inicio']) and !empty($options['evento_inicio'])){
			$this->db->where('evento_inicio',$options['evento_inicio']);
			}	
		if(isset($options['evento_fim']) and !empty($options['evento_fim'])){
			$this->db->where('evento_fim',$options['evento_fim']);
			}	
		if(isset($options['evento_link'])){
			$this->db->where('evento_link',$options['evento_link']);
			}
		if(isset($options['evento_corbg'])){
			$this->db->where('evento_corbg',$options['evento_corbg']);
			}	
		if(isset($options['evento_corfont'])){
			$this->db->where('evento_corfont',$options['evento_corfont']);
			}		
		$this->db->limit($limit, $start);
		$query = $this->db->get('eventos');
		return $query->result();
		}
	function count_eventos($options){
		$this->db->order_by("evento_inicio", "desc"); 
		if(isset($options['evento_titulo'])){
			$this->db->like('evento_titulo_ptBR',$options['evento_titulo']);
			}
		if(isset($options['evento_titulo'])){
			$this->db->or_like('evento_titulo_en',$options['evento_titulo']);
			}	
		if(isset($options['evento_titulo'])){
			$this->db->or_like('evento_titulo_es',$options['evento_titulo']);
			}
		if(isset($options['evento_inicio']) and !empty($options['evento_inicio'])){
			$this->db->where('evento_inicio',$options['evento_inicio']);
			}	
		if(isset($options['evento_fim']) and !empty($options['evento_fim'])){
			$this->db->where('evento_fim',$options['evento_fim']);
			}	
		if(isset($options['evento_link'])){
			$this->db->where('evento_link',$options['evento_link']);
			}
		if(isset($options['evento_corbg'])){
			$this->db->where('evento_corbg',$options['evento_corbg']);
			}	
		if(isset($options['evento_corfont'])){
			$this->db->where('evento_corfont',$options['evento_corfont']);
			}	
		$query = $this->db->get('eventos');
        return $query->num_rows();
	} 
}