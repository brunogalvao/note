<?php
class planos_model extends CI_Model {

	function get_planos(){
		$query = $this->db->get('planos');
		
		$result['qt'] = $query->num_rows();
		$result['rows'] = $query->result();
		return $result;
	}
	function add_record($options = array()){
		$this->db->insert('planos', $options);
		return $this->db->affected_rows();
	}
  
	function update_planos($options = array()){
		$this->db->where('plano_id', $options['plano_id']);
		$this->db->update('planos', $options);
		return $this->db->affected_rows();
	}
	function delete_record($id){
		$this->db->where('plano_id', $id);
		$this->db->delete('planos');
		return $this->db->affected_rows();
	}
  
	
	function update_record($options = array()){
		
		if(isset($options['plano_preco'])){
			$this->db->set('plano_preco',$options['plano_preco']);
			}
			
		$this->db->where('plano_id',$options['plano_id']);
		$this->db->update('planos');		
		return $this->db->affected_rows();	
		
		}	
		
		
	function get_by_id($id){
		$this->db->where("plano_id",$id);
		$query = $this->db->get("planos");
		return $query->row(0);
		}

	function pesquisa_planos($pesquisa){
		if (isset($pesquisa["plano_tipo"])) {
			$this->db->where('plano_tipo',$pesquisa["plano_tipo"]);
		}
		if (isset($pesquisa["plano_pagamento"])) {
		$this->db->where('plano_pagamento',$pesquisa["plano_pagamento"]);
		}
		if (isset($pesquisa["plano_modalidade"])) {
		$this->db->where('plano_modalidade',$pesquisa["plano_modalidade"]);
		}
		if (isset($pesquisa["plano_qtd"])) { 
		$this->db->where('plano_qtd',$pesquisa["plano_qtd"]);
		}

		$query = $this->db->get('planos');
		return $query->result();
	}
		
	function get_all($pesquisa, $limit, $start) {
	
		if (isset($pesquisa["plano_tipo"])) {
			$this->db->where('plano_tipo',$pesquisa["plano_tipo"]);
		}
		if (isset($pesquisa["plano_pagamento"])) {
		$this->db->where('plano_pagamento',$pesquisa["plano_pagamento"]);
		}
		if (isset($pesquisa["plano_modalidade"])) {
		$this->db->where('plano_modalidade',$pesquisa["plano_modalidade"]);
		}
		if (isset($pesquisa["plano_qtd"])) { 
		$this->db->where('plano_qtd',$pesquisa["plano_qtd"]);
		}

		$this->db->limit($limit, $start);
		$query = $this->db->get('planos');
		return $query->result();
		}
	function count_planos($pesquisa){
		if (isset($pesquisa["plano_tipo"])) {
			$this->db->where('plano_tipo',$pesquisa["plano_tipo"]);
		}
		if (isset($pesquisa["plano_pagamento"])) {
		$this->db->where('plano_pagamento',$pesquisa["plano_pagamento"]);
		}
		if (isset($pesquisa["plano_modalidade"])) {
		$this->db->where('plano_modalidade',$pesquisa["plano_modalidade"]);
		}
		if (isset($pesquisa["plano_qtd"])) { 
		$this->db->where('plano_qtd',$pesquisa["plano_qtd"]);
		}

		$query = $this->db->get('planos');
        return $query->num_rows();
} 
}