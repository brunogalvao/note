<?php 
header("location:http://192.168.1.55/uniodonto/clientes/");
print_r();
print "<br />";
print_r($_SERVER['REQUEST_URI']);


?>