<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Menus extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			$pesquisa = $this->input->post('pesquisa');
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->menus_model->count_menu($pesquisa);
		$config['base_url'] = site_url() . 'admin/menus/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->menus_model->count_menu($pesquisa);
		$this->data['menus'] = $this->menus_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/menus_view', $this->data);
        
    }
	
	function limpar_pesquisa(){
		
		$this->session->unset_userdata('pesquisa');
		redirect('admin/menus/','refresh');
		}
	
	public function adicionar(){
		if($_POST){
			
		$this->form_validation->set_rules('menu_titulo', 'menu_titulo', 'trim|required|min_length[2]');
		if($this->form_validation->run()){
				$dados_query = array(
					'menu_id' => "",
					'menu_titulo' => $this->input->post('menu_titulo'),
					'menu_status' => $this->input->post('menu_status'),
					'menu_pai' => $this->input->post('menu_pai'),
					'menu_link' => $this->input->post('menu_link'),
					'menu_pagina' => $this->input->post('menu_pagina')

				);
				
				//cadastra o menue recebe o id
				$id = $this->menus_model->add_record($dados_query);
						
				//Volta para a página inicial de menus
				$this->session->set_flashdata('msg', 'Menu cadastrado com sucesso!');					
				redirect('admin/menus/index/1','refresh');
						
									
				
			
					
				}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect('admin/menus/adicionar/','refresh');
							}
			}
		$query = array("menu_pai" => 0);	
		$data['menus_pai'] = $this->menus_model->pesquisa_menus($query);	
		$this->load->view('admin/add_menus_view',$data);
		
		
		}
		
		//Função para excluir Menu de acordo com id informado
		public function excluir($id){
				
		$resultado = $this->menus_model->delete_record($id);
		if($resultado != 0){
			$this->session->set_flashdata('msg', 'Menu excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Menu não pode ser excluído!');
				}
		redirect(base_url().'admin/menus/index/1');	
		}
		
		public function editar($id){
			
			
			if($_POST){
			
				$this->form_validation->set_rules('menu_titulo', 'menu_titulo', 'trim|required|min_length[2]');
				
				if($this->form_validation->run()){
						$dados_query = array(
							'menu_id' => $this->input->post('menu_id'),
							'menu_titulo' => $this->input->post('menu_titulo'),
							'menu_pai' => $this->input->post('menu_pai'),
							'menu_status' => $this->input->post('menu_status'),
							'menu_link' => $this->input->post('menu_link'),
							'menu_pagina' => $this->input->post('menu_pagina')
		
						);
						
						//atualiza menu e recebe o id
						$id = $this->menus_model->update_record($dados_query);
						//Volta para a página inicial de menus
						$this->session->set_flashdata('msg', 'Menu editado com sucesso!');					
						redirect(base_url().'admin/menus/index/1');
								
						}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect(base_url().'admin/menus/editar/'.$this->input->post('menu_id'));
							}
			}
		$data["menu"] = $this->menus_model->get_by_id($id);	
		$query = array("menu_pai" => 0, "id_menu_ativo" => $id);	
		$data['menus_pai'] = $this->menus_model->pesquisa_menus($query);
		$this->load->view('admin/edit_menus_view',$data);
		}
}
