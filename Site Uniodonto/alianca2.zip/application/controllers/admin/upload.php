<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Upload extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
			
		
        
    }
	
	public function arquivosupload() {
		$data['link'] = 'includes/kcfinder/browse.php?type=files&lang=pt-br&theme=oxygen" frameborder="0" width="1000" height="100%" style="height: 523px;" ';	
		$data["titulo"] ="Enviar arquivos";
		$data["texto"] ='Os arquivos dentro das pastas Benefici&aacute;rio, Dentista, Empresa, Representante, Uniodonto s&atilde;o restritos e somente ap&oacute;s fazer o login &eacute; poss&iacute;vel visualizar.<br />Para acessar os arquivos utilize o seguinte link http://www.uniodontocuritiba.com.br/curitiba/upload/files/(&quot;Pasta e nome do arquivo&quot;)<br /><br />';
		$this->load->view('admin/upload_view', $data);
        
    }
	
	public function clientes() {
			
		$data['link'] = 'includes/kcfinder/browse.php?type=clientes&lang=pt-br&theme=oxygen" frameborder="0" width="1000" height="100%" style="height: 523px;" ';	
		$data["titulo"] ="Clientes";
		$data["texto"] = "As logos de clientes devem ter o tamanho de 75x50px <br /><br />";
		$this->load->view('admin/upload_view', $data);
        
    }

	
	
}
