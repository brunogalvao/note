<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Revistas extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			$pesquisa["revista_titulo"] = htmlentities($this->input->post('revista_titulo'), ENT_QUOTES, "UTF-8");
			
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->revistas_model->count_revistas($pesquisa);
		$config['site_url'] = site_url() . 'admin/revistas/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$data['qt'] = $this->revistas_model->count_revistas($pesquisa);
		$data['revistas'] = $this->revistas_model->get_all($pesquisa, $config['per_page'], $pag);
		$data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/revistas_view', $data);
        
    }
	
	// funçăo adicionar revista
	public function adicionar(){
		
	
		if($_POST){
			
		$this->form_validation->set_rules('revista_titulo', 'revista_titulo', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
			
			if($_FILES["capa"] ["error"] == 0 ){		
				$config['upload_path'] = "./upload/revistas/";
				$field_name = "capa";
				$config['allowed_types'] = 'gif|jpg|png';
				$config['remove_spaces'] = TRUE;
				$config['encrypt_name'] = TRUE;
				$config['overwrite'] = FALSE;
				$config['max_size']	= '0';
				$this->upload->initialize($config);
					if ( ! $this->upload->do_upload($field_name)){
							$this->session->set_flashdata('msg', 'Erro ao incluir imagem! Tente novamente');
							redirect(site_url().'admin/revista');
						}else{
										$dados_upload = $this->upload->data();
										$config['image_library'] = 'gd2';
										$config['source_image'] = $dados_upload['full_path'];
										$config['create_thumb'] = FALSE;
										$config['maintain_ratio'] = FALSE;
										$config['width'] = 120;
										$config['height'] = 170;
										$config['quality'] = 100;
										$this->image_lib->initialize($config);
										$this->image_lib->resize();
										$img_final = 'upload/revistas/'.$dados_upload['file_name'];
										
										
								}
					}else{
						$img_final = "";
						}
					
					if($_FILES["pdf"] ){
									
						$config['upload_path'] = "./upload/revistas/";
						$field_name = "pdf";
						$config['allowed_types'] = "pdf";
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '0';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$pdf = 'upload/revistas/'.$dados_upload['file_name'];
						

						
						}else{
							
							$pdf = "";
						}
						
						
						
					$dados_query = array(
									"revista_id" => "",
									"revista_titulo" => htmlentities($this->input->post("revista_titulo"), ENT_QUOTES, "UTF-8"),
									"revista_pdf" => $pdf,
									"revista_capa" => $img_final 
				
								);
								
								
					//cadastra revista e recebe o id
					$id = $this->revistas_model->add_record($dados_query);
									
					//Volta para a página inicial de revistas
					$this->session->set_flashdata('msg', 'Revista cadastrada com sucesso!');					
					redirect('admin/revistas/','refresh');
					
				}else{
					$this->session->set_flashdata('msg', 'É necessário adicionar um título a este revista!');
					redirect('admin/revistas/adicionar/','refresh');
				}
			}
		
		$this->load->view('admin/add_revista_view');
		
		
		}
		
		public function editar($id){
			$revista = $this->revistas_model->get_by_id($id);
			if($_POST){
			$this->form_validation->set_rules('revista_titulo', 'revista_titulo', 'trim|required|min_length[3]');
			
			if($this->form_validation->run()){
				if($_FILES["capa"] ["error"] == 0 ){	
					@unlink("./".$revista->revista_capa);
					$config['upload_path'] = "./upload/revistas/";
					$field_name = "capa";
					$config['allowed_types'] = 'gif|jpg|png';
					$config['remove_spaces'] = TRUE;
					$config['encrypt_name'] = TRUE;
					$config['overwrite'] = FALSE;
					$config['max_size']	= '0';
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload($field_name)){
								$this->session->set_flashdata('msg', 'Erro ao incluir imagem! Tente novamente');
								redirect('admin/revistas/editar/'.$id,'refresh');
							}else{
											$dados_upload = $this->upload->data();
											$config['image_library'] = 'gd2';
											$config['source_image'] = $dados_upload['full_path'];
											$config['create_thumb'] = FALSE;
											$config['maintain_ratio'] = FALSE;
											$config['width'] = 120;
											$config['height'] = 170;
											$config['quality'] = 100;
											$this->image_lib->initialize($config);
											$this->image_lib->resize();
											
											$img_final = 'upload/revistas/'.$dados_upload['file_name'];
										}
				}else{
					
					$img_final = $revista->revista_capa;
				}
				
				if($_FILES["pdf"] ){
						$config['upload_path'] = "./upload/revistas/";
						$field_name = "pdf";
						$config['allowed_types'] = 'docx|doc|pdf';
						$config['remove_spaces'] = TRUE;
						$config['encrypt_name'] = TRUE;
						$config['overwrite'] = FALSE;
						$config['max_size']	= '0';
						$this->upload->initialize($config);
						$this->upload->do_upload($field_name);
						$dados_upload = $this->upload->data();
						$pdf = 'upload/revistas/'.$dados_upload['file_name'];
						}else{
							
							$pdf = $revista->revista_pdf;
						}
				//FIM UPLOAD IMAGENS
			
			
			$dados_query = array(
					"revista_id" => $id,
					"revista_titulo" => htmlentities($this->input->post("revista_titulo"), ENT_QUOTES, "UTF-8"),
					"revista_capa" => $img_final,
					"revista_pdf" => $pdf 
					
					

				);
								
				//cadastra revista e recebe o id
				$id = $this->revistas_model->update_record($dados_query);
				
				//Volta para a página inicial de revistas
				$this->session->set_flashdata('msg', 'Revista alterada com sucesso!');					
				redirect('admin/revistas/editar/'.$dados_query["revista_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este revista!');
							redirect('admin/revistas/editar/'.$id,'refresh');
							}
			}				
			
					
		$data['revista'] = $this->revistas_model->get_by_id($id);
		
		$this->load->view('admin/edit_revista_view',$data);
		}
		
		//Funçăo para excluir revista de acordo com id informado
		public function excluir($id){
		$revista = 	$this->revistas_model->get_by_id($id);
		
		$resultado = $this->revistas_model->delete_record($id);
		if($resultado != 0){
			
			@unlink("./".$revista->revista-img);
			
			$this->session->set_flashdata('msg', 'revista excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'revista năo pode ser excluído!');
				}
		redirect(site_url().'admin/revistas/index/1');	
		}
}
