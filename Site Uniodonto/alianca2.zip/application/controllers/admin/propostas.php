<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class propostas extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
		
    }
    
    public function index() {
		
		$pesquisa['datade'] = date('Y-m-d', strtotime("-30 days"));
		$pesquisa['dataate'] = date('Y-m-d');
		$data['propostas_mes'] = $this->proposta_model->count_propostas($pesquisa); 
		
		$pesquisa['datade'] = date('Y-m-d', strtotime("-7 days"));
		$pesquisa['dataate'] = date('Y-m-d');
		$data['propostas_semana'] = $this->proposta_model->count_propostas($pesquisa);
		
		$pesquisa['datade'] = date('Y-m-d');
		$pesquisa['dataate'] = date('Y-m-d');
    	$data['propostas_hoje'] = $this->proposta_model->count_propostas($pesquisa);  
		
		$data['ranking'] = $this->proposta_model->propostas_por_representantes();
		
		$this->load->view("admin/home_propostas_view",$data);  
        
    }
	public function relatorio() {

        if($_POST){
			if($_POST['proposta_n'] != ""){
				$pesquisa['proposta_n'] = $_POST['proposta_n'];
				}
			if($_POST['cod_rep'] != ""){
				$pesquisa['proposta_cod_rep'] = $_POST['cod_rep'];
				}	
			if($_POST['nome_rep'] != ""){
				$pesquisa['proposta_nome_rep'] = $_POST['nome_rep'];
				}
			if($_POST['cod_consultor'] != ""){
				$pesquisa['proposta_cod_consultor'] = $_POST['cod_consultor'];
				}	
			if($_POST['nome_consultor'] != ""){
				$pesquisa['proposta_nome_consultor'] = $_POST['nome_consultor'];
				}	
			if($_POST['datade'] != ""){
				$datade = explode("/",$_POST['datade']);
				$pesquisa['datade'] = $datade[2]."-".$datade[1]."-".$datade[0];
				}
			if($_POST['dataate'] != ""){
				$dataate = explode("/",$_POST['dataate']);
				$pesquisa['dataate'] = $dataate[2]."-".$dataate[1]."-".$dataate[0];
				}
			if($_POST['validadede'] != ""){
				$validadede = explode("/",$_POST['validadede']);
				$pesquisa['validadede'] = $validadede[2]."-".$validadede[1]."-".$validadede[0];
				}
			if($_POST['validadeate'] != ""){
				$validadeate = explode("/",$_POST['validadeate']);
				$pesquisa['validadeate'] = $validadeate[2]."-".$validadeate[1]."-".$validadeate[0];
				}		
			if($_POST['empresa'] != ""){
				$pesquisa['proposta_empresa'] = $_POST['empresa'];
				}
			if($_POST['cnpj'] != ""){
				$pesquisa['proposta_cnpj'] = $_POST['cnpj'];
				}
			if($_POST['email'] != ""){
				$pesquisa['proposta_email'] = $_POST['email'];
				}
			if($_POST['cidade'] != ""){
				$pesquisa['proposta_cidade'] = $_POST['cidade'];
				}
			if($_POST['uf'] != ""){
				$pesquisa['proposta_uf'] = $_POST['uf'];
				}

			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
	
		$config['total_rows'] = $this->proposta_model->count_propostas($pesquisa);
		$config['base_url'] = site_url() . 'admin/relatoriopropostas/completo/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$data['qt'] = $this->proposta_model->count_propostas($pesquisa);
		$data['propostas'] = $this->proposta_model->get_all($pesquisa, $config['per_page'], $pag);
		$data['paginacao'] = $this->pagination->create_links();
		$this->load->view("admin/relatorio_propostas_view",$data);
        
    }
}