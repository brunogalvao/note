<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class links_abas extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index($pagina) {
		
		if($_POST){
			$pesquisa["link_aba_titulo"] = htmlentities($this->input->post('link_aba_titulo'), ENT_QUOTES, "UTF-8");
			$pesquisa["link_aba_aba"] = $this->input->post('aba');
			$this->session->set_userdata("pesquisa",$pesquisa);	
			
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->links_abas_model->count_links_abas($pesquisa);
		$config['base_url'] = site_url() . 'admin/links_abas/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->links_abas_model->count_links_abas($pesquisa);
		$this->data['links_abas'] = $this->links_abas_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/links_abas_view', $this->data);
        
    }
	
	// funçăo adicionar link
	public function adicionar($pagina){
		if($_POST){
			
		$this->form_validation->set_rules('link_aba_titulo_ptBR', 'link_aba_titulo_ptBR', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
						
				$dados_query = array(
					"link_aba_id" => "",
					"link_aba_titulo_ptBR" =>  htmlentities($this->input->post("link_aba_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"link_aba_titulo_en" =>  htmlentities($this->input->post("link_aba_titulo_en"), ENT_QUOTES, "UTF-8"),
					"link_aba_titulo_es" =>  htmlentities($this->input->post("link_aba_titulo_es"), ENT_QUOTES, "UTF-8"),
					"link_aba_aba" => $this->input->post("link_aba_aba"),
					"link_aba_menu" => $this->input->post("link_aba_menu"),
					"link_aba_link" => $this->input->post("link_aba_link")

				);
				
				
				//cadastra link e recebe o id
				$id = $this->links_abas_model->add_record($dados_query);
						
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Link cadastrado com sucesso!');					
				redirect('admin/links_abas/','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este link!');
							redirect('admin/links_abas/adicionar/','refresh');
							}
			}
		if($pagina == "beneficiario"){
			
			$data["menus_link"] = '<option value="1">Você benefici&aacute;rio</option>
									<option value="2">Como utilizar seu plano</option>';
			}
		if($pagina == "empresa"){
			$data["menus_link"] = '<option value="1">Sistema Unioweb</option>
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Relat&oacute;rios</option>';
			}
		if($pagina == "dentista"){
			$data["menus_link"] = '<option value="1">A Uniodonto e voc&ecirc;</option>	
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Tabelas</option>
									<option value="4">Fique por dentro</option>
									<option value="5">Manuais</option>';
			}
		if($pagina == "uniodonto"){
			$data["menus_link"] = '<option value="1">A Uniodonto e você</option>	
									<option value="2">Sistema Unioweb</option>
									<option value="3">Relatórios</option>';
			}
		if($pagina == "colaborador"){
			$data["menus_link"] = '<option value="1">Fique por dentro</option>
									<option value="2">Formul&aacute;rios</option>
									<option value="3">Recursos humanos</option>
									<option value="4">Odontom&oacute;vel</option>
									<option value="5">Processo seletivo</option>';
			}
		if($pagina == "representante"){
			$data["menus_link"] = '<option value="1">An&aacute;lise Cr&iacute;tica</option>
									<option value="2">Contrato</option>
									<option value="3">Marketing</option>';
			}
		
		
		$data["link_aba_aba"] = $pagina;
		$this->load->view('admin/add_links_abas_view',$data);
		
		
		}
		
				
		//Funçăo para excluir link de acordo com id informado
		public function excluir($id){
		$link = 	$this->links_abas_model->get_by_id($id);
		
		$resultado = $this->links_abas_model->delete_record($id);
		if($resultado != 0){
			$this->session->set_flashdata('msg', 'link excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'link năo pode ser excluído!');
				}
		redirect(base_url().'admin/links_abas/index/1');	
		}
		
		public function editar($id){
		
			if($_POST){
			$this->form_validation->set_rules('link_aba_titulo_ptBR', 'link_aba_titulo_ptBR', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
			
				
			$link = $this->links_abas_model->get_by_id($id);
			$dados_query = array(
					"link_aba_id" => $id,
					"link_aba_titulo_ptBR" =>  htmlentities($this->input->post("link_aba_titulo_ptBR"), ENT_QUOTES, "UTF-8"),
					"link_aba_titulo_en" =>  htmlentities($this->input->post("link_aba_titulo_en"), ENT_QUOTES, "UTF-8"),
					"link_aba_titulo_es" =>  htmlentities($this->input->post("link_aba_titulo_es"), ENT_QUOTES, "UTF-8"),
					"link_aba_menu" => $this->input->post("link_aba_menu"),
					"link_aba_link" => $this->input->post("link_aba_link")
					
					

				);
							
				//cadastra link e recebe o id
				$id = $this->links_abas_model->update_record($dados_query);
				
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Link atualizado com sucesso!');					
				redirect('admin/links_abas/editar/'.$dados_query["link_aba_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este link!');
							redirect('admin/links_abas/editar/'.$id,'refresh');
							}
			}				
			
		$data['link'] = $this->links_abas_model->get_by_id($id);
		$pagina = $data['link']->link_aba_aba;	
		if($pagina == "beneficiario"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Você benefici&aacute;rio</option>';
			
			$data["menus_link"] .= '<option value="2"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Como utilizar seu plano</option>';	
			}
		if($pagina == "empresa"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Sistema Unioweb</option><option value="2"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Formul&aacute;rios</option>';
			$data["menus_link"] .= '<option value="3"';
			if($data['link']->link_aba_menu == 3){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Relat&oacute;rios</option>';
			}
		if($pagina == "dentista"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>A Uniodonto e Voc&ecirc;</option>';
						
			$data["menus_link"] .= '<option value="2"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Formul&aacute;rios</option>';
			
			$data["menus_link"] .= '<option value="3"';
			if($data['link']->link_aba_menu == 3){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Tabelas</option>';
			
			$data["menus_link"] .= '<option value="4"';
			if($data['link']->link_aba_menu == 4){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Fique por dentro</option>';
			
			$data["menus_link"] .= '<option value="5"';
			if($data['link']->link_aba_menu == 5){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Manuais</option>';
			}
		
		if($pagina == "uniodonto"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>A Uniodonto e você</option>	
									<option value="2" ';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Formul&aacute;rios</option>
									<option value="3" ';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Fique por dentro</option>';
			}
		if($pagina == "colaborador"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Fique por dentro</option>';
			$data["menus_link"] .= '<option value="2"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Formul&aacute;rios</option>';
			$data["menus_link"] .= '<option value="3"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}						
			$data["menus_link"] .= '>Recursos humanos</option>';
			$data["menus_link"] .= '<option value="4"';
			if($data['link']->link_aba_menu == 3){
				$data["menus_link"] .= ' selected ';
				}						
			$data["menus_link"] .= '>Odontom&oacute;vel</option>';
			$data["menus_link"] .= '<option value="5"';
			if($data['link']->link_aba_menu == 5){
				$data["menus_link"] .= ' selected ';
				}						
			$data["menus_link"] .= '>Processo seletivo</option>';
			}
		if($pagina == "representante"){
			$data["menus_link"] = '<option value="1"';
			if($data['link']->link_aba_menu == 1){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>An&aacute;lise Cr&iacute;tica</option>';
			$data["menus_link"] .= '<option value="2"';
			if($data['link']->link_aba_menu == 2){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Contrato</option>';
			$data["menus_link"] .= '<option value="3"';
			if($data['link']->link_aba_menu == 3){
				$data["menus_link"] .= ' selected ';
				}
			$data["menus_link"] .= '>Marketing</option>';
			
			}	
					
		$data["link_aba_aba"] = $pagina;
		$this->load->view('admin/edit_links_abas_view',$data);
		}
	
}
