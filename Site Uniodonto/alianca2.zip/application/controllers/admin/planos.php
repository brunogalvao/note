<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Planos extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			if($this->input->post('plano_tipo') != ""){
				$pesquisa["plano_tipo"] = $this->input->post('plano_tipo');	
			}
			if($this->input->post('plano_pagamento') != ""){
				$pesquisa["plano_pagamento"] = $this->input->post('plano_pagamento');	
			}
			if($this->input->post('plano_modalidade') != ""){
				$pesquisa["plano_modalidade"] = $this->input->post('plano_modalidade');	
			}
			
			
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->planos_model->count_planos($pesquisa);
		$config['base_url'] = site_url() . 'admin/planos/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->planos_model->count_planos($pesquisa);
		$this->data['planos'] = $this->planos_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/planos_view', $this->data);
        
    }
	
	
	public function editar($id){
		
			if($_POST){
			$this->form_validation->set_rules('plano_preco', 'plano_preco', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
			
				
			$link = $this->planos_model->get_by_id($id);
			$dados_query = array(
					"plano_id" => $id,
					"plano_preco" => $this->input->post("plano_preco")					
					

				);
							
				//cadastra link e recebe o id
				$id = $this->planos_model->update_record($dados_query);
				
				//Volta para a página inicial de notícias
				$this->session->set_flashdata('msg', 'Plano atualizado com sucesso!');					
				redirect('admin/planos/','refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um valor a este plano!');
							redirect('admin/planos/editar/'.$id,'refresh');
							}
			}				
			
		$data["plano"] =	$this->planos_model->get_by_id($id);	
		$this->load->view('admin/edit_planos_view',$data);
		}
      
 
	
}