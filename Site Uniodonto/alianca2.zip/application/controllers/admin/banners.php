<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Banners extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			
			if($this->input->post('banner_titulo') != ""){
				$pesquisa["banner_titulo"] = htmlentities($this->input->post('banner_titulo'), ENT_QUOTES, "UTF-8");	
			}
			if($this->input->post('banner_status') != ""){
				$pesquisa["banner_status"] = $this->input->post('banner_status');	
			}
			if($this->input->post('aba') != ""){
				$pesquisa[$this->input->post('aba')] = 1;
			}
			
			
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->banners_model->count_banners($pesquisa);
		$config['base_url'] = site_url() . 'admin/banners/index/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$data['qt'] = $this->banners_model->count_banners($pesquisa);
		$data['banners'] = $this->banners_model->get_all($pesquisa, $config['per_page'], $pag);
		$data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/banners_view', $data);
		
		
        
    }
	

		
	// funçăo adicionar banner
	public function adicionar(){
		
	
		if($_POST){
			
		$this->form_validation->set_rules('banner_titulo', 'banner_titulo', 'trim|required|min_length[3]');
		
		if($this->form_validation->run()){
			if($_FILES["img"] ["error"] == 0 ){		
				$config['upload_path'] = "./images/banners/";
				$field_name = "img";
				$config['allowed_types'] = 'gif|jpg|png';
				$config['remove_spaces'] = TRUE;
				$config['encrypt_name'] = TRUE;
				$config['overwrite'] = FALSE;
				$config['max_size']	= '100000';
				$this->upload->initialize($config);
					if ( ! $this->upload->do_upload($field_name)){
							$this->session->set_flashdata('msg', 'Erro ao incluir imagem! Tente novamente');
							redirect(site_url().'admin/banner');
						}else{
										$dados_upload = $this->upload->data();
										$config['image_library'] = 'gd2';
										$config['source_image'] = $dados_upload['full_path'];
										$config['create_thumb'] = FALSE;
										$config['maintain_ratio'] = FALSE;
										$config['width'] = 1000;
										$config['height'] = 300;
										$config['quality'] = 100;
										$this->image_lib->initialize($config);
										$this->image_lib->resize();
										
										$img_final = 'images/banners/'.$dados_upload['file_name'];
										
										
								}
					}else{
						$img_final = "";
						}
					$dados_query = array(
									"banner_id" => "",
									"banner_titulo" => $this->input->post("banner_titulo"),
									"banner_idioma" => $this->input->post("banner_idioma"),
									"banner_link" => $this->input->post("banner_link"),
									"banner_status" => $this->input->post("banner_status"),
									"banner_home" => $this->input->post("banner_home"),
									"banner_beneficiario" => $this->input->post("banner_beneficiario"),
									"banner_empresa" => $this->input->post("banner_empresa"),
									"banner_dentista" => $this->input->post("banner_dentista"),
									"banner_uniodonto" => $this->input->post("banner_uniodonto"),
									"banner_colaborador" => $this->input->post("banner_colaborador"),
									"banner_representante" => $this->input->post("banner_representante"),
									"banner_img" => $img_final 
				
								);
								
								
					//cadastra banner e recebe o id
					$id = $this->banners_model->add_record($dados_query);
									
					//Volta para a página inicial de banners
					$this->session->set_flashdata('msg', 'Banner cadastrado com sucesso!');					
					redirect('admin/banners/','refresh');
					
				}else{
					$this->session->set_flashdata('msg', 'É necessário adicionar um título a este banner!');
					redirect('admin/banners/adicionar/','refresh');
				}
			}
		
		$this->load->view('admin/add_banner_view');
		
		
		}
		
		public function editar($id){
			$banner = $this->banners_model->get_by_id($id);
			if($_POST){
			$this->form_validation->set_rules('banner_titulo', 'banner_titulo', 'trim|required|min_length[3]');
		
			if($this->form_validation->run()){
				if($_FILES["img"] ["error"] == 0 ){	
					@unlink("./".$banner->banner_img);
					$config['upload_path'] = "./images/banners/";
					$field_name = "img";
					$config['allowed_types'] = 'gif|jpg|png';
					$config['remove_spaces'] = TRUE;
					$config['encrypt_name'] = TRUE;
					$config['overwrite'] = FALSE;
					$config['max_size']	= '100000';
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload($field_name)){
								$this->session->set_flashdata('msg', 'Erro ao incluir imagem! Tente novamente');
								redirect('admin/banners/editar/'.$id,'refresh');
							}else{
											$dados_upload = $this->upload->data();
											$config['image_library'] = 'gd2';
											$config['source_image'] = $dados_upload['full_path'];
											$config['create_thumb'] = FALSE;
											$config['maintain_ratio'] = FALSE;
											$config['width'] = 1000;
											$config['height'] = 300;
											$config['quality'] = 100;
											$this->image_lib->initialize($config);
											$this->image_lib->resize();
											
											$img_final = 'images/banners/'.$dados_upload['file_name'];
										}
				}
				//FIM UPLOAD IMAGENS
			
			
			$dados_query = array(
					"banner_id" => $id,
					"banner_titulo" => $this->input->post("banner_titulo"),
					"banner_idioma" => $this->input->post("banner_idioma"),
					"banner_link" => $this->input->post("banner_link"),
					"banner_status" => $this->input->post("banner_status"),
					"banner_home" => $this->input->post("banner_home"),
					"banner_beneficiario" => $this->input->post("banner_beneficiario"),
					"banner_empresa" => $this->input->post("banner_empresa"),
					"banner_dentista" => $this->input->post("banner_dentista"),
					"banner_uniodonto" => $this->input->post("banner_uniodonto"),
					"banner_colaborador" => $this->input->post("banner_colaborador"),
					"banner_representante" => $this->input->post("banner_representante"),
					"banner_img" => $img_final 
					
					

				);
								
				//cadastra banner e recebe o id
				$id = $this->banners_model->update_record($dados_query);
				
				//Volta para a página inicial de banners
				$this->session->set_flashdata('msg', 'Banner alterado com sucesso!');					
				redirect('admin/banners/editar/'.$dados_query["banner_id"],'refresh');
						
									
					
			
					
				}else{
							$this->session->set_flashdata('msg', 'É necessário adicionar um título a este banner!');
							redirect('admin/banners/editar/'.$id,'refresh');
							}
			}				
			
					
		$data['banner'] = $this->banners_model->get_by_id($id);
		
		$this->load->view('admin/edit_banner_view',$data);
		}
		
		//Funçăo para excluir banner de acordo com id informado
		public function excluir($id){
		$banner = 	$this->banners_model->get_by_id($id);
		
		$resultado = $this->banners_model->delete_record($id);
		if($resultado != 0){
			
			@unlink("./".$banner->banner-img);
			
			$this->session->set_flashdata('msg', 'Banner excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Banner năo pode ser excluído!');
				}
		redirect(site_url().'admin/banners/index/1');	
		}
}
