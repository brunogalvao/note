<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Usuarios extends CI_Controller {
    
    function __construct() {
        parent::__construct();
        $this->auth->check_logged($this->router->class , $this->router->method);
    }
    
    public function index() {
		
		if($_POST){
			$pesquisa["user"] = $this->input->post('pesquisa');
			$this->session->set_userdata("pesquisa",$pesquisa);	
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
		
		$config['total_rows'] = $this->usuarios_model->count_user($pesquisa);
		$config['base_url'] = site_url() . 'admin/usuarios/index/';
		$config['per_page'] = '12';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$this->data['qt'] = $this->usuarios_model->count_user($pesquisa);
		$this->data['usuarios'] = $this->usuarios_model->get_all($pesquisa, $config['per_page'], $pag);
		$this->data['paginacao'] = $this->pagination->create_links();
		$this->load->view('admin/usuarios_view', $this->data);
        
    }
	
	
	public function adicionar(){
		if($_POST){
			
		$this->form_validation->set_rules('user_nome', 'user_nome', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('user_email', 'user_email', 'trim|required|valid_email');
		$this->form_validation->set_rules('user_senha', 'user_senha', 'trim|required|max_length[10]|min_length[3]');
		if($this->form_validation->run()){
				$dados_query = array(
					'user_id' => "",
					'user_nome' => $this->input->post('user_nome'),
					'user_email' => $this->input->post('user_email'),
					'user_senha' => $this->input->post('user_senha'),
					'user_status' => 1

				);
				
				//Verifica se o email já esta cadastrado
				$query['email'] = $this->input->post('user_email');
				$qt_emails = $this->usuarios_model->get_by_email($query);
				if($qt_emails["qt"] != 0){
					
					$this->session->set_flashdata('msg', 'E-mail já cadastrado no sistema!');
					redirect('admin/usuarios/adicionar/','refresh');
					}else{
						//cadastra usuario e recebe o id
						$id = $this->usuarios_model->add_record($dados_query);
						
						foreach($_POST["metodo"] as $id_metodo){
							$permissao = array("id_metodo" => $id_metodo, "id_usuario" => $id );
							$this->sys_permissoes_model->add_record($permissao);
		
						}
						
							//Volta para a página inicial de usuários
							$this->session->set_flashdata('msg', 'Usuário cadastrado com sucesso!');					
							redirect('admin/usuarios/index/1','refresh');
						
									
					}
			
					
				}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect('admin/usuarios/adicionar/','refresh');
							}
			}
		$data['metodos'] = $this->sys_metodos_model->get_metodos();
		$this->load->view('admin/add_usuarios_view', $data);
		
		
		}
		
		//Função para excluir usuário de acordo com id informado
		public function excluir($id){
				
		$resultado = $this->usuarios_model->delete_record($id);
		if($resultado != 0){
			$this->session->set_flashdata('msg', 'Usuário excluído com sucesso!');
			
			}else{
				$this->session->set_flashdata('msg', 'Usuário não pode ser excluído!');
				}
		redirect(base_url().'admin/usuarios/index/1');	
		}
		
		public function editar($id){
			
			
			if($_POST){
			
				$this->form_validation->set_rules('user_nome', 'user_nome', 'trim|required|min_length[3]');
				$this->form_validation->set_rules('user_email', 'user_email', 'trim|required|valid_email');
				$this->form_validation->set_rules('user_senha', 'user_senha', 'trim|required|max_length[10]|min_length[3]');
				if($this->form_validation->run()){
						$dados_query = array(
							'user_id' => $this->input->post('user_id'),
							'user_nome' => $this->input->post('user_nome'),
							'user_email' => $this->input->post('user_email'),
							'user_senha' => $this->input->post('user_senha'),
							'user_status' => 1
		
						);
						$query['id'] = $this->input->post('user_id');
						$query['email'] = $this->input->post('user_email');
						$emailcad = $this->usuarios_model->get_by_email($query);
						
						//Verifica se o email já esta cadastrado
						if($emailcad['qt'] == 0){
							//cadastra usuario e recebe o id
									$this->usuarios_model->update_record($dados_query);
									$this->sys_permissoes_model->delete_permissao($id);
									foreach($_POST["metodo"] as $id_metodo){
										$permissao = array("id_metodo" => $id_metodo, "id_usuario" => $id );
										$this->sys_permissoes_model->add_record($permissao);
					
									}
									//Volta para a página inicial de usuários
									$this->session->set_flashdata('msg', 'Usuário editado com sucesso!');					
									redirect(base_url().'admin/usuarios/index/1');
							}
							
						if($emailcad['rows']->user_id != $this->input->post('user_id')){
							
							$this->session->set_flashdata('msg', 'E-mail já cadastrado no sistema!');
							redirect(base_url().'admin/usuarios/editar/'.$this->input->post('user_id'));
							}else{
								//cadastra usuario e recebe o id
								$this->usuarios_model->update_record($dados_query);
								
								$this->sys_permissoes_model->delete_permissao($id);
								foreach($_POST["metodo"] as $id_metodo){
									$permissao = array("id_metodo" => $id_metodo, "id_usuario" => $id );
									$this->sys_permissoes_model->add_record($permissao);
				
								}
								//Volta para a página inicial de usuários
								$this->session->set_flashdata('msg', 'Usuário editado com sucesso!');					
								redirect(base_url().'admin/usuarios/editar/'.$this->input->post('user_id'));
									
								
											
							}
					
							
						}else{
							$this->session->set_flashdata('msg', 'Preencha todos os campos!');
							redirect(base_url().'admin/usuarios/editar/'.$this->input->post('user_id'));
							}
			}	
		$data['usuario'] = $this->usuarios_model->get_by_id($id);
		$data['metodos'] = $this->sys_metodos_model->get_metodos();
		
		$this->load->view('admin/edit_usuarios_view',$data);
		}
}
