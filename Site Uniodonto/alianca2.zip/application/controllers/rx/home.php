<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller {
    
    function __construct() {
        parent::__construct();
		$this->auth->check_logged($this->router->class , $this->router->method, $this->uri->segment(1));		
    }
    
    public function index() {

        $this->load->view('rx/home_view');
        
    }
	
}