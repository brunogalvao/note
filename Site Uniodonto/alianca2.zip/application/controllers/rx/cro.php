<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class cro extends CI_Controller {
    
    function __construct() {
        parent::__construct();
		$this->auth->check_logged($this->router->class , $this->router->method, $this->uri->segment(1));		
    }
    
    public function index() {
		
        $cro = $_POST['cro'];
		$uf = $_POST['uf'];
		$cadastro_dentista = json_decode(file_get_contents( "http://sio.uniodontocuritiba.com.br/Uniodonto/BuscaDadosCirurgiaoDentistaSiteServlet?tipo=C&cro=".$cro."&uf=".$uf."&status=0"));	
		
		if($cadastro_dentista->statusBusca == TRUE){
			print json_encode($cadastro_dentista);
			}else{
				$cadastro_dentista = json_decode(file_get_contents( "http://sio.uniodontocuritiba.com.br/Uniodonto/BuscaDadosCirurgiaoDentistaSiteServlet?tipo=F&cro=".$cro."&uf=".$uf."&status=0"));
				if($cadastro_dentista->statusBusca == TRUE){
					print json_encode($cadastro_dentista);
					}else{
						$cadastro_dentista = json_decode(file_get_contents( "http://sio.uniodontocuritiba.com.br/Uniodonto/BuscaDadosCirurgiaoDentistaSiteServlet?tipo=J&cro=".$cro."&uf=".$uf."&status=0"));
						if($cadastro_dentista->statusBusca == TRUE){
							print json_encode($cadastro_dentista);
							}else{
								print json_encode(array("statusBusca"=>false));
							}
					}
			}
			
        
    }
	

	
}