<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class lote extends CI_Controller {
    
    function __construct() {
        parent::__construct();
		$this->auth->check_logged($this->router->class , $this->router->method, $this->uri->segment(1));		
    }
    
    public function index() {
		if($_POST){
		
			$pesquisa = array_filter($_POST);
			
			}else{
				$pesquisa = $this->session->userdata('pesquisa');
				}
			
		$config['total_rows'] = $this->rx_qtd_model->count_rx_qtd($pesquisa);
		$config['base_url'] = site_url() . 'rx/lote/index/';
		$config['per_page'] = '20';
		$config['uri_segment'] = '4';
		$config['first_link'] = "<<";
		$config['last_link'] = ">>";
		$pag = ($this->uri->segment(4) * $config['per_page']) - $config['per_page'];
			if($pag < 0){
				$pag = 0;
			}
		$this->pagination->initialize($config);
		$data['qt'] = $this->rx_qtd_model->count_rx_qtd($pesquisa);
		$data['lotes'] = $this->rx_qtd_model->get_all($pesquisa, $config['per_page'], $pag);
		$data['paginacao'] = $this->pagination->create_links();
        $this->load->view('rx/lote_view',$data);		        
    }
	
	public function adicionar() {
		
		if($_POST){
			$this->form_validation->set_rules('lote', 'lote', 'required');
			$this->form_validation->set_rules('inicio', 'inicio', 'required');
			$this->form_validation->set_rules('fim', 'fim', 'required');
				
			if($this->form_validation->run()){
				if($this->input->post("fim") < $this->input->post("inicio") or $this->input->post("fim") == $this->input->post("inicio")){
					$this->session->set_flashdata('msg', "O n&uacute;mero final deve ser maior que o inicial");
					redirect('rx/lote/adicionar','refresh');
				}else{
					
					
					$dados_query = array(
							"rx_qtd_lote" => $this->input->post("lote"),
							"rx_qtd" => $this->input->post("fim") - $this->input->post("inicio"),
							"rx_qtd_inicio" => $this->input->post("inicio"),
							"rx_qtd_fim" => $this->input->post("fim"),
							"rx_qtd_data" => date("Y-m-d"),

						);
					$qt = $this->rx_qtd_model->confere_lote($dados_query);
					if($qt == 0){	
						$id[] = $this->rx_qtd_model->add_record($dados_query);
						redirect('rx/lote/','refresh');
						}else{
							$this->session->set_flashdata('msg', "Valor j&aacute; cadastrados em outro lote");
							redirect('rx/lote/adicionar','refresh');
							}
				}
			}else{
				$this->session->set_flashdata('msg', "Preencha todos os campos");
				redirect('rx/lote/adicionar','refresh');
				}

				
			}
			
			$this->load->view('rx/adicionar_lote_view');
		
		
		}
	
	public function editar() {
		
		
		}
	
	public function excluir($id) {
		$qt = $this->rx_model->count_rx(array("rx_lote" => $id));
		if($qt == 0){
			$result = $this->rx_qtd_model->delete_record($id);
			if($result == 0){
				$this->session->set_flashdata('msg', "N&atilde;o foi poss&iacute;vel excluir o lote tente novamente!");
				redirect('rx/lote/','refresh');
				}else{
					$this->session->set_flashdata('msg', "Lote exclu&iacute;do com sucesso!");
					redirect('rx/lote/','refresh');
					}
			}else{
				$this->session->set_flashdata('msg', "Lote n&atilde;o pode ser exclu&iacute;do, j&aacute; existem rx(s) cadastrados!");
				redirect('rx/lote/','refresh');
				}
		}
	
}