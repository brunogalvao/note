<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mec extends CI_Controller {
	public $data = array(
		"pasta" => "mec",
		"titulo" => "O MEC e a Uniodonto se unem para oferecer o melhor plano odontol&oacute;gico",
		"nome_contrato" => "",
		"plano" => ""
	
	);
	
	function __construct() {
        parent::__construct();
		}

	function index() {
		
		$this->load->view('hotsite/PJ/mec/index_view',$this->data);

    }

	function plano() {
		
		$this->load->view('hotsite/PJ/mec/plano_view',$this->data);

    }
	function tabela_atos() {
		
		$this->load->view('hotsite/PJ/mec/tabela_atos_view',$this->data);

    }
	function clinica() {
		
		$this->load->view('hotsite/PJ/mec/clinica_view',$this->data);

    }
	function perguntas() {
		
		$this->load->view('hotsite/PJ/mec/perguntas_view',$this->data);

    }
	function odontomovel() {
		
		$this->load->view('hotsite/PJ/mec/odontomovel_view',$this->data);

    }
	function encontreseudentista() {
		
		$this->load->view('hotsite/PJ/mec/encontreseudentista_view',$this->data);

    }
	function contato() {
		
		$this->load->view('hotsite/PJ/mec/contato_view',$this->data);

    }
	function envia() {
			
			$this->load->model("mec_model");
			$this->load->model("mec_dependente_model");
		    
			if($_POST){
				$dados_query["mec_nome"] = $this->input->post("nome");
				$dados_query["mec_sexo"] = $this->input->post("sexo");
				$dados_query["mec_estadoCivil"] = $this->input->post("estadoCivil");
				$dados_query["mec_cpf"] = $this->input->post("cpf");
				$dados_query["mec_dataNascimento"] = $this->input->post("dataNascimento");
				$dados_query["mec_nascidovivo"] = $this->input->post("nascidovivo");
				$dados_query["mec_cartaonacionalsaude"] = $this->input->post("cartaonacionalsaude");
				$dados_query["mec_rg"] = $this->input->post("rg");
				$dados_query["mec_orgaoemissor"] = $this->input->post("orgaoemissor");
				$dados_query["mec_dataemissao"] = $this->input->post("dataemissao");
				$dados_query["mec_tipobeneficiario"] = $this->input->post("tipobeneficiario");
				$dados_query["mec_matriculaservidor"] = $this->input->post("matriculaservidor");
				$dados_query["mec_matriculapensionista"] = $this->input->post("matriculapensionista");
				$dados_query["mec_ocupacao"] = $this->input->post("ocupacao");
				$dados_query["mec_nomemae"] = $this->input->post("nomemae");
				$dados_query["mec_email"] = $this->input->post("email");
				$dados_query["mec_endereco"] = $this->input->post("endereco");
				$dados_query["mec_numero"] = $this->input->post("numero");
				$dados_query["mec_complemento"] = $this->input->post("complemento");
				$dados_query["mec_bairro"] = $this->input->post("bairro");
				$dados_query["mec_cidade"] = $this->input->post("cidade");
				$dados_query["mec_cep"] = $this->input->post("cep");
				$dados_query["mec_uf"] = $this->input->post("uf");
				$dados_query["mec_tipoendereco"] = $this->input->post("tipoendereco");
				$dados_query["mec_telresidencial"] = $this->input->post("telresidencial");
				$dados_query["mec_telcomercial"] = $this->input->post("telcomercial");
				$dados_query["mec_ramal"] = $this->input->post("ramal");
				$dados_query["mec_telcelular"] = $this->input->post("telcelular");
				$dados_query["mec_pispasep"] = $this->input->post("pispasep");

				$id = $this->mec_model->add_record($dados_query);
				$qt = count($this->input->post("qtddependente"));
				for ($i = 0; $i < $qt; $i++) {
						$dados_dependente_query["dependente_id_titular"] = $id;
						$dados_dependente_query["dependentenome"] = $_POST["dependentenome"][$i];
						$dados_dependente_query["dependenteestadoCivil"] = $_POST["dependenteestadoCivil"][$i];
						$dados_dependente_query["dependenteparentesco"] = $_POST["dependenteparentesco"][$i];
						$dados_dependente_query["dependentecpf"] = $_POST["dependentecpf"][$i];
						$dados_dependente_query["dependenterg"] = $_POST["dependenterg"][$i];
						$dados_dependente_query["dependenteorgaorg"] = $_POST["dependenteorgaorg"][$i];
						$dados_dependente_query["dependentedatarg"] = $_POST["dependentedatarg"][$i];
						$dados_dependente_query["dependentenascidovivo"] = $_POST["dependentenascidovivo"][$i];
						$dados_dependente_query["dependentecartaonacionalsaude"] = $_POST["dependentecartaonacionalsaude"][$i];
						$dados_dependente_query["dependentenomemae"] = $_POST["dependentenomemae"][$i];
						$dados_dependente_query["dependentesexo"] = $_POST["dependentesexo"][$i];



					$this->mec_dependente_model->add_record($dados_dependente_query);	

					}
				
				}
			
	
			
			
			
		
		

    }
	
	// Funďż˝ďż˝o que valida o CPF
	private function validaCPF($cpf)
		{	// Verifiva se o nĂşmero digitado contĂŠm todos os digitos
			$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
			
			// Verifica se nenhuma das sequďż˝ncias abaixo foi digitada, caso seja, retorna falso
			if (strlen($cpf) != 11 || $cpf == '00000000000' || $cpf == '11111111111' || $cpf == '22222222222' || $cpf == '33333333333' || $cpf == '44444444444' || $cpf == '55555555555' || $cpf == '66666666666' || $cpf == '77777777777' || $cpf == '88888888888' || $cpf == '99999999999')
			{
			return false;
			}
			else
			{   // Calcula os nĂşmeros para verificar se o CPF ĂŠ verdadeiro
				for ($t = 9; $t < 11; $t++) {
					for ($d = 0, $c = 0; $c < $t; $c++) {
						$d += $cpf{$c} * (($t + 1) - $c);
					}
		
					$d = ((10 * $d) % 11) % 10;
		
					if ($cpf{$c} != $d) {
						return false;
					}
				}
		
				return true;
			}
		}
	
	
}
