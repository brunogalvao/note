<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class cabralmotor extends CI_Controller {
	public $data = array(
		"pasta" => "cabralmotor",
		"titulo" => "A Cabral Motor e a Uniodonto se unem para oferecer o melhor plano odontol&oacute;gico",
		"nome_contrato" => "a Cabral Motor",
		"plano" => "R$ 14,47 mensais por pessoa."
	
	);
	
	function __construct() {
        parent::__construct();
		if(!$this->session->userdata("acesso-hotsite") or $this->session->userdata("acesso-hotsite") != "613545dbfec11f67f9adaa49391cf2d6"){
			if(isset($_GET["a"]) != "613545dbfec11f67f9adaa49391cf2d6" ){
					redirect(site_url("404_override"));
			
			}else{
				$this->session->set_userdata("acesso-hotsite","613545dbfec11f67f9adaa49391cf2d6");
				redirect(site_url("cabralmotor"));
				}
			}	
		}

	function index() {
		
		$this->load->view('hotsite/PJ/avancado/index_view',$this->data);

    }

	function plano() {
		
		$this->load->view('hotsite/PJ/avancado/plano_view',$this->data);

    }
	function tabela_atos() {
		
		$this->load->view('hotsite/PJ/avancado/tabela_atos_view',$this->data);

    }
	function clinica() {
		
		$this->load->view('hotsite/PJ/avancado/clinica_view',$this->data);

    }
	function perguntas() {
		
		$this->load->view('hotsite/PJ/avancado/perguntas_view',$this->data);

    }
	function odontomovel() {
		
		$this->load->view('hotsite/PJ/avancado/odontomovel_view',$this->data);

    }
	function encontreseudentista() {
		
		$this->load->view('hotsite/PJ/avancado/encontreseudentista_view',$this->data);

    }
	function contato() {
		
		$this->load->view('hotsite/PJ/avancado/contato_view',$this->data);

    }
	function envia() {
		
		$cpf = str_replace("-", "",str_replace(".", "",$this->input->post('cpf')));
		$dependentes = explode("<span>",$this->input->post('lista_dependentes'));
		$msg = "";
		$erro = false;
		
		unset($dependentes[0]);
		foreach($dependentes as $dependente) {
			$dadosdependente = explode("<br>",$dependente);
			$nomedependente =  str_replace("Nome completo: ", "", $dadosdependente[0]);
			$cpfdependente =  str_replace("CPF: ", "",str_replace("-", "",str_replace(".", "",$dadosdependente[3])));
			if($this->validaCPF($cpfdependente) == false){
			
				$erro = true;
			}
		}
		if(
			$_POST["nome"] == "" or
			$_POST["dataNascimento"] == "" or
			$_POST["cpf"] == "" or
			$_POST["rg"] == "" or
			$_POST["orgaorg"] == "" or
			$_POST["datarg"] == "" or
			$_POST["endereco"] == "" or
			$_POST["numero"] == "" or
			$_POST["bairro"] == "" or
			$_POST["cidade"] == "" or
			$_POST["cep"] == "" or
			$_POST["estado"] == "" or
			$_POST["telresidencial"] == "" or
			$_POST["celular"] == "" 
		){
			$msg = 1;
		}elseif($this->validaCPF($cpf) == false){
			$msg = 2;
			
		}elseif($erro == true){
			$msg = 3;
			
		}else{
		
			if($this->input->post('tutelar')){
				$this->data["tutelar"] = $this->input->post('tutelar');
				}else{
					$this->data["tutelar"] = "N&atilde;o";
				}
			if($this->input->post('lista_dependentes') != ""){
				$this->data["dadosdependentes"] = $this->input->post('lista_dependentes');
				
			}else{
				
				$this->data["dadosdependentes"]= "";
			}	
			$this->data["nome"] = $this->input->post('nome');
			$this->data["dataNascimento"] = $this->input->post('dataNascimento');
			$this->data["matricula"] = $this->input->post('matricula');
			$this->data["cpf"] = $this->input->post('cpf');
			$this->data["rg"] = $this->input->post('rg');
			$this->data["orgaorg"] = $this->input->post('orgaorg');
			$this->data["datarg"] = $this->input->post('datarg');
			$this->data["sexo"] = $this->input->post('sexo');
			$this->data["endereco"] = $this->input->post('endereco');
			$this->data["numero"] = $this->input->post('numero');
			$this->data["complemento"] = $this->input->post('complemento');
			$this->data["bairro"] = $this->input->post('bairro');
			$this->data["cidade"] = $this->input->post('cidade');
			$this->data["cep"] = $this->input->post('cep');
			$this->data["estado"] = $this->input->post('estado');
			$this->data["telresidencial"] = $this->input->post('telresidencial');
			$this->data["celular"] = $this->input->post('celular');
			$this->data["nomemae"] = $this->input->post('nomemae');
			
		
			
			}
		
		
		// Dia da semana em nďż˝mero. Ex.: 0 => Sunday, 1 => Monday
		$dia_num = date("w");
		
		// Nome do mďż˝s em nďż˝mero. Ex.: 01 => January, 02 => February
		$mes_num = date("m");
		
		// Converte o dia da semana nďż˝mero em dia da semana texto (Portuguďż˝s)
		
		switch($dia_num){
		
		   case 0:
			   $this->data["dia_port"] = "Domingo";
			   break;
		   case 1:
			   $this->data["dia_port"] = "Segunda";
			   break;
		   case 3:
			   $this->data["dia_port"] = "Terďż˝a";
			   break;
		   case 4:
			   $this->data["dia_port"] = "Quarta";
			   break;
		   case 5:
			   $this->data["dia_port"] = "Quinta";
			   break;
		   case 6:
			   $this->data["dia_port"] = "Sexta";
			   break;
		   case 7:
			   $this->data["dia_port"] = "Sďż˝bado";
			   break;
		
		}
		
		// Converte o mďż˝s nďż˝mero em mďż˝s texto (Portuguďż˝s)
		switch ($mes_num){
		   
		   case 01:
			   $this->data["mes_port"] = "Janeiro";
			   break;
		   case 02:
			   $this->data["mes_port"] = "Fevereiro";
			   break;
		   case 03:
			   $this->data["mes_port"] = "Marďż˝o";
			   break;
		   case 04:
			   $this->data["mes_port"] = "Abril";
			   break;
		   case 05:
			   $this->data["mes_port"] = "Maio";
			   break;
		   case 06:
			   $this->data["mes_port"] = "Junho";
			   break;
		   case 07:
			   $this->data["mes_port"] = "Julho";
			   break;
		   case 08:
			   $this->data["mes_port"] = "Agosto";
			   break;
		   case 09:
			   $this->data["mes_port"] = "Setembtro";
			   break;
		   case 10:    
			   $this->data["mes_port"] = "Outubro";
			   break;
		   case 11:
			   $this->data["mes_port"] = "Novembro";
			   break;
		   case 12:
			   $this->data["mes_port"] = "Dezembro";
			   break;
		
		}
		
		// Coleta o dia do mďż˝s
		$this->data["dia_mes"] = date("d");
		
		// Coleta o ano corrente
		$this->data["ano"] = date("Y");
		
		
		
		
			
			
		if($msg == ""){	
			$mensagem = $this->load->view('hotsite/PJ/avancado/email_view',$this->data, TRUE);
			
			$this->email->from("hotsite@uniodontocuritiba.com.br");
			$this->email->to("rh.cabralmotor@cabralmotor.com.br");
			$this->email->subject("Ficha de cadastro Uniodonto");
			$this->email->message($mensagem);
			if($this->email->send()){
				print 4;
				}else{
					print 5;
					}
						
			
		
		}else{
			print $msg;		
			
		}

    }
	
	function imprimir() {
		
		$cpf = str_replace("-", "",str_replace(".", "",$this->input->post('cpf')));
		$dependentes = explode("<span>",$this->input->post('lista_dependentes'));
		$msg = "";
		$erro = false;
		
		unset($dependentes[0]);
		foreach($dependentes as $dependente) {
			$dadosdependente = explode("<br>",$dependente);
			$nomedependente =  str_replace("Nome completo: ", "", $dadosdependente[0]);
			$cpfdependente =  str_replace("CPF: ", "",str_replace("-", "",str_replace(".", "",$dadosdependente[3])));
			if($this->validaCPF($cpfdependente) == false){
			
				$erro = true;
			}
		}
		if(
			$_POST["nome"] == "" or
			$_POST["dataNascimento"] == "" or
			$_POST["cpf"] == "" or
			$_POST["rg"] == "" or
			$_POST["orgaorg"] == "" or
			$_POST["datarg"] == "" or
			$_POST["endereco"] == "" or
			$_POST["numero"] == "" or
			$_POST["bairro"] == "" or
			$_POST["cidade"] == "" or
			$_POST["cep"] == "" or
			$_POST["estado"] == "" or
			$_POST["telresidencial"] == "" or
			$_POST["celular"] == "" 
		){
			$msg = 1;
		}elseif($this->validaCPF($cpf) == false){
			$msg = 2;
			
		}elseif($erro == true){
			$msg = 3;
			
		}else{
		
			if($this->input->post('tutelar')){
				$this->data["tutelar"] = $this->input->post('tutelar');
				}else{
					$this->data["tutelar"] = "N&atilde;o";
				}
			if($this->input->post('lista_dependentes') != ""){
				$this->data["dadosdependentes"] = $this->input->post('lista_dependentes');
				
			}else{
				
				$this->data["dadosdependentes"]= "";
			}	
			$this->data["nome"] = $this->input->post('nome');
			$this->data["dataNascimento"] = $this->input->post('dataNascimento');
			$this->data["matricula"] = $this->input->post('matricula');
			$this->data["cpf"] = $this->input->post('cpf');
			$this->data["rg"] = $this->input->post('rg');
			$this->data["orgaorg"] = $this->input->post('orgaorg');
			$this->data["datarg"] = $this->input->post('datarg');
			$this->data["sexo"] = $this->input->post('sexo');
			$this->data["endereco"] = $this->input->post('endereco');
			$this->data["numero"] = $this->input->post('numero');
			$this->data["complemento"] = $this->input->post('complemento');
			$this->data["bairro"] = $this->input->post('bairro');
			$this->data["cidade"] = $this->input->post('cidade');
			$this->data["cep"] = $this->input->post('cep');
			$this->data["estado"] = $this->input->post('estado');
			$this->data["telresidencial"] = $this->input->post('telresidencial');
			$this->data["celular"] = $this->input->post('celular');
			$this->data["nomemae"] = $this->input->post('nomemae');
			
		
			
			}
		
		
		// Dia da semana em nďż˝mero. Ex.: 0 => Sunday, 1 => Monday
		$dia_num = date("w");
		
		// Nome do mďż˝s em nďż˝mero. Ex.: 01 => January, 02 => February
		$mes_num = date("m");
		
		// Converte o dia da semana nďż˝mero em dia da semana texto (Portuguďż˝s)
		
		switch($dia_num){
		
		   case 0:
			   $this->data["dia_port"] = "Domingo";
			   break;
		   case 1:
			   $this->data["dia_port"] = "Segunda";
			   break;
		   case 3:
			   $this->data["dia_port"] = "Terďż˝a";
			   break;
		   case 4:
			   $this->data["dia_port"] = "Quarta";
			   break;
		   case 5:
			   $this->data["dia_port"] = "Quinta";
			   break;
		   case 6:
			   $this->data["dia_port"] = "Sexta";
			   break;
		   case 7:
			   $this->data["dia_port"] = "Sďż˝bado";
			   break;
		
		}
		
		// Converte o mďż˝s nďż˝mero em mďż˝s texto (Portuguďż˝s)
		switch ($mes_num){
		   
		   case 01:
			   $this->data["mes_port"] = "Janeiro";
			   break;
		   case 02:
			   $this->data["mes_port"] = "Fevereiro";
			   break;
		   case 03:
			   $this->data["mes_port"] = "Marďż˝o";
			   break;
		   case 04:
			   $this->data["mes_port"] = "Abril";
			   break;
		   case 05:
			   $this->data["mes_port"] = "Maio";
			   break;
		   case 06:
			   $this->data["mes_port"] = "Junho";
			   break;
		   case 07:
			   $this->data["mes_port"] = "Julho";
			   break;
		   case 08:
			   $this->data["mes_port"] = "Agosto";
			   break;
		   case 09:
			   $this->data["mes_port"] = "Setembtro";
			   break;
		   case 10:    
			   $this->data["mes_port"] = "Outubro";
			   break;
		   case 11:
			   $this->data["mes_port"] = "Novembro";
			   break;
		   case 12:
			   $this->data["mes_port"] = "Dezembro";
			   break;
		
		}
		
		// Coleta o dia do mďż˝s
		$this->data["dia_mes"] = date("d");
		
		// Coleta o ano corrente
		$this->data["ano"] = date("Y");
		
		
		
		
			
			
		if($msg == ""){	
			$this->load->view('hotsite/PJ/avancado/imprimir_view',$this->data);
		
		}else{
			print $msg;		
			
		}

    }
	// Funďż˝ďż˝o que valida o CPF
	private function validaCPF($cpf)
		{	// Verifiva se o nĂşmero digitado contĂŠm todos os digitos
			$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
			
			// Verifica se nenhuma das sequďż˝ncias abaixo foi digitada, caso seja, retorna falso
			if (strlen($cpf) != 11 || $cpf == '00000000000' || $cpf == '11111111111' || $cpf == '22222222222' || $cpf == '33333333333' || $cpf == '44444444444' || $cpf == '55555555555' || $cpf == '66666666666' || $cpf == '77777777777' || $cpf == '88888888888' || $cpf == '99999999999')
			{
			return false;
			}
			else
			{   // Calcula os nĂşmeros para verificar se o CPF ĂŠ verdadeiro
				for ($t = 9; $t < 11; $t++) {
					for ($d = 0, $c = 0; $c < $t; $c++) {
						$d += $cpf{$c} * (($t + 1) - $c);
					}
		
					$d = ((10 * $d) % 11) % 10;
		
					if ($cpf{$c} != $d) {
						return false;
					}
				}
		
				return true;
			}
		}
	
	
}
