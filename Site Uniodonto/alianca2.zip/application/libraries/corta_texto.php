<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CI_corta_texto {
	var $texto = "";
	function limitarTexto($texto){
	 
	return substr($texto, 0, strrpos(substr($texto, 0, 120), ' ')) . '...';
	 
	}
}