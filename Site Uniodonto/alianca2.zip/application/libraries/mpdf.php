<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define('_MPDF_URI','http://192.168.1.55/uniodonto/application/libraries/mpdf/');
require_once("mpdf/mpdf.php");

class pdf extends mpdf {

	function __construct()
		{
			parent::__construct();
		}
    
}
