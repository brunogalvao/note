<?php 
header("location:../index.php/404_override");


?>