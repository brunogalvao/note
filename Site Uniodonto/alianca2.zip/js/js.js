    
		
function addEspecialidade() {
	if($("#dentistaEspecialidade").val() == 0) {
		alert("Selecione uma Especialidade");
		return;
	}
	//verificando se existe mais de uma especialidade como principal
	principal = $("#especialidadePrincipal").is(":checked") == true ? "Sim" : "N&atilde;o";
	if(principal == "Sim" && $("#countPrincipal").val() == 1){
		alert("S\u00f3 pode haver uma especialidade principal");
		return;
	}
	if(principal == "Sim" && $("#countPrincipal").val() == 0){
		$("#countPrincipal").val(1);
	}
	registradoCRO = $("#registradoCRO").is(":checked") == true ? "Sim" : "N&atilde;o";
	especialidede = $("#dentistaEspecialidade option:selected").text();
	//Adiciona uma linha na tabela com os valores informados
	$('#tb_especialidade').append('<div style="border: 1px solid #333; padding: 5px; margin: 5px;">'
		+ 'Especialidade: ' + especialidede + '<br />'
		+ 'Registro CRO: ' + registradoCRO + '<br />'
		+ 'Especialidade Pricipal: ' + principal + '<br />'
		+ 'Remover: <img class="delete" style="height: 16px; width: 16px; cursor: pointer" src="../images/bt-excluir.png" />'
		+ '</div>');
	$("#tb_especialidade").show();
	}

function addEspecializacao() {
	
	if($("#areaEspecializacao").val().length == 0) {
		alert("Informe a \u00c1rea da Especializa\u00e7\u00e3o");
		return;
	}
	if($("#instituicaoEspecializacao").val().length == 0) {
		alert("Informe a Institui\u00e7\u00e3o da Especializa\u00e7\u00e3o");
		return;
	}
	statusEspecializacao = $(".statusEspecializacao:checked").val() == "C" ? "Conclu&iacute;do" : "Em Andamento";
	//Adiciona uma linha na tabela com os valores informados
	$('#tb_especializacao').append('<div style="border: 1px solid #333; padding: 5px; margin: 5px;">'
		+ '&Aacute;rea: ' + $("#areaEspecializacao").val() + '<br />'
		+ 'Institui&ccedil;&otilde;es: ' + $("#instituicaoEspecializacao").val() + '<br />'
		+ 'Conclu&iacute;do: ' + statusEspecializacao + '<br />'
		+ 'Remover: <img class="delete" style="height: 16px; width: 16px; cursor: pointer" src="../images/bt-excluir.png" />'
		+ '</div>');
	$("#tb_especializacao").show();
	}
function addPalestra() {
		if($("#nomePalestra").val().length == 0) {
		alert("Informe o nome da Palestra/Treinamento...");
		return;
	}
	if($("#dataPalestra").val().length == 0) {
		alert("Informe a data da Palestra/Treinamento...");
		return;
	}
	//Adiciona uma linha na tabela com os valores informados
	$('#tb_palestra').append('<div style="border: 1px solid #333; padding: 5px; margin: 5px;">'
		+ 'Nome: ' + $("#nomePalestra").val() + '<br />'
		+ 'Data: ' + $("#dataPalestra").val() + '<br />'
		+ 'Remover: <img class="delete" style="height: 16px; width: 16px; cursor: pointer" src="../images/bt-excluir.png" />'
		+ '</div>');
	$("#tb_palestra").show();
	}
function addComercial() {
		if($("#enderecoComercial").val().length == 0) {
		alert("Informe o Endere\u00e7o");
		return;
	}
	if($("#bairroComercial").val().length == 0) {
		alert("Informe o Bairro");
		return;
	}
	if($("#cidadeComercial").val().length == 0) {
		alert("Informe a Cidade");
		return;
	}
	if($("#cepComercial").val().length == 0) {
		alert("Informe o CEP");
		return;
	}
	if($("#telefoneComercial").val().length == 0) {
		alert("Informe o telefone");
		return;
	}
	endereco = ($("#tipoEnderecoComercial option:selected").text() + " " + $("#enderecoComercial").val() + ", "
	+ $("#bairroComercial").val() + ", " + $("#cidadeComercial").val() + " - "
	+ $("#estadoComercial").val() + " - " + $("#cepComercial").val());
	//Monta os dias de atendimento
	diasSemanaList = $('#diasSemana input:checked');
	diasAtendimento = "";
	for(i = 0; i < diasSemanaList.length; i++){
		if(diasSemanaList[i].checked) {
			if(diasAtendimento == "") {
				diasAtendimento += diasSemanaList[i].value;
				}else{
				diasAtendimento += ", " + diasSemanaList[i].value;
			}
		}
	} 
	horarioAtendimento = "";
	if($("#horarioInicial").val().length != 0 && $("#horarioFinal").val().length != 0)
	horarioAtendimento = $("#horarioInicial").val() + " as " + $("#horarioFinal").val();
	localPrincipal = $("#comercialPrincipal:checked").val() == "S" ? "Sim" : "N&atilde;o";
	pacientesEspeciais = $("#pacientesEspeciais").is(":checked") == true ? "Sim" : "N&atilde;o";
	acessoPacientes = $("#acessoPacientes").is(":checked") ? "Sim" : "N&atilde;o";
	telefone = $("#telefoneComercial").val();
	//Adiciona uma linha na tabela com os valores informados
	$('#tb_comercial').append('<div style="border: 1px solid #333; padding: 5px; margin: 5px;">'
		+ 'Endereço: ' + endereco + '<br />'
		+ 'Tel:' + telefone + '<br />'
		+ 'Aten. Paciente Especiais: ' + pacientesEspeciais + '<br />'
		+ 'Possui Acesso aos Mesmos: ' + acessoPacientes + '<br />'
		+ 'Dias de atendimento: ' + diasAtendimento + '<br />'
		+ 'Hor&aacute;rio: ' + horarioAtendimento + '<br />'
		+ 'Local principal: ' + localPrincipal + '<br />'
		+ 'Remover: <img class="delete" style="height: 16px; width: 16px; cursor: pointer" src="../images/bt-excluir.png" />'
		+ '</div>');
	$("#tb_comercial").show();
	}
function addAperfeicoamento() {
	if($("#nomeAperfeicoamento").val().length == 0) {
		alert("Informe o nome do Aperfei\u00e7oamento");
		return;
	}
	if($("#dataAperfeicoamento").val().length == 0) {
		alert("Informe a data do Aperfei\u00e7oamento");
		return;
	}
	//Adiciona uma linha na tabela com os valores informados
	$('#tb_aperfeicoamento').append('<div style="border: 1px solid #333; padding: 5px; margin: 5px;">'
		+ 'Nome: ' + $("#nomeAperfeicoamento").val() + '<br />'
		+ 'Data: ' + $("#dataAperfeicoamento").val() + '<br />'
		+ 'Remover: <img class="delete" style="height: 16px; width: 16px; cursor: pointer" src="../images/bt-excluir.png" />'
		+ '</div>');
	$("#tb_aperfeicoamento").show();
}

 //deleta uma linha da tabela de aperfeicoamento
$('#tb_aperfeicoamento img.delete').live('click',function(){
	$(this).parent().remove();
});
//deleta uma linha da tabela de palestra
$('#tb_palestra img.delete').live('click',function(){
	$(this).parent().remove();
});
//deleta uma linha da tabela de especializacao
$('#tb_especializacao img.delete').live('click',function(){
	$(this).parent().remove();
});
//deleta uma linha da tabela de especialidade
$('#tb_especialidade img.delete').live('click',function(){
	$(this).parent().remove();
});
//deleta uma linha da tabela comercial
$('#tb_comercial img.delete').live('click',function(){
	$(this).parent().remove();
});

function enviarFormDentista()
{
	
	
	$(".tabelaPalestra").val($("#tb_palestra").html());
	$(".tabelaEspecialidade").val($("#tb_especialidade").html());
	$(".tabelaComercial").val($("#tb_comercial").html());
	$(".tabelaAperfeicoamento").val($("#tb_aperfeicoamento").html());
	$(".tabelaEspecializacao").val($("#tb_especializacao").html());
	$(".tabelaPalestra").val($("#tb_palestra").html());
	form.submit("#form");

} ;


 
 
			
			


			