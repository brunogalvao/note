var chartID = 0;
var xmlHttpLine=null;
var xmlHttpBarAtoCobertoXComplementar=null;
var xmlHttpBar=null;
var xmlHttpBarProducao=null;
var xmlHttpPie=null;
var xmlHttpStackedColumn=null;
var xmlHttpFaturamento=null;

function showCustomer(cod, option, target, host, xmlHttp) {

	if (xmlHttp==null) {
	  alert ("Seu navegador n�o suporta AJAX!");
	  return;
	}

	//var url = "http://"+host+"/";
	var url = "http://www.sistemauniodonto.com.br/curitiba/site/serverRequest";

	if(target=="cooperado"){
		url=url+"?call=CooperadosCharts";

	}else if(target=="empresa"){
		url=url+"?call=EmpresaCharts";
	}

	url=url+"&option="+option;
	url=url+"&cod="+cod;

	if( option=="line" )
		xmlHttp.onreadystatechange=getLinha;

	else if (option=="bar-atos-x-complementar")
		xmlHttp.onreadystatechange=getBarAtoCobertoXComplementar;

	else if( option=="bar" )
		xmlHttp.onreadystatechange=getBar;

	else if( option=="bar-producao-cooperado" )
		xmlHttp.onreadystatechange=getBar2;

	else if( option=="pie" )
		xmlHttp.onreadystatechange=getPie;

	xmlHttp.open("GET",url,true);

	xmlHttp.send(null);
}

function getLinha() {

	if (xmlHttpLine.readyState==4) {
		var xml = xmlHttpLine.responseText;
		buildChart( "line",xml );
	}
}

function getBarAtoCobertoXComplementar() {
	if (xmlHttpBarAtoCobertoXComplementar.readyState==4) {
		var xml = xmlHttpBarAtoCobertoXComplementar.responseText;
		buildChart( "bar-atos-x-complementar",xml );
	}
}

function getBar() {
	if (xmlHttpBar.readyState==4) {
		var xml = xmlHttpBar.responseText;
		buildChart( "bar",xml );
	}
}

function getBar2() {
	if (xmlHttpBarProducao.readyState==4) {
		var xml = xmlHttpBarProducao.responseText;
		buildChart( "bar-producao-cooperado",xml );
	}
}

function getBarFaturamento(){
	if(xmlHttpFaturamento.readyState==4){
		var xml = xmlHttpFaturamento.responseText;
		buildChartFaturamento("bar", xml);
	}
}

function getBarFaturamentoEmpresa() {
	if (xmlHttpBar.readyState==4) {
		var xml = xmlHttpBar.responseText;
		buildChart( "barFaturamentoEmpresa",xml );
	}
}

function getPie() {

	if (xmlHttpPie.readyState==4) {
		var xml = xmlHttpPie.responseText;
		buildChart( "pie",xml );
	}
}

function getStackedColumn(){
	if (xmlHttpStackedColumn.readyState==4) {
		var xml = xmlHttpStackedColumn.responseText;
		buildChart( "stackedColumn",xml );
	}
}



//parametro call na url � obrigat�rio
function call(xmlHttp,url,callbackFunction) {

	if (xmlHttp==null) {
	  alert ("Seu navegador n�o suporta AJAX!");
	  return;
	}

	xmlHttp.onreadystatechange=callbackFunction;

	xmlHttp.open("GET",url,true);

	xmlHttp.send(null);
}

function GetXmlHttpObject() {

	xmlHttp = null;

	try {
	  // Firefox, Opera 8.0+, Safari
	  xmlHttp=new XMLHttpRequest();

	} catch (e){
	  // Internet Explorer
	  try {
	    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");

	    } catch (e) {
	    	xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");

	    }
	}
	return xmlHttp;
}


function showCustomerWithFilter(cod, option, target, host, xmlHttp, monthFilter) {

	if (xmlHttp==null) {
	  alert ("Seu navegador n�o suporta AJAX!");
	  return;
	}

	var url = "http://192.168.1.157/uniodonto/site/serverRequest";

	if(target=="cooperado"){
		url=url+"?call=CooperadosCharts";
	}else if(target=="empresa"){
		url=url+"?call=EmpresaCharts";
	}else if(target=="beneficiario"){
		url=url+"?call=AssociadoCharts";
	}else if(target=="uniodonto"){
		url=url+"?call=UniodontoCharts";
	}

	url=url+"&option="+option;
	url=url+"&cod="+cod;
	url=url+"&month="+monthFilter;

	if( option=="line" )
		xmlHttp.onreadystatechange=getLinha;
	else if (option=="bar-atos-x-complementar")
		xmlHttp.onreadystatechange=getBarAtoCobertoXComplementar;
	else if( option=="bar" )
		xmlHttp.onreadystatechange=getBar;
	else if( option=="bar-producao-cooperado")
		xmlHttp.onreadystatechange=getBar2;
	else if( option=="bar-faturamento" )
		xmlHttp.onreadystatechange=getBarFaturamento;
	else if( option=="pie" )
		xmlHttp.onreadystatechange=getPie;
	else if(option == "barFaturamentoUnio")
		xmlHttp.onreadystatechange=getBar;
	else if(option=="stackedColumn")
		xmlHttp.onreadystatechange=getStackedColumn;
	else if(option == "barFaturamentoEmpresa"){
		xmlHttp.onreadystatechange=getBarFaturamentoEmpresa;
	}


	var paramAjaxSinc = true;
	//se ff<4  e ie<9 passa deixa o getRemot sincrono;
	if(jQuery.browser.msie || jQuery.browser.mozilla){
		if(jQuery.browser.msie ){
			if( (parseInt(jQuery.browser.version,10)*1) < 9){
				paramAjaxSinc = false;
			}
		}else if(jQuery.browser.mozilla){
			if( (parseInt(jQuery.browser.version,10)*1) >= 5){
				paramAjaxSinc = false;
			}
		}
	}

	xmlHttp.open("GET",url,paramAjaxSinc);
	xmlHttp.setRequestHeader("Cache-Control", "no-store, no-cache, must-revalidate");
	xmlHttp.setRequestHeader("Cache-Control", "post-check=0, pre-check=0");
	xmlHttp.setRequestHeader("Pragma", "no-cache");
	xmlHttp.send(null);
}
