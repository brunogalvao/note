		
$(function($){
	$(".data").mask("99/99/9999");
	$(".tel").mask("99-99999999");
	$(".cep").mask("99999-999");
	$(".cpf").mask("999.999.999-99");
	$(".matricula").mask("9999999");
	$(".matPensionista").mask("99999999");
	$(".nascvivo").mask("99999999999");
	$(".saude").mask("999999999999999");
	$(".pis").mask("99999999999");
	});

function buscaCep(linkbusca) {
		var $preparingFileModal = $("#busca-endereco");
 
        $preparingFileModal.dialog({ 
			dialogClass: "popup",
		 	modal: true,
			height: 60 
			});
			$.ajax({

				url : "http://republicavirtual.com.br/web_cep.php?cep="+$("#cep").val()+"&formato=json",
	
				dataType : "json",
	

				success : function(dados){

					if(dados.resultado == 1){
						$("#endereco").val(dados.tipo_logradouro+" "+dados.logradouro);
						$("#bairro").val(dados.bairro);
						$("#cidade").val(dados.cidade);
						$("#uf").val(dados.uf);
						} 
					$preparingFileModal.dialog('close');
					
				}
			});
		};
	
function tipoPagamento(){
	if($("#formaPagamento").val() == 2){
		$("#msgdebito").hide();
		$("#debito").hide();
		$("#consignacao").show();	
		}else if($("#formaPagamento").val() == 1){
			$("#dadosBanco").hide();
			$("#consignacao").hide();	
			$("#msgdebito").show();
			
			}else{
				$("#dadosBanco").hide();
				$("#msgdebito").hide();
				$("#consignacao").hide();	
				}

	}

function AlterarFormaPagamento(id){
	if(id == 2){
		$("#msgdebito").hide();
		$("#debito").show();
		$('#formaPagamento option:eq('+id+')').attr({ selected : 'selected' });
			
		}else if(id == 1){
			$('#formaPagamento option:eq('+id+')').attr({ selected : 'selected' });	
			$("#consignacao").show();
			$("#msgdebito").hide();
			$("#debito").hide();
			}
	}

function tipoBanco(){
	if($("#banco").val() == 104){
		$("#fsOperacao").show();	
		}else{
			$("#fsOperacao").hide();

			}

	}

function matriculaPencionista(){
	if($("#tipoServidor").val() == 3){
		$("#divMatriculaPencionista").show();	
		}else{
			$("#divMatriculaPencionista").hide();

			}

	}

function validarCpf(){
		var $preparingFileModal = $("#verificando-cpf");
		$preparingFileModal.dialog({ 
			dialogClass: "popup",
		 	modal: true,
			height: 60 
			});
		$.ajax({

				url : "http://192.168.1.248/uniodonto/alianca/site/verificacpf/"+$("#cpf").val()+"/1",
				//url : "http://www.uniodontocuritiba.com.br/curitiba/alianca/site/verificacpf/"+$("#cpf").val()+"/1",
	
				dataType : "text",
	
		
				success : function(resultado){
					if(resultado == 0){
						alert("CPF inválido");
						$("#cpf").val("");
						}

					if(resultado == 2){
						alert("CPF já esta cadastrado no sistema");
						$("#cpf").val("");
						}
					$preparingFileModal.dialog('close');
					
				}
			});
    }
	
function calculaMaioridade(dobString) {
	var dob = new Date($(dobString).val());
	var currentDate = new Date();
	var currentYear = currentDate.getFullYear();
	var birthdayThisYear = new Date(currentYear, dob.getMonth(), dob.getDate());
	var age = currentYear - dob.getFullYear();
	if(birthdayThisYear > currentDate) {
	age--;
	}
	if(age >= 18){
		$("#cpf").addClass("validate[required]");		
		}else{
			$("#cpf").removeClass("validate[required]");
			}

}
function baixarProposta(url){
	var $preparingFileModal = $("#gerando-proposta");
 
        $preparingFileModal.dialog({ 
			dialogClass: "popup",
		 	modal: true,
			height: 60 
			});
 
        $.fileDownload(url, {
            successCallback: function (url) {
 
                $preparingFileModal.dialog('close');
            },
            failCallback: function (responseHtml, url) {
 
                $preparingFileModal.dialog('close');
                $("#erro-gera-proposta").dialog({ modal: true });
            }
        });
        return false;
	}





	